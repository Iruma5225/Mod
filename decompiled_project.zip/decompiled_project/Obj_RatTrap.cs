using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class Obj_RatTrap : Obj_Base
{
	public Sprite ratTrappedSprite;

	public Sprite unsprungTrapSprite;

	private bool isRatTrapped;

	[SerializeField]
	private int ratMinFood;

	[SerializeField]
	private int ratMaxFood;

	[SerializeField]
	private int m_uses;

	private float distance;

	private float previousDistance;

	private bool m_hasBeenUsed;

	private List<ItemStack> m_Loot = new List<ItemStack>();

	private SpriteRenderer m_SpriteRenderer;

	public int uses => m_uses;

	public bool HasBeenUsed()
	{
		return m_hasBeenUsed;
	}

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.RatTrap;
	}

	public override void Awake()
	{
		base.Awake();
		m_SpriteRenderer = ((Component)this).GetComponentInChildren<SpriteRenderer>();
	}

	private void OnTriggerEnter2D(Collider2D coll)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		if (((Component)coll).gameObject.tag == "Pest")
		{
			distance = Vector3.Distance(((Component)this).transform.position, ((Component)coll).transform.position);
			previousDistance = distance;
		}
	}

	private void OnTriggerStay2D(Collider2D coll)
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		if (m_hasBeenUsed || IsBeingMoved() || !(((Component)coll).gameObject.tag == "Pest"))
		{
			return;
		}
		distance = Vector3.Distance(((Component)this).transform.position, ((Component)coll).transform.position);
		if (((Object)coll).name.StartsWith("Rat"))
		{
			isRatTrapped = true;
		}
		if (distance > previousDistance)
		{
			RatMovement component = ((Component)coll).GetComponent<RatMovement>();
			if ((Object)(object)component != (Object)null)
			{
				UseTrap(component);
			}
		}
		else
		{
			previousDistance = distance;
		}
	}

	private void UseTrap(RatMovement pest)
	{
		AudioSource component = ((Component)this).GetComponent<AudioSource>();
		if (!((Object)(object)pest == (Object)null))
		{
			m_hasBeenUsed = true;
			if ((Object)(object)m_SpriteRenderer != (Object)null && isRatTrapped)
			{
				m_SpriteRenderer.sprite = ratTrappedSprite;
			}
			ItemStack itemStack = new ItemStack();
			itemStack.m_type = ItemManager.ItemType.Meat;
			if (isRatTrapped)
			{
				itemStack.m_count = Random.Range(ratMinFood, ratMaxFood + 1);
			}
			m_Loot.Add(itemStack);
			if ((Object)(object)component != (Object)null)
			{
				component.Play();
			}
			if (m_uses > 0)
			{
				m_uses--;
			}
			pest.Kill();
		}
	}

	public void ResetTrap()
	{
		isRatTrapped = false;
		m_hasBeenUsed = false;
		distance = 0f;
		previousDistance = 0f;
		m_SpriteRenderer.sprite = unsprungTrapSprite;
		if (m_Loot != null)
		{
			m_Loot.Clear();
		}
	}

	public override List<string> GetTooltipExtraInfo()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append(uses.ToString());
		List<string> list = new List<string>();
		list.Add(Localization.Get("text.ui.snareUses"));
		list.Add(stringBuilder.ToString());
		return list;
	}

	public List<ItemStack> GetItemList()
	{
		return m_Loot;
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		data.SaveLoad("used", ref m_hasBeenUsed);
		data.SaveLoad("ratTrapped", ref isRatTrapped);
		data.SaveLoad("uses", ref m_uses);
		data.SaveLoadList("loot", m_Loot, delegate(int i)
		{
			int value = (int)m_Loot[i].m_type;
			int value2 = m_Loot[i].m_count;
			data.SaveLoad("type", ref value);
			data.SaveLoad("count", ref value2);
		}, delegate
		{
			int value = -1;
			int value2 = 0;
			data.SaveLoad("type", ref value);
			data.SaveLoad("count", ref value2);
			if (value2 > 0 && value != -1)
			{
				m_Loot.Add(new ItemStack((ItemManager.ItemType)value, value2));
			}
		});
		if (data.isLoading && m_hasBeenUsed && (Object)(object)m_SpriteRenderer != (Object)null)
		{
			m_SpriteRenderer.sprite = ratTrappedSprite;
		}
	}
}
