using UnityEngine;

public class InteractionInstance_AddFuel : InteractionInstance_Base
{
	private Int_AddFuel interaction;

	private Obj_Generator generator_object;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_AddFuel;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		generator_object = ((Component)this).GetComponent<Obj_Generator>();
		if ((Object)(object)generator_object == (Object)null)
		{
			return false;
		}
		if ((Object)(object)InventoryManager.Instance != (Object)null)
		{
			if (!InventoryManager.Instance.RemoveItemOfType(ItemManager.ItemType.Petrol))
			{
				return false;
			}
			InventoryManager.Instance.AddNewItem(ItemManager.ItemType.EmptyPetrolCan);
		}
		if ((Object)(object)member != (Object)null)
		{
			member.TriggerAnim("Rummage");
		}
		if ((Object)(object)interaction.fillSound != (Object)null && (Object)(object)AudioManager.Instance != (Object)null)
		{
			AudioManager.Instance.PlaySFX(interaction.fillSound);
		}
		return true;
	}

	protected override bool UpdateInteractionTimer()
	{
		if (base.UpdateInteractionTimer())
		{
			return true;
		}
		generator_object.Fuel += 50f / interaction.Duration * Time.deltaTime;
		return false;
	}

	protected override bool OnInteractionComplete()
	{
		PowerManager.Instance.UpdatePowerFlow();
		return true;
	}
}
