using GooglePlayGames;
using GooglePlayGames.BasicApi;
using GooglePlayGames.OurUtils;
using UnityEngine;

public class GPSInitialisation : MonoBehaviour
{
	private PlayGamesClientConfiguration config;

	private void Awake()
	{
		config = new PlayGamesClientConfiguration.Builder().Build();
		PlayGamesPlatform.InitializeInstance(config);
		PlayGamesPlatform.DebugLogEnabled = true;
		PlayGamesPlatform.Activate();
		if (PlayGamesPlatform.Instance == null)
		{
			return;
		}
		PlayGamesPlatform.Instance.Authenticate(delegate(bool succeed)
		{
			if (!succeed)
			{
				PlayGamesPlatform.Instance.Authenticate(delegate(bool confirm)
				{
					if (!confirm)
					{
						Logger.e("Can't log into Google Play Services");
					}
				}, silent: false);
			}
		}, silent: true);
	}
}
