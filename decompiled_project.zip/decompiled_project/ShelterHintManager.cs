using System;
using System.Collections.Generic;
using UnityEngine;

public class ShelterHintManager : BaseManager, ISaveable
{
	public enum HintEnum
	{
		Dying,
		DyingRadiation,
		Hungry,
		Thirst,
		TraumaHigh,
		Tired,
		Dirty,
		Toilet,
		StressHigh,
		TiredNoBed,
		DirtyNoShower,
		ToiletNoToilet,
		CraftingInDark,
		OutsideNoHazmat,
		FoodLow,
		WaterLow,
		DoorsOpen,
		GeneratorIntegrityNone,
		OxygenFilterIntegrityNone,
		WaterFilterIntegrityNone,
		PetDogHungry,
		PetDogDying,
		PetCatHungry,
		PetCatDying,
		CorpseDecaying,
		GeneratorIntegrityLow,
		OxygenFilterIntegrityLow,
		WaterFilterIntegrityLow,
		BedIntegrityLow,
		ShowerIntegrityLow,
		ToiletIntegrityLow,
		UsedLastPetrol,
		UsedLastPetrolIncinerator,
		StorageFull,
		UpgradeAvailable,
		CarPartsAvailable,
		SnaredAnimal,
		NotExploredRecently,
		PowerOut,
		Max
	}

	public class HintStatus
	{
		public bool triggered;

		public float lastShownTime;

		public List<FamilyMember> familyMembers = new List<FamilyMember>();
	}

	private delegate bool FamilyMemberConditionDelegate(FamilyMember member);

	private delegate bool ShelterConditionDelegate();

	private Dictionary<HintEnum, HintStatus> hint_status = new Dictionary<HintEnum, HintStatus>();

	[SerializeField]
	private float update_interval_min;

	[SerializeField]
	private float update_interval_max;

	private float next_update_time;

	[SerializeField]
	private float hint_cooldown;

	private List<FamilyMember> familyInShelter = new List<FamilyMember>();

	private static ShelterHintManager m_theInstance;

	public static ShelterHintManager Instance => m_theInstance;

	public void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
		}
		else
		{
			Debug.Log((object)"Duplicate ShelterHintManager created!");
		}
		for (HintEnum hintEnum = HintEnum.Dying; hintEnum < HintEnum.Max; hintEnum++)
		{
			hint_status.Add(hintEnum, new HintStatus());
		}
	}

	public override void StartManager()
	{
		next_update_time = Time.time + Random.Range(update_interval_min, update_interval_max);
	}

	public override void UpdateManager()
	{
		if (Time.time < next_update_time)
		{
			return;
		}
		next_update_time = Time.time + Random.Range(update_interval_min, update_interval_max);
		if (TutorialManager.Instance.TutorialActive)
		{
			return;
		}
		List<FamilyMember> allFamilyMembers = FamilyManager.Instance.GetAllFamilyMembers();
		familyInShelter.Clear();
		for (int i = 0; i < allFamilyMembers.Count; i++)
		{
			if (!allFamilyMembers[i].isDead && !allFamilyMembers[i].isCatatonic && !allFamilyMembers[i].isAway && !allFamilyMembers[i].isUncontrollable && allFamilyMembers[i].IsIdle() && !allFamilyMembers[i].isSpeaking && !allFamilyMembers[i].IsSleeping && !allFamilyMembers[i].isHiding)
			{
				familyInShelter.Add(allFamilyMembers[i]);
			}
		}
		UpdateFamilyHints();
		UpdateShelterHints();
		List<HintEnum> list = new List<HintEnum>();
		for (HintEnum hintEnum = HintEnum.Dying; hintEnum < HintEnum.Max; hintEnum++)
		{
			if (CanShowHint(hintEnum))
			{
				list.Add(hintEnum);
			}
		}
		if (list.Count > 0)
		{
			HintEnum hintEnum2 = RandomHintPriority(list);
			if (hintEnum2 != HintEnum.Max)
			{
				ShowHint(hintEnum2);
			}
		}
	}

	private HintEnum RandomHintPriority(List<HintEnum> hints)
	{
		hints.Sort();
		int num = 0;
		for (int i = 0; i < hints.Count; i++)
		{
			num += i;
		}
		int num2 = Random.Range(0, num);
		for (int j = 0; j < hints.Count; j++)
		{
			num2 -= num - j;
			if (num2 <= 0)
			{
				return hints[j];
			}
		}
		return hints[hints.Count - 1];
	}

	private void UpdateFamilyHints()
	{
		UpdateFamilySpecificHint(HintEnum.Dying, (FamilyMember member) => (float)member.health <= 25f && !member.illness.IsIll());
		UpdateFamilySpecificHint(HintEnum.DyingRadiation, (FamilyMember member) => (float)member.health <= 25f && member.illness.radiation.isActive && InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.AntiRadMedicine) > 0);
		UpdateFamilySpecificHint(HintEnum.Tired, (FamilyMember member) => member.stats.fatigue.Value >= member.stats.fatigue.stressIncreaseThreshold);
		UpdateFamilySpecificHint(HintEnum.Toilet, (FamilyMember member) => member.stats.toilet.Value >= member.stats.toilet.stressIncreaseThreshold);
		UpdateFamilySpecificHint(HintEnum.Dirty, (FamilyMember member) => member.stats.dirtiness.Value >= member.stats.dirtiness.stressIncreaseThreshold);
		UpdateFamilySpecificHint(HintEnum.OutsideNoHazmat, (FamilyMember member) => member.isOutside && !member.isWearingHazmatSuit);
		UpdateFamilySpecificHint(HintEnum.Thirst, (FamilyMember member) => member.DaysWithoutWater >= 2f);
		UpdateFamilySpecificHint(HintEnum.Hungry, (FamilyMember member) => member.DaysWithoutFood >= 3f);
		UpdateFamilySpecificHint(HintEnum.TraumaHigh, (FamilyMember member) => member.stats.trauma.Value >= 75f);
		UpdateFamilySpecificHint(HintEnum.StressHigh, (FamilyMember member) => member.stats.stress.Value >= member.stats.stress.stressIncreaseThreshold);
		UpdateFamilySpecificHint(HintEnum.CraftingInDark, delegate(FamilyMember member)
		{
			if (member.IsInDarkness())
			{
				Job current = member.job_queue.GetCurrent();
				if (current != null)
				{
					string jobType = current.GetJobType();
					if (string.Compare(jobType, "Job_Craft") == 0 || string.Compare(jobType, "Job_CraftRoom") == 0)
					{
						return true;
					}
					if (string.Compare(current.type, "fix") == 0)
					{
						return true;
					}
				}
			}
			return false;
		});
		UpdateFamilySpecificHint(HintEnum.DirtyNoShower, delegate(FamilyMember member)
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Shower);
			return member.stats.dirtiness.Value >= member.stats.dirtiness.stressIncreaseThreshold && objectsOfType.Count <= 0;
		});
		UpdateFamilySpecificHint(HintEnum.ToiletNoToilet, delegate(FamilyMember member)
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Toilet);
			return member.stats.toilet.Value >= member.stats.toilet.stressIncreaseThreshold && objectsOfType.Count <= 0;
		});
		UpdateFamilySpecificHint(HintEnum.TiredNoBed, delegate(FamilyMember member)
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Bed);
			return member.stats.fatigue.Value >= member.stats.fatigue.stressIncreaseThreshold && objectsOfType.Count <= 0;
		});
	}

	private void UpdateShelterHints()
	{
		UpdateShelterHint(HintEnum.OxygenFilterIntegrityLow, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.OxygenFilter);
			if (objectsOfType.Count > 0)
			{
				Obj_Integrity obj_Integrity = objectsOfType[0] as Obj_Integrity;
				return (float)obj_Integrity.Integrity <= 25f && obj_Integrity.IsNotBroken();
			}
			return false;
		});
		UpdateShelterHint(HintEnum.OxygenFilterIntegrityNone, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.OxygenFilter);
			if (objectsOfType.Count > 0)
			{
				Obj_Integrity obj_Integrity = objectsOfType[0] as Obj_Integrity;
				return obj_Integrity.IsBroken();
			}
			return false;
		});
		UpdateShelterHint(HintEnum.WaterFilterIntegrityLow, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.WaterFilter);
			if (objectsOfType.Count > 0)
			{
				Obj_Integrity obj_Integrity = objectsOfType[0] as Obj_Integrity;
				return (float)obj_Integrity.Integrity <= 25f && obj_Integrity.IsNotBroken();
			}
			return false;
		});
		UpdateShelterHint(HintEnum.WaterFilterIntegrityNone, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.WaterFilter);
			if (objectsOfType.Count > 0)
			{
				Obj_Integrity obj_Integrity = objectsOfType[0] as Obj_Integrity;
				return obj_Integrity.IsBroken();
			}
			return false;
		});
		UpdateShelterHint(HintEnum.GeneratorIntegrityLow, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Generator);
			if (objectsOfType.Count > 0)
			{
				Obj_Integrity obj_Integrity = objectsOfType[0] as Obj_Integrity;
				return (float)obj_Integrity.Integrity <= 25f && obj_Integrity.IsNotBroken();
			}
			return false;
		});
		UpdateShelterHint(HintEnum.GeneratorIntegrityNone, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Generator);
			if (objectsOfType.Count > 0)
			{
				Obj_Integrity obj_Integrity = objectsOfType[0] as Obj_Integrity;
				return obj_Integrity.IsBroken();
			}
			return false;
		});
		UpdateShelterHint(HintEnum.NotExploredRecently, () => ExplorationManager.Instance.DaysSinceLastExploration >= 3f && !ExplorationManager.Instance.isPartyExploring);
		UpdateShelterHint(HintEnum.UsedLastPetrol, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Incinerator);
			return InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.Petrol) <= 0 && objectsOfType.Count <= 0;
		});
		UpdateShelterHint(HintEnum.UsedLastPetrolIncinerator, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Incinerator);
			return InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.Petrol) <= 0 && objectsOfType.Count > 0;
		});
		UpdateShelterHint(HintEnum.FoodLow, () => FoodManager.Instance.TotalFood <= 4 && FoodManager.Instance.TotalFood > 0);
		UpdateShelterHint(HintEnum.WaterLow, () => WaterManager.Instance.StoredWater <= 4f);
		UpdateShelterHint(HintEnum.PetDogDying, delegate
		{
			CompanionAnimal pet = FamilyManager.Instance.GetPet();
			return (Object)(object)pet != (Object)null && (pet.m_type == FamilySpawner.PetType.Dog || pet.m_type == FamilySpawner.PetType.Horse) && pet.health <= 25f && pet.Poisoned && !pet.isAway;
		});
		UpdateShelterHint(HintEnum.PetDogHungry, delegate
		{
			CompanionAnimal pet = FamilyManager.Instance.GetPet();
			return (Object)(object)pet != (Object)null && (pet.m_type == FamilySpawner.PetType.Dog || pet.m_type == FamilySpawner.PetType.Horse) && pet.Starving && !pet.isAway;
		});
		UpdateShelterHint(HintEnum.PetCatDying, delegate
		{
			CompanionAnimal pet = FamilyManager.Instance.GetPet();
			return (Object)(object)pet != (Object)null && pet.m_type == FamilySpawner.PetType.Cat && pet.health <= 25f && pet.Poisoned;
		});
		UpdateShelterHint(HintEnum.PetCatHungry, delegate
		{
			CompanionAnimal pet = FamilyManager.Instance.GetPet();
			return (Object)(object)pet != (Object)null && pet.m_type == FamilySpawner.PetType.Cat && pet.Starving;
		});
		UpdateShelterHint(HintEnum.CorpseDecaying, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Corpse);
			for (int i = 0; i < objectsOfType.Count; i++)
			{
				Obj_Corpse obj_Corpse = objectsOfType[i] as Obj_Corpse;
				if (Time.time - obj_Corpse.TimeOfDeath >= GameTime.RealSecondsPerDay)
				{
					return true;
				}
			}
			return false;
		});
		UpdateShelterHint(HintEnum.SnaredAnimal, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.SnareTrap);
			for (int i = 0; i < objectsOfType.Count; i++)
			{
				Obj_SnareTrap obj_SnareTrap = objectsOfType[i] as Obj_SnareTrap;
				if (obj_SnareTrap.HasBeenUsed())
				{
					return true;
				}
			}
			return false;
		});
		UpdateShelterHint(HintEnum.StorageFull, () => InventoryManager.Instance.GetTotalStackCount() >= InventoryManager.Instance.storageCapacity);
		UpdateShelterHint(HintEnum.CarPartsAvailable, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.CamperVan);
			if (objectsOfType.Count > 0)
			{
				Obj_CamperVan obj_CamperVan = objectsOfType[0] as Obj_CamperVan;
				return obj_CamperVan.PlayerHasParts();
			}
			return false;
		});
		UpdateShelterHint(HintEnum.BedIntegrityLow, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Bed);
			if (objectsOfType.Count > 0)
			{
				Obj_Integrity obj_Integrity = objectsOfType[0] as Obj_Integrity;
				return (float)obj_Integrity.Integrity <= 25f;
			}
			return false;
		});
		UpdateShelterHint(HintEnum.ShowerIntegrityLow, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Shower);
			if (objectsOfType.Count > 0)
			{
				Obj_Integrity obj_Integrity = objectsOfType[0] as Obj_Integrity;
				return (float)obj_Integrity.Integrity <= 25f;
			}
			return false;
		});
		UpdateShelterHint(HintEnum.ToiletIntegrityLow, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Toilet);
			if (objectsOfType.Count > 0)
			{
				Obj_Integrity obj_Integrity = objectsOfType[0] as Obj_Integrity;
				return (float)obj_Integrity.Integrity <= 25f;
			}
			return false;
		});
		UpdateShelterHint(HintEnum.UpgradeAvailable, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Generator);
			List<Obj_Base> objectsOfType2 = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.OxygenFilter);
			List<Obj_Base> objectsOfType3 = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.WaterFilter);
			List<UpgradeObject> list = new List<UpgradeObject>();
			if (objectsOfType.Count > 0)
			{
				Obj_Generator obj_Generator = objectsOfType[0] as Obj_Generator;
				list.Add(((Component)obj_Generator).GetComponent<UpgradeObject>());
			}
			if (objectsOfType2.Count > 0)
			{
				Obj_OxygenFilter obj_OxygenFilter = objectsOfType2[0] as Obj_OxygenFilter;
				list.Add(((Component)obj_OxygenFilter).GetComponent<UpgradeObject>());
			}
			if (objectsOfType3.Count > 0)
			{
				Obj_WaterFilter obj_WaterFilter = objectsOfType3[0] as Obj_WaterFilter;
				list.Add(((Component)obj_WaterFilter).GetComponent<UpgradeObject>());
			}
			for (int i = 0; i < list.Count; i++)
			{
				List<UpgradeObject.PathEnum> paths = list[i].GetPaths();
				for (int j = 0; j < paths.Count; j++)
				{
					UpgradeObject.LevelInfo levelInfo = list[i].GetLevelInfo(paths[j], list[i].GetUpgradeLevel(paths[j]) + 1);
					if (levelInfo != null)
					{
						int num = 0;
						for (int k = 0; k < levelInfo.items.Count; k++)
						{
							int numItemsOfType = InventoryManager.Instance.GetNumItemsOfType(levelInfo.items[k].Item);
							if (numItemsOfType >= levelInfo.items[k].Quantity)
							{
								num++;
							}
						}
						if (num == levelInfo.items.Count)
						{
							return true;
						}
					}
				}
			}
			return false;
		});
		UpdateShelterHint(HintEnum.PowerOut, delegate
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Generator);
			Obj_Generator obj_Generator = ((objectsOfType.Count <= 0) ? null : (objectsOfType[0] as Obj_Generator));
			return ((Object)(object)obj_Generator != (Object)null && obj_Generator.Fuel <= 0f) ? true : false;
		});
	}

	private void UpdateFamilySpecificHint(HintEnum hint, FamilyMemberConditionDelegate condition)
	{
		HintStatus hintStatus = GetHintStatus(hint);
		if (hintStatus != null)
		{
			hintStatus.familyMembers = GetAllFamilyMembersWithCondition(condition);
			hintStatus.triggered = hintStatus.familyMembers.Count > 0;
		}
	}

	private void UpdateShelterHint(HintEnum hint, ShelterConditionDelegate condition)
	{
		HintStatus hintStatus = GetHintStatus(hint);
		if (hintStatus != null)
		{
			hintStatus.familyMembers = null;
			hintStatus.triggered = condition();
		}
	}

	private HintStatus GetHintStatus(HintEnum hint)
	{
		if (!hint_status.TryGetValue(hint, out var value))
		{
			return null;
		}
		return value;
	}

	private bool CanShowHint(HintEnum hint)
	{
		HintStatus hintStatus = GetHintStatus(hint);
		if (hintStatus == null)
		{
			return false;
		}
		return hintStatus.triggered && Time.time - hintStatus.lastShownTime > hint_cooldown;
	}

	private List<FamilyMember> GetAllFamilyMembersWithCondition(FamilyMemberConditionDelegate condition)
	{
		List<FamilyMember> list = new List<FamilyMember>();
		for (int i = 0; i < familyInShelter.Count; i++)
		{
			if (condition(familyInShelter[i]))
			{
				list.Add(familyInShelter[i]);
			}
		}
		return list;
	}

	private void ShowHint(HintEnum hint)
	{
		HintStatus hintStatus = GetHintStatus(hint);
		if (hintStatus == null)
		{
			return;
		}
		FamilyMember familyMember = null;
		if (hintStatus.familyMembers != null && hintStatus.familyMembers.Count > 0)
		{
			familyMember = hintStatus.familyMembers[Random.Range(0, hintStatus.familyMembers.Count)];
		}
		else if (familyInShelter != null && familyInShelter.Count > 0)
		{
			familyMember = familyInShelter[Random.Range(0, familyInShelter.Count)];
		}
		if (!((Object)(object)familyMember == (Object)null))
		{
			string key = "Hint." + Enum.GetName(typeof(HintEnum), hint);
			string text = Localization.Get(key);
			if (text.Length > 0)
			{
				familyMember.Say(text);
				hintStatus.lastShownTime = Time.time;
			}
		}
	}

	public bool IsRelocationEnabled()
	{
		return true;
	}

	public bool IsReadyForLoad()
	{
		return true;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("HintManager");
		HintStatus hintStatus = null;
		for (HintEnum hintEnum = HintEnum.Dying; hintEnum < HintEnum.Max; hintEnum++)
		{
			hintStatus = GetHintStatus(hintEnum);
			if (hintStatus != null)
			{
				data.SaveLoadAbsoluteTime("hint_" + hintEnum.ToString() + "_lastShown", ref hintStatus.lastShownTime);
			}
		}
		data.GroupEnd();
		return true;
	}
}
