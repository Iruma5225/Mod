using UnityEngine;

public class InteractionInstance_TakeWater : InteractionInstance_Base
{
	private Int_TakeWater interaction;

	private Obj_WaterTank tank;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_TakeWater;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		tank = ((Component)this).GetComponent<Obj_WaterTank>();
		if ((Object)(object)tank == (Object)null)
		{
			return false;
		}
		if ((Object)(object)WaterManager.Instance == (Object)null)
		{
			return false;
		}
		if (WaterManager.Instance.StoredWater < (float)interaction.WaterUsed)
		{
			return false;
		}
		member.TriggerAnim("Rummage");
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled)
		{
			WaterManager.Instance.UseWater(interaction.WaterUsed);
			FamilyAI component = ((Component)member).GetComponent<FamilyAI>();
			if ((Object)(object)component != (Object)null)
			{
				component.CarriedWater_SetWaterTaken(interaction.WaterUsed, WaterManager.Instance.Contamination);
				component.CarriedWater_SetThirstReduction((float)interaction.WaterUsed * interaction.ThirstReduction);
			}
		}
		return true;
	}
}
