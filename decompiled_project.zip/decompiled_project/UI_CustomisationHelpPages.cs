using UnityEngine;

public class UI_CustomisationHelpPages : MonoBehaviour
{
	public GameObject statsPage;

	public GameObject traitsPage1;

	public GameObject traitsPage2;

	public GameObject nextButton;

	public GameObject prevButton;

	private int currentPage;

	public AudioClip openSound;

	private void Start()
	{
		currentPage = 0;
		SwitchOnPage(currentPage);
	}

	public void NextPage()
	{
		SwitchOnPage(++currentPage);
	}

	public void PreviousPage()
	{
		SwitchOnPage(--currentPage);
	}

	private void SwitchOnPage(int pageNumber)
	{
		if ((Object)(object)openSound != (Object)null)
		{
			UISound.instance.Play(openSound);
		}
		if (currentPage < 0 || currentPage > 2)
		{
			return;
		}
		if (Object.op_Implicit((Object)(object)statsPage))
		{
			statsPage.SetActive(currentPage == 0);
		}
		if (Object.op_Implicit((Object)(object)traitsPage1))
		{
			traitsPage1.SetActive(currentPage == 1);
		}
		if (Object.op_Implicit((Object)(object)traitsPage2))
		{
			traitsPage2.SetActive(currentPage == 2);
		}
		if (Object.op_Implicit((Object)(object)nextButton))
		{
			if (currentPage < 2)
			{
				nextButton.SetActive(true);
			}
			else
			{
				nextButton.SetActive(false);
			}
		}
		if (Object.op_Implicit((Object)(object)prevButton))
		{
			if (currentPage > 0)
			{
				prevButton.SetActive(true);
			}
			else
			{
				prevButton.SetActive(false);
			}
		}
	}
}
