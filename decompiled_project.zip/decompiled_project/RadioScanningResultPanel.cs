using UnityEngine;

public class RadioScanningResultPanel : BasePanel
{
	public AudioClip openSound;

	public AudioClip closeSound;

	public UILabel textLabel;

	[SerializeField]
	private GameObject continueButton;

	[SerializeField]
	private TutorialPopupPanel m_tutorialPanel;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override void OnCancel()
	{
		base.OnCancel();
		Close();
	}

	public void OnCancelButton()
	{
		Close();
	}

	public override void OnClose()
	{
		base.OnClose();
		AudioManager.Instance.PlayUI(closeSound);
	}

	public void SetResultText(string text)
	{
		if ((Object)(object)textLabel != (Object)null)
		{
			textLabel.text = text;
		}
	}
}
