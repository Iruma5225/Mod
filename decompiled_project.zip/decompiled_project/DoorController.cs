using Pathfinding;
using UnityEngine;

public class DoorController : MonoBehaviour
{
	private bool open;

	public int opentag = 1;

	public int closedtag = 1;

	public bool updateGraphsWithGUO = true;

	public float yOffset = 5f;

	private Bounds bounds;

	public void Start()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		bounds = ((Component)this).GetComponent<Collider>().bounds;
		SetState(open);
	}

	private void OnGUI()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		if (GUI.Button(new Rect(5f, yOffset, 100f, 22f), "Toggle Door"))
		{
			SetState(!open);
		}
	}

	public void SetState(bool open)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		this.open = open;
		if (updateGraphsWithGUO)
		{
			GraphUpdateObject graphUpdateObject = new GraphUpdateObject(bounds);
			int num = ((!open) ? closedtag : opentag);
			if (num > 31)
			{
				Debug.LogError((object)"tag > 31");
				return;
			}
			graphUpdateObject.modifyTag = true;
			graphUpdateObject.setTag = num;
			graphUpdateObject.updatePhysics = false;
			AstarPath.active.UpdateGraphs(graphUpdateObject);
		}
		if (open)
		{
			((Component)this).GetComponent<Animation>().Play("Open");
		}
		else
		{
			((Component)this).GetComponent<Animation>().Play("Close");
		}
	}
}
