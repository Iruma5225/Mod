using UnityEngine;

public class InteractionInstance_WaterPlant : InteractionInstance_Base
{
	private Int_WaterPlant interaction;

	private Obj_Planter planter_object;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_WaterPlant;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		planter_object = ((Component)this).GetComponent<Obj_Planter>();
		if ((Object)(object)planter_object == (Object)null)
		{
			return false;
		}
		if ((Object)(object)WaterManager.Instance != (Object)null && !WaterManager.Instance.UseWater(1f))
		{
			return false;
		}
		if ((Object)(object)member != (Object)null)
		{
			member.TriggerAnim("Rummage");
		}
		return true;
	}

	protected override bool UpdateInteractionTimer()
	{
		if (base.UpdateInteractionTimer())
		{
			return true;
		}
		return false;
	}

	protected override bool OnInteractionComplete()
	{
		if ((Object)(object)planter_object != (Object)null)
		{
			planter_object.Water();
		}
		return true;
	}
}
