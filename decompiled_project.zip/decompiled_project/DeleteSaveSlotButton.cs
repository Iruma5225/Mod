using UnityEngine;

public class DeleteSaveSlotButton : MonoBehaviour
{
	[SerializeField]
	private SlotSelectionPanel m_slotSelectionPanel;

	[SerializeField]
	public int slotNum;

	private void Start()
	{
	}

	private void Update()
	{
	}

	public void DeleteSlot()
	{
		if ((Object)(object)m_slotSelectionPanel != (Object)null)
		{
			m_slotSelectionPanel.m_selectedSlot = slotNum;
			m_slotSelectionPanel.PromptDeleteCurrentSlot();
		}
	}
}
