using Pathfinding;

public delegate void NodeDelegate(GraphNode node);
