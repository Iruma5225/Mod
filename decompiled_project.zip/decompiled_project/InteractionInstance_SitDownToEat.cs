using UnityEngine;

public class InteractionInstance_SitDownToEat : InteractionInstance_Base
{
	private Int_SitDownToEat interaction;

	private Obj_Chair chair_object;

	protected override bool CanCancelImmediately()
	{
		return false;
	}

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_SitDownToEat;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		chair_object = ((Component)this).GetComponent<Obj_Chair>();
		if ((Object)(object)chair_object == (Object)null)
		{
			return false;
		}
		FamilyAI component = ((Component)member).GetComponent<FamilyAI>();
		if ((Object)(object)component != (Object)null && !component.IsCarryingFood())
		{
			return false;
		}
		member.TriggerAnim("Eat");
		chair_object.SetInUse(being_used: true);
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		chair_object.SetInUse(being_used: false);
		if (!base.cancelled)
		{
			FamilyAI component = ((Component)member).GetComponent<FamilyAI>();
			if ((Object)(object)component != (Object)null)
			{
				component.CarriedFood_AddMultiplier(interaction.HungerReductionModifier);
				component.CarriedFood_Consume();
			}
			if ((Object)(object)chair_object != (Object)null)
			{
				chair_object.Degrade(interaction.IntegrityPerSit);
			}
		}
		return true;
	}
}
