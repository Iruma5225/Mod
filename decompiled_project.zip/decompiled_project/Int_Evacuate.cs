using UnityEngine;

public class Int_Evacuate : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "evacuate";
	}

	public override bool IsPlayerSelectable()
	{
		if ((Object)(object)BreachMan.instance != (Object)null && BreachMan.instance.inProgress)
		{
			Obj_HidingSpot component = ((Component)this).GetComponent<Obj_HidingSpot>();
			if ((Object)(object)component != (Object)null && component.numHidden > 0)
			{
				return true;
			}
		}
		return false;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		Obj_HidingSpot component = ((Component)this).GetComponent<Obj_HidingSpot>();
		if ((Object)(object)component != (Object)null && component.numHidden > 0)
		{
			component.ExpelHidden();
			return true;
		}
		return false;
	}
}
