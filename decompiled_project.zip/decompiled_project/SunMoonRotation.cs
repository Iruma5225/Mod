using UnityEngine;

public class SunMoonRotation : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		Quaternion identity = Quaternion.identity;
		((Quaternion)(ref identity)).eulerAngles = new Vector3(0f, 0f, GameTime.DayProgress * -360f);
		((Component)this).transform.rotation = identity;
	}
}
