using System.Collections.Generic;
using UnityEngine;

public class AchievementHandler_Base
{
	protected Dictionary<AchievementManager.Achievement, bool> m_achievements = new Dictionary<AchievementManager.Achievement, bool>();

	protected Dictionary<AchievementManager.Stat, int> m_stats = new Dictionary<AchievementManager.Stat, int>();

	public virtual void Initialise()
	{
	}

	public virtual bool SetAchievement(AchievementManager.Achievement achievement)
	{
		if (GetAchievement(achievement))
		{
			return true;
		}
		if (!m_achievements.TryGetValue(achievement, out var _))
		{
			m_achievements.Add(achievement, value: false);
		}
		m_achievements[achievement] = true;
		return true;
	}

	public virtual bool SetStat(AchievementManager.Stat stat, int progress)
	{
		if (!m_stats.TryGetValue(stat, out var _))
		{
			m_stats.Add(stat, 0);
		}
		m_stats[stat] = Mathf.Max(progress, 0);
		return true;
	}

	public virtual bool IncreaseStat(AchievementManager.Stat stat, int increase)
	{
		int value = 0;
		if (!m_stats.TryGetValue(stat, out value))
		{
			m_stats.Add(stat, 0);
		}
		m_stats[stat] += Mathf.Max(0, increase);
		return true;
	}

	public virtual void SubmitStats()
	{
	}

	public bool GetAchievement(AchievementManager.Achievement achievement)
	{
		bool value = false;
		m_achievements.TryGetValue(achievement, out value);
		return value;
	}

	public int GetStatProgress(AchievementManager.Stat stat)
	{
		int value = 0;
		m_stats.TryGetValue(stat, out value);
		return value;
	}
}
