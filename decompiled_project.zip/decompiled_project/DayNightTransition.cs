using System.Collections.Generic;
using UnityEngine;

public class DayNightTransition : MonoBehaviour
{
	private const float start_time = 11f / 48f;

	private const float end_time = 13f / 48f;

	private const float nightStart_time = 0.75f;

	private const float nightEnd_time = 37f / 48f;

	public Color TransitionColor1;

	[HideInInspector]
	public Color lerpedColor;

	public bool checkForChild = true;

	public bool checkRecursive;

	public bool alphaTransition;

	public bool particleTransition;

	private Color particleDayColor;

	private float TransitionTime;

	private bool m_Transition;

	private List<SpriteRenderer> childSprites;

	private ParticleSystem dustPartSystem;

	private CharacterMesh m_mesh;

	private Obj_Base obj;

	public bool Transition => m_Transition;

	private List<SpriteRenderer> GetAllChildSprites(Transform obj)
	{
		List<SpriteRenderer> list = new List<SpriteRenderer>();
		SpriteRenderer component = ((Component)obj).GetComponent<SpriteRenderer>();
		if ((Object)(object)component != (Object)null)
		{
			list.Add(component);
		}
		for (int i = 0; i < obj.childCount; i++)
		{
			list.AddRange(GetAllChildSprites(obj.GetChild(i)));
		}
		return list;
	}

	private void Awake()
	{
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		if (checkForChild)
		{
			if (checkRecursive)
			{
				childSprites = GetAllChildSprites(((Component)this).transform);
			}
			else
			{
				childSprites = new List<SpriteRenderer>(((Component)this).GetComponentsInChildren<SpriteRenderer>());
			}
		}
		else
		{
			childSprites = new List<SpriteRenderer> { ((Component)this).GetComponent<SpriteRenderer>() };
		}
		if (particleTransition)
		{
			dustPartSystem = ((Component)this).GetComponent<ParticleSystem>();
			MainModule main = dustPartSystem.main;
			MinMaxGradient startColor = ((MainModule)(ref main)).startColor;
			particleDayColor = ((MinMaxGradient)(ref startColor)).color;
		}
		m_mesh = ((Component)this).GetComponent<CharacterMesh>();
		obj = ((Component)this).GetComponent<Obj_Base>();
	}

	private void Update()
	{
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		if (GameTime.DayProgress >= 0.75f && GameTime.DayProgress <= 37f / 48f)
		{
			TransitionTime = Mathf.Clamp((GameTime.DayProgress - 0.75f) / 0.020833313f, 0f, 1f);
		}
		else if (GameTime.DayProgress >= 11f / 48f && GameTime.DayProgress <= 13f / 48f)
		{
			TransitionTime = 1f - Mathf.Clamp((GameTime.DayProgress - 11f / 48f) / 0.04166667f, 0f, 1f);
		}
		else if (GameTime.DayProgress > 37f / 48f || GameTime.DayProgress < 11f / 48f)
		{
			TransitionTime = 1f;
		}
		else
		{
			TransitionTime = 0f;
		}
		if (particleTransition)
		{
			lerpedColor = Color.Lerp(particleDayColor, TransitionColor1, TransitionTime);
		}
		else
		{
			lerpedColor = Color.Lerp(Color.white, TransitionColor1, TransitionTime);
		}
		if (alphaTransition)
		{
			lerpedColor.a = Mathf.Lerp(0f, TransitionColor1.a, TransitionTime);
		}
		bool flag = true;
		if ((Object)(object)obj != (Object)null && (Object)(object)InteractionManager.Instance != (Object)null && InteractionManager.Instance.IsBeingMoved(obj))
		{
			flag = false;
		}
		if (!flag)
		{
			return;
		}
		if (particleTransition)
		{
			((Renderer)((Component)dustPartSystem).GetComponent<ParticleSystemRenderer>()).material.SetColor("_TintColor", lerpedColor);
		}
		else
		{
			for (int i = 0; i < childSprites.Count; i++)
			{
				if ((Object)(object)childSprites[i] != (Object)null)
				{
					if (!alphaTransition && !particleTransition)
					{
						lerpedColor.a = childSprites[i].color.a;
					}
					childSprites[i].color = lerpedColor;
				}
			}
		}
		if ((Object)(object)m_mesh != (Object)null)
		{
			m_mesh.SetTintColor(lerpedColor);
		}
	}
}
