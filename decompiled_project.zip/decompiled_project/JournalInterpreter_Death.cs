using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class JournalInterpreter_Death : JournalInterpreter_Base
{
	public override JournalManager.JournalEntryType GetEntryType()
	{
		return JournalManager.JournalEntryType.Death;
	}

	public override string CreateJournalEntry(JournalEvents events, JournalStatus status)
	{
		StringBuilder stringBuilder = new StringBuilder();
		JournalEvents.EventRecord eventRecord = null;
		JournalEvents.EventRecord eventRecord2 = null;
		List<JournalEvents.EventRecord> list = new List<JournalEvents.EventRecord>();
		List<JournalEvents.EventRecord> list2 = new List<JournalEvents.EventRecord>();
		List<JournalEvents.EventRecord> eventsOfType = events.GetEventsOfType(JournalEvents.Event.Death);
		List<JournalEvents.EventRecord> allEvents = events.GetAllEvents();
		for (int num = allEvents.Count - 1; num >= 0; num--)
		{
			if (allEvents[num].type == JournalEvents.Event.BodyBuried || allEvents[num].type == JournalEvents.Event.BodyIncinerated || allEvents[num].type == JournalEvents.Event.BodyHarvested)
			{
				eventRecord2 = allEvents[num];
				break;
			}
		}
		if (eventRecord2 != null)
		{
			for (int i = 0; i < eventsOfType.Count; i++)
			{
				if (eventRecord2.extra1.m_text == eventsOfType[i].extra1.m_text)
				{
					eventRecord = eventsOfType[i];
				}
			}
		}
		list = events.GetEventsOfType(JournalEvents.Event.Catatonic, eventRecord, eventRecord2);
		list2 = events.GetEventsOfType(JournalEvents.Event.LostStrength, eventRecord, eventRecord2);
		StringBuilder stringBuilder2 = new StringBuilder();
		if (eventRecord2 != null && eventRecord != null)
		{
			stringBuilder2.Append(Localization.Get("Journal.Event.Death" + Random.Range(1, 6)));
			stringBuilder2 = stringBuilder2.Replace("$1$", eventRecord.extra1.m_text);
			stringBuilder.Append((object?)stringBuilder2);
			stringBuilder.Append(" ");
			stringBuilder2.Length = 0;
			if (eventRecord2.type == JournalEvents.Event.BodyBuried)
			{
				int num2 = Random.Range(1, 4);
				stringBuilder2.Append(Localization.Get("Journal.Event.Buried" + num2));
				if (num2 == 1)
				{
					stringBuilder2 = ((!(eventRecord.extra2.m_text == "male")) ? stringBuilder2.Replace("$1$", Localization.Get("Journal.Gender.Her")) : stringBuilder2.Replace("$1$", Localization.Get("Journal.Gender.Him")));
				}
				else if (eventRecord.extra2.m_text == "male")
				{
					stringBuilder2 = stringBuilder2.Replace("$1$", Localization.Get("Journal.Gender.Him"));
					stringBuilder2 = stringBuilder2.Replace("$2$", Localization.Get("Journal.Gender.He"));
				}
				else
				{
					stringBuilder2 = stringBuilder2.Replace("$1$", Localization.Get("Journal.Gender.Her"));
					stringBuilder2 = stringBuilder2.Replace("$2$", Localization.Get("Journal.Gender.She"));
				}
				stringBuilder.Append((object?)stringBuilder2);
			}
			else if (eventRecord2.type == JournalEvents.Event.BodyIncinerated)
			{
				int num3 = Random.Range(1, 6);
				stringBuilder2.Append(Localization.Get("Journal.Event.Incinerated" + num3));
				if (num3 != 5)
				{
					stringBuilder2 = ((!(eventRecord.extra2.m_text == "male")) ? stringBuilder2.Replace("$1$", Localization.Get("Journal.Gender.Her")) : stringBuilder2.Replace("$1$", Localization.Get("Journal.Gender.Him")));
				}
				else if (eventRecord.extra2.m_text == "male")
				{
					stringBuilder2 = stringBuilder2.Replace("$1$", Localization.Get("Journal.Gender.Him"));
					stringBuilder2 = stringBuilder2.Replace("$2$", Localization.Get("Journal.Gender.He"));
				}
				else
				{
					stringBuilder2 = stringBuilder2.Replace("$1$", Localization.Get("Journal.Gender.Her"));
					stringBuilder2 = stringBuilder2.Replace("$2$", Localization.Get("Journal.Gender.She"));
				}
				stringBuilder.Append((object?)stringBuilder2);
			}
			else
			{
				int num4 = Random.Range(1, 5);
				stringBuilder2.Append(Localization.Get("Journal.Event.Harvested"));
				if (num4 != 4)
				{
					stringBuilder2 = ((!(eventRecord.extra2.m_text == "male")) ? stringBuilder2.Replace("$1$", Localization.Get("Journal.Gender.Her")) : stringBuilder2.Replace("$1$", Localization.Get("Journal.Gender.Him")));
				}
				else if (eventRecord.extra2.m_text == "male")
				{
					stringBuilder2 = stringBuilder2.Replace("$1$", Localization.Get("Journal.Gender.Him"));
					stringBuilder2 = stringBuilder2.Replace("$2$", Localization.Get("Journal.Gender.He"));
				}
				else
				{
					stringBuilder2 = stringBuilder2.Replace("$1$", Localization.Get("Journal.Gender.Her"));
					stringBuilder2 = stringBuilder2.Replace("$2$", Localization.Get("Journal.Gender.She"));
				}
				stringBuilder.Append((object?)stringBuilder2);
			}
			stringBuilder.AppendLine();
			stringBuilder.AppendLine();
			stringBuilder2.Length = 0;
		}
		if (list.Count > 0)
		{
			stringBuilder2.Append(Localization.Get("Journal.Event.Catatonic" + Random.Range(1, 6)));
			stringBuilder2 = stringBuilder2.Replace("$1$", list[Random.Range(0, list.Count)].extra1.m_text);
			stringBuilder.Append((object?)stringBuilder2);
			stringBuilder.Append(" ");
			stringBuilder2.Length = 0;
		}
		if (list2.Count > 0)
		{
			stringBuilder2.Append(Localization.Get("Journal.Event.LostStrength" + Random.Range(1, 6)));
			stringBuilder2 = stringBuilder2.Replace("$1$", list2[Random.Range(0, list2.Count)].extra1.m_text);
			stringBuilder.Append((object?)stringBuilder2);
			stringBuilder.Append(" ");
			stringBuilder2.Length = 0;
		}
		return stringBuilder.ToString();
	}
}
