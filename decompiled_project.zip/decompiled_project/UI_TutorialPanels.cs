using UnityEngine;

public class UI_TutorialPanels : BaseManagerNoUpdate
{
	[Header("Game Panels")]
	public BaseTutorialPanel m_automationPanel;

	public CustomizationHelpPanel m_deathPanel;

	public CustomizationHelpPanel m_foodPoisonPanel;

	public CustomizationHelpPanel m_radiationPoisonPanel;

	public CustomizationHelpPanel m_malnourishedPanel;

	public CustomizationHelpPanel m_dehydrationPanel;

	public CustomizationHelpPanel m_infectionPanel;

	public CustomizationHelpPanel m_visitorPanel;

	public CustomizationHelpPanel m_healthPanel;

	public CustomizationHelpPanel m_tiredPanel;

	public CustomizationHelpPanel m_hungryPanel;

	public CustomizationHelpPanel m_thirstyPanel;

	public CustomizationHelpPanel m_toiletPanel;

	public CustomizationHelpPanel m_showerPanel;

	public CustomizationHelpPanel m_stressPanel;

	public CustomizationHelpPanel m_traumaPanel;

	public CustomizationHelpPanel m_catatoniaPanel;

	public CustomizationHelpPanel m_jobsPanel;

	public CustomizationHelpPanel m_hazmatPanel;

	public CustomizationHelpPanel m_gasmaskPanel;

	public CustomizationHelpPanel m_oxygenFilterPanel;

	public CustomizationHelpPanel m_waterFilterPanel;

	public CustomizationHelpPanel m_combatPanel;

	public CustomizationHelpPanel m_radioPanel;

	public CustomizationHelpPanel m_breachPanel;

	public BaseTutorialPanel m_fastForwardPanel;

	public BaseTutorialPanel m_craftReminderPanel;

	public CustomizationHelpPanel m_expeditionReminderPanel;

	public BaseTutorialPanel m_rearrangePanel;

	[Header("UI Panels")]
	public CustomizationHelpPanel m_partyPanel;

	public CustomizationHelpPanel m_waypointsPanel;

	public CustomizationHelpPanel m_loadoutPanel;

	public CustomizationHelpPanel m_searchPanel;

	public CustomizationHelpPanel m_recruitPanel;

	public CustomizationHelpPanel m_tradePanel;

	public CustomizationHelpPanel m_workbenchPanel;

	public CustomizationHelpPanel m_ammoPressPanel;

	public CustomizationHelpPanel m_incineratorPanel;

	public CustomizationHelpPanel m_itemsShelterPanel;

	public CustomizationHelpPanel m_itemsWastelandPanel;

	public CustomizationHelpPanel m_mapPanel;

	public CustomizationHelpPanel m_storagePanel;

	public CustomizationHelpPanel m_upgradePanel;

	public CustomizationHelpPanel m_vehiclePanel;

	private static UI_TutorialPanels m_instance;

	public static UI_TutorialPanels instance => m_instance;

	private void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else
		{
			Debug.Log((object)"Duplicate UI_TutorialPanels created!");
		}
	}

	public override void StartManager()
	{
	}

	public BasePanel GetTutorialPanel(TutorialManager.PopupType type)
	{
		BasePanel result = null;
		switch (type)
		{
		case TutorialManager.PopupType.Intercom:
			result = m_visitorPanel;
			break;
		case TutorialManager.PopupType.Automation:
			result = m_automationPanel;
			break;
		case TutorialManager.PopupType.Death:
			result = m_deathPanel;
			break;
		case TutorialManager.PopupType.FoodPoisoning:
			result = m_foodPoisonPanel;
			break;
		case TutorialManager.PopupType.RadiationPoisoning:
			result = m_radiationPoisonPanel;
			break;
		case TutorialManager.PopupType.Starvation:
			result = m_malnourishedPanel;
			break;
		case TutorialManager.PopupType.Dehydration:
			result = m_dehydrationPanel;
			break;
		case TutorialManager.PopupType.Infection:
			result = m_infectionPanel;
			break;
		case TutorialManager.PopupType.LostHealth:
			result = m_healthPanel;
			break;
		case TutorialManager.PopupType.Tired:
			result = m_tiredPanel;
			break;
		case TutorialManager.PopupType.Hunger:
			result = m_hungryPanel;
			break;
		case TutorialManager.PopupType.Thirsty:
			result = m_thirstyPanel;
			break;
		case TutorialManager.PopupType.Toilet:
			result = m_toiletPanel;
			break;
		case TutorialManager.PopupType.Shower:
			result = m_showerPanel;
			break;
		case TutorialManager.PopupType.Stress:
			result = m_stressPanel;
			break;
		case TutorialManager.PopupType.Trauma:
			result = m_traumaPanel;
			break;
		case TutorialManager.PopupType.Catatonia:
			result = m_catatoniaPanel;
			break;
		case TutorialManager.PopupType.Jobs:
			result = m_jobsPanel;
			break;
		case TutorialManager.PopupType.Hazmat:
			result = m_hazmatPanel;
			break;
		case TutorialManager.PopupType.GasMask:
			result = m_gasmaskPanel;
			break;
		case TutorialManager.PopupType.OxygenFilter:
			result = m_oxygenFilterPanel;
			break;
		case TutorialManager.PopupType.WaterFilter:
			result = m_waterFilterPanel;
			break;
		case TutorialManager.PopupType.Combat:
			result = m_combatPanel;
			break;
		case TutorialManager.PopupType.Radio:
			result = m_radioPanel;
			break;
		case TutorialManager.PopupType.Breach:
			result = m_breachPanel;
			break;
		case TutorialManager.PopupType.ChooseParty:
			result = m_partyPanel;
			break;
		case TutorialManager.PopupType.PlotWaypoints:
			result = m_waypointsPanel;
			break;
		case TutorialManager.PopupType.ChooseEquipment:
			result = m_loadoutPanel;
			break;
		case TutorialManager.PopupType.SearchLocation:
			result = m_searchPanel;
			break;
		case TutorialManager.PopupType.Recruit:
			result = m_recruitPanel;
			break;
		case TutorialManager.PopupType.TradePanel:
			result = m_tradePanel;
			break;
		case TutorialManager.PopupType.FastForward:
			result = m_fastForwardPanel;
			break;
		case TutorialManager.PopupType.CraftReminder:
			result = m_craftReminderPanel;
			break;
		case TutorialManager.PopupType.ExpeditionReminder:
			result = m_expeditionReminderPanel;
			break;
		case TutorialManager.PopupType.Rearrange:
			result = m_rearrangePanel;
			break;
		case TutorialManager.PopupType.CraftingPanel:
			result = m_workbenchPanel;
			break;
		case TutorialManager.PopupType.IncineratorPanel:
			result = m_incineratorPanel;
			break;
		case TutorialManager.PopupType.ItemTransferShelter:
			result = m_itemsShelterPanel;
			break;
		case TutorialManager.PopupType.ItemTransferWasteland:
			result = m_itemsWastelandPanel;
			break;
		case TutorialManager.PopupType.MapPanel:
			result = m_mapPanel;
			break;
		case TutorialManager.PopupType.StoragePanel:
			result = m_storagePanel;
			break;
		case TutorialManager.PopupType.UpgradePanel:
			result = m_upgradePanel;
			break;
		case TutorialManager.PopupType.VehiclePanel:
			result = m_vehiclePanel;
			break;
		}
		return result;
	}

	public static void ShowTutorialPopup(TutorialManager.PopupType type)
	{
		if ((!((Object)(object)SaveManager.instance != (Object)null) || !SaveManager.instance.isLoading) && !((Object)(object)TutorialManager.Instance == (Object)null) && !TutorialManager.Instance.HasSeenPopup(type) && !TutorialManager.Instance.TutorialActive)
		{
			BasePanel basePanel = null;
			if ((Object)(object)instance != (Object)null)
			{
				basePanel = instance.GetTutorialPanel(type);
			}
			if ((Object)(object)basePanel != (Object)null && (Object)(object)UIPanelManager.instance != (Object)null && !UIPanelManager.instance.IsPanelOnStack(basePanel))
			{
				UIPanelManager.instance.PushPanel(basePanel);
			}
			if (type != TutorialManager.PopupType.Intercom)
			{
				TutorialManager.Instance.SetPopupSeen(type);
			}
		}
	}

	public static void ShowTutorialPopup(TutorialManager.PopupType type, float delay)
	{
		if ((!((Object)(object)SaveManager.instance != (Object)null) || !SaveManager.instance.isLoading) && !((Object)(object)TutorialManager.Instance == (Object)null) && delay > 0f)
		{
			TutorialManager.Instance.AddDelayedPopup(type, delay);
		}
	}
}
