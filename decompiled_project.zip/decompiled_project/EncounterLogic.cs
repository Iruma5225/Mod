using System.Collections.Generic;
using UnityEngine;

public class EncounterLogic
{
	public enum AttackResult
	{
		Hit,
		Miss,
		Block,
		Counter
	}

	public enum SubdueResult
	{
		Fail,
		Daze,
		Subdue
	}

	public enum StatCheckResult
	{
		FailedBadly,
		Failed,
		FailedSlightly,
		PoorSuccess,
		ModerateSuccess,
		GoodSuccess
	}

	private const float HitBaseChance = 0.8f;

	private const float HitBonusDaze = 0.2f;

	private const float HitBaseChance_Special = 0.6f;

	private const float BlockThreshold = 0.3f;

	private const float BlockDefendPenalty = 0.5f;

	private const int MultiShotAttackPenalty = 10;

	private const int PiercingBleedChance = 80;

	private const int SlashingBleedChance = 50;

	private const int BluntBleedChance = 20;

	private const int DazeThreshold = 10;

	private const int BaseEscapeChance = 60;

	private const int EscapeBonusPartialDaze = 5;

	private const int EscapeBonusFullDaze = 10;

	private const int BaseStatChance = 60;

	private const int statCheckGoodSuccessLevel = 30;

	private const int statCheckPoorSuccessLevel = 15;

	private const int statCheckFailedSlightyLevel = -15;

	private const int statCheckFailedBadlyLevel = -30;

	public static AttackResult AttackRoll_Melee(EncounterCharacter character, EncounterCharacter target, ItemManager.ItemType wep)
	{
		if ((Object)(object)character == (Object)null || (Object)(object)target == (Object)null || wep == ItemManager.ItemType.Undefined)
		{
			return AttackResult.Miss;
		}
		ItemDefinition_Combat combatDefinition = ItemManager.Instance.GetCombatDefinition(wep);
		if ((Object)(object)combatDefinition == (Object)null)
		{
			return AttackResult.Miss;
		}
		float num = 0.8f + (float)(character.Dexterity - target.Dexterity) / 100f;
		float num2 = 0f;
		if ((Object)(object)combatDefinition != (Object)null)
		{
			num2 += (float)combatDefinition.HitModifier / 20f;
		}
		if (target.isDazed)
		{
			num2 += 0.2f;
		}
		float num3 = Mathf.Clamp01(num + num2);
		float num4 = 1f - num3;
		float num5 = num4 * 0.3f;
		if (target.isDefending)
		{
			num5 *= 0.5f;
		}
		float value = Random.value;
		if (value > num4)
		{
			return AttackResult.Hit;
		}
		if (value > num4 - num4 * 0.3f)
		{
			return AttackResult.Block;
		}
		return AttackResult.Counter;
	}

	public static AttackResult AttackRoll_Special(EncounterCharacter character, EncounterCharacter target, ItemManager.ItemType wep)
	{
		if ((Object)(object)character == (Object)null || (Object)(object)target == (Object)null || wep == ItemManager.ItemType.Undefined)
		{
			return AttackResult.Miss;
		}
		ItemDefinition_Combat combatDefinition = ItemManager.Instance.GetCombatDefinition(wep);
		if ((Object)(object)combatDefinition == (Object)null)
		{
			return AttackResult.Miss;
		}
		float num = 0.6f + (float)(character.Dexterity - target.Dexterity) / 100f;
		float num2 = 0f;
		if ((Object)(object)combatDefinition != (Object)null)
		{
			num2 += (float)combatDefinition.HitModifier / 20f;
		}
		if (target.isDazed)
		{
			num2 += 0.2f;
		}
		float num3 = Mathf.Clamp01(num + num2);
		float num4 = 1f - num3;
		float value = Random.value;
		if (value > num4)
		{
			return AttackResult.Hit;
		}
		return AttackResult.Block;
	}

	public static AttackResult AttackRoll_Ranged(EncounterCharacter character, EncounterCharacter target, ItemManager.ItemType wep, bool multiple_shots = false)
	{
		if ((Object)(object)character == (Object)null || (Object)(object)target == (Object)null || wep == ItemManager.ItemType.Undefined)
		{
			return AttackResult.Miss;
		}
		ItemDefinition_Combat combatDefinition = ItemManager.Instance.GetCombatDefinition(wep);
		if ((Object)(object)combatDefinition == (Object)null)
		{
			return AttackResult.Miss;
		}
		float strHitMultiplier = combatDefinition.GetStrHitMultiplier(character.Strength, combatDefinition.StrRequired);
		int num = 100 - Mathf.FloorToInt((float)combatDefinition.Accuracy * strHitMultiplier);
		if (multiple_shots)
		{
			num += 10;
		}
		num = Mathf.Clamp(num, 0, 100);
		int num2 = DiceRoll.d100();
		if (num2 > num)
		{
			return AttackResult.Hit;
		}
		return AttackResult.Miss;
	}

	public static int DamageRoll(EncounterCharacter character, EncounterCharacter target, ItemManager.ItemType wep)
	{
		if ((Object)(object)character == (Object)null || (Object)(object)target == (Object)null || wep == ItemManager.ItemType.Undefined)
		{
			return 0;
		}
		ItemDefinition_Combat combatDefinition = ItemManager.Instance.GetCombatDefinition(wep);
		if ((Object)(object)combatDefinition == (Object)null)
		{
			return 0;
		}
		int num = Random.Range(combatDefinition.BaseDamageMin, combatDefinition.BaseDamageMax + 1);
		float strDmgMultiplier = combatDefinition.GetStrDmgMultiplier(character.Strength, combatDefinition.StrRequired);
		int num2 = Mathf.CeilToInt((float)num * strDmgMultiplier);
		if (target.isDefending)
		{
			num2 /= 2;
		}
		return num2;
	}

	public static bool BleedRoll(ItemDefinition_Combat.DamageTypeEnum dmgType)
	{
		if (dmgType == ItemDefinition_Combat.DamageTypeEnum.Undefined)
		{
			return false;
		}
		int num = 0;
		switch (dmgType)
		{
		case ItemDefinition_Combat.DamageTypeEnum.Piercing:
			num = 80;
			break;
		case ItemDefinition_Combat.DamageTypeEnum.Slashing:
			num = 50;
			break;
		case ItemDefinition_Combat.DamageTypeEnum.Blunt:
			num = 20;
			break;
		}
		int num2 = DiceRoll.d100();
		if (num2 < num)
		{
			return true;
		}
		return false;
	}

	public static SubdueResult SubdueRoll(EncounterCharacter character, EncounterCharacter target, ItemManager.ItemType wep)
	{
		if ((Object)(object)character == (Object)null || (Object)(object)target == (Object)null || wep == ItemManager.ItemType.Undefined)
		{
			return SubdueResult.Fail;
		}
		ItemDefinition_Combat combatDefinition = ItemManager.Instance.GetCombatDefinition(wep);
		if ((Object)(object)combatDefinition == (Object)null)
		{
			return SubdueResult.Fail;
		}
		int num = 100 - combatDefinition.SubdueChance;
		int num2 = DiceRoll.d100();
		if ((Object)(object)character.partyMember != (Object)null && (Object)(object)character.partyMember.person != (Object)null && character.partyMember.person.traits.HasStrength(Traits.Strength.Courageous))
		{
			num2 += 5;
		}
		if (num2 > num)
		{
			return SubdueResult.Subdue;
		}
		if (num2 > num - 10)
		{
			return SubdueResult.Daze;
		}
		return SubdueResult.Fail;
	}

	public static bool EscapeRoll(List<EncounterCharacter> escapees, List<EncounterCharacter> enemies)
	{
		int num = 0;
		int num2 = 0;
		for (int i = 0; i < enemies.Count; i++)
		{
			if (!enemies[i].isDead && !enemies[i].isSubdued)
			{
				num++;
				if (enemies[i].isDazed)
				{
					num2++;
				}
			}
		}
		int num3 = 0;
		int num4 = 0;
		for (int j = 0; j < escapees.Count; j++)
		{
			if (!escapees[j].isDead && !escapees[j].isSubdued)
			{
				num3 += escapees[j].Dexterity;
				num4++;
			}
		}
		int num5 = 0;
		if (num4 > 0)
		{
			num5 = Mathf.CeilToInt((float)num3 / (float)num4);
		}
		int num6 = 60 + num5;
		if (num2 >= num)
		{
			num6 += 10;
		}
		else if (num2 > 1)
		{
			num6 += 5;
		}
		int num7 = 100 - num6;
		int num8 = DiceRoll.d100();
		if (num8 >= num7)
		{
			return true;
		}
		return false;
	}

	public static StatCheckResult StatCheck(int positiveStat, int negativeStat)
	{
		int num = 60 + positiveStat;
		int num2 = 100 - num;
		int num3 = DiceRoll.d100();
		int num4 = num3 - num2;
		if (num4 <= -30)
		{
			return StatCheckResult.FailedBadly;
		}
		if (num4 < -15)
		{
			return StatCheckResult.Failed;
		}
		if (num4 < 0)
		{
			return StatCheckResult.FailedSlightly;
		}
		if (num4 <= 15)
		{
			return StatCheckResult.PoorSuccess;
		}
		if (num4 < 30)
		{
			return StatCheckResult.ModerateSuccess;
		}
		return StatCheckResult.GoodSuccess;
	}
}
