using UnityEngine;

public class UI_PanelContainer : BaseManagerNoUpdate
{
	[Header("HUD Panels")]
	[SerializeField]
	private UI_Avatar avatarPanel;

	[SerializeField]
	private UI_GameTime timePanel;

	[SerializeField]
	[Header("Game Panels")]
	private MainMenuPanel menuPanel;

	[SerializeField]
	private ObjectStatusPanel objectStatusPanel;

	[SerializeField]
	private InfoPanel infoPanel;

	[SerializeField]
	private InfoPanelNotification infoPanelNotification;

	[SerializeField]
	private GameOverPanel gameOverPanel;

	[SerializeField]
	private UpsellPanel m_upsellPanel;

	[SerializeField]
	private ControllerDisconnectedPanel m_controllerDisconnectPanel;

	[Header("Inventory Panels")]
	[SerializeField]
	private StoragePanel storagePanel;

	[SerializeField]
	private TradingPanel tradingPanel;

	[SerializeField]
	private CraftingPanel craftingPanel;

	[SerializeField]
	private LabCraftingPanel labCraftingPanel;

	[SerializeField]
	private AmmoCraftingPanel ammoCraftingPanel;

	[SerializeField]
	private UpgradePanel upgradePanel;

	[SerializeField]
	private DeconstructionPanel deconstructionPanel;

	[SerializeField]
	private IncineratorPanel incineratePanel;

	[SerializeField]
	private RecyclingPanel recyclePanel;

	[SerializeField]
	private RecyclingOutputPanel recycleOutputPanel;

	[SerializeField]
	private ItemTransferPanel m_itemTransferPanel;

	[SerializeField]
	private RelocationTransferPanel m_relocationTransferPanel;

	[SerializeField]
	private HarvestPlantPanel m_harvestPlantPanel;

	[SerializeField]
	private HarvestSnarePanel m_harvestSnarePanel;

	[Header("Expedition Panels")]
	[SerializeField]
	private ExpeditionMainPanelNew expeditionPanel;

	[SerializeField]
	[Header("WeaponLoadout Panels")]
	private WeaponLoadoutPanel weaponloadoutPanel;

	[SerializeField]
	private PartyMapPanel mapPanel;

	[SerializeField]
	private NpcDialoguePanel npcDialoguePanel;

	[SerializeField]
	[Header("Object Panels")]
	private JournalPanel journalPanel;

	[SerializeField]
	private VehiclePanel vehiclePanel;

	[SerializeField]
	private GravestonePanel gravestonePanel;

	[SerializeField]
	private GravestoneEditPanel gravestoneEditPanel;

	[SerializeField]
	private RadioScanningResultPanel radioScanResultPanel;

	[SerializeField]
	private FrontBackPanel colourComparisonPanel;

	private static UI_PanelContainer m_theInstance;

	public UI_Avatar AvatarPanel => avatarPanel;

	public UI_GameTime TimePanel => timePanel;

	public MainMenuPanel MenuPanel => menuPanel;

	public ObjectStatusPanel ObjectStatusPanel => objectStatusPanel;

	public InfoPanel InfoPanel => infoPanel;

	public InfoPanelNotification InfoPanelNotification => infoPanelNotification;

	public GameOverPanel GameOverPanel => gameOverPanel;

	public UpsellPanel upsellPanel => m_upsellPanel;

	public ControllerDisconnectedPanel controllerDisconnectPanel => m_controllerDisconnectPanel;

	public StoragePanel StoragePanel => storagePanel;

	public TradingPanel TradingPanel => tradingPanel;

	public CraftingPanel CraftingPanel => craftingPanel;

	public LabCraftingPanel LabCraftingPanel => labCraftingPanel;

	public AmmoCraftingPanel AmmoCraftingPanel => ammoCraftingPanel;

	public UpgradePanel UpgradePanel => upgradePanel;

	public DeconstructionPanel DeconstructionPanel => deconstructionPanel;

	public IncineratorPanel IncineratePanel => incineratePanel;

	public RecyclingPanel RecyclePanel => recyclePanel;

	public RecyclingOutputPanel RecycleOutputPanel => recycleOutputPanel;

	public ItemTransferPanel itemTransferPanel => m_itemTransferPanel;

	public RelocationTransferPanel relocationTransferPanel => m_relocationTransferPanel;

	public HarvestPlantPanel HarvestPlantPanel => m_harvestPlantPanel;

	public HarvestSnarePanel harvestSnarePanel => m_harvestSnarePanel;

	public ExpeditionMainPanelNew ExpeditionPanel => expeditionPanel;

	public WeaponLoadoutPanel WeaponloadoutPanel => weaponloadoutPanel;

	public PartyMapPanel MapPanel => mapPanel;

	public NpcDialoguePanel NpcDialoguePanel => npcDialoguePanel;

	public JournalPanel JournalPanel => journalPanel;

	public VehiclePanel VehiclePanel => vehiclePanel;

	public GravestonePanel GravestonePanel => gravestonePanel;

	public GravestoneEditPanel GravestoneEditPanel => gravestoneEditPanel;

	public RadioScanningResultPanel RadioScanResultPanel => radioScanResultPanel;

	public FrontBackPanel ColourComparisonPanel => colourComparisonPanel;

	public static UI_PanelContainer Instance => m_theInstance;

	private void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
		}
		else
		{
			Debug.Log((object)"Duplicate UI_PanelContainer created!");
		}
	}

	public override void StartManager()
	{
	}

	[ContextMenu("Switch to 2D Colliders")]
	private void SwitchTo2D()
	{
		UICamera uICamera = UICamera.FindCameraForLayer(((Component)this).gameObject.layer);
		if ((Object)(object)uICamera == (Object)null || uICamera.eventType == UICamera.EventType.World_3D || uICamera.eventType == UICamera.EventType.World_2D)
		{
			return;
		}
		uICamera.eventType = UICamera.EventType.UI_2D;
		for (int i = 0; i < ((Component)this).transform.childCount; i++)
		{
			if (!((Object)(object)((Component)this).transform.GetChild(i) == (Object)null))
			{
				SwitchTo2D(((Component)((Component)this).transform.GetChild(i)).gameObject);
			}
		}
	}

	private static void SwitchTo2D(GameObject go)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)go == (Object)null)
		{
			return;
		}
		BoxCollider component = go.GetComponent<BoxCollider>();
		if ((Object)(object)component != (Object)null)
		{
			Vector3 center = component.center;
			Vector3 size = component.size;
			NGUITools.DestroyImmediate((Object)(object)component);
			BoxCollider2D val = go.AddComponent<BoxCollider2D>();
			val.size = Vector2.op_Implicit(size);
			((Collider2D)val).offset = Vector2.op_Implicit(center);
			((Collider2D)val).isTrigger = true;
			NGUITools.SetDirty((Object)(object)go);
		}
		for (int i = 0; i < go.transform.childCount; i++)
		{
			if (!((Object)(object)go.transform.GetChild(i) == (Object)null))
			{
				SwitchTo2D(((Component)go.transform.GetChild(i)).gameObject);
			}
		}
	}

	[ContextMenu("Switch to 3D Colliders")]
	private void SwitchTo3D()
	{
		UICamera uICamera = UICamera.FindCameraForLayer(((Component)this).gameObject.layer);
		if ((Object)(object)uICamera == (Object)null || uICamera.eventType == UICamera.EventType.World_3D || uICamera.eventType == UICamera.EventType.World_2D)
		{
			return;
		}
		uICamera.eventType = UICamera.EventType.UI_3D;
		for (int i = 0; i < ((Component)this).transform.childCount; i++)
		{
			if (!((Object)(object)((Component)this).transform.GetChild(i) == (Object)null))
			{
				SwitchTo3D(((Component)((Component)this).transform.GetChild(i)).gameObject);
			}
		}
	}

	private static void SwitchTo3D(GameObject go)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)go == (Object)null)
		{
			return;
		}
		BoxCollider2D component = go.GetComponent<BoxCollider2D>();
		if ((Object)(object)component != (Object)null)
		{
			Vector3 center = Vector2.op_Implicit(((Collider2D)component).offset);
			Vector3 size = Vector2.op_Implicit(component.size);
			NGUITools.DestroyImmediate((Object)(object)component);
			BoxCollider val = go.AddComponent<BoxCollider>();
			if ((Object)(object)val != (Object)null)
			{
				val.size = size;
				val.center = center;
				((Collider)val).isTrigger = true;
			}
			NGUITools.SetDirty((Object)(object)go);
		}
		for (int i = 0; i < go.transform.childCount; i++)
		{
			if (!((Object)(object)go.transform.GetChild(i) == (Object)null))
			{
				SwitchTo3D(((Component)go.transform.GetChild(i)).gameObject);
			}
		}
	}
}
