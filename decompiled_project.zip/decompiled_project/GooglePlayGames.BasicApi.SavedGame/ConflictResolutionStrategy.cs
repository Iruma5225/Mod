namespace GooglePlayGames.BasicApi.SavedGame;

public enum ConflictResolutionStrategy
{
	UseLongestPlaytime,
	UseOriginal,
	UseUnmerged
}
