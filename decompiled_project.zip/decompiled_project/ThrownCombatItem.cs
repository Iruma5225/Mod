using UnityEngine;

public class ThrownCombatItem : MonoBehaviour
{
	private const float gravity = -9.8f;

	[SerializeField]
	private UISprite m_sprite;

	[SerializeField]
	private AudioSource m_audio;

	[SerializeField]
	private TweenRotation m_rotateTween;

	[SerializeField]
	private ParticleSystem m_explosionParticle;

	[SerializeField]
	private Color m_explosionFlashPlayer = default(Color);

	[SerializeField]
	private Color m_explosionFlashNPC = default(Color);

	[SerializeField]
	private ParticleSystem m_dudParticle;

	[SerializeField]
	private TweenAlpha m_dudTween;

	[SerializeField]
	private AudioClip m_dudSound;

	[SerializeField]
	private bool m_dud;

	[SerializeField]
	private float m_airTime;

	[SerializeField]
	private float m_airTimeExtra;

	private float m_landTime;

	[SerializeField]
	private float m_destroyDelay;

	private float m_destroyTime;

	private bool landed;

	private bool destroyed;

	private Vector3 velocity = Vector3.zero;

	private ItemDefinition_Combat combat_def;

	public bool isDud => m_dud;

	private void Awake()
	{
		if ((Object)(object)m_audio != (Object)null)
		{
			m_audio.ignoreListenerPause = true;
		}
	}

	public bool Initialise(Vector3 target, ItemManager.ItemType item, bool dud = false)
	{
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		combat_def = ItemManager.Instance.GetCombatDefinition(item);
		if ((Object)(object)combat_def == (Object)null)
		{
			return false;
		}
		if ((Object)(object)m_sprite != (Object)null)
		{
			m_sprite.spriteName = combat_def.WorldSprite;
		}
		m_dud = dud;
		m_landTime = PausableTime.time + m_airTime + m_airTimeExtra;
		velocity.x = (target.x - ((Component)this).transform.position.x) / m_airTime;
		velocity.y = 9.8f * (m_airTime / 2f);
		return true;
	}

	public void Update()
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		if (destroyed || (Object)(object)combat_def == (Object)null)
		{
			return;
		}
		if (!landed)
		{
			ref Vector3 reference = ref velocity;
			reference.y += -9.8f * PausableTime.deltaTime;
			Transform transform = ((Component)this).transform;
			transform.position += velocity * PausableTime.deltaTime;
		}
		if (!landed && PausableTime.time >= m_landTime)
		{
			if (!isDud)
			{
				if (combat_def.DamageType == ItemDefinition_Combat.DamageTypeEnum.Concussion)
				{
					FadeManager.Instance.FlashScreen(Color.white);
				}
				else if (combat_def.DamageType == ItemDefinition_Combat.DamageTypeEnum.Explosive)
				{
					FadeManager.Instance.FlashScreen(m_explosionFlashNPC);
					if ((Object)(object)m_explosionParticle != (Object)null)
					{
						((Component)m_explosionParticle).gameObject.SetActive(true);
						m_explosionParticle.Play(true);
					}
				}
				ItemDefinition_Combat.AnimInfo animInfo = combat_def.GetAnimInfo(ItemDefinition_Combat.WeaponAnimEnum.Throw);
				if (animInfo != null && (Object)(object)m_audio != (Object)null)
				{
					m_audio.clip = animInfo.GetImpactSound();
					m_audio.Play();
				}
				if ((Object)(object)m_sprite != (Object)null)
				{
					((Component)m_sprite).gameObject.SetActive(false);
				}
			}
			else
			{
				if ((Object)(object)m_dudParticle != (Object)null)
				{
					((Component)m_dudParticle).gameObject.SetActive(true);
					m_dudParticle.Play(true);
				}
				if ((Object)(object)m_dudTween != (Object)null)
				{
					m_dudTween.ResetToBeginning();
					m_dudTween.PlayForward();
				}
				if ((Object)(object)m_audio != (Object)null && (Object)(object)m_dudSound != (Object)null)
				{
					m_audio.clip = m_dudSound;
					m_audio.Play();
				}
			}
			if ((Object)(object)m_rotateTween != (Object)null)
			{
				((Behaviour)m_rotateTween).enabled = false;
			}
			m_destroyTime = PausableTime.time + m_destroyDelay;
			landed = true;
		}
		if (!destroyed && landed && PausableTime.time >= m_destroyTime)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
			destroyed = true;
		}
	}

	public bool HasLanded()
	{
		return landed;
	}
}
