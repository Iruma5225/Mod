using System.Collections.Generic;
using UnityEngine;

public class Int_Enable : Int_Base
{
	[SerializeField]
	private List<AudioClip> m_enable_sounds = new List<AudioClip>();

	private AudioSource m_audio;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_Enable";
	}

	public override string GetInteractionType()
	{
		return "Enable";
	}

	public override int GetInteractionPriority()
	{
		return 20;
	}

	public override bool IsPlayerSelectable()
	{
		return base.InteractionEnabled && (Object)(object)obj != (Object)null && !obj.IsEnabled() && !obj.isBurningOrBurntOut;
	}

	public override bool IsAvailable()
	{
		return obj.disablable;
	}

	public override void Awake()
	{
		base.Awake();
		m_audio = ((Component)this).GetComponent<AudioSource>();
	}

	public void PlayEnableSound()
	{
		if ((Object)(object)m_audio != (Object)null && m_enable_sounds != null && m_enable_sounds.Count > 0)
		{
			m_audio.PlayOneShot(m_enable_sounds[Random.Range(0, m_enable_sounds.Count)]);
		}
	}
}
