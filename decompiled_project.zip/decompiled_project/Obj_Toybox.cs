using System.Collections.Generic;
using UnityEngine;

public class Obj_Toybox : Obj_Base
{
	[SerializeField]
	private int m_Capacity = 100;

	public int ToyCapacity => m_Capacity;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.Toybox;
	}

	public override void Start()
	{
		base.Start();
		if ((Object)(object)EntertainmentManager.Instance != (Object)null)
		{
			EntertainmentManager.Instance.RegisterStorage(this);
		}
		int numItemsOfType = InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.Toy);
		if (numItemsOfType > 0)
		{
			EntertainmentManager.Instance.AddToys(numItemsOfType);
			InventoryManager.Instance.RemoveAllItemsOfType(ItemManager.ItemType.Toy);
		}
	}

	public override List<string> GetTooltipExtraInfo()
	{
		List<string> list = new List<string>();
		list.Add(Localization.Get("Tooltip.Entertainment.Toys"));
		list.Add(EntertainmentManager.Instance.Toys.ToString());
		return list;
	}
}
