public enum PathCompleteState
{
	NotCalculated,
	Error,
	Complete,
	Partial
}
