using System;
using System.Collections.Generic;
using UnityEngine;

public class Obj_OxygenFilter : Obj_Integrity
{
	[Serializable]
	public class SoundSet
	{
		public AudioClip loop;

		public AudioClip enabled;

		public AudioClip disabled;
	}

	[SerializeField]
	[Header("Radiation Filtering Multipliers")]
	private float m_OxygenInMult = 1f;

	[Range(0f, 10f)]
	[SerializeField]
	private float[] m_OxygenInMultPerLevel = new float[5] { 1f, 1.2f, 1.6f, 2.2f, 3f };

	private float baseDegradeInterval;

	[Range(1f, 1000f)]
	[SerializeField]
	private float[] m_DegradeIntervalPerLevel = new float[5] { 25f, 27.5f, 30f, 32.5f, 37.5f };

	[SerializeField]
	[Range(0f, 2f)]
	private float[] m_ResistancePerLevel = new float[5] { 1f, 1.1f, 1.2f, 1.3f, 1.5f };

	[SerializeField]
	[Range(0f, 1f)]
	private float mediumSandStormDegradeModifier;

	[Range(0f, 1f)]
	[SerializeField]
	private float heavySandStormDegradeModifier;

	[SerializeField]
	[Header("Sound Effects")]
	private List<SoundSet> m_soundSets = new List<SoundSet>();

	[SerializeField]
	private int upgradesPerSoundSet;

	private SoundSet m_sounds;

	private AudioSource m_audio;

	public float OxygenInMult => m_OxygenInMult;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.OxygenFilter;
	}

	public override void Awake()
	{
		base.Awake();
		m_audio = ((Component)this).GetComponent<AudioSource>();
	}

	public override void Start()
	{
		base.Start();
		baseDegradeInterval = m_DegradeInterval;
		int amount = Random.Range(25, 51);
		Degrade(amount);
		UpdateSoundSet();
		if (HasEnoughPower() && ((Object)(object)TutorialManager.Instance == (Object)null || !TutorialManager.Instance.TutorialActive))
		{
			StartFilterSound();
		}
	}

	public override void Update()
	{
		int upgradeLevel = upgrade_component.GetUpgradeLevel(UpgradeObject.PathEnum.Durability);
		baseDegradeInterval = m_DegradeIntervalPerLevel[upgradeLevel];
		int upgradeLevel2 = upgrade_component.GetUpgradeLevel(UpgradeObject.PathEnum.Resistance);
		float num = 1f;
		int upgradeLevel3 = upgrade_component.GetUpgradeLevel(UpgradeObject.PathEnum.Generation);
		m_OxygenInMult = m_OxygenInMultPerLevel[upgradeLevel3];
		if ((Object)(object)WeatherManager.Instance != (Object)null)
		{
			if (WeatherManager.Instance.currentState == WeatherManager.WeatherState.MediumSand)
			{
				num = mediumSandStormDegradeModifier;
			}
			else if (WeatherManager.Instance.currentState == WeatherManager.WeatherState.HeavySand)
			{
				num = heavySandStormDegradeModifier;
			}
		}
		num += (1f - num) * m_ResistancePerLevel[upgradeLevel2];
		m_DegradeInterval = baseDegradeInterval * num;
		base.Update();
		if (!m_audio.isPlaying && HasEnoughPower())
		{
			StartFilterSound();
		}
		else if (m_audio.isPlaying && !HasEnoughPower())
		{
			StopFilterSound();
		}
	}

	public override void OnUpgraded(UpgradeObject.PathEnum path, int level)
	{
		base.OnUpgraded(path, level);
		UpdateSoundSet();
	}

	private void UpdateSoundSet()
	{
		int num = 0;
		if ((Object)(object)upgrade_component != (Object)null)
		{
			List<UpgradeObject.PathEnum> paths = upgrade_component.GetPaths();
			for (int i = 0; i < paths.Count; i++)
			{
				num += upgrade_component.GetUpgradeLevel(paths[i]);
			}
		}
		int num2 = Mathf.FloorToInt((float)num / (float)upgradesPerSoundSet);
		num2 = Mathf.Clamp(num2, 0, m_soundSets.Count);
		m_sounds = m_soundSets[num2];
		bool isPlaying = m_audio.isPlaying;
		m_audio.clip = m_sounds.loop;
		if (isPlaying)
		{
			m_audio.Play();
		}
	}

	public override void EnableObject()
	{
		base.EnableObject();
		if (HasEnoughPower() && ((Object)(object)TutorialManager.Instance == (Object)null || !TutorialManager.Instance.TutorialActive))
		{
			StartFilterSound();
		}
	}

	public override void DisableObject()
	{
		base.DisableObject();
		if (HasEnoughPower())
		{
			StopFilterSound();
		}
	}

	private void StartFilterSound()
	{
		if ((Object)(object)m_audio != (Object)null)
		{
			if (m_sounds != null)
			{
				m_audio.clip = m_sounds.loop;
				m_audio.PlayOneShot(m_sounds.enabled);
			}
			m_audio.Play();
		}
	}

	private void StopFilterSound()
	{
		if ((Object)(object)m_audio != (Object)null)
		{
			m_audio.Stop();
			if (m_sounds != null)
			{
				m_audio.PlayOneShot(m_sounds.disabled);
			}
		}
	}

	protected override void OnBroken()
	{
		base.OnBroken();
		UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.OxygenFilter);
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		data.SaveLoad("baseDegradeInterval", ref baseDegradeInterval);
	}
}
