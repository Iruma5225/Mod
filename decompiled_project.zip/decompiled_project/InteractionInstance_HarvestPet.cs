using System.Collections.Generic;
using UnityEngine;

public class InteractionInstance_HarvestPet : InteractionInstance_Base
{
	private Int_HarvestPet interaction;

	private Obj_Pet pet_object;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_HarvestPet;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		pet_object = ((Component)this).GetComponent<Obj_Pet>();
		if ((Object)(object)pet_object == (Object)null)
		{
			return false;
		}
		if (!pet_object.isDead)
		{
			return false;
		}
		if ((Object)(object)member != (Object)null)
		{
			member.TriggerAnim("Rummage");
		}
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled)
		{
			Obj_Freezer obj_Freezer = null;
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Freezer);
			for (int i = 0; i < objectsOfType.Count; i++)
			{
				Obj_Freezer obj_Freezer2 = objectsOfType[i] as Obj_Freezer;
				if ((Object)(object)obj_Freezer2 != (Object)null && obj_Freezer2.Meat + obj_Freezer2.DesperateMeat <= obj_Freezer2.TotalMeatCapacity)
				{
					obj_Freezer = obj_Freezer2;
				}
			}
			if ((Object)(object)obj_Freezer != (Object)null)
			{
				obj_Freezer.AddMeat(interaction.Meat);
			}
			if ((Object)(object)pet_object != (Object)null)
			{
				pet_object.OnHarvest();
			}
		}
		return true;
	}
}
