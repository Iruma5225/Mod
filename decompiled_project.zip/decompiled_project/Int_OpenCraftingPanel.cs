using UnityEngine;

public class Int_OpenCraftingPanel : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "open_crafting_panel";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		return !obj.isBurningOrBurntOut && base.InteractionEnabled;
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		if ((Object)(object)UI_PanelContainer.Instance.CraftingPanel != (Object)null)
		{
			UI_PanelContainer.Instance.CraftingPanel.SetWorkbench(obj);
			UIPanelManager.Instance().PushPanel(UI_PanelContainer.Instance.CraftingPanel);
			return true;
		}
		return false;
	}
}
