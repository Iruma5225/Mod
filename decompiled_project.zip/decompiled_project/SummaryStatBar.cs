using UnityEngine;

public class SummaryStatBar : MonoBehaviour
{
	[SerializeField]
	private UILabel stat_label;

	[SerializeField]
	private UISprite stat_icon;

	[SerializeField]
	private UIProgressBar progress_bar;

	[SerializeField]
	private UILabel xp_label;

	[SerializeField]
	private UITweener level_up_tween;

	[SerializeField]
	private float XPPerSecond;

	[SerializeField]
	private AudioClip stat_level_sound;

	private AudioSource m_audio;

	private BaseStat m_stat = new BaseStat(BaseStats.StatType.Max);

	private int target_xp;

	private float xp_accumulator;

	private float m_percentage;

	private bool m_PlayingAnimation;

	[SerializeField]
	private string[] spriteNames = new string[5] { "IconStrength", "IconStatDexterity", "IconIntelligence", "IconStatCharisma", "IconPerception" };

	public bool isPlayingAnimation => m_PlayingAnimation;

	private void Awake()
	{
		m_stat.onLevelGain = OnLevelUp;
		m_audio = ((Component)this).GetComponent<AudioSource>();
		if ((Object)(object)m_audio != (Object)null)
		{
			m_audio.ignoreListenerPause = true;
		}
	}

	public void SetupBar(BaseStat stat, int xp_awarded)
	{
		m_stat.CopyStat(stat);
		target_xp = m_stat.Exp + xp_awarded;
		if ((Object)(object)stat_label != (Object)null)
		{
			UILocalize component = ((Component)stat_label).GetComponent<UILocalize>();
			if ((Object)(object)component != (Object)null)
			{
				component.key = "UI." + stat.type;
				component.Refresh();
			}
		}
		if ((Object)(object)stat_icon != (Object)null)
		{
			string text = spriteNames[Mathf.Clamp((int)stat.type, 0, spriteNames.Length)];
			if (!string.IsNullOrEmpty(text))
			{
				stat_icon.spriteName = text;
			}
		}
		UpdateBar();
		m_PlayingAnimation = false;
	}

	private void Update()
	{
		if (m_PlayingAnimation)
		{
			if (UpdateXP())
			{
				Stop();
			}
			UpdateBar();
		}
	}

	private bool UpdateXP()
	{
		if (m_stat.Exp >= target_xp)
		{
			return true;
		}
		if (m_stat.Level >= m_stat.LevelCap && m_stat.NormalizedExp >= 1f)
		{
			return true;
		}
		xp_accumulator += PausableTime.deltaTime * XPPerSecond;
		if (xp_accumulator >= 1f)
		{
			int num = Mathf.FloorToInt(xp_accumulator);
			xp_accumulator -= num;
			m_stat.IncreaseExp(num);
			if (m_stat.Exp >= target_xp)
			{
				return true;
			}
		}
		return false;
	}

	private void UpdateBar()
	{
		progress_bar.value = m_stat.NormalizedExp;
		xp_label.text = m_stat.Level.ToString();
	}

	public void Play()
	{
		m_PlayingAnimation = true;
		if ((Object)(object)m_audio != (Object)null)
		{
			m_audio.Play();
		}
	}

	public void Stop()
	{
		m_PlayingAnimation = false;
		if ((Object)(object)m_audio != (Object)null)
		{
			m_audio.Stop();
		}
	}

	private void OnLevelUp(BaseStats.StatType statType)
	{
		if ((Object)(object)level_up_tween != (Object)null)
		{
			level_up_tween.ResetToBeginning();
			level_up_tween.PlayForward();
		}
		AudioManager.Instance.PlayUI(stat_level_sound);
	}
}
