using System.Collections.Generic;
using UnityEngine;

public class InteractionInstance_SnareTrap : InteractionInstance_Base
{
	private Obj_SnareTrap obj_trap;

	protected override bool CanCancelImmediately()
	{
		return false;
	}

	protected override bool OnInteractionStarted()
	{
		obj_trap = obj_base as Obj_SnareTrap;
		if ((Object)(object)obj_trap == (Object)null)
		{
			return false;
		}
		bool flag = false;
		bool flag2 = false;
		bool flag3 = true;
		bool flag4 = true;
		List<ItemStack> itemList = obj_trap.GetItemList();
		for (int i = 0; i < itemList.Count; i++)
		{
			if (itemList[i].m_type == ItemManager.ItemType.Leather && itemList[i].m_count > 0)
			{
				flag2 = true;
			}
		}
		if (flag2)
		{
			if ((Object)(object)FoodManager.Instance != (Object)null && FoodManager.Instance.TotalMeat == FoodManager.Instance.MaxMeat)
			{
				flag3 = false;
			}
			if ((Object)(object)InventoryManager.Instance != (Object)null)
			{
				if (!InventoryManager.Instance.AddNewItems(ItemManager.ItemType.Leather, 1))
				{
					flag4 = false;
				}
				else
				{
					InventoryManager.Instance.RemoveItemsOfType(ItemManager.ItemType.Leather, 1);
				}
			}
			if (!flag3 && !flag4)
			{
				flag = true;
			}
		}
		else if ((Object)(object)FoodManager.Instance != (Object)null && FoodManager.Instance.TotalMeat == FoodManager.Instance.MaxMeat)
		{
			flag = true;
		}
		if (flag)
		{
			member.Say(Localization.Get("hint.cantharvesttrapfullinventory"));
			return false;
		}
		if ((Object)(object)member != (Object)null)
		{
			member.TriggerAnim("Rummage");
		}
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (base.cancelled)
		{
			return true;
		}
		if ((Object)(object)obj_trap == (Object)null)
		{
			return true;
		}
		List<ItemStack> itemList = obj_trap.GetItemList();
		List<ItemManager.ItemType> list = new List<ItemManager.ItemType>();
		bool enoughRoom = false;
		for (int i = 0; i < itemList.Count; i++)
		{
			for (int j = 0; j < itemList[i].m_count; j++)
			{
				if (InventoryManager.Instance.AddNewItems(itemList[i].m_type, 1))
				{
					list.Add(itemList[i].m_type);
				}
				else
				{
					enoughRoom = true;
				}
			}
		}
		if (obj_trap.uses <= 0)
		{
			ObjectManager.Instance.RemoveObject(obj_trap);
		}
		else
		{
			obj_trap.ResetTrap();
		}
		if ((Object)(object)UIPanelManager.Instance() != (Object)null && (Object)(object)UI_PanelContainer.Instance.harvestSnarePanel != (Object)null)
		{
			UI_PanelContainer.Instance.harvestSnarePanel.Setup(list, enoughRoom);
			UIPanelManager.Instance().PushPanel(UI_PanelContainer.Instance.harvestSnarePanel);
		}
		return true;
	}
}
