using UnityEngine;

public class UI_PlaySound : MonoBehaviour
{
	public enum Trigger
	{
		OnClick,
		OnSelect,
		OnDeselect,
		OnPress,
		OnRelease
	}

	public AudioClip audioClip;

	public Trigger trigger;

	public bool gamepadOnly;

	public bool keyboardOnly;

	private UIButton m_button;

	private bool m_selected;

	public bool canPlay => ((Behaviour)this).enabled && ((Object)(object)m_button == (Object)null || m_button.isEnabled);

	private void Awake()
	{
		m_button = ((Component)this).GetComponent<UIButton>();
	}

	private void OnSelect(bool selected)
	{
		if (m_selected != selected)
		{
			m_selected = selected;
			if ((trigger == Trigger.OnSelect && selected) || (trigger == Trigger.OnDeselect && !selected))
			{
				Play();
			}
		}
	}

	private void OnHover(bool hovered)
	{
		OnSelect(hovered);
	}

	private void OnClick()
	{
		if (trigger == Trigger.OnClick)
		{
			Play();
		}
	}

	private void OnPress(bool pressed)
	{
		if (m_selected != pressed)
		{
			m_selected = pressed;
			if ((trigger == Trigger.OnPress && pressed) || (trigger == Trigger.OnRelease && !pressed))
			{
				Play();
			}
		}
	}

	public void Play()
	{
		if (canPlay)
		{
			AudioManager.Instance.PlayUI(audioClip);
		}
	}
}
