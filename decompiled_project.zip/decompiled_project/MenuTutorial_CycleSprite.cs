using System.Collections;
using UnityEngine;

public class MenuTutorial_CycleSprite : MonoBehaviour
{
	private UISprite spriteRenderer;

	public UISprite spriteRenderer2;

	private bool switchSprite = true;

	[SerializeField]
	private string spriteOne1;

	[SerializeField]
	private string spriteOne2;

	[SerializeField]
	private string spriteTwo1;

	[SerializeField]
	private string spriteTwo2;

	[SerializeField]
	private bool useSingleTimer = true;

	[SerializeField]
	private float timerEven = 2f;

	[SerializeField]
	private float timerOdd = 2f;

	private float timer;

	[SerializeField]
	private bool doubleTapPause;

	private int counter = -1;

	[SerializeField]
	private bool menuSelect;

	[SerializeField]
	private float menuOnDelay = 1f;

	[SerializeField]
	private float menuOffDelay = 1f;

	[SerializeField]
	private bool moveIcon;

	[SerializeField]
	private GameObject moveIconGameObject;

	[SerializeField]
	private bool guiGlow;

	[SerializeField]
	private TweenAlpha guiGlowTween;

	private void Awake()
	{
		spriteRenderer = ((Component)this).GetComponent<UISprite>();
		timer = timerEven;
	}

	private void OnEnable()
	{
		if (spriteOne1 != string.Empty && spriteOne1 != null && (Object)(object)spriteRenderer != (Object)null)
		{
			spriteRenderer.spriteName = spriteOne1;
		}
		if (spriteTwo1 != string.Empty && spriteTwo1 != null && (Object)(object)spriteRenderer2 != (Object)null)
		{
			spriteRenderer2.spriteName = spriteTwo1;
		}
		if (moveIcon && Object.op_Implicit((Object)(object)moveIconGameObject))
		{
			moveIconGameObject.SetActive(true);
		}
		if (moveIcon && Object.op_Implicit((Object)(object)moveIconGameObject))
		{
			moveIconGameObject.SetActive(false);
		}
		if (Object.op_Implicit((Object)(object)guiGlowTween))
		{
			guiGlowTween.value = 0f;
			((Behaviour)guiGlowTween).enabled = false;
		}
		((MonoBehaviour)this).StartCoroutine(CycleSprite());
	}

	private void OnDisable()
	{
		((MonoBehaviour)this).StopCoroutine(CycleSprite());
	}

	private IEnumerator CycleSprite()
	{
		while (true)
		{
			if (Object.op_Implicit((Object)(object)spriteRenderer))
			{
				if (switchSprite)
				{
					switchSprite = !switchSprite;
					if (spriteOne1 != string.Empty && spriteOne1 != null && (Object)(object)spriteRenderer != (Object)null)
					{
						spriteRenderer.spriteName = spriteOne1;
					}
					if (spriteTwo1 != string.Empty && spriteTwo1 != null && (Object)(object)spriteRenderer2 != (Object)null && !menuSelect)
					{
						spriteRenderer2.spriteName = spriteTwo1;
					}
					if (!useSingleTimer)
					{
						timer = timerEven;
					}
					if (doubleTapPause && ++counter > 1)
					{
						counter = 0;
						timer = 2f;
					}
				}
				else
				{
					switchSprite = !switchSprite;
					if (spriteOne2 != string.Empty && spriteOne2 != null && (Object)(object)spriteRenderer != (Object)null)
					{
						spriteRenderer.spriteName = spriteOne2;
						if (guiGlow && Object.op_Implicit((Object)(object)guiGlowTween))
						{
							guiGlowTween.ResetToBeginning();
							guiGlowTween.PlayForward();
						}
					}
					if (spriteTwo2 != string.Empty && spriteTwo2 != null && (Object)(object)spriteRenderer2 != (Object)null && !menuSelect)
					{
						spriteRenderer2.spriteName = spriteTwo2;
					}
					if (menuSelect)
					{
						((MonoBehaviour)this).StartCoroutine(SpriteTwoSwitch(menuOnDelay));
					}
					if (!useSingleTimer)
					{
						timer = timerOdd;
					}
					if (moveIcon && Object.op_Implicit((Object)(object)moveIconGameObject) && counter == 1)
					{
						moveIconGameObject.SetActive(true);
						((MonoBehaviour)this).StartCoroutine(SwitchOffMoveIcon(1f));
					}
				}
			}
			yield return (object)new WaitForSecondsRealtime(timer);
		}
	}

	private IEnumerator SpriteTwoSwitch(float waitTime)
	{
		yield return (object)new WaitForSecondsRealtime(waitTime);
		if (spriteTwo1 != string.Empty && spriteTwo1 != null && (Object)(object)spriteRenderer2 != (Object)null)
		{
			spriteRenderer2.spriteName = spriteTwo2;
			((MonoBehaviour)this).StartCoroutine(SpriteOneSwitch(menuOffDelay));
		}
	}

	private IEnumerator SpriteOneSwitch(float waitTime)
	{
		yield return (object)new WaitForSecondsRealtime(waitTime);
		if (spriteTwo2 != string.Empty && spriteTwo2 != null && (Object)(object)spriteRenderer2 != (Object)null)
		{
			spriteRenderer2.spriteName = spriteTwo1;
		}
	}

	private IEnumerator SwitchOffMoveIcon(float waitTime)
	{
		yield return (object)new WaitForSecondsRealtime(waitTime);
		if (Object.op_Implicit((Object)(object)moveIconGameObject))
		{
			moveIconGameObject.SetActive(false);
		}
	}
}
