using System.Collections.Generic;
using UnityEngine;

public class TutorialStage_EnterShelter : BaseTutorial
{
	public Transform[] m_walkWaypoints;

	private List<FamilyMember> m_Travellers = new List<FamilyMember>();

	public override TutorialManager.TutorialStage GetTutorialStage()
	{
		return TutorialManager.TutorialStage.EnterShelter;
	}

	public override void OnEnterStage(bool showPanel)
	{
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		base.OnEnterStage(showPanel);
		if ((Object)(object)FamilyManager.Instance != (Object)null)
		{
			m_Travellers = FamilyManager.Instance.GetAllFamilyMembers();
		}
		if (((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading) && m_Travellers != null && m_Travellers.Count > 0)
		{
			for (int i = 0; i < m_Travellers.Count && i <= m_walkWaypoints.Length; i++)
			{
				m_Travellers[i].AddAIJob(new Job_GoToLocation(m_Travellers[i], m_walkWaypoints[i].position, cancellableInTransit: false));
			}
		}
	}

	public override bool IsStageComplete()
	{
		if (m_Travellers != null && m_Travellers.Count > 0)
		{
			for (int i = 0; i < m_Travellers.Count; i++)
			{
				if (!m_Travellers[i].ai_queue.is_empty)
				{
					return false;
				}
			}
		}
		return true;
	}
}
