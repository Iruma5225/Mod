using System.Collections.Generic;
using UnityEngine;

public abstract class Int_Base : MonoBehaviour
{
	[SerializeField]
	private bool m_InteractionEnabled = true;

	[SerializeField]
	private float m_Duration = 2f;

	[SerializeField]
	private int m_PowerUse;

	[SerializeField]
	private float m_FatigueRate = 1f;

	[SerializeField]
	private List<BaseStats.StatType> m_StatsToAwardExp = new List<BaseStats.StatType>();

	[SerializeField]
	private int m_ExpToAward;

	protected Obj_Base obj;

	public bool InteractionEnabled
	{
		get
		{
			return m_InteractionEnabled;
		}
		set
		{
			m_InteractionEnabled = value;
		}
	}

	public float Duration => m_Duration;

	public int PowerUse => m_PowerUse;

	public float FatigueRate => m_FatigueRate;

	public List<BaseStats.StatType> StatsToAwardExp => m_StatsToAwardExp;

	public int ExpAward => m_ExpToAward;

	public abstract string GetInstanceTypeName();

	public abstract string GetInteractionType();

	public virtual int GetInteractionPriority()
	{
		return 1;
	}

	public virtual bool HasSubMenu()
	{
		return false;
	}

	public virtual void Awake()
	{
		obj = ((Component)this).GetComponent<Obj_Base>();
		if ((Object)(object)obj != (Object)null)
		{
			obj.RegisterInteraction(this, GetInteractionType());
		}
	}

	public virtual bool IsPlayerSelectable()
	{
		return obj.IsNotBroken() && obj.HasEnoughPower() && !obj.isBurningOrBurntOut && InteractionEnabled;
	}

	public virtual bool IsPlayerSelectableWithoutValidMember()
	{
		return false;
	}

	public virtual bool IsAvailable()
	{
		return obj.IsNotBroken() && obj.HasEnoughPower() && !obj.isBurntOut;
	}

	public virtual bool OnInteractionSelected(FamilyMember member)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)member == (Object)null)
		{
			return false;
		}
		if ((Object)(object)obj == (Object)null)
		{
			return false;
		}
		if (member.job_queue.isFull)
		{
			return false;
		}
		return member.AddPlayerJob(new Job(GetInteractionType(), obj.GetInteractionPosition(), member, obj));
	}
}
