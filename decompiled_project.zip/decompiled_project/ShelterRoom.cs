using System.Collections.Generic;
using UnityEngine;

public class ShelterRoom : MonoBehaviour
{
	public class RoomGraffiti
	{
		public Sprite sprite;

		public Color color = Color.white;
	}

	public List<Sprite> wallSprites = new List<Sprite>();

	public SpriteRenderer wallRenderer;

	public Sprite dirt_left;

	public Sprite dirt_right;

	public Sprite dirt_both;

	public SpriteRenderer dirtRenderer;

	public SpriteRenderer roomShadow;

	public Transform light_object;

	public Transform smoke_pos;

	public GameObject pathnodes;

	private PathNode[] nodes;

	private List<RoomGraffiti> roomGraffiti = new List<RoomGraffiti>();

	[SerializeField]
	private List<SpriteRenderer> graffitiRenderers = new List<SpriteRenderer>();

	[SerializeField]
	private SpriteRenderer paintRenderer;

	private float paintApplyTime = -1f;

	private Color paintColor = Color.white;

	[SerializeField]
	private SpriteRenderer wiresRenderer;

	public bool isPainted => (Object)(object)paintRenderer != (Object)null && ((Renderer)paintRenderer).enabled && (Object)(object)paintRenderer.sprite != (Object)null;

	public float PaintApplyTime => paintApplyTime;

	public Color PaintColor => paintColor;

	public void Awake()
	{
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)pathnodes != (Object)null)
		{
			nodes = pathnodes.GetComponentsInChildren<PathNode>();
		}
		for (int i = 0; i < graffitiRenderers.Count; i++)
		{
			roomGraffiti.Add(new RoomGraffiti());
		}
		if (wallSprites.Count > 0)
		{
			SetWallSprite(Random.Range(0, wallSprites.Count));
		}
		if ((Object)(object)roomShadow != (Object)null)
		{
			roomShadow.color = new Color(1f, 1f, 1f, 1f);
		}
	}

	public Obj_Light SpawnRoomLight()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)light_object != (Object)null)
		{
			Obj_Base obj_Base = ObjectManager.Instance.SpawnObject(ObjectManager.ObjectType.RoomLight, 1, Vector2.op_Implicit(light_object.position));
			if ((Object)(object)obj_Base != (Object)null)
			{
				Obj_Light component = ((Component)obj_Base).GetComponent<Obj_Light>();
				if ((Object)(object)component != (Object)null)
				{
					component.setShadow(roomShadow);
				}
				light_object = ((Component)obj_Base).transform;
				return component;
			}
		}
		return null;
	}

	public bool SetWallSprite(int index)
	{
		if ((Object)(object)wallRenderer == (Object)null)
		{
			return false;
		}
		if (index < 0 || index >= wallSprites.Count)
		{
			return false;
		}
		wallRenderer.sprite = wallSprites[index];
		((Renderer)wallRenderer).enabled = (Object)(object)wallRenderer.sprite != (Object)null;
		return true;
	}

	public int GetWallSprite()
	{
		return wallSprites.FindIndex((Sprite sprite) => (Object)(object)sprite == (Object)(object)wallRenderer.sprite);
	}

	public bool ShowGraffiti(Sprite sprite, Color color)
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < graffitiRenderers.Count; i++)
		{
			if (!((Object)(object)graffitiRenderers[i].sprite != (Object)null))
			{
				graffitiRenderers[i].sprite = sprite;
				graffitiRenderers[i].color = color;
				((Renderer)graffitiRenderers[i]).enabled = true;
				roomGraffiti[i].sprite = sprite;
				roomGraffiti[i].color = color;
				return true;
			}
		}
		return false;
	}

	public void RemoveAllGraffiti()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < graffitiRenderers.Count; i++)
		{
			graffitiRenderers[i].sprite = null;
			graffitiRenderers[i].color = Color.white;
			((Renderer)graffitiRenderers[i]).enabled = false;
			roomGraffiti[i].sprite = null;
			roomGraffiti[i].color = Color.white;
		}
	}

	public List<RoomGraffiti> GetAllGraffiti()
	{
		List<RoomGraffiti> list = new List<RoomGraffiti>();
		for (int i = 0; i < roomGraffiti.Count; i++)
		{
			if (!((Object)(object)roomGraffiti[i].sprite == (Object)null))
			{
				list.Add(roomGraffiti[i]);
			}
		}
		return list;
	}

	public void PaintWall(Sprite sprite, Color color, float apply_time = -1f)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		if (apply_time <= 0f)
		{
			paintApplyTime = Time.time;
		}
		else
		{
			paintApplyTime = apply_time;
		}
		paintRenderer.color = color;
		paintColor = color;
		SetPaintSprite(sprite);
	}

	public void RemovePaint()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		SetPaintSprite(null);
		paintRenderer.color = Color.white;
		paintColor = Color.white;
		paintApplyTime = -1f;
	}

	public void SetPaintSprite(Sprite sprite)
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)paintRenderer == (Object)null) && (!((Object)(object)sprite == (Object)(object)paintRenderer.sprite) || !((Object)(object)sprite != (Object)null)))
		{
			paintRenderer.sprite = sprite;
			paintRenderer.color = paintColor;
			if ((Object)(object)sprite != (Object)null && !((Renderer)paintRenderer).enabled)
			{
				((Renderer)paintRenderer).enabled = true;
			}
			else if ((Object)(object)sprite == (Object)null && ((Renderer)paintRenderer).enabled)
			{
				((Renderer)paintRenderer).enabled = false;
			}
		}
	}

	public void PaintOverRoom(float progress)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < graffitiRenderers.Count; i++)
		{
			graffitiRenderers[i].color = roomGraffiti[i].color * (1f - progress);
		}
		if ((Object)(object)paintRenderer != (Object)null && paintApplyTime >= 0f)
		{
			paintRenderer.color = paintColor * (1f - progress);
		}
	}

	public bool SetWiring(Sprite sprite)
	{
		if ((Object)(object)wiresRenderer == (Object)null)
		{
			return false;
		}
		wiresRenderer.sprite = sprite;
		((Renderer)wiresRenderer).enabled = (Object)(object)sprite != (Object)null;
		return true;
	}

	public Sprite GetWires()
	{
		return (!((Object)(object)wiresRenderer != (Object)null)) ? null : wiresRenderer.sprite;
	}

	public void OnNeighboursChanged(ShelterRoomGrid.CellType[] neighbours)
	{
		if (neighbours.Length == 4 && (Object)(object)dirtRenderer != (Object)null)
		{
			if ((neighbours[2] == ShelterRoomGrid.CellType.Room || neighbours[2] == ShelterRoomGrid.CellType.RoomTop) && (neighbours[3] == ShelterRoomGrid.CellType.Room || neighbours[3] == ShelterRoomGrid.CellType.RoomTop))
			{
				dirtRenderer.sprite = null;
			}
			else if (neighbours[2] == ShelterRoomGrid.CellType.Room || neighbours[2] == ShelterRoomGrid.CellType.RoomTop)
			{
				dirtRenderer.sprite = dirt_right;
			}
			else if (neighbours[3] == ShelterRoomGrid.CellType.Room || neighbours[3] == ShelterRoomGrid.CellType.RoomTop)
			{
				dirtRenderer.sprite = dirt_left;
			}
			else
			{
				dirtRenderer.sprite = dirt_both;
			}
			((Renderer)dirtRenderer).enabled = (Object)(object)dirtRenderer.sprite != (Object)null;
		}
	}

	public void OnLadderPlaced(ShelterLadder ladder)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)ladder == (Object)null) && (Object)(object)light_object != (Object)null && ladder.IsPointWithinLadderCollision(light_object.position))
		{
			Vector3 position = light_object.position;
			position.x = ladder.light_pos.x;
			light_object.position = position;
		}
	}

	public void RemovePathnodes()
	{
		if (nodes != null)
		{
			PathNode[] array = nodes;
			foreach (PathNode pathNode in array)
			{
				((Component)pathNode).transform.parent = ((Component)this).transform;
			}
			AstarPath.active.Scan();
		}
	}
}
