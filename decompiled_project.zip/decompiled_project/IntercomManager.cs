using System.Collections.Generic;
using UnityEngine;

public class IntercomManager : BaseManagerNoUpdate
{
	[SerializeField]
	private AudioClip m_firstBuzzerSound;

	[SerializeField]
	private AudioClip m_secondBuzzerSound;

	private AudioSource m_audio;

	private NpcVisitor m_waitingNpc;

	private bool m_answeredIntercomOnce;

	private static IntercomManager m_instance;

	public bool isNpcWaiting => (Object)(object)m_waitingNpc != (Object)null;

	public static IntercomManager Instance => m_instance;

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
		}
	}

	public override void StartManager()
	{
		m_audio = ((Component)this).GetComponent<AudioSource>();
	}

	public void RingIntercom(NpcVisitor npc)
	{
		if ((Object)(object)m_waitingNpc != (Object)null)
		{
			return;
		}
		m_waitingNpc = npc;
		m_audio.PlayOneShot(m_firstBuzzerSound);
		if (!m_answeredIntercomOnce)
		{
			UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.Intercom);
		}
		Obj_Intercom obj_Intercom = null;
		if ((Object)(object)ObjectManager.Instance != (Object)null)
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Intercom);
			if (objectsOfType.Count > 0)
			{
				obj_Intercom = objectsOfType[0] as Obj_Intercom;
			}
		}
		if ((Object)(object)ActivityLog.Instance != (Object)null)
		{
			ActivityLog.Instance.Add(ActivityLog.Activity.NpcBuzzedIntercom, ((Component)obj_Intercom).transform);
		}
		if ((Object)(object)obj_Intercom != (Object)null)
		{
			obj_Intercom.SetIsRinging(ringing: true);
		}
		if ((Object)(object)ObjectiveArrowMan.Instance != (Object)null)
		{
			ObjectiveArrowMan.Instance.AddObjective(obj_Intercom.objectiveTarget, m_secondBuzzerSound, 10f, 10f);
		}
	}

	public void AbandonIntercom(NpcVisitor npc)
	{
		if (!((Object)(object)npc != (Object)null) || !((Object)(object)m_waitingNpc == (Object)(object)npc))
		{
			return;
		}
		m_waitingNpc = null;
		Obj_Intercom obj_Intercom = null;
		if ((Object)(object)ObjectManager.Instance != (Object)null)
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Intercom);
			if (objectsOfType.Count > 0)
			{
				obj_Intercom = objectsOfType[0] as Obj_Intercom;
			}
		}
		if ((Object)(object)obj_Intercom != (Object)null)
		{
			obj_Intercom.SetIsRinging(ringing: false);
			if ((Object)(object)ObjectiveArrowMan.Instance != (Object)null)
			{
				ObjectiveArrowMan.Instance.RemoveObjective(obj_Intercom.objectiveTarget);
			}
		}
	}

	public void AnswerIntercom()
	{
		if (!((Object)(object)m_waitingNpc != (Object)null))
		{
			return;
		}
		m_answeredIntercomOnce = true;
		if ((Object)(object)TutorialManager.Instance != (Object)null)
		{
			TutorialManager.Instance.SetPopupSeen(TutorialManager.PopupType.Intercom);
		}
		m_waitingNpc.OnIntercomAnswered();
		Obj_Intercom obj_Intercom = null;
		if ((Object)(object)ObjectManager.Instance != (Object)null)
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Intercom);
			if (objectsOfType.Count > 0)
			{
				obj_Intercom = objectsOfType[0] as Obj_Intercom;
			}
		}
		if ((Object)(object)obj_Intercom != (Object)null)
		{
			obj_Intercom.SetIsRinging(ringing: false);
			if ((Object)(object)ObjectiveArrowMan.Instance != (Object)null)
			{
				ObjectiveArrowMan.Instance.RemoveObjective(obj_Intercom.objectiveTarget);
			}
		}
	}
}
