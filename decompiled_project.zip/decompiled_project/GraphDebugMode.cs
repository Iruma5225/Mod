public enum GraphDebugMode
{
	Areas,
	G,
	H,
	F,
	Penalty,
	Connections,
	Tags
}
