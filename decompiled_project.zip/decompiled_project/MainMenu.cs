using System.Collections.Generic;
using System.Diagnostics;
using AnimationOrTween;
using UnityEngine;

public class MainMenu : BasePanel
{
	public string gameSceneName = string.Empty;

	public BasePanel leaderboardsPanel;

	public BasePanel creditsPanel;

	public BasePanel optionsPCPanel;

	public BasePanel optionsXboxPanel;

	public BasePanel controlsPanel;

	public GameObject userLegend;

	public GameObject trialLogo;

	public GameObject storeButton;

	public GameObject exitButton;

	public GameObject controlsButton;

	public GameObject leaderboardsButton;

	public GameObject quitConfirmationPanel;

	[SerializeField]
	private UITablePivot m_table;

	private int m_tableNeedsUpdate;

	[SerializeField]
	private BasePanel m_slotSelectionPanel;

	[SerializeField]
	private BasePanel m_customizationPanel;

	[SerializeField]
	private BasePanel m_gameModeSelectionPanel;

	private UILabel m_userLegendLabel;

	private TweenAlpha m_tween;

	private bool m_userSignedOut;

	private bool m_inputEnabled = true;

	private bool isInputEnabled => m_inputEnabled;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return false;
	}

	public void OnUserSignedOut()
	{
		m_userSignedOut = true;
	}

	private void Awake()
	{
		if ((Object)(object)userLegend != (Object)null)
		{
			m_userLegendLabel = userLegend.GetComponent<UILabel>();
		}
		m_tween = ((Component)this).GetComponent<TweenAlpha>();
	}

	public override void OnShow()
	{
		base.OnShow();
		m_userSignedOut = false;
		if ((Object)(object)userLegend != (Object)null)
		{
			userLegend.SetActive(false);
		}
		OnTrialLicenceChanged(trialChanged: false, userChanged: false);
		if ((Object)(object)m_tween != (Object)null)
		{
			m_tween.PlayForward();
		}
		if ((Object)(object)m_table != (Object)null)
		{
			m_table.Reposition();
			m_tableNeedsUpdate = 2;
		}
	}

	private void UpdateButtonTable()
	{
		if (!((Object)(object)m_table != (Object)null))
		{
			return;
		}
		List<Transform> children = m_table.children;
		if (children == null)
		{
			return;
		}
		List<UIKeyNavigation> list = new List<UIKeyNavigation>();
		for (int i = 0; i < children.Count; i++)
		{
			if ((Object)(object)children[i] != (Object)null && ((Component)children[i]).gameObject.activeSelf)
			{
				UIKeyNavigation component = ((Component)children[i]).GetComponent<UIKeyNavigation>();
				if ((Object)(object)component != (Object)null)
				{
					list.Add(component);
				}
			}
		}
		for (int j = 0; j < list.Count; j++)
		{
			list[j].constraint = UIKeyNavigation.Constraint.Explicit;
			list[j].onUp = null;
			list[j].onDown = null;
			list[j].onLeft = null;
			list[j].onRight = null;
			if (j > 0)
			{
				list[j].onUp = ((Component)list[j - 1]).gameObject;
			}
			if (j < list.Count - 1)
			{
				list[j].onDown = ((Component)list[j + 1]).gameObject;
			}
		}
	}

	public override void Update()
	{
		if (m_tableNeedsUpdate > 0)
		{
			m_tableNeedsUpdate--;
			if (m_tableNeedsUpdate == 0)
			{
				UpdateButtonTable();
			}
		}
		if (Input.GetKeyDown((KeyCode)27))
		{
			if ((Object)(object)quitConfirmationPanel != (Object)null && !quitConfirmationPanel.activeInHierarchy)
			{
				quitConfirmationPanel.SetActive(true);
			}
			else if ((Object)(object)quitConfirmationPanel != (Object)null && quitConfirmationPanel.activeInHierarchy)
			{
				quitConfirmationPanel.SetActive(false);
			}
		}
	}

	public void QuitGame()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		quitConfirmationPanel.SetActive(false);
		AndroidJavaObject val = ((AndroidJavaObject)new AndroidJavaClass("com.unity3d.player.UnityPlayer")).GetStatic<AndroidJavaObject>("currentActivity");
		val.Call<bool>("moveTaskToBack", new object[1] { true });
	}

	public void ResumeGame()
	{
		if ((Object)(object)quitConfirmationPanel != (Object)null)
		{
			quitConfirmationPanel.SetActive(false);
		}
	}

	public override void OnResume()
	{
		base.OnResume();
		m_tween.PlayForward();
	}

	public void OnPlayButtonPressed()
	{
		if (isInputEnabled && (Object)(object)m_tween != (Object)null)
		{
			m_tween.PlayReverse();
			if ((Object)(object)quitConfirmationPanel != (Object)null)
			{
				quitConfirmationPanel.SetActive(false);
			}
		}
	}

	public void OnTweenFinished()
	{
		if (!((Object)(object)m_tween != (Object)null))
		{
			return;
		}
		if (m_tween.direction == Direction.Reverse)
		{
			m_inputEnabled = false;
			if ((Object)(object)m_slotSelectionPanel != (Object)null && (Object)(object)UIPanelManager.instance != (Object)null)
			{
				UIPanelManager.Instance().PushPanel(m_slotSelectionPanel);
			}
		}
		else
		{
			m_inputEnabled = true;
		}
	}

	private void OnFadeComplete()
	{
	}

	public void OnOptionsButtonPressed()
	{
		if (isInputEnabled)
		{
			BasePanel basePanel = null;
			basePanel = optionsPCPanel;
			if ((Object)(object)basePanel != (Object)null)
			{
				UIPanelManager.Instance().PushPanel(basePanel);
			}
		}
	}

	public void OnControlsButtonPressed()
	{
		if (isInputEnabled && (Object)(object)controlsPanel != (Object)null)
		{
			UIPanelManager.Instance().PushPanel(controlsPanel);
		}
	}

	public void OnLeaderboardsButtonPressed()
	{
		if (isInputEnabled)
		{
			Social.ShowLeaderboardUI();
		}
	}

	public void OnHelpButtonPressed()
	{
	}

	public void OnStoreButtonPressed()
	{
	}

	public void OnCreditsButtonPressed()
	{
		if (isInputEnabled && (Object)(object)creditsPanel != (Object)null)
		{
			UIPanelManager.Instance().PushPanel(creditsPanel);
		}
	}

	public void OnUserLegendButtonPressed()
	{
		if (isInputEnabled)
		{
			MessageBox.Show(MessageBoxButtons.YesNo_Buttons, "Text.Platform.XB1.ConfirmChangeActiveUser", OnChangeUserMessageBoxCallback);
		}
	}

	public void OnExitButtonPressed()
	{
		if (isInputEnabled)
		{
			if (Application.isEditor)
			{
				Application.Quit();
			}
			else
			{
				Process.GetCurrentProcess().Kill();
			}
		}
	}

	public void OnChangeUserMessageBoxCallback(int result)
	{
	}

	private void OnUserChangeComplete(bool success)
	{
	}

	private void OnTrialLicenceChanged(bool trialChanged, bool userChanged)
	{
	}
}
