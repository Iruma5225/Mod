using UnityEngine;

public abstract class BaseDialogueStage
{
	public enum DialogueResult
	{
		Continue,
		StageTrade,
		StageRecruit,
		StageIntimidate,
		NpcSwitchToTrade,
		NpcSwitchToRecruit,
		NpcSwitchToIntimidate,
		DoCombat,
		DoPoorTrade,
		DoNormalTrade,
		DoGoodTrade,
		TradeOver,
		RecruitOver,
		EndEncounter,
		QuestReward
	}

	public delegate DialogueResult DialogueState();

	public delegate void ButtonCallback();

	public delegate void CharacterSelectionCallback(EncounterCharacter character, bool selected);

	public delegate void CharacterClickCallback(EncounterCharacter character, bool wasRightClick);

	protected DialogueState m_state;

	protected float m_timer;

	protected ButtonCallback m_onSelect;

	protected ButtonCallback m_onCancel;

	protected ButtonCallback m_onExtra1;

	protected ButtonCallback m_onExtra2;

	protected ButtonCallback m_onTabLeft;

	protected ButtonCallback m_onTabRight;

	protected CharacterSelectionCallback m_onCharSelected;

	protected CharacterClickCallback m_onCharClicked;

	protected void SetState(DialogueState newState)
	{
		m_state = newState;
		ResetCallbacks();
	}

	public DialogueResult Update()
	{
		if (m_timer > Mathf.Epsilon)
		{
			m_timer = Mathf.Max(m_timer - RealTime.deltaTime, 0f);
		}
		if (m_state != null)
		{
			return m_state();
		}
		return DialogueResult.EndEncounter;
	}

	private void ResetCallbacks()
	{
		m_onSelect = null;
		m_onCancel = null;
		m_onExtra1 = null;
		m_onExtra2 = null;
		m_onTabRight = null;
		m_onTabLeft = null;
		m_onCharSelected = null;
		m_onCharClicked = null;
	}

	public void OnSelect()
	{
		if (m_onSelect != null)
		{
			m_onSelect();
		}
	}

	public void OnCancel()
	{
		if (m_onCancel != null)
		{
			m_onCancel();
		}
	}

	public void OnExtra1()
	{
		if (m_onExtra1 != null)
		{
			m_onExtra1();
		}
	}

	public void OnExtra2()
	{
		if (m_onExtra2 != null)
		{
			m_onExtra2();
		}
	}

	public void OnTabRight()
	{
		if (m_onTabRight != null)
		{
			m_onTabRight();
		}
	}

	public void OnTabLeft()
	{
		if (m_onTabLeft != null)
		{
			m_onTabLeft();
		}
	}

	public void OnCharSelected(EncounterCharacter character, bool selected)
	{
		if (m_onCharSelected != null)
		{
			m_onCharSelected(character, selected);
		}
	}

	public void OnCharClicked(EncounterCharacter character, bool wasRightClick)
	{
		if (m_onCharClicked != null)
		{
			m_onCharClicked(character, wasRightClick);
		}
	}
}
