using System;
using UnityEngine;

[Serializable]
public class Illness_Bleeding : Illness_Base
{
	private int m_healthDamageAmount;

	private float m_healthDamageInterval;

	private float m_healthDamageTime;

	public override void Initialize(FamilyMember member)
	{
		base.Initialize(member);
		m_healthDamageInterval = GameTime.GameSecondsToRealSeconds(720f);
		m_healthDamageAmount = 1;
		m_healthDamageTime = 0f;
	}

	public override void UpdateIllness()
	{
		if (base.isActive && Time.time >= m_healthDamageTime)
		{
			m_healthDamageTime = Time.time + m_healthDamageInterval;
			m_member.Damage(m_healthDamageAmount, BaseCharacter.DamageType.Bleeding, string.Empty);
		}
	}

	public void OnFirstAid()
	{
		SetActive(active: false);
	}

	protected override void OnContractIllness()
	{
		m_healthDamageTime = Time.time + m_healthDamageInterval;
		m_member.SetWalkSpeedMultiplier(0.5f);
	}

	protected override void OnCureIllness()
	{
		m_member.SetWalkSpeedMultiplier(1f);
	}

	public override void SaveLoadIllness(SaveData data)
	{
		data.GroupStart("Bleeding");
		base.SaveLoadIllness(data);
		data.SaveLoadAbsoluteTime("damageTime", ref m_healthDamageTime);
		data.GroupEnd();
	}
}
