using UnityEngine;

public class PoweredObject : MonoBehaviour
{
	[SerializeField]
	private int m_RequiredPower = 1;

	[SerializeField]
	private int m_Priority;

	private bool m_HasPower = true;

	private Obj_Base obj;

	public int RequiredPower
	{
		get
		{
			return m_RequiredPower;
		}
		set
		{
			m_RequiredPower = Mathf.Max(value, 0);
		}
	}

	public int Priority => m_Priority;

	public bool HasPower
	{
		get
		{
			return m_HasPower;
		}
		set
		{
			m_HasPower = value;
		}
	}

	private void Awake()
	{
		obj = ((Component)this).GetComponent<Obj_Base>();
	}

	private void Start()
	{
		if (Object.op_Implicit((Object)(object)PowerManager.Instance))
		{
			PowerManager.Instance.RegisterConsumer(this);
		}
	}

	private void OnDestroy()
	{
		if (Object.op_Implicit((Object)(object)PowerManager.Instance))
		{
			PowerManager.Instance.UnRegisterConsumer(this);
		}
	}

	public bool CanUsePower()
	{
		if ((Object)(object)obj != (Object)null)
		{
			return obj.IsEnabled() && !obj.IsBroken() && !obj.isBurntOut;
		}
		return false;
	}
}
