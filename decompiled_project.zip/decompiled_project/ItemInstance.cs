using System;
using UnityEngine;

[Serializable]
public class ItemInstance
{
	[SerializeField]
	private ItemManager.ItemType m_Type = ItemManager.ItemType.Undefined;

	private ItemDefinition m_Definition;

	private ItemDefinition_Combat m_DefinitionCombat;

	public ItemManager.ItemType Type => m_Type;

	public ItemInstance(ItemManager.ItemType type)
	{
		m_Type = type;
		if ((Object)(object)ItemManager.Instance != (Object)null)
		{
			m_Definition = ItemManager.Instance.GetItemDefinition(m_Type);
			m_DefinitionCombat = ItemManager.Instance.GetCombatDefinition(m_Type);
		}
	}

	public ItemDefinition GetItemDefinition()
	{
		if ((Object)(object)m_Definition == (Object)null && (Object)(object)ItemManager.Instance != (Object)null)
		{
			m_Definition = ItemManager.Instance.GetItemDefinition(m_Type);
		}
		return m_Definition;
	}

	public ItemDefinition_Combat GetCombatDefinition()
	{
		if ((Object)(object)m_DefinitionCombat == (Object)null && (Object)(object)ItemManager.Instance != (Object)null)
		{
			m_DefinitionCombat = ItemManager.Instance.GetCombatDefinition(m_Type);
		}
		return m_DefinitionCombat;
	}
}
