using UnityEngine;

public class InteractionInstance_MedicatePet : InteractionInstance_Base
{
	private Obj_Pet m_pet;

	protected override bool OnInteractionStarted()
	{
		m_pet = obj_base as Obj_Pet;
		if ((Object)(object)m_pet == (Object)null)
		{
			return false;
		}
		if ((Object)(object)InventoryManager.Instance == (Object)null || InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.AntiRadMedicine) < 1)
		{
			return false;
		}
		InventoryManager.Instance.RemoveItemOfType(ItemManager.ItemType.AntiRadMedicine);
		member.TriggerAnim("Rummage");
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled)
		{
			m_pet.Medicate();
		}
		else if ((Object)(object)InventoryManager.Instance != (Object)null)
		{
			InventoryManager.Instance.AddNewItem(ItemManager.ItemType.AntiRadMedicine);
		}
		return true;
	}
}
