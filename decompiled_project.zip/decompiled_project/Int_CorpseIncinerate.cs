using UnityEngine;

public class Int_CorpseIncinerate : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "corpse_burn";
	}

	public override int GetInteractionPriority()
	{
		return 2;
	}

	public override bool IsPlayerSelectable()
	{
		FamilyMember selectedFamilyMember = InteractionManager.Instance.GetSelectedFamilyMember();
		if ((Object)(object)selectedFamilyMember == (Object)null || selectedFamilyMember.isCarryingCorpse || obj.isBurningOrBurntOut)
		{
			return false;
		}
		if ((Object)(object)ObjectManager.Instance == (Object)null || ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Incinerator).Count == 0)
		{
			return false;
		}
		return true;
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		if (member.job_queue.isFull)
		{
			return false;
		}
		Obj_Base nearestObjectOfType = ObjectManager.Instance.GetNearestObjectOfType(ObjectManager.ObjectType.Incinerator, ((Component)obj).transform.position);
		if ((Object)(object)nearestObjectOfType != (Object)null)
		{
			return member.AddPlayerJob(new Job_MoveCorpse(member, obj as Obj_Corpse, nearestObjectOfType, "burn_corpse"));
		}
		return false;
	}
}
