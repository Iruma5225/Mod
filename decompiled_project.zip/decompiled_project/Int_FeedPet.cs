using UnityEngine;

public class Int_FeedPet : Int_Base
{
	public int RationsUsed = 1;

	public bool crouch;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_FeedPet";
	}

	public override string GetInteractionType()
	{
		return "feed_pet";
	}

	public override bool IsPlayerSelectable()
	{
		if (!base.IsPlayerSelectable())
		{
			return false;
		}
		if ((Object)(object)FoodManager.Instance == (Object)null || FoodManager.Instance.TotalFood <= 0)
		{
			return false;
		}
		Obj_Pet obj_Pet = obj as Obj_Pet;
		if ((Object)(object)obj_Pet != (Object)null && !obj_Pet.hasFood && !obj_Pet.isDead)
		{
			return true;
		}
		return false;
	}
}
