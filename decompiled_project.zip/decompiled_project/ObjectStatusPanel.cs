using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class ObjectStatusPanel : BasePanel
{
	public static readonly int kNumRows = 12;

	public GameObject arrowLeft;

	public GameObject arrowRight;

	public UILabel pageNumberLabel;

	public bool closeOnCancelButton = true;

	public AudioClip openSound;

	public AudioClip closeSound;

	public AudioClip nextPageSound;

	private UILabel[] m_rowNames = new UILabel[kNumRows];

	private UILabel[] m_rowValues = new UILabel[kNumRows];

	private UISprite[] m_disabledIcons = new UISprite[kNumRows];

	private UISprite[] m_noPowerIcons = new UISprite[kNumRows];

	private List<Obj_Integrity> m_objects = new List<Obj_Integrity>();

	private int m_page;

	private int m_numPages;

	public float familyMemberThreshold = 0.9f;

	private void Awake()
	{
		for (int i = 0; i < kNumRows; i++)
		{
			Transform val = ((Component)this).gameObject.transform.Find("ObjectLabels/Label_" + (i + 1));
			Transform val2 = ((Component)this).gameObject.transform.Find("ObjectValues/Value_" + (i + 1));
			if ((Object)(object)val == (Object)null || (Object)(object)val2 == (Object)null)
			{
				throw new Exception("Failed to find name or value object for row " + i);
			}
			m_rowNames[i] = ((Component)val).gameObject.GetComponent<UILabel>();
			m_rowValues[i] = ((Component)val2).gameObject.GetComponent<UILabel>();
			if ((Object)(object)m_rowNames[i] == (Object)null || (Object)(object)m_rowValues[i] == (Object)null)
			{
				throw new Exception("Failed to find name or value UILabel for row " + i);
			}
			Transform val3 = ((Component)this).gameObject.transform.Find("DisabledIcons/Disabled_" + (i + 1));
			Transform val4 = ((Component)this).gameObject.transform.Find("UnpoweredIcons/NoPower_" + (i + 1));
			if ((Object)(object)val3 == (Object)null || (Object)(object)val4 == (Object)null)
			{
				throw new Exception("Failed to find an icon object for row " + i);
			}
			m_disabledIcons[i] = ((Component)val3).gameObject.GetComponent<UISprite>();
			m_noPowerIcons[i] = ((Component)val4).gameObject.GetComponent<UISprite>();
			if ((Object)(object)m_disabledIcons[i] == (Object)null || (Object)(object)m_noPowerIcons[i] == (Object)null)
			{
				throw new Exception("Failed to find an icon sprite for row " + i);
			}
		}
	}

	public void OnNextSubPage()
	{
		if (m_page < m_numPages - 1)
		{
			m_page++;
			UpdatePage();
		}
	}

	public void OnPreviousSubPage()
	{
		if (m_page > 0)
		{
			m_page--;
			UpdatePage();
		}
	}

	private void GatherShelterObjects()
	{
		m_objects.Clear();
		Array values = Enum.GetValues(typeof(ObjectManager.ObjectType));
		foreach (int item in values)
		{
			ObjectManager.ObjectType objectType = (ObjectManager.ObjectType)Enum.ToObject(typeof(ObjectManager.ObjectType), item);
			if (objectType == ObjectManager.ObjectType.Undefined || objectType == ObjectManager.ObjectType.Max)
			{
				continue;
			}
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(objectType);
			foreach (Obj_Base item2 in objectsOfType)
			{
				Obj_Integrity component = ((Component)item2).gameObject.GetComponent<Obj_Integrity>();
				if ((Object)(object)component != (Object)null && component.listedInClipboard)
				{
					m_objects.Add(component);
				}
			}
		}
		m_numPages = (int)Mathf.Ceil((float)m_objects.Count / (float)kNumRows);
		if (m_page >= m_numPages)
		{
			m_page = 0;
		}
	}

	private void UpdatePage()
	{
		for (int i = 0; i < kNumRows; i++)
		{
			int num = m_page * kNumRows + i;
			if (num < m_objects.Count)
			{
				((Component)m_rowNames[i]).gameObject.SetActive(true);
				m_rowNames[i].text = m_objects[num].GetName();
				((Component)m_rowValues[i]).gameObject.SetActive(true);
				StringBuilder stringBuilder = new StringBuilder();
				if (m_objects[num].Integrity < 30)
				{
					stringBuilder.Append("[B42C2C]");
				}
				else if (m_objects[num].Integrity < 75)
				{
					stringBuilder.Append("[9E8917]");
				}
				else
				{
					stringBuilder.Append("[64945B]");
				}
				stringBuilder.Append(m_objects[num].Integrity.ToString());
				stringBuilder.Append("%[-]");
				m_rowValues[i].text = stringBuilder.ToString();
				bool flag = !m_objects[num].IsEnabled();
				bool flag2 = m_objects[num].IsDuctTaped();
				bool active = !flag && !m_objects[num].HasEnoughPower();
				((Component)m_disabledIcons[i]).gameObject.SetActive(flag);
				((Component)m_noPowerIcons[i]).gameObject.SetActive(active);
			}
			else
			{
				((Component)m_rowNames[i]).gameObject.SetActive(false);
				((Component)m_rowValues[i]).gameObject.SetActive(false);
				((Component)m_disabledIcons[i]).gameObject.SetActive(false);
				((Component)m_noPowerIcons[i]).gameObject.SetActive(false);
			}
		}
		pageNumberLabel.text = m_page + 1 + "/" + m_numPages;
		arrowLeft.SetActive(m_page > 0);
		arrowRight.SetActive(m_page < m_numPages - 1);
	}

	public override void OnShow()
	{
		if (!((Object)(object)arrowLeft == (Object)null) && !((Object)(object)arrowRight == (Object)null) && !((Object)(object)pageNumberLabel == (Object)null))
		{
			base.OnShow();
			if ((Object)(object)openSound != (Object)null)
			{
				UISound.instance.Play(openSound);
			}
			GatherShelterObjects();
			UpdatePage();
		}
	}

	public override void OnCancel()
	{
		base.OnCancel();
		if (closeOnCancelButton)
		{
			UIPanelManager.Instance().PopPanel(this);
		}
	}

	public override void OnClose()
	{
		if ((Object)(object)closeSound != (Object)null)
		{
			UISound.instance.Play(closeSound);
		}
		base.OnClose();
	}

	public override bool AlwaysShow()
	{
		return true;
	}

	public override bool DestroyOnClose()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override bool PausesGameInput()
	{
		return true;
	}
}
