using UnityEngine;

public class Int_RadioRejectTransmission : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "radio_reject_transmission";
	}

	public override int GetInteractionPriority()
	{
		return 2;
	}

	public override bool IsPlayerSelectable()
	{
		if (!base.IsPlayerSelectable())
		{
			return false;
		}
		Obj_Radio obj_Radio = (Obj_Radio)obj;
		if ((Object)(object)obj_Radio != (Object)null && obj_Radio.incomingTransmission)
		{
			return true;
		}
		return false;
	}

	public override bool IsPlayerSelectableWithoutValidMember()
	{
		return IsPlayerSelectable();
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		Obj_Radio obj_Radio = obj as Obj_Radio;
		if ((Object)(object)obj_Radio != (Object)null)
		{
			obj_Radio.RejectTransmission();
			return true;
		}
		return false;
	}
}
