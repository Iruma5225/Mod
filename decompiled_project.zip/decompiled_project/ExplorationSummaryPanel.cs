using System.Collections.Generic;
using UnityEngine;

public class ExplorationSummaryPanel : BasePanel
{
	[SerializeField]
	private UILabel m_title;

	[SerializeField]
	private UIGrid member_grid;

	[SerializeField]
	private AudioClip open_sound;

	private List<EncounterSummaryCharacter> characterSummaries = new List<EncounterSummaryCharacter>();

	private EncounterCharacter[] m_playerCharacters;

	private ExplorationParty m_party;

	private void Awake()
	{
		EncounterSummaryCharacter[] componentsInChildren = ((Component)member_grid).GetComponentsInChildren<EncounterSummaryCharacter>();
		if (componentsInChildren != null && componentsInChildren.Length > 0)
		{
			characterSummaries.AddRange(componentsInChildren);
		}
		m_playerCharacters = ((Component)member_grid).GetComponentsInChildren<EncounterCharacter>();
	}

	public override void OnShow()
	{
		base.OnShow();
		if ((Object)(object)m_party == (Object)null)
		{
			return;
		}
		for (int i = 0; i < characterSummaries.Count; i++)
		{
			if (i >= m_party.membersCount)
			{
				((Component)characterSummaries[i]).gameObject.SetActive(false);
				continue;
			}
			m_playerCharacters[i].Reset();
			m_playerCharacters[i].Setup(m_party.GetMember(i));
			m_playerCharacters[i].ModifyStat(BaseStats.StatType.Perception, m_party.searchExperience);
			characterSummaries[i].ShowCharacter(m_playerCharacters[i], BaseStats.StatType.Perception);
			((Component)characterSummaries[i]).gameObject.SetActive(true);
		}
		if ((Object)(object)member_grid != (Object)null)
		{
			member_grid.Reposition();
		}
		if ((Object)(object)m_title != (Object)null)
		{
			m_title.text = Localization.Get("Text.UI.ExplorationSummaryHeading") + m_party.locationsSearched;
		}
		AudioManager.Instance.PlayUI(open_sound);
	}

	public void SetExplorationParty(ExplorationParty party)
	{
		m_party = party;
	}

	public override void OnCancel()
	{
		base.OnCancel();
		UIPanelManager.Instance().PopPanel(this);
		m_party.OnExerienceDisplayComplete();
	}

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}
}
