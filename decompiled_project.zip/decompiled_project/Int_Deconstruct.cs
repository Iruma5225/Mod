using UnityEngine;

[AddComponentMenu("Sheltered/Interaction/Deconstruct")]
public class Int_Deconstruct : Int_Base
{
	[SerializeField]
	private CraftingManager.Recipe.Ingredient[] overrideItems = new CraftingManager.Recipe.Ingredient[0];

	[Range(0f, 1f)]
	[SerializeField]
	private float returnChance = 0.6f;

	[Range(0f, 1f)]
	[SerializeField]
	private float returnChance_Wasteful = 0.3f;

	[SerializeField]
	[Range(0f, 1f)]
	private float returnChance_Resourceful = 0.9f;

	public CraftingManager.Recipe.Ingredient[] OverrideItems => overrideItems;

	public float ReturnChance => returnChance;

	public float ReturnChance_Wasteful => returnChance_Wasteful;

	public float ReturnChance_Resourceful => returnChance_Resourceful;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_Deconstruct";
	}

	public override string GetInteractionType()
	{
		return "deconstruct";
	}

	public override int GetInteractionPriority()
	{
		return 15;
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool IsPlayerSelectable()
	{
		if ((Object)(object)obj == (Object)null || !obj.IsDeconstructable())
		{
			return false;
		}
		if (!obj.isBurningOrBurntOut && base.InteractionEnabled && (overrideItems.Length > 0 || !string.IsNullOrEmpty(obj.recipeId)))
		{
			return true;
		}
		return false;
	}
}
