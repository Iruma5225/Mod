using UnityEngine;

[RequireComponent(typeof(AudioSource))]
[AddComponentMenu("Sheltered/Interaction/Take Food")]
public class Int_TakeFood : Int_Base
{
	public AudioClip m_RummageSFX;

	public AudioClip m_FinishedSFX;

	[SerializeField]
	private int m_FoodUsed = 1;

	[SerializeField]
	private float m_HungerReduction = 25f;

	public int FoodUsed => m_FoodUsed;

	public float HungerReduction => m_HungerReduction;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_TakeFood";
	}

	public override string GetInteractionType()
	{
		return "take_food";
	}

	public void RummageSoundEffect()
	{
		if ((Object)(object)m_RummageSFX != (Object)null)
		{
			((Component)this).GetComponent<AudioSource>().PlayOneShot(m_RummageSFX);
		}
	}

	public void FinishedSoundEffect()
	{
		if ((Object)(object)m_FinishedSFX != (Object)null)
		{
			((Component)this).GetComponent<AudioSource>().PlayOneShot(m_FinishedSFX);
		}
	}

	public override bool IsPlayerSelectable()
	{
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}
}
