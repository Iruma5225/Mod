using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class Obj_Pantry : Obj_Base
{
	[SerializeField]
	private int m_Capacity = 100;

	[SerializeField]
	private float m_RationGeneration;

	private float m_NextRationGenerationTime;

	public List<Sprite> m_PantrySprites = new List<Sprite>();

	private SpriteRenderer m_PantrySprite;

	public int Capacity => m_Capacity;

	public float RationGeneration => m_RationGeneration;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.Pantry;
	}

	public override void Awake()
	{
		base.Awake();
		m_PantrySprite = ((Component)this).GetComponentInChildren<SpriteRenderer>();
	}

	public override void Start()
	{
		base.Start();
		if ((Object)(object)FoodManager.Instance != (Object)null)
		{
			FoodManager.Instance.RegisterStorage(this);
			OnFoodUpdated();
		}
		if (m_RationGeneration > 0f)
		{
			m_NextRationGenerationTime = Time.time + GameTime.RealSecondsPerDay / m_RationGeneration;
		}
	}

	public override void Update()
	{
		base.Update();
		if (m_RationGeneration > 0f && Time.time >= m_NextRationGenerationTime)
		{
			AddRations(1);
			m_NextRationGenerationTime = Time.time + GameTime.RealSecondsPerDay / m_RationGeneration;
		}
	}

	public override void OnDestroy()
	{
		base.OnDestroy();
		if ((Object)(object)FoodManager.Instance != (Object)null)
		{
			FoodManager.Instance.UnRegisterStorage(this);
			OnFoodUpdated();
		}
	}

	public void OnFoodUpdated()
	{
		if ((Object)(object)FoodManager.Instance != (Object)null && (Object)(object)m_PantrySprite != (Object)null && m_PantrySprites.Count > 0)
		{
			int num = Mathf.CeilToInt((float)FoodManager.Instance.Rations / (float)FoodManager.Instance.MaxRations * (float)(m_PantrySprites.Count - 1));
			num = Mathf.Clamp(num, 0, m_PantrySprites.Count - 1);
			if ((Object)(object)m_PantrySprites[num] != (Object)null)
			{
				m_PantrySprite.sprite = m_PantrySprites[num];
			}
		}
	}

	public bool AddRations(int amount)
	{
		if ((Object)(object)FoodManager.Instance != (Object)null)
		{
			return FoodManager.Instance.AddRations(amount);
		}
		return false;
	}

	public int TakeRations(int amount)
	{
		if ((Object)(object)FoodManager.Instance != (Object)null)
		{
			return FoodManager.Instance.TakeRations(amount);
		}
		return 0;
	}

	public int GetRations()
	{
		if ((Object)(object)FoodManager.Instance != (Object)null)
		{
			return FoodManager.Instance.Rations;
		}
		return 0;
	}

	public override void OnCheck()
	{
		base.OnCheck();
	}

	public override List<string> GetTooltipExtraInfo()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append(GetRations());
		stringBuilder.Append("/");
		stringBuilder.Append(FoodManager.Instance.MaxRations);
		List<string> list = new List<string>();
		list.Add(Localization.Get("clipboard.food"));
		list.Add(stringBuilder.ToString());
		return list;
	}

	public override bool IsReadyForLoad()
	{
		return (Object)(object)FoodManager.Instance != (Object)null && SaveManager.instance.HasBeenLoaded(FoodManager.Instance);
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		if (m_RationGeneration > 0f)
		{
			data.SaveLoadAbsoluteTime("next_ration", ref m_NextRationGenerationTime);
		}
		if (data.isLoading)
		{
			OnFoodUpdated();
		}
	}
}
