using UnityEngine;
using UnityEngine.SceneManagement;

public class UpsellPanel : BasePanel
{
	[SerializeField]
	private float m_panelDuration = 15f;

	private float m_closeTime;

	private bool m_fadeStarted;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override void OnShow()
	{
		base.OnShow();
		m_closeTime = Time.realtimeSinceStartup + m_panelDuration;
	}

	public override void Update()
	{
		if (m_closeTime > 0f && Time.realtimeSinceStartup >= m_closeTime && !m_fadeStarted)
		{
			m_fadeStarted = true;
			if ((Object)(object)ScreenFade.instance != (Object)null)
			{
				ScreenFade.instance.m_fadeComplete += OnFadeComplete;
				ScreenFade.instance.StartFade(2f);
			}
			else
			{
				OnFadeComplete();
			}
		}
	}

	private void OnFadeComplete()
	{
		if ((Object)(object)ScreenFade.instance != (Object)null)
		{
			ScreenFade.instance.m_fadeComplete -= OnFadeComplete;
		}
		SceneManager.LoadScene("MenuScene");
	}
}
