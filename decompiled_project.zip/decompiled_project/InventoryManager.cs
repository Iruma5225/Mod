using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

public class InventoryManager : BaseManagerNoUpdate, ISaveable
{
	private class Items
	{
		public List<ItemInstance> Instances = new List<ItemInstance>();
	}

	[Serializable]
	private class StartingItems
	{
		public ItemManager.ItemType Item = ItemManager.ItemType.Undefined;

		public int Count;
	}

	public delegate void ToolAddedDelegate(ItemManager.ItemType type);

	public delegate void ToolRemovedDelegate(ItemManager.ItemType type);

	private Dictionary<ItemManager.ItemType, Items> m_Inventory = new Dictionary<ItemManager.ItemType, Items>();

	[SerializeField]
	private List<StartingItems> m_StartingInventory = new List<StartingItems>();

	[SerializeField]
	private int numberOfRandomStartingItems;

	[SerializeField]
	private int maxStackSizeOfRandStartItems;

	[SerializeField]
	private List<ItemManager.ItemType> listOfRandomStartingItems = new List<ItemManager.ItemType>();

	[SerializeField]
	private int m_storageCapacity = 32;

	private List<Obj_Storage> m_storageUnits = new List<Obj_Storage>();

	private List<ItemManager.ItemType> m_Tools = new List<ItemManager.ItemType>();

	private static InventoryManager m_theInstance;

	public int storageCapacity => m_storageCapacity;

	public ReadOnlyCollection<ItemManager.ItemType> Tools => (m_Tools == null) ? null : m_Tools.AsReadOnly();

	public int ToolCount => m_Tools.Count;

	public static InventoryManager Instance => m_theInstance;

	public event ToolAddedDelegate onToolAdded;

	public event ToolRemovedDelegate onToolRemoved;

	private void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
		}
		else
		{
			Debug.Log((object)"Duplicate InventoryManager created!");
		}
	}

	public override void StartManager()
	{
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
	}

	public void InitialiseInventory()
	{
		if (m_Inventory.Count > 0 || (Object)(object)ItemManager.Instance == (Object)null)
		{
			return;
		}
		List<ItemManager.ItemType> allDefinedItems = ItemManager.Instance.GetAllDefinedItems();
		for (int i = 0; i < allDefinedItems.Count; i++)
		{
			m_Inventory.Add(allDefinedItems[i], new Items());
		}
		if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading)
		{
			for (int j = 0; j < m_StartingInventory.Count; j++)
			{
				AddNewItems(m_StartingInventory[j].Item, m_StartingInventory[j].Count);
			}
			AddRandomStartingItems(numberOfRandomStartingItems, maxStackSizeOfRandStartItems);
		}
	}

	public void AddRandomStartingItems(int randomStacks, int maxStackSize)
	{
		for (int i = 0; i < randomStacks; i++)
		{
			int num = Random.Range(0, listOfRandomStartingItems.Count);
			if (num >= 0 && num < listOfRandomStartingItems.Count)
			{
				AddNewItems(listOfRandomStartingItems[num], Random.Range(1, maxStackSize));
			}
		}
	}

	public bool AddNewItems(ItemManager.ItemType type, int count)
	{
		if (count > 0 && type != ItemManager.ItemType.Undefined)
		{
			for (int i = 0; i < count; i++)
			{
				if (!AddNewItem(type))
				{
					return false;
				}
			}
			return true;
		}
		return false;
	}

	public List<ItemInstance> GetAllItemsOfTypeRange(ItemManager.ItemType itemStart, ItemManager.ItemType itemEnd)
	{
		if (itemStart == ItemManager.ItemType.Undefined || itemEnd == ItemManager.ItemType.Undefined)
		{
			return null;
		}
		Items value = null;
		List<ItemInstance> list = new List<ItemInstance>();
		for (int i = (int)itemStart; i <= (int)itemEnd; i++)
		{
			if (m_Inventory.TryGetValue((ItemManager.ItemType)i, out value) && value.Instances != null)
			{
				list.AddRange(value.Instances);
			}
		}
		return list;
	}

	public List<ItemInstance> GetAllCombatItems()
	{
		List<ItemInstance> list = new List<ItemInstance>();
		foreach (KeyValuePair<ItemManager.ItemType, Items> item in m_Inventory)
		{
			if (ItemManager.Instance.HasCombatDefinition(item.Key))
			{
				list.AddRange(item.Value.Instances);
			}
		}
		return list;
	}

	public int GetNumItemsOfType(ItemManager.ItemType item)
	{
		if (item == ItemManager.ItemType.Undefined)
		{
			return 0;
		}
		Items value = null;
		if (m_Inventory.TryGetValue(item, out value) && value.Instances != null)
		{
			return value.Instances.Count;
		}
		return 0;
	}

	public int GetNumOfSpecificTools(ItemManager.ItemType tool)
	{
		int num = 0;
		if (tool == ItemManager.ItemType.Undefined)
		{
			return 0;
		}
		for (int i = 0; i < m_Tools.Count; i++)
		{
			if (m_Tools[i] == tool)
			{
				num++;
				num += GetNumItemsOfType(tool);
				break;
			}
		}
		return num;
	}

	public int GetTotalStackCount()
	{
		int num = 0;
		List<Items> list = new List<Items>();
		list.AddRange(m_Inventory.Values);
		for (int i = 0; i < list.Count; i++)
		{
			if (list[i].Instances.Count <= 0)
			{
				continue;
			}
			ItemDefinition itemDefinition = list[i].Instances[0].GetItemDefinition();
			if (!((Object)(object)itemDefinition != (Object)null))
			{
				continue;
			}
			int num2 = 1;
			if (itemDefinition.StackSize > 0)
			{
				num2 = list[i].Instances.Count / itemDefinition.StackSize;
				if (list[i].Instances.Count % itemDefinition.StackSize > 0)
				{
					num2++;
				}
			}
			num += num2;
		}
		return num;
	}

	public bool AddExistingItem(ItemInstance item)
	{
		if (item.Type == ItemManager.ItemType.Undefined)
		{
			return false;
		}
		Items value = null;
		if (m_Inventory.TryGetValue(item.Type, out value))
		{
			ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(item.Type);
			if (itemDefinition.Category == ItemManager.ItemCategory.Undefined || itemDefinition.Category == ItemManager.ItemCategory.Object)
			{
				return false;
			}
			if (itemDefinition.Category == ItemManager.ItemCategory.Tool && !m_Tools.Contains(item.Type))
			{
				m_Tools.Add(item.Type);
				if (this.onToolAdded != null)
				{
					this.onToolAdded(item.Type);
				}
				return true;
			}
			if (itemDefinition.Category == ItemManager.ItemCategory.Food && (Object)(object)FoodManager.Instance != (Object)null)
			{
				FoodManager.Instance.AddRations(itemDefinition.RationValue);
				return true;
			}
			if (itemDefinition.Category == ItemManager.ItemCategory.Meat)
			{
				List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Freezer);
				List<Obj_Freezer> list = new List<Obj_Freezer>();
				List<Obj_Freezer> list2 = new List<Obj_Freezer>();
				for (int i = 0; i < objectsOfType.Count; i++)
				{
					Obj_Freezer obj_Freezer = objectsOfType[i] as Obj_Freezer;
					if ((Object)(object)obj_Freezer != (Object)null)
					{
						if (obj_Freezer.IsMeatContaminated())
						{
							list.Add(obj_Freezer);
						}
						else
						{
							list2.Add(obj_Freezer);
						}
					}
				}
				bool flag = false;
				for (int j = 0; j < list2.Count; j++)
				{
					Obj_Freezer obj_Freezer2 = list2[j];
					if ((Object)(object)obj_Freezer2 != (Object)null && obj_Freezer2.TotalSpaceAvailable() > 0)
					{
						if (itemDefinition.ItemType == ItemManager.ItemType.Meat)
						{
							flag = obj_Freezer2.AddMeat(1) > 0;
							break;
						}
						if (itemDefinition.ItemType == ItemManager.ItemType.DesperateMeat)
						{
							flag = obj_Freezer2.AddDesperateMeat(1) > 0;
							break;
						}
					}
				}
				if (!flag)
				{
					for (int k = 0; k < list.Count; k++)
					{
						Obj_Freezer obj_Freezer3 = list[k];
						if ((Object)(object)obj_Freezer3 != (Object)null && obj_Freezer3.TotalSpaceAvailable() > 0)
						{
							if (itemDefinition.ItemType == ItemManager.ItemType.Meat)
							{
								flag = obj_Freezer3.AddMeat(1) > 0;
								break;
							}
							if (itemDefinition.ItemType == ItemManager.ItemType.DesperateMeat)
							{
								flag = obj_Freezer3.AddDesperateMeat(1) > 0;
								break;
							}
						}
					}
				}
				return flag;
			}
			if (itemDefinition.Category == ItemManager.ItemCategory.Water && (Object)(object)WaterManager.Instance != (Object)null)
			{
				WaterManager.Instance.AddWater(itemDefinition.RationValue);
				WaterManager.Instance.AddContamination(itemDefinition.Contamination);
				return true;
			}
			if (itemDefinition.Category == ItemManager.ItemCategory.Entertainment && (Object)(object)EntertainmentManager.Instance != (Object)null && EntertainmentManager.Instance.AddItem(item.Type))
			{
				return true;
			}
			if (itemDefinition.Category == ItemManager.ItemCategory.Schematic)
			{
				if ((Object)(object)CraftingManager.Instance != (Object)null)
				{
					CraftingManager.Instance.UnlockRecipe(itemDefinition.RecipeID);
					return true;
				}
				if ((Object)(object)ExpeditionMap.Instance != (Object)null)
				{
					ExpeditionMap.Instance.SpecialItemRemoved(item.Type);
				}
			}
			if (value.Instances != null)
			{
				int totalStackCount = GetTotalStackCount();
				value.Instances.Add(item);
				int totalStackCount2 = GetTotalStackCount();
				if (totalStackCount < m_storageCapacity && totalStackCount2 >= m_storageCapacity && (Object)(object)ActivityLog.Instance != (Object)null)
				{
					ActivityLog.Instance.Add(ActivityLog.Activity.StorageFull);
				}
				if (totalStackCount2 > m_storageCapacity)
				{
					value.Instances.Remove(item);
					return false;
				}
				return true;
			}
		}
		return false;
	}

	public bool AddNewItem(ItemManager.ItemType item)
	{
		if (item == ItemManager.ItemType.Undefined)
		{
			return false;
		}
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(item);
		if ((Object)(object)itemDefinition != (Object)null)
		{
			if (itemDefinition.Category == ItemManager.ItemCategory.Object)
			{
				return false;
			}
			if (!AddExistingItem(new ItemInstance(item)))
			{
				return false;
			}
			if ((Object)(object)AchievementManager.instance != (Object)null)
			{
				AchievementManager.instance.OnItemAddedToInventory(item, 1);
			}
			return true;
		}
		return false;
	}

	public bool RemoveItemOfType(ItemManager.ItemType item)
	{
		if (item == ItemManager.ItemType.Undefined)
		{
			return false;
		}
		Items value = null;
		if (m_Inventory.TryGetValue(item, out value))
		{
			if (value.Instances != null && value.Instances.Count > 0)
			{
				value.Instances.RemoveAt(0);
				return true;
			}
			ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(item);
			if ((Object)(object)itemDefinition != (Object)null && itemDefinition.Category == ItemManager.ItemCategory.Tool && m_Tools.Contains(item))
			{
				m_Tools.Remove(item);
				if (this.onToolRemoved != null)
				{
					this.onToolRemoved(item);
				}
				return true;
			}
		}
		return false;
	}

	public bool RemoveItemsOfType(ItemManager.ItemType item, int quantity)
	{
		if (item == ItemManager.ItemType.Undefined)
		{
			return false;
		}
		if (quantity <= 0)
		{
			return true;
		}
		Items value = null;
		if (m_Inventory.TryGetValue(item, out value) && value.Instances != null && value.Instances.Count > 0)
		{
			int num = quantity;
			for (int num2 = value.Instances.Count - 1; num2 >= 0; num2--)
			{
				if (num <= 0)
				{
					return true;
				}
				value.Instances.RemoveAt(num2);
				num--;
			}
			if (num <= 0)
			{
				return true;
			}
		}
		return false;
	}

	public bool RemoveAllItemsOfType(ItemManager.ItemType item)
	{
		if (item == ItemManager.ItemType.Undefined)
		{
			return false;
		}
		Items value = null;
		if (m_Inventory.TryGetValue(item, out value) && value.Instances != null)
		{
			value.Instances.Clear();
			return true;
		}
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(item);
		if ((Object)(object)itemDefinition != (Object)null && itemDefinition.Category == ItemManager.ItemCategory.Tool && m_Tools.Contains(item))
		{
			m_Tools.Remove(item);
			if (this.onToolRemoved != null)
			{
				this.onToolRemoved(item);
			}
			return true;
		}
		return false;
	}

	public List<ItemStack> GetItems()
	{
		List<ItemStack> list = new List<ItemStack>();
		foreach (KeyValuePair<ItemManager.ItemType, Items> item in m_Inventory)
		{
			if (item.Key != ItemManager.ItemType.Undefined && item.Value.Instances != null)
			{
				list.Add(new ItemStack(item.Key, item.Value.Instances.Count));
			}
		}
		return list;
	}

	public bool CanCraftRecipe(CraftingManager.Recipe recipe)
	{
		if (recipe == null || recipe.Result == ItemManager.ItemType.Undefined)
		{
			return false;
		}
		for (int i = 0; i < recipe.Input.Length; i++)
		{
			if (recipe.Input[i].Quantity > GetNumItemsOfType(recipe.Input[i].Item))
			{
				return false;
			}
		}
		return true;
	}

	public bool IsInventoryFull()
	{
		int totalStackCount = GetTotalStackCount();
		if (totalStackCount >= m_storageCapacity)
		{
			return true;
		}
		return false;
	}

	public void RegisterStorage(Obj_Storage storage)
	{
		if (!m_storageUnits.Contains(storage))
		{
			m_storageUnits.Add(storage);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_storageCapacity += storage.storageCapacity;
			}
		}
	}

	public void UnRegisterStorage(Obj_Storage storage)
	{
		if (m_storageUnits.Contains(storage))
		{
			m_storageUnits.Remove(storage);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_storageCapacity -= storage.storageCapacity;
			}
		}
	}

	public bool IsRelocationEnabled()
	{
		return false;
	}

	public bool IsReadyForLoad()
	{
		return (Object)(object)ItemManager.Instance != (Object)null;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("InventoryManager");
		if (data.isLoading)
		{
			m_Inventory.Clear();
			m_Tools.Clear();
			if ((Object)(object)ItemManager.Instance != (Object)null)
			{
				List<ItemManager.ItemType> allDefinedItems = ItemManager.Instance.GetAllDefinedItems();
				for (int i = 0; i < allDefinedItems.Count; i++)
				{
					m_Inventory.Add(allDefinedItems[i], new Items());
				}
			}
		}
		data.SaveLoad("storage", ref m_storageCapacity);
		data.SaveLoadList("tools", m_Tools, delegate(int index)
		{
			int value = (int)m_Tools[index];
			data.SaveLoad("type", ref value);
		}, delegate
		{
			int value = -1;
			data.SaveLoad("type", ref value);
			m_Tools.Add((ItemManager.ItemType)value);
			if (this.onToolAdded != null)
			{
				this.onToolAdded((ItemManager.ItemType)value);
			}
		});
		List<ItemManager.ItemType> itemTypes = new List<ItemManager.ItemType>(m_Inventory.Keys);
		data.SaveLoadList("inventory", itemTypes, delegate(int index)
		{
			int value = (int)itemTypes[index];
			int value2 = m_Inventory[itemTypes[index]].Instances.Count;
			data.SaveLoad("type", ref value);
			data.SaveLoad("count", ref value2);
		}, delegate
		{
			int value = -1;
			int value2 = 0;
			data.SaveLoad("type", ref value);
			data.SaveLoad("count", ref value2);
			ItemManager.ItemType itemType = (ItemManager.ItemType)value;
			if (itemType != ItemManager.ItemType.Undefined && m_Inventory.ContainsKey(itemType) && value2 > 0)
			{
				for (int j = 0; j < value2; j++)
				{
					m_Inventory[itemType].Instances.Add(new ItemInstance(itemType));
				}
			}
		});
		data.GroupEnd();
		return true;
	}
}
