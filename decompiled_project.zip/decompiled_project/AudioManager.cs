using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;

public class AudioManager : BaseManagerNoUpdate
{
	public enum MixerEnum
	{
		Master,
		Shelter,
		Encounter
	}

	[SerializeField]
	private List<AudioClip> m_shelterMusic = new List<AudioClip>();

	[SerializeField]
	private List<AudioClip> m_breachMusic = new List<AudioClip>();

	[SerializeField]
	private AudioClip showItemHelp_SFX;

	[SerializeField]
	private AudioClip closeItemHelp_SFX;

	private int m_prevMusicIndex;

	public AudioClip menuMusic;

	[SerializeField]
	[Header("Mixers")]
	private AudioMixer masterMixer;

	[SerializeField]
	private AudioMixer shelterMixer;

	[SerializeField]
	private AudioMixer encounterMixer;

	[SerializeField]
	[Header("SFX Audio Sources")]
	private AudioSource shelter_sfx;

	[SerializeField]
	private AudioSource encounter_sfx;

	[SerializeField]
	[Header("Music / Ambience")]
	private MusicSound shelter_music;

	[SerializeField]
	private MusicSound encounter_music;

	[SerializeField]
	private MusicSound shelter_ambience;

	[SerializeField]
	private MusicSound encounter_ambience;

	[Range(0f, 1f)]
	[SerializeField]
	[Header("Preferences")]
	private float userPrefsSFX = 1f;

	[Range(0f, 1f)]
	[SerializeField]
	private float userPrefsMusic = 1f;

	[Range(0f, 1f)]
	[SerializeField]
	private float userPrefsUI = 1f;

	private AudioSource audio_source;

	private static AudioManager m_theInstance;

	private const float MinDBValue = -30f;

	private const float MaxDBValue = 0f;

	public AudioClip ShowItemHelpSFX => showItemHelp_SFX;

	public AudioClip CloseItemHelpSFX => closeItemHelp_SFX;

	public float MusicVolume
	{
		get
		{
			return userPrefsMusic;
		}
		set
		{
			userPrefsMusic = Mathf.Clamp01(value);
			Debug.Log((object)("AudioManager : Music volume set to " + userPrefsMusic));
			ApplyUserPreferences();
		}
	}

	public float SfxVolume
	{
		get
		{
			return userPrefsSFX;
		}
		set
		{
			userPrefsSFX = Mathf.Clamp01(value);
			Debug.Log((object)("AudioManager : Sfx volume set to " + userPrefsSFX));
			ApplyUserPreferences();
		}
	}

	public float UiVolume
	{
		get
		{
			return userPrefsUI;
		}
		set
		{
			userPrefsUI = Mathf.Clamp01(value);
			Debug.Log((object)("AudioManager : UI volume set to " + userPrefsUI));
			ApplyUserPreferences();
		}
	}

	public static AudioManager Instance => m_theInstance;

	public void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
			if ((Object)(object)SaveManager.instance != (Object)null)
			{
				SaveManager.instance.onGlobalDataLoaded -= GlobalSaveDataLoaded;
				SaveManager.instance.onGlobalDataLoaded += GlobalSaveDataLoaded;
			}
		}
		else
		{
			Debug.Log((object)"Duplicate AudioManager created!");
		}
	}

	public override void StartManager()
	{
		if ((Object)(object)shelter_sfx != (Object)null)
		{
			shelter_sfx.ignoreListenerPause = true;
		}
		if ((Object)(object)encounter_sfx != (Object)null)
		{
			encounter_sfx.ignoreListenerPause = true;
		}
		if (m_shelterMusic.Count > 0)
		{
			int num = Random.Range(0, m_shelterMusic.Count);
			PlayMusic(m_shelterMusic[num]);
			m_prevMusicIndex = num;
		}
	}

	private void Update()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)shelter_music != (Object)null) || !shelter_music.isFinished)
		{
			return;
		}
		Scene activeScene = SceneManager.GetActiveScene();
		if (((Scene)(ref activeScene)).name != "ShelterScene")
		{
			PlayMusic(shelter_music.currentSound);
		}
		else if ((Object)(object)BreachMan.instance != (Object)null && BreachMan.instance.inProgress && m_breachMusic.Count > 0)
		{
			PlayMusic(m_breachMusic[Random.Range(0, m_breachMusic.Count)]);
		}
		else if (m_shelterMusic.Count > 0)
		{
			int num = Random.Range(0, m_shelterMusic.Count);
			if (num == m_prevMusicIndex && ++num >= m_shelterMusic.Count)
			{
				num = 0;
			}
			PlayMusic(m_shelterMusic[num]);
			m_prevMusicIndex = num;
		}
	}

	private AudioMixer GetMixerForType(MixerEnum mixerType)
	{
		return (AudioMixer)(mixerType switch
		{
			MixerEnum.Master => masterMixer, 
			MixerEnum.Shelter => shelterMixer, 
			MixerEnum.Encounter => encounterMixer, 
			_ => null, 
		});
	}

	public void SetMixerValue(MixerEnum type, string parameter, float value)
	{
		AudioMixer mixerForType = GetMixerForType(type);
		if (!((Object)(object)mixerForType == (Object)null))
		{
			mixerForType.SetFloat(parameter, value);
		}
	}

	private void GlobalSaveDataLoaded(bool success)
	{
		if (success)
		{
			Debug.Log((object)"AudioManager : Global save loaded");
			SfxVolume = SaveGlobal.Instance.sfxVolume;
			MusicVolume = SaveGlobal.Instance.musicVolume;
			UiVolume = SaveGlobal.Instance.uiVolume;
		}
		else
		{
			SfxVolume = 1f;
			MusicVolume = 1f;
			UiVolume = 1f;
		}
	}

	private void ApplyUserPreferences()
	{
		SetMixerValue(MixerEnum.Master, "UserUI", ConvertPercentageToDecibel(userPrefsUI));
		SetMixerValue(MixerEnum.Shelter, "UserSFX", ConvertPercentageToDecibel(userPrefsSFX));
		SetMixerValue(MixerEnum.Encounter, "UserSFX", ConvertPercentageToDecibel(userPrefsSFX));
		SetMixerValue(MixerEnum.Shelter, "UserMusic", ConvertPercentageToDecibel(userPrefsMusic));
		SetMixerValue(MixerEnum.Encounter, "UserMusic", ConvertPercentageToDecibel(userPrefsMusic));
	}

	private static float ConvertPercentageToDecibel(float percentage)
	{
		float result = -80f;
		if (percentage >= 0.1f)
		{
			float num = Mathf.Log10(percentage * 10f);
			result = Mathf.Lerp(-30f, 0f, num);
		}
		return result;
	}

	public void PlaySFX(AudioClip clip, MixerEnum mixerType = MixerEnum.Shelter)
	{
		if (!((Object)(object)clip == (Object)null))
		{
			if (mixerType == MixerEnum.Shelter && (Object)(object)shelter_sfx != (Object)null)
			{
				shelter_sfx.PlayOneShot(clip);
			}
			if (mixerType == MixerEnum.Encounter && (Object)(object)encounter_sfx != (Object)null)
			{
				encounter_sfx.PlayOneShot(clip);
			}
		}
	}

	public void PlayMusic(AudioClip clip, bool encounter = false)
	{
		if (encounter)
		{
			if ((Object)(object)encounter_music != (Object)null)
			{
				encounter_music.SetPendingSound(clip);
			}
		}
		else if ((Object)(object)shelter_music != (Object)null)
		{
			shelter_music.SetPendingSound(clip);
		}
	}

	public void PlayAmbience(AudioClip clip, bool encounter = false)
	{
		if (encounter)
		{
			if ((Object)(object)encounter_ambience != (Object)null)
			{
				encounter_ambience.SetPendingSound(clip);
			}
		}
		else if ((Object)(object)shelter_ambience != (Object)null)
		{
			shelter_ambience.SetPendingSound(clip);
		}
	}

	public void PlayUI(AudioClip clip)
	{
		if (!((Object)(object)clip == (Object)null) && (Object)(object)UISound.instance != (Object)null)
		{
			UISound.instance.Play(clip);
		}
	}

	public void TransitionToEncounter(float time = 0f)
	{
		if (!((Object)(object)masterMixer == (Object)null))
		{
			AudioMixerSnapshot val = masterMixer.FindSnapshot("Encounter");
			if (!((Object)(object)val == (Object)null))
			{
				val.TransitionTo(time);
			}
		}
	}

	public void TransitionToShelter(float time = 0f)
	{
		if (!((Object)(object)masterMixer == (Object)null))
		{
			AudioMixerSnapshot val = masterMixer.FindSnapshot("Shelter");
			if (!((Object)(object)val == (Object)null))
			{
				val.TransitionTo(time);
			}
		}
	}

	public void StartBreachMusic()
	{
		if (m_breachMusic != null)
		{
			PlayMusic(m_breachMusic[Random.Range(0, m_breachMusic.Count)]);
		}
	}

	public void StopBreachMusic()
	{
		if (m_shelterMusic.Count > 0)
		{
			int num = Random.Range(0, m_shelterMusic.Count);
			PlayMusic(m_shelterMusic[num]);
			m_prevMusicIndex = num;
		}
	}
}
