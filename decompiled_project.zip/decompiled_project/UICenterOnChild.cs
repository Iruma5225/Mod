using UnityEngine;

[AddComponentMenu("NGUI/Interaction/Center Scroll View on Child")]
public class UICenterOnChild : MonoBehaviour
{
	public delegate void OnCenterCallback(GameObject centeredObject);

	public float springStrength = 8f;

	public float nextPageThreshold;

	public bool bConstrainWithinGrid;

	public bool bWorkOnUpdate;

	public SpringPanel.OnFinished onFinished;

	public OnCenterCallback onCenter;

	private UIScrollView mScrollView;

	private GameObject mCenteredObject;

	private UIGrid mChildGrid;

	public GameObject centeredObject => mCenteredObject;

	private void OnEnable()
	{
		Recenter();
	}

	private void OnDragFinished()
	{
		if (((Behaviour)this).enabled)
		{
			Recenter();
		}
	}

	private void OnValidate()
	{
		nextPageThreshold = Mathf.Abs(nextPageThreshold);
	}

	[ContextMenu("Execute")]
	public void Recenter()
	{
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		Transform transform = ((Component)this).transform;
		if (transform.childCount == 0)
		{
			return;
		}
		if ((Object)(object)mScrollView == (Object)null)
		{
			mScrollView = NGUITools.FindInParents<UIScrollView>(((Component)this).gameObject);
			if ((Object)(object)mScrollView == (Object)null)
			{
				Debug.LogWarning((object)string.Concat(((object)this).GetType(), " requires ", typeof(UIScrollView), " on a parent object in order to work"), (Object)(object)this);
				((Behaviour)this).enabled = false;
				return;
			}
			mScrollView.onDragFinished = OnDragFinished;
			if ((Object)(object)mScrollView.horizontalScrollBar != (Object)null)
			{
				mScrollView.horizontalScrollBar.onDragFinished = OnDragFinished;
			}
			if ((Object)(object)mScrollView.verticalScrollBar != (Object)null)
			{
				mScrollView.verticalScrollBar.onDragFinished = OnDragFinished;
			}
		}
		if ((Object)(object)mScrollView.panel == (Object)null)
		{
			return;
		}
		Vector3[] worldCorners = mScrollView.panel.worldCorners;
		Vector3 val = (worldCorners[2] + worldCorners[0]) * 0.5f;
		Vector3 val2 = val - mScrollView.currentMomentum * (mScrollView.momentumAmount * 0.1f);
		mScrollView.currentMomentum = Vector3.zero;
		float num = float.MaxValue;
		Transform target = null;
		int num2 = 0;
		int i = 0;
		for (int childCount = transform.childCount; i < childCount; i++)
		{
			Transform child = transform.GetChild(i);
			if (((Component)child).gameObject.activeInHierarchy)
			{
				float num3 = Vector3.SqrMagnitude(child.position - val2);
				if (num3 < num)
				{
					num = num3;
					target = child;
					num2 = i;
				}
			}
		}
		if (nextPageThreshold > 0f && UICamera.currentTouch != null && (Object)(object)mCenteredObject != (Object)null && (Object)(object)mCenteredObject.transform == (Object)(object)transform.GetChild(num2))
		{
			Vector2 totalDelta = UICamera.currentTouch.totalDelta;
			float num4 = 0f;
			num4 = mScrollView.movement switch
			{
				UIScrollView.Movement.Horizontal => totalDelta.x, 
				UIScrollView.Movement.Vertical => totalDelta.y, 
				_ => ((Vector2)(ref totalDelta)).magnitude, 
			};
			if (num4 > nextPageThreshold)
			{
				if (num2 > 0)
				{
					target = transform.GetChild(num2 - 1);
				}
			}
			else if (num4 < 0f - nextPageThreshold && num2 < transform.childCount - 1)
			{
				target = transform.GetChild(num2 + 1);
			}
		}
		CenterOn(target, val);
	}

	private void CenterOn(Transform target, Vector3 panelCenter)
	{
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)mChildGrid == (Object)null)
		{
			mChildGrid = ((Component)((Component)this).transform).GetComponentInChildren<UIGrid>();
			if (!((Object)(object)mChildGrid == (Object)null))
			{
			}
		}
		if ((Object)(object)target != (Object)null && (Object)(object)mScrollView != (Object)null && (Object)(object)mScrollView.panel != (Object)null)
		{
			Transform cachedTransform = mScrollView.panel.cachedTransform;
			mCenteredObject = ((Component)target).gameObject;
			Vector3 val = Vector3.zero;
			if (bConstrainWithinGrid)
			{
				Vector3[] sides = mScrollView.panel.GetSides(target);
				if (mScrollView.canMoveVertically)
				{
					float num = mChildGrid.cellHeight * 0.5f;
					if (sides[3].y > 0f - num)
					{
						val.y = (sides[3].y + num) * -1f;
					}
					else if (sides[1].y < num)
					{
						val.y = (sides[1].y - num) * -1f;
					}
				}
				if (mScrollView.canMoveHorizontally)
				{
					float num2 = mChildGrid.cellWidth * 0.5f;
					if (sides[0].x > 0f - num2)
					{
						val.x = (sides[0].x + num2) * -1f;
					}
					else if (sides[2].x < num2)
					{
						val.x = (sides[2].x - num2) * -1f;
					}
				}
			}
			else
			{
				val = cachedTransform.InverseTransformPoint(target.position) - cachedTransform.InverseTransformPoint(panelCenter);
				if (!mScrollView.canMoveHorizontally)
				{
					val.x = 0f;
				}
				if (!mScrollView.canMoveVertically)
				{
					val.y = 0f;
				}
			}
			val.z = 0f;
			SpringPanel.Begin(mScrollView.panel.cachedGameObject, cachedTransform.localPosition - val, springStrength).onFinished = onFinished;
		}
		else
		{
			mCenteredObject = null;
		}
		if (onCenter != null)
		{
			onCenter(mCenteredObject);
		}
	}

	public void CenterOn(Transform target)
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)mScrollView == (Object)null)
		{
			mScrollView = NGUITools.FindInParents<UIScrollView>(((Component)this).gameObject);
		}
		if ((Object)(object)mScrollView != (Object)null && (Object)(object)mScrollView.panel != (Object)null)
		{
			Vector3[] worldCorners = mScrollView.panel.worldCorners;
			Vector3 panelCenter = (worldCorners[2] + worldCorners[0]) * 0.5f;
			CenterOn(target, panelCenter);
		}
	}

	private void Update()
	{
		if (!bWorkOnUpdate)
		{
			return;
		}
		if ((Object)(object)mChildGrid != (Object)null)
		{
			GameObject selectedObject = UICamera.selectedObject;
			if (!((Object)(object)selectedObject != (Object)null) || !((Object)(object)mCenteredObject != (Object)(object)selectedObject))
			{
				return;
			}
			BetterList<Transform> childList = mChildGrid.GetChildList();
			int size = childList.size;
			for (int i = 0; i < size; i++)
			{
				if ((Object)(object)((Component)childList[i]).gameObject == (Object)(object)selectedObject)
				{
					CenterOn(selectedObject.transform);
					break;
				}
			}
		}
		else
		{
			mChildGrid = ((Component)((Component)this).transform).GetComponentInChildren<UIGrid>();
			if (!((Object)(object)mChildGrid == (Object)null))
			{
			}
		}
	}
}
