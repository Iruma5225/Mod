using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class Interruption_Vomit : Interruption_Base
{
	[SerializeField]
	private Vector2 vomit_offset = Vector2.zero;

	[SerializeField]
	private float spawn_vomit_time = 2.6f;

	private bool vomit_spawned;

	[SerializeField]
	private float vomit_time_min;

	[SerializeField]
	private float vomit_time_max;

	[SerializeField]
	private List<AudioClip> vomit_sounds = new List<AudioClip>();

	private float next_vomit_wait;

	public override void Initialize(FamilyMember member)
	{
		base.Initialize(member);
		next_vomit_wait = Random.Range(vomit_time_min, vomit_time_max);
	}

	public override void UpdateInterruption()
	{
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		if (!base.isActive)
		{
			if (m_member.illness.foodPoisoning.isActive)
			{
				next_vomit_wait -= Time.deltaTime;
				if (m_member.IsIdle() && next_vomit_wait <= 0f)
				{
					Activate();
					next_vomit_wait = Random.Range(vomit_time_min, vomit_time_max);
				}
			}
		}
		else if (Time.time >= end_time)
		{
			Deactivate();
		}
		else
		{
			if (vomit_spawned || !(Time.time >= start_time + spawn_vomit_time))
			{
				return;
			}
			vomit_spawned = true;
			if ((Object)(object)LitterManager.Instance != (Object)null)
			{
				Vector3 val = Vector2.op_Implicit(vomit_offset);
				if ((Object)(object)m_member != (Object)null && m_member.meshLocalScale.x < 0f)
				{
					val.x *= -1f;
				}
				LitterManager.Instance.DropLitter(((Component)m_member).transform.position + val, LitterManager.LitterType.Vomit);
			}
		}
	}

	protected override void OnStartInterruption()
	{
		base.OnStartInterruption();
		if (m_member.IsNearWall())
		{
			if (m_member.IsNearWall(behind: true))
			{
				Deactivate();
				return;
			}
			m_member.ChangeFacingDirection();
		}
		m_member.TriggerAnim("Vomit");
		if (vomit_sounds != null && vomit_sounds.Count > 0)
		{
			m_member.PlaySound(vomit_sounds[Random.Range(0, vomit_sounds.Count)]);
		}
		m_member.stats.dirtiness.Modify(10f);
		vomit_spawned = false;
	}

	protected override void OnEndInterruption()
	{
		base.OnEndInterruption();
	}

	public override void SaveLoadInterruption(SaveData data)
	{
		data.GroupStart("Vomit");
		base.SaveLoadInterruption(data);
		data.SaveLoad("vomit_spawned", ref vomit_spawned);
		data.SaveLoad("next_vomit_wait", ref next_vomit_wait);
		data.GroupEnd();
	}
}
