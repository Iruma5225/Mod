using UnityEngine;

public class Int_HarvestPet : Int_Base
{
	[SerializeField]
	private int meat;

	public int Meat => meat;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_HarvestPet";
	}

	public override string GetInteractionType()
	{
		return "harvest_pet";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		if (!base.IsPlayerSelectable())
		{
			return false;
		}
		Obj_Pet obj_Pet = obj as Obj_Pet;
		if ((Object)(object)obj_Pet == (Object)null || !obj_Pet.isDead || obj_Pet.hasBeenHarvested)
		{
			return false;
		}
		if (FoodManager.Instance.MaxMeat - FoodManager.Instance.TotalMeat <= 0)
		{
			return false;
		}
		return true;
	}
}
