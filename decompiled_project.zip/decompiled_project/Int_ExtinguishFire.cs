using UnityEngine;

public class Int_ExtinguishFire : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "extinguish_fire";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		return (Object)(object)obj != (Object)null && obj.isBurning && WaterManager.Instance.StoredWater > 0f;
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		if (member.job_queue.isFull)
		{
			return false;
		}
		return member.AddPlayerJob(new Job_ExtinguishFires(member, null, obj));
	}
}
