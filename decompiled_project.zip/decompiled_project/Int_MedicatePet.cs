using UnityEngine;

public class Int_MedicatePet : Int_Base
{
	public bool crouch;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_MedicatePet";
	}

	public override string GetInteractionType()
	{
		return "medicate_pet";
	}

	public override int GetInteractionPriority()
	{
		return 3;
	}

	public override bool IsPlayerSelectable()
	{
		if (!base.IsPlayerSelectable())
		{
			return false;
		}
		Obj_Pet obj_Pet = obj as Obj_Pet;
		if ((Object)(object)obj_Pet == (Object)null || obj_Pet.hasFood || obj_Pet.isDead)
		{
			return false;
		}
		if ((Object)(object)InventoryManager.Instance == (Object)null || InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.AntiRadMedicine) <= 0)
		{
			return false;
		}
		return true;
	}
}
