using UnityEngine;

public class ForumLink : MonoBehaviour
{
	private readonly string unicubeUrl = "http://www.unicube.net/discussion-forum/";

	private string m_Url;

	public AudioClip buttonSound;

	public void Awake()
	{
		m_Url = GetPlatformUrl();
		UILabel component = ((Component)this).GetComponent<UILabel>();
		if ((Object)(object)component != (Object)null)
		{
			string text = Localization.Get("text.ui.forum");
			text += m_Url;
			component.text = text;
		}
	}

	private string GetPlatformUrl()
	{
		return unicubeUrl;
	}

	public void OnClick()
	{
	}

	public void FacebookLink()
	{
		if ((Object)(object)buttonSound != (Object)null)
		{
			UISound.instance.Play(buttonSound);
		}
		Application.OpenURL("https://www.facebook.com/unicubestudios/");
	}

	public void TwitterLink()
	{
		if ((Object)(object)buttonSound != (Object)null)
		{
			UISound.instance.Play(buttonSound);
		}
		Application.OpenURL("https://twitter.com/unicube");
	}
}
