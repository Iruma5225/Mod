using System.Collections.Generic;
using UnityEngine;

public class ContextMenuLayer : MonoBehaviour
{
	[SerializeField]
	private List<GameObject> m_buttons;

	private Vector3 m_originalPosition = Vector3.zero;

	private int m_halfButtonHeight;

	private bool m_initialised;

	private void Awake()
	{
		if (!m_initialised)
		{
			Initialise();
		}
	}

	private void Initialise()
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		m_initialised = true;
		if (m_buttons.Count > 0)
		{
			UISprite component = m_buttons[0].gameObject.GetComponent<UISprite>();
			if ((Object)(object)component != (Object)null)
			{
				m_halfButtonHeight = component.height / 2;
			}
		}
		m_originalPosition = ((Component)this).transform.localPosition;
	}

	public void ShowButtons(int count, ContextMenuPanel.AlignMode buttonAlignment)
	{
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		if (!m_initialised)
		{
			Initialise();
		}
		float num = 0f;
		switch (buttonAlignment)
		{
		case ContextMenuPanel.AlignMode.Top:
			num = 0f;
			break;
		case ContextMenuPanel.AlignMode.Center:
			num = Mathf.Min(((float)m_buttons.Count - (float)count) * (float)(-m_halfButtonHeight), 0f);
			break;
		case ContextMenuPanel.AlignMode.Bottom:
			num = Mathf.Min(((float)m_buttons.Count - (float)count) * ((float)(-m_halfButtonHeight) * 2f), 0f);
			break;
		}
		((Component)this).transform.localPosition = m_originalPosition + new Vector3(0f, num, 0f);
		for (int i = 0; i < m_buttons.Count; i++)
		{
			m_buttons[i].SetActive(i < count);
		}
	}

	public void ResetPosition()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if (!m_initialised)
		{
			Initialise();
		}
		((Component)this).transform.localPosition = m_originalPosition;
	}
}
