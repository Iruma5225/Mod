public class Obj_SingleBed : Obj_Bed
{
	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.SingleBed;
	}
}
