using System.Collections.Generic;
using UnityEngine;

public class CursorStandard : CursorBase, ITriggerDisabled2D
{
	private SpriteRenderer sprite;

	private bool bEnabled = true;

	private bool m_snapToCentre;

	public GameObject cogSprite;

	private SpriteRenderer m_cogButtonRenderer;

	public float tooltipDelay = 0.5f;

	private float tooltipCountdown;

	private Collider2D previous_collider;

	[SerializeField]
	private Sprite m_ps4ObjectButton;

	[SerializeField]
	private Sprite m_ps4CharacterButton;

	[SerializeField]
	private Sprite m_xboxObjectButton;

	[SerializeField]
	private Sprite m_xboxCharacterButton;

	private bool moved;

	private List<Collider2D> collided_with = new List<Collider2D>();

	private List<ObjectManager.ObjectType> priorityObjs = new List<ObjectManager.ObjectType>
	{
		ObjectManager.ObjectType.Corpse,
		ObjectManager.ObjectType.CatatonicGhost
	};

	public override CursorType GetCursorType()
	{
		return CursorType.Standard;
	}

	public override void Awake()
	{
		base.Awake();
		sprite = ((Component)this).GetComponent<SpriteRenderer>();
		if (!cameraScript.isConsoleMode && (Object)(object)sprite != (Object)null)
		{
			((Renderer)sprite).enabled = false;
		}
		if ((Object)(object)cogSprite != (Object)null)
		{
			m_cogButtonRenderer = cogSprite.GetComponent<SpriteRenderer>();
			if ((Object)(object)m_cogButtonRenderer != (Object)null)
			{
				UpdateCogSprite(overObject: true);
			}
		}
	}

	private void UpdateCogSprite(bool overObject)
	{
		if ((Object)(object)m_cogButtonRenderer != (Object)null)
		{
			m_cogButtonRenderer.sprite = ((!overObject) ? m_xboxCharacterButton : m_xboxObjectButton);
		}
	}

	public void Update()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		if (!IsEnabled())
		{
			return;
		}
		if (Input.touchCount == 1)
		{
			Touch touch = Input.GetTouch(0);
			if (!(((Touch)(ref touch)).deltaPosition.x > 0.02f))
			{
				Touch touch2 = Input.GetTouch(0);
				if (!(((Touch)(ref touch2)).deltaPosition.y > 0.02f))
				{
					goto IL_005e;
				}
			}
			moved = true;
		}
		goto IL_005e;
		IL_005e:
		if (Input.touchCount == 0 && moved)
		{
			moved = false;
		}
		if ((Object)(object)sprite != (Object)null)
		{
			if (cameraScript.isConsoleMode && !((Renderer)sprite).enabled)
			{
				((Renderer)sprite).enabled = false;
			}
			else if (!cameraScript.isConsoleMode && ((Renderer)sprite).enabled)
			{
				((Renderer)sprite).enabled = false;
				cogSprite.SetActive(false);
			}
		}
		Obj_Base obj_Base = null;
		Obj_Base obj_Base2 = null;
		for (int num = collided_with.Count - 1; num >= 0; num--)
		{
			obj_Base2 = ColliderToObject(collided_with[num]);
			if ((Object)(object)obj_Base2 != (Object)null && obj_Base2.selectable)
			{
				obj_Base = obj_Base2;
				break;
			}
		}
		if ((Object)(object)InteractionManager.Instance.SelectedObject != (Object)(object)obj_Base)
		{
			InteractionManager.Instance.UnSelectObject(InteractionManager.Instance.SelectedObject);
			if ((Object)(object)obj_Base != (Object)null)
			{
				InteractionManager.Instance.SelectObject(obj_Base);
			}
		}
		if (collided_with.Count > 0 && IsInteractable(collided_with[collided_with.Count - 1]))
		{
			if (cameraScript.isConsoleMode)
			{
				cogSprite.SetActive(true);
				UpdateCogSprite(((Component)collided_with[collided_with.Count - 1]).tag != "NPC");
			}
			if ((Object)(object)collided_with[collided_with.Count - 1] != (Object)(object)previous_collider)
			{
				ShowTooltip(null);
				previous_collider = collided_with[collided_with.Count - 1];
				tooltipCountdown = 0f;
			}
			tooltipCountdown = Mathf.Max(tooltipCountdown - RealTime.deltaTime, 0f);
			if (tooltipCountdown <= 0f)
			{
				ShowTooltip(collided_with[collided_with.Count - 1]);
			}
		}
		else
		{
			previous_collider = null;
			tooltipCountdown = tooltipDelay;
			cogSprite.SetActive(false);
			ShowTooltip(null);
		}
	}

	public void SnapToCentreOfScreen()
	{
		m_snapToCentre = true;
	}

	public void LateUpdate()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = GetDefaultMovement(((Component)this).transform.position);
		if (cameraScript.isConsoleMode && (Object)(object)cameraScript != (Object)null)
		{
			if (cameraScript.ShouldHideCursor() && IsEnabled())
			{
				DisableCursor();
			}
			else if (!cameraScript.ShouldHideCursor() && !IsEnabled())
			{
				EnableCursor();
			}
			if (!IsEnabled() || m_snapToCentre)
			{
				m_snapToCentre = false;
				val = ((Component)game_cam).transform.position - ((Component)this).transform.position;
			}
		}
		Vector3 pos = ((Component)this).transform.position + val;
		ClampToScreen(ref pos);
		((Component)this).transform.position = pos;
	}

	private void OnTriggerStay2D(Collider2D col)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)InteractionManager.Instance == (Object)null || (Object)(object)col == (Object)null)
		{
			return;
		}
		if (!UICamera.touchedDraggableGUI && !moved && Input.touchCount == 1)
		{
			Touch touch = Input.GetTouch(0);
			if ((int)((Touch)(ref touch)).phase != 0 && (((Component)col).CompareTag("NPC") || ((Component)col).CompareTag("Pet")))
			{
				FamilyMember familyMember = null;
				if (((Component)col).CompareTag("NPC"))
				{
					familyMember = ((Component)col).GetComponent<FamilyMember>();
					if ((Object)(object)familyMember != (Object)null && (Object)(object)InteractionManager.Instance != (Object)null && !familyMember.isHiding)
					{
						InteractionManager.Instance.OnHoverCharacterStart(familyMember);
					}
				}
				if ((Object)(object)familyMember == (Object)null || !familyMember.isHiding)
				{
					if (!collided_with.Contains(col))
					{
						collided_with.Add(col);
					}
					return;
				}
			}
		}
		if (Input.touchCount == 1)
		{
			Obj_Base obj_Base = null;
			if (((Component)col).CompareTag("Object") || ((Component)col).CompareTag("CraftingGhost"))
			{
				obj_Base = ((Component)col).GetComponent<Obj_Base>();
			}
			else if (((Component)col).CompareTag("DoorCursor"))
			{
				DoorCollider component = ((Component)col).GetComponent<DoorCollider>();
				if ((Object)(object)component != (Object)null)
				{
					if (!component.ShouldTrigger_Cursor())
					{
						return;
					}
					obj_Base = component.GetDoor();
				}
			}
			if ((Object)(object)obj_Base == (Object)null)
			{
				return;
			}
			if (!collided_with.Contains(col))
			{
				Obj_Base obj_Base2 = null;
				int index = 0;
				for (int num = collided_with.Count - 1; num >= 0; num--)
				{
					if ((Object)(object)collided_with[num] == (Object)null || ((Component)collided_with[num]).CompareTag("NPC") || ((Component)collided_with[num]).CompareTag("Pet"))
					{
						continue;
					}
					if (((Component)collided_with[num]).CompareTag("Object"))
					{
						obj_Base2 = ((Component)collided_with[num]).GetComponent<Obj_Base>();
						if ((Object)(object)obj_Base2 == (Object)null || (!obj_Base.hasSelectionPriority && obj_Base2.hasSelectionPriority) || (!priorityObjs.Contains(obj_Base.GetObjectType()) && !obj_Base.hasSelectionPriority && priorityObjs.Contains(obj_Base2.GetObjectType())))
						{
							continue;
						}
					}
					index = Mathf.Clamp(num + 1, 0, collided_with.Count);
					break;
				}
				collided_with.Insert(index, col);
			}
		}
		if (Input.touchCount == 0 && collided_with.Contains(col) && InteractionManager.Instance.Mode != InteractionManager.InteractionMode.Standard)
		{
			OnTriggerExit2D(col);
		}
	}

	private void OnTriggerExit2D(Collider2D col)
	{
		if ((Object)(object)col == (Object)null)
		{
			collided_with.Remove(col);
		}
		else
		{
			if ((Object)(object)InteractionManager.Instance == (Object)null || (!((Component)col).CompareTag("NPC") && !((Component)col).CompareTag("Object") && !((Component)col).CompareTag("CraftingGhost") && !((Component)col).CompareTag("DoorCursor") && !((Component)col).CompareTag("Pet")) || !collided_with.Contains(col))
			{
				return;
			}
			bool flag = (Object)(object)col == (Object)(object)collided_with[collided_with.Count - 1];
			collided_with.Remove(col);
			if (((Component)col).CompareTag("NPC"))
			{
				FamilyMember component = ((Component)col).GetComponent<FamilyMember>();
				if ((Object)(object)component != (Object)null && (Object)(object)InteractionManager.Instance != (Object)null)
				{
					InteractionManager.Instance.OnHoverCharacterStop(component);
				}
			}
			Obj_Base obj_Base = null;
			if (((Component)col).CompareTag("Object") || ((Component)col).CompareTag("CraftingGhost"))
			{
				obj_Base = ((Component)col).GetComponent<Obj_Base>();
			}
			else if (((Component)col).CompareTag("DoorCursor"))
			{
				DoorCollider component2 = ((Component)col).GetComponent<DoorCollider>();
				if ((Object)(object)component2 != (Object)null)
				{
					if (!component2.ShouldTrigger_Cursor())
					{
						return;
					}
					obj_Base = component2.GetDoor();
				}
			}
			if ((Object)(object)obj_Base == (Object)null || !obj_Base.selectable)
			{
				return;
			}
			InteractionManager.Instance.UnSelectObject(obj_Base);
			if (!flag || collided_with.Count <= 0)
			{
				return;
			}
			for (int num = collided_with.Count - 1; num >= 0; num--)
			{
				if ((Object)(object)collided_with[num] != (Object)null)
				{
					OnTriggerStay2D(collided_with[num]);
					break;
				}
				collided_with.RemoveAt(num);
			}
		}
	}

	public void OnTriggerDisabled2D(Collider2D col)
	{
		if (!((Object)(object)this == (Object)null) && !((Object)(object)((Component)this).gameObject == (Object)null))
		{
			OnTriggerExit2D(col);
		}
	}

	public override void OnCursorDeactivated()
	{
		for (int num = collided_with.Count - 1; num >= 0; num--)
		{
			OnTriggerExit2D(collided_with[num]);
		}
		TooltipperObj.ShowTooltip(null);
		if ((Object)(object)InteractionManager.Instance != (Object)null)
		{
			InteractionManager.Instance.ClearHoveredCharacters();
		}
	}

	private bool IsInteractable(Collider2D col)
	{
		if (((Component)col).CompareTag("NPC") || ((Component)col).CompareTag("Pet"))
		{
			return true;
		}
		Obj_Base obj_Base = ColliderToObject(col);
		if ((Object)(object)obj_Base == (Object)null || !obj_Base.selectable)
		{
			return false;
		}
		return true;
	}

	private Obj_Base ColliderToObject(Collider2D col)
	{
		if (!((Component)col).CompareTag("Object") && !((Component)col).CompareTag("CraftingGhost") && !((Component)col).CompareTag("DoorCursor"))
		{
			return null;
		}
		if (((Component)col).CompareTag("Object") || ((Component)col).CompareTag("CraftingGhost"))
		{
			return ((Component)col).GetComponent<Obj_Base>();
		}
		if (((Component)col).CompareTag("DoorCursor"))
		{
			DoorCollider component = ((Component)col).GetComponent<DoorCollider>();
			if ((Object)(object)component == (Object)null || !component.ShouldTrigger_Cursor())
			{
				return null;
			}
			return component.GetDoor();
		}
		return null;
	}

	private void ShowTooltip(Collider2D col)
	{
		if ((Object)(object)col == (Object)null)
		{
			TooltipperObj.ShowTooltip(null);
		}
		else
		{
			if (!IsEnabled())
			{
				return;
			}
			ITooltipObject tooltipObject = ((Component)col).GetComponent<ITooltipObject>();
			if (((Component)col).CompareTag("DoorCursor"))
			{
				DoorCollider component = ((Component)col).GetComponent<DoorCollider>();
				if ((Object)(object)component != (Object)null)
				{
					tooltipObject = component.GetDoor();
				}
			}
			if (tooltipObject != null && tooltipObject is FamilyMember)
			{
			}
		}
	}

	public bool IsEnabled()
	{
		return bEnabled;
	}

	public void DisableCursor()
	{
		if (IsEnabled())
		{
			TooltipperObj.ShowTooltip(null);
			if ((Object)(object)sprite != (Object)null && ((Renderer)sprite).enabled)
			{
				((Renderer)sprite).enabled = false;
				cogSprite.SetActive(false);
			}
			bEnabled = false;
		}
	}

	public void EnableCursor()
	{
		if (!IsEnabled())
		{
			if ((Object)(object)sprite != (Object)null && !((Renderer)sprite).enabled)
			{
				((Renderer)sprite).enabled = true;
			}
			bEnabled = true;
			if (collided_with.Count > 0)
			{
				OnTriggerStay2D(collided_with[collided_with.Count - 1]);
			}
		}
	}
}
