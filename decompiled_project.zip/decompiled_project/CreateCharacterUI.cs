using UnityEngine;

public class CreateCharacterUI : MonoBehaviour
{
	public GameObject prefab;

	public void Start()
	{
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		UICamera uICamera = UICamera.FindCameraForLayer(prefab.layer);
		if ((Object)(object)uICamera != (Object)null)
		{
			GameObject gameObject = ((Component)uICamera).gameObject;
			UIAnchor component = gameObject.GetComponent<UIAnchor>();
			if ((Object)(object)component != (Object)null)
			{
				gameObject = ((Component)component).gameObject;
			}
			GameObject val = Object.Instantiate<GameObject>(prefab);
			if ((Object)(object)val != (Object)null)
			{
				Transform transform = val.transform;
				transform.parent = gameObject.transform;
				transform.localScale = Vector3.one;
				transform.localRotation = Quaternion.identity;
				transform.localPosition = Vector3.zero;
				UI_Character component2 = val.GetComponent<UI_Character>();
				if ((Object)(object)component2 != (Object)null)
				{
					component2.character = ((Component)this).transform;
				}
			}
		}
		Object.Destroy((Object)(object)this);
	}
}
