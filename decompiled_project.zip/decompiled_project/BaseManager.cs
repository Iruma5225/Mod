public abstract class BaseManager : BaseManagerNoUpdate
{
	private void Update()
	{
		if (LoadingManager.IsLoadingFinished())
		{
			UpdateManager();
		}
	}

	public abstract void UpdateManager();
}
