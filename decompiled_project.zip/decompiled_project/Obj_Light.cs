using UnityEngine;

public class Obj_Light : Obj_Base
{
	public float frequency;

	public SpriteRenderer m_glowSprite;

	public SpriteRenderer m_fixtureSprite;

	public bool twoLights;

	private float random;

	private Color color;

	private Color lightOffCol = new Color(27f / 85f, 27f / 85f, 27f / 85f);

	private float randomWaitOff;

	private float randomWaitOn;

	[SerializeField]
	private SpriteRenderer shadow;

	private bool lightOff;

	private bool lostPower;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.RoomLight;
	}

	public override void Start()
	{
		base.Start();
		randomWaitOff = Random.Range(1f, 1000f);
		randomWaitOff *= frequency;
		randomWaitOff += Time.time;
		PowerManager.Instance.RegisterLight(this);
	}

	public override void Update()
	{
		base.Update();
		if (Time.time >= randomWaitOff && randomWaitOff > 0f)
		{
			switchOffLightResetTimer();
			randomWaitOff = 0f;
		}
		if (Time.time >= randomWaitOn && randomWaitOn > 0f)
		{
			switchOnLightResetTimer();
			randomWaitOn = 0f;
		}
		if (IsEnabled() && !HasEnoughPower())
		{
			lostPower = true;
		}
		if (!IsEnabled() || !HasEnoughPower())
		{
			if (!lightOff)
			{
				switchOffLight();
			}
		}
		else if (randomWaitOn == 0f && randomWaitOff == 0f)
		{
			if (lostPower)
			{
				lostPower = false;
				randomWaitOn = Random.Range(0.5f, 1.5f);
			}
			else
			{
				randomWaitOn = Random.Range(0.1f, 0.15f);
			}
			randomWaitOn += Time.time;
		}
	}

	public void switchOffLight()
	{
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		randomWaitOff = 0f;
		randomWaitOn = 0f;
		if ((Object)(object)shadow != (Object)null)
		{
			if (twoLights)
			{
				if (shadow.color.a == 0.5f)
				{
					shadow.color = Color.white;
				}
				else
				{
					shadow.color = new Color(1f, 1f, 1f, 0.5f);
				}
			}
			else
			{
				shadow.color = Color.white;
			}
		}
		if ((Object)(object)m_glowSprite != (Object)null)
		{
			m_glowSprite.color = new Color(1f, 1f, 1f, 0f);
		}
		if ((Object)(object)m_fixtureSprite != (Object)null)
		{
			m_fixtureSprite.color = lightOffCol;
		}
		lightOff = true;
	}

	public void switchOffLightResetTimer()
	{
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)shadow != (Object)null)
		{
			if (twoLights)
			{
				if (shadow.color.a == 0.5f)
				{
					shadow.color = Color.white;
				}
				else
				{
					shadow.color = new Color(1f, 1f, 1f, 0.5f);
				}
			}
			else
			{
				shadow.color = Color.white;
			}
		}
		if ((Object)(object)m_glowSprite != (Object)null)
		{
			m_glowSprite.color = new Color(1f, 1f, 1f, 0f);
		}
		if ((Object)(object)m_fixtureSprite != (Object)null)
		{
			m_fixtureSprite.color = lightOffCol;
		}
		randomWaitOn = Random.Range(0.1f, 0.15f);
		randomWaitOn += Time.time;
		lightOff = true;
	}

	public void switchOnLightResetTimer()
	{
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		if (!IsEnabled() || !HasEnoughPower())
		{
			return;
		}
		if ((Object)(object)shadow != (Object)null)
		{
			if (twoLights)
			{
				if (shadow.color.a == 0.5f)
				{
					shadow.color = new Color(1f, 1f, 1f, 0f);
				}
				else
				{
					shadow.color = new Color(1f, 1f, 1f, 0.5f);
				}
			}
			else
			{
				shadow.color = new Color(1f, 1f, 1f, 0f);
			}
		}
		if ((Object)(object)m_glowSprite != (Object)null)
		{
			m_glowSprite.color = Color.white;
		}
		if ((Object)(object)m_fixtureSprite != (Object)null)
		{
			m_fixtureSprite.color = Color.white;
		}
		randomWaitOff = Random.Range(1f, 1000f);
		randomWaitOff *= frequency;
		randomWaitOff += Time.time;
		lightOff = false;
	}

	public void setFrequency(float newFreq)
	{
		frequency = newFreq;
		if (!lightOff)
		{
			randomWaitOff = Random.Range(1f, 1000f);
			randomWaitOff *= frequency;
			randomWaitOff += Time.time;
		}
	}

	public void setShadow(SpriteRenderer Shadow)
	{
		shadow = Shadow;
	}

	public bool isLightOff()
	{
		return lightOff;
	}

	public override bool IsReadyForLoad()
	{
		if (base.initialObject)
		{
			return base.IsReadyForLoad();
		}
		return true;
	}

	public override bool SaveLoad(SaveData data)
	{
		if (base.initialObject)
		{
			return base.SaveLoad(data);
		}
		return true;
	}
}
