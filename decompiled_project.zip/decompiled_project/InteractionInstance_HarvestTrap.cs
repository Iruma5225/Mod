using System.Collections.Generic;
using UnityEngine;

public class InteractionInstance_HarvestTrap : InteractionInstance_Base
{
	private Obj_Landmine obj_mine;

	private Int_HarvestTrap int_harvest;

	protected override bool CanCancelImmediately()
	{
		return false;
	}

	protected override bool OnInteractionStarted()
	{
		obj_mine = obj_base as Obj_Landmine;
		if ((Object)(object)obj_mine == (Object)null)
		{
			return false;
		}
		int_harvest = ((Component)this).GetComponent<Int_HarvestTrap>();
		if ((Object)(object)int_harvest == (Object)null)
		{
			return false;
		}
		if ((Object)(object)member != (Object)null)
		{
			member.TriggerAnim("Rummage");
		}
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if ((Object)(object)obj_mine == (Object)null || (Object)(object)int_harvest == (Object)null)
		{
			return true;
		}
		FamilyManager.Instance.CharacterHasHarvestedCorpse(member, int_harvest.Trauma);
		List<ItemStack> harvestItemList = obj_mine.GetHarvestItemList();
		for (int i = 0; i < harvestItemList.Count; i++)
		{
			InventoryManager.Instance.AddNewItems(harvestItemList[i].m_type, harvestItemList[i].m_count);
		}
		harvestItemList = obj_mine.GetLootItemList();
		for (int j = 0; j < harvestItemList.Count; j++)
		{
			InventoryManager.Instance.AddNewItems(harvestItemList[j].m_type, harvestItemList[j].m_count);
		}
		ObjectManager.Instance.RemoveObject(obj_mine);
		return true;
	}
}
