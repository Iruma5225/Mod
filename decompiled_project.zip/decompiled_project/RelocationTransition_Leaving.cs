using System.Collections.Generic;
using UnityEngine;

public class RelocationTransition_Leaving : RelocationTransition_Base
{
	private List<FamilyMember> members = new List<FamilyMember>();

	private CompanionAnimal pet;

	private Obj_CamperVan vehicle;

	private Obj_HazmatSuit hazmatSuits;

	private Vector3 offscreenPos = Vector3.zero;

	private const float fadeDuration = 6f;

	private const float fadeDuration_Short = 2f;

	private List<FamilyMember> readyMembers = new List<FamilyMember>();

	public RelocationTransition_Leaving()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (Initialise())
		{
			Begin_LadderFade();
		}
	}

	private bool Initialise()
	{
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		members = FamilyManager.Instance.GetAllFamilyMembers();
		members.RemoveAll((FamilyMember x) => x.isDead || x.isCatatonic || x.isAway || x.isAdopted);
		pet = FamilyManager.Instance.GetPet();
		if ((Object)(object)pet != (Object)null && ((pet.m_type != FamilySpawner.PetType.Dog && pet.m_type != FamilySpawner.PetType.Cat) || pet.isDead || pet.isAway || !pet.isVisible))
		{
			pet = null;
		}
		if ((Object)(object)ObjectManager.Instance != (Object)null)
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.CamperVan);
			if (objectsOfType != null && objectsOfType.Count > 0)
			{
				vehicle = objectsOfType[0] as Obj_CamperVan;
			}
			List<Obj_Base> objectsOfType2 = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.HazmatSuits);
			if (objectsOfType2 != null && objectsOfType2.Count > 0)
			{
				hazmatSuits = objectsOfType2[0] as Obj_HazmatSuit;
			}
		}
		if ((Object)(object)ExplorationManager.Instance != (Object)null)
		{
			List<GameObject> offScreenNodes = ExplorationManager.Instance.offScreenNodes;
			if (offScreenNodes.Count > 0)
			{
				offscreenPos = offScreenNodes[0].transform.position;
			}
		}
		return true;
	}

	private void Begin_LadderFade()
	{
		for (int i = 0; i < members.Count; i++)
		{
			LockCharacter(members[i]);
		}
		FadeOut(2f);
		m_update = Update_WaitForLadderFade;
	}

	private TransitionResult Update_WaitForLadderFade()
	{
		if (!IsFadeOver())
		{
			return TransitionResult.Continue;
		}
		Begin_SurfaceFade();
		return TransitionResult.Continue;
	}

	private void Begin_SurfaceFade()
	{
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		List<GameObject> list = new List<GameObject>();
		int num = 0;
		if ((Object)(object)RelocationManager.instance != (Object)null)
		{
			list.AddRange(RelocationManager.instance.GetTransitionSurfaceNodes());
		}
		for (int i = 0; i < members.Count; i++)
		{
			if (num >= 0 && num < list.Count)
			{
				SetCharacterPosition(members[i], list[num].transform.position);
				if (++num >= list.Count)
				{
					num = 0;
				}
			}
		}
		if ((Object)(object)pet != (Object)null)
		{
			((Component)pet).transform.position = offscreenPos;
			pet.ClearPath();
		}
		Vector3 zero = Vector3.zero;
		if ((Object)(object)ShelterRoomGrid.Instance != (Object)null)
		{
			zero.x = (float)ShelterRoomGrid.Instance.grid_width * ShelterRoomGrid.Instance.grid_cell_width;
		}
		SetCameraZoom(zoom: false);
		SetCameraPosition(zero);
		FadeIn(2f);
		Begin_LeaveShelter();
	}

	private void Begin_LeaveShelter()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		Vector3 boardingPosition = vehicle.GetBoardingPosition();
		for (int i = 0; i < members.Count; i++)
		{
			if (members[i].isWearingHazmatSuit && (Object)(object)hazmatSuits != (Object)null)
			{
				hazmatSuits.ReturnSuit(members[i].RemoveHazmatSuit());
			}
			QueueCharacterMove(members[i], boardingPosition);
		}
		readyMembers.Clear();
		m_update = Update_WaitForLeaveShelter;
	}

	private TransitionResult Update_WaitForLeaveShelter()
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < members.Count; i++)
		{
			if (!readyMembers.Contains(members[i]) && members[i].ai_queue.is_empty)
			{
				SetCharacterPosition(members[i], offscreenPos);
				readyMembers.Add(members[i]);
			}
		}
		if (readyMembers.Count < members.Count)
		{
			return TransitionResult.Continue;
		}
		Begin_VehicleLeaving();
		return TransitionResult.Continue;
	}

	private void Begin_VehicleLeaving()
	{
		if ((Object)(object)vehicle != (Object)null)
		{
			vehicle.GoOnExpedition();
		}
		m_update = Update_WaitForVehicleMoving;
	}

	private TransitionResult Update_WaitForVehicleMoving()
	{
		if ((Object)(object)vehicle != (Object)null && !vehicle.isMoving)
		{
			return TransitionResult.Continue;
		}
		FadeOut(6f);
		m_update = Update_VehicleLeaving;
		return TransitionResult.Continue;
	}

	private TransitionResult Update_VehicleLeaving()
	{
		if (!vehicle.isStationary && !IsFadeOver())
		{
			return TransitionResult.Continue;
		}
		return TransitionResult.End;
	}
}
