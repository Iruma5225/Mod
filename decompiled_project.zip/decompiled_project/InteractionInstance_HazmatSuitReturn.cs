using UnityEngine;

public class InteractionInstance_HazmatSuitReturn : InteractionInstance_Base
{
	private Int_HazmatSuitReturn interaction;

	private Obj_HazmatSuit hazmat_suits_object;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_HazmatSuitReturn;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		hazmat_suits_object = ((Component)this).GetComponent<Obj_HazmatSuit>();
		if ((Object)(object)hazmat_suits_object == (Object)null)
		{
			return false;
		}
		if (hazmat_suits_object.IsFullOfSuits())
		{
			return false;
		}
		if (!member.isWearingHazmatSuit)
		{
			return false;
		}
		member.TriggerAnim("Rummage");
		hazmat_suits_object.PlayReturnSound();
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled && (Object)(object)hazmat_suits_object != (Object)null)
		{
			Obj_HazmatSuit.HazmatSuit hazmatSuit = member.RemoveHazmatSuit();
			if (hazmatSuit != null)
			{
				hazmat_suits_object.ReturnSuit(hazmatSuit);
			}
		}
		return true;
	}
}
