using System.Collections.Generic;
using UnityEngine;

public class UI_CharacterInfoNPC : MonoBehaviour
{
	public enum PopupType
	{
		TrapHit,
		TrapMiss,
		Max
	}

	private class PopupInfo
	{
		public PopupType m_type = PopupType.Max;

		public float m_value;

		public BaseStats.StatType m_stat = BaseStats.StatType.Max;
	}

	[SerializeField]
	private UISprite m_sprite;

	[SerializeField]
	private UILabel m_floatingText;

	private TweenAlpha m_textAlphaTween;

	private TweenPosition m_textPosTween;

	[SerializeField]
	private float m_popupDuration = 1f;

	[SerializeField]
	private float m_popupFadeTime = 0.5f;

	private NpcVisitor m_member;

	private float m_fadeStartAlpha;

	private float m_fadeStartTime;

	private float m_fadeEndTime;

	private float m_showUntilTime;

	[SerializeField]
	private bool m_testPopup;

	private bool m_showingPopup;

	private bool m_showingTrapText;

	private List<PopupInfo> m_popupQueue = new List<PopupInfo>();

	public void Awake()
	{
		if ((Object)(object)m_floatingText != (Object)null)
		{
			m_textAlphaTween = ((Component)m_floatingText).GetComponent<TweenAlpha>();
			m_textPosTween = ((Component)m_floatingText).GetComponent<TweenPosition>();
		}
	}

	public void AddPopup(PopupType type)
	{
		PopupInfo popupInfo = new PopupInfo();
		popupInfo.m_type = type;
		m_popupQueue.Add(popupInfo);
	}

	public void Update()
	{
		if ((Object)(object)m_member == (Object)null && (Object)(object)((Component)this).transform.parent != (Object)null)
		{
			UI_Character component = ((Component)((Component)this).transform.parent).GetComponent<UI_Character>();
			if ((Object)(object)component == (Object)null && (Object)(object)((Component)this).transform.parent.parent != (Object)null)
			{
				component = ((Component)((Component)this).transform.parent.parent).GetComponent<UI_Character>();
			}
			if ((Object)(object)component != (Object)null)
			{
				m_member = component.baseCharacter as NpcVisitor;
				m_member.SetCharacterInfoUI(this);
			}
		}
		if (m_popupQueue.Count > 0 || m_showingPopup)
		{
			UpdatePopupIcon();
		}
		if (m_testPopup)
		{
			m_testPopup = false;
			PopupInfo popupInfo = new PopupInfo();
			popupInfo.m_stat = (BaseStats.StatType)Random.Range(0, 5);
			popupInfo.m_type = (PopupType)Random.Range(0, 2);
			popupInfo.m_value = Random.value * 20f;
			m_popupQueue.Add(popupInfo);
		}
	}

	private void UpdatePopupIcon()
	{
		if (!m_showingPopup)
		{
			m_showingPopup = true;
			m_showUntilTime = Time.time + m_popupDuration;
			m_fadeStartTime = m_showUntilTime;
			m_fadeEndTime = m_showUntilTime + m_popupFadeTime;
			m_fadeStartAlpha = 1f;
			PopupInfo popupInfo = m_popupQueue[0];
			if ((Object)(object)m_floatingText != (Object)null && (Object)(object)m_textPosTween != (Object)null && (Object)(object)m_textAlphaTween != (Object)null)
			{
				switch (popupInfo.m_type)
				{
				case PopupType.TrapHit:
					m_floatingText.text = m_member.trapDamageDealt.ToString();
					m_showingTrapText = true;
					break;
				case PopupType.TrapMiss:
					m_floatingText.text = Localization.Get("Text.Combat.Miss");
					m_showingTrapText = true;
					break;
				}
				m_floatingText.alpha = 1f;
				m_textPosTween.duration = m_popupDuration + m_popupFadeTime;
				m_textPosTween.ResetToBeginning();
				m_textPosTween.PlayForward();
				m_textAlphaTween.duration = m_popupDuration + m_popupFadeTime;
				m_textAlphaTween.ResetToBeginning();
				m_textAlphaTween.PlayForward();
			}
			m_popupQueue.RemoveAt(0);
		}
		if (Time.time >= m_fadeStartTime)
		{
			float num = (Time.time - m_fadeStartTime) / (m_fadeEndTime - m_fadeStartTime);
			float alpha = Mathf.Lerp(m_fadeStartAlpha, 0f, num);
			if ((Object)(object)m_sprite != (Object)null && !m_showingTrapText)
			{
				m_sprite.alpha = alpha;
			}
			if (num >= 1f)
			{
				m_showingPopup = false;
				m_showingTrapText = false;
			}
		}
	}
}
