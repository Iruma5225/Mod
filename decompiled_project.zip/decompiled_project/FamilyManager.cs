using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

public class FamilyManager : BaseManager, ISaveable
{
	[Serializable]
	public class DeadCharacterInfo
	{
		public int id = -1;

		public string mesh_id = "man";

		public string head_texture = "default";

		public string torso_texture = "default";

		public string leg_texture = "default";

		public Color hair_colour = Color.white;

		public Color skin_color = Color.white;

		public Color shirt_color = Color.white;

		public Color pants_color = Color.white;

		public string first_name = string.Empty;

		public string last_name = string.Empty;

		public int death_date;

		public BaseCharacter.DamageType death_cause;

		public string death_extra_info = string.Empty;

		public bool catatonic;

		public void SaveLoadInfo(SaveData data)
		{
			data.SaveLoad("id", ref id);
			data.SaveLoad("first_name", ref first_name);
			data.SaveLoad("lastName", ref last_name);
			data.SaveLoad("death_date", ref death_date);
			int value = (int)death_cause;
			data.SaveLoad("death_cause", ref value);
			data.SaveLoad("death_info", ref death_extra_info);
			data.SaveLoad("catatonic", ref catatonic);
			data.SaveLoad("meshId", ref mesh_id);
			data.SaveLoad("headTexture", ref head_texture);
			data.SaveLoad("torsoTexture", ref torso_texture);
			data.SaveLoad("legTexture", ref leg_texture);
			data.SaveLoad("hairColor", ref hair_colour);
			data.SaveLoad("skinColor", ref skin_color);
			data.SaveLoad("shirtColor", ref shirt_color);
			data.SaveLoad("pantsColor", ref pants_color);
		}
	}

	[Serializable]
	private class LeaveTypeWeights
	{
		[Range(0f, 10f)]
		public int normal = 1;

		[Range(0f, 10f)]
		public int damage = 1;

		[Range(0f, 10f)]
		public int steal = 1;

		[Range(0f, 10f)]
		public int defecate = 1;

		[Range(0f, 10f)]
		public int deupgrade = 1;
	}

	private static int uniqueMemberId;

	private bool someoneDied;

	[SerializeField]
	private GameObject m_familyUIPrefab;

	[SerializeField]
	private GameObject m_npcUIPrefab;

	private Color m_particleTint = default(Color);

	private bool m_particleTintActive;

	private float m_nextColourReset;

	private List<DeadCharacterInfo> m_deadCharactersInfo = new List<DeadCharacterInfo>();

	[SerializeField]
	[Range(0f, 100f)]
	[Header("Death")]
	private int DeathTrauma = 60;

	[SerializeField]
	[Range(0f, 100f)]
	private int DeathTraumaAway = 60;

	[SerializeField]
	private int MaxHarvestedCorpses;

	private int m_corpsesHarvested;

	[SerializeField]
	private AudioClip deathSound;

	private bool m_pendingDeathSound;

	[Header("Loyalty / Leaving")]
	[SerializeField]
	private List<string> m_leaveStrings = new List<string>();

	[SerializeField]
	private LeaveTypeWeights m_leaveWeights_Generic = new LeaveTypeWeights();

	[SerializeField]
	private LeaveTypeWeights m_leaveWeights_Aggressive = new LeaveTypeWeights();

	[SerializeField]
	private LeaveTypeWeights m_leaveWeights_Haggler = new LeaveTypeWeights();

	[SerializeField]
	private LeaveTypeWeights m_leaveWeights_Passive = new LeaveTypeWeights();

	[SerializeField]
	private int m_itemsToTakeWhenLeaving;

	[SerializeField]
	private int m_rationsToTakeWhenLeaving;

	[SerializeField]
	private int m_waterToTakeWhenLeaving;

	[SerializeField]
	private int m_damageToDoWhenLeaving;

	[SerializeField]
	[Header("Game Over")]
	private float m_gameOverFadeDuration;

	[SerializeField]
	private AudioClip m_gameOverSound;

	[SerializeField]
	private List<UIPanel> m_disableOnGameOver = new List<UIPanel>();

	private Dictionary<FamilyMember, Obj_CatatonicGhost> catatonicGhosts = new Dictionary<FamilyMember, Obj_CatatonicGhost>();

	private List<FamilyMember> catatonicFamilyMembers = new List<FamilyMember>();

	private List<FamilyMember> familyMembers = new List<FamilyMember>();

	private FamilySpawner.PetType m_petType = FamilySpawner.PetType.Max;

	private CompanionAnimal m_familyPet;

	private Obj_Pet m_objectPet;

	private GameObject[] m_adoptNodes;

	private static FamilyManager m_theInstance;

	private bool game_over;

	public float nextColourReset => m_nextColourReset;

	public int ItemsToTakeWhenLeaving => m_itemsToTakeWhenLeaving;

	public int RationsToTakeWhenLeaving => m_rationsToTakeWhenLeaving;

	public int WaterToTakeWhenLeaving => m_waterToTakeWhenLeaving;

	public int DamageToDoWhenLeaving => m_damageToDoWhenLeaving;

	public static FamilyManager Instance => m_theInstance;

	public bool isGameOver => game_over;

	public void SetParticleTint()
	{
		m_particleTintActive = true;
	}

	private void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
		}
		else
		{
			Debug.Log((object)"Duplicate FamilyManager created!");
		}
		uniqueMemberId = 0;
		m_adoptNodes = GameObject.FindGameObjectsWithTag("ReturnNode");
		if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading)
		{
			m_particleTint.r = Random.Range(1, 10);
			m_particleTint.g = Random.Range(1, 10);
			m_particleTint.b = Random.Range(1, 10);
			m_particleTint.a = Random.Range(1, 10);
		}
	}

	public Color GetParticleTint()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		return (Color)((!m_particleTintActive) ? new Color(-2f, -2f, -2f, -2f) : m_particleTint);
	}

	public override void StartManager()
	{
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
		if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading)
		{
			UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.CraftReminder, GameTime.RealSecondsPerDay / 4f);
			UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.FastForward, GameTime.RealSecondsPerDay / 2f);
			UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.ExpeditionReminder, GameTime.RealSecondsPerDay + GameTime.RealSecondsPerDay / 4f);
			UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.Automation, GameTime.RealSecondsPerDay * 2f);
		}
		GameTime.newDay += CheckForStuckPartyMemebers;
	}

	public override void UpdateManager()
	{
		if (isGameOver)
		{
			if ((Object)(object)FadeManager.Instance == (Object)null || !FadeManager.Instance.IsFading())
			{
				BasePanel gameOverPanel = UI_PanelContainer.Instance.GameOverPanel;
				if ((Object)(object)gameOverPanel != (Object)null && !UIPanelManager.instance.IsPanelOnStack(gameOverPanel))
				{
					UIPanelManager.Instance().PushPanel(gameOverPanel);
				}
			}
			return;
		}
		bool flag = (Object)(object)FamilySpawner.instance != (Object)null && FamilySpawner.numPendingSpawns > 0;
		bool flag2 = (Object)(object)SaveManager.instance != (Object)null && SaveManager.instance.isLoading;
		if (!IsOriginalFamilyAlive() && !flag && !flag2)
		{
			game_over = true;
			OnGameOver();
		}
		else if (m_pendingDeathSound)
		{
			m_pendingDeathSound = false;
			if (IsOriginalFamilyAlive() && (Object)(object)AudioManager.Instance != (Object)null)
			{
				AudioManager.Instance.PlayUI(deathSound);
			}
		}
	}

	public CompanionAnimal GetPet()
	{
		return m_familyPet;
	}

	public Obj_Pet GetPetObject()
	{
		return m_objectPet;
	}

	public bool IsOriginalFamilyAlive()
	{
		bool flag = false;
		bool flag2 = false;
		for (int i = 0; i < familyMembers.Count; i++)
		{
			if (familyMembers[i].GetCharacterType() == BaseCharacter.CharacterType.FamilyMember)
			{
				if (!familyMembers[i].isDead && !familyMembers[i].isCatatonic)
				{
					return true;
				}
				if (familyMembers[i].isCatatonic && !familyMembers[i].isCatatonicPermanent)
				{
					flag = true;
				}
			}
			else if (familyMembers[i].GetCharacterType() == BaseCharacter.CharacterType.FamilyAdoptee && !familyMembers[i].isDead && !familyMembers[i].isCatatonic)
			{
				flag2 = true;
			}
		}
		return false;
	}

	private void OnGameOver()
	{
		ForceUpdateDeadCharacterInfo();
		BasicCamera basicCamera = null;
		Camera main = Camera.main;
		if ((Object)(object)main != (Object)null)
		{
			basicCamera = ((Component)main).GetComponent<BasicCamera>();
		}
		if ((Object)(object)basicCamera != (Object)null)
		{
			basicCamera.SetPendingZoom(zoomOut: true);
			basicCamera.SetCursor(CursorBase.CursorType.None);
		}
		if ((Object)(object)LeaderboardMan.instance != (Object)null)
		{
			LeaderboardMan.instance.PostScores();
		}
		if ((Object)(object)AudioManager.Instance != (Object)null)
		{
			AudioManager.Instance.PlayUI(m_gameOverSound);
		}
		for (int i = 0; i < m_disableOnGameOver.Count; i++)
		{
			((Component)m_disableOnGameOver[i]).gameObject.SetActive(false);
		}
		TooltipperObj.ShowTooltip(null);
		if ((Object)(object)FadeManager.Instance != (Object)null)
		{
			FadeManager.Instance.SetFadeLength(m_gameOverFadeDuration);
			FadeManager.Instance.FadeToBlack(force: true);
		}
	}

	public void CharacterHasDied(FamilyMember member)
	{
		m_pendingDeathSound = true;
		if ((Object)(object)InteractionManager.Instance != (Object)null)
		{
			InteractionManager.Instance.UnRegisterFamilyMember(member);
		}
		if (member.GetCharacterType() == BaseCharacter.CharacterType.FamilyMember)
		{
			m_deadCharactersInfo.Add(CreateObituaryInfo(member));
		}
		float num = (float)DeathTrauma * member.stats.loyalty.NormalizedValue;
		float num2 = (float)DeathTraumaAway * member.stats.loyalty.NormalizedValue;
		for (int i = 0; i < familyMembers.Count; i++)
		{
			if (!familyMembers[i].isDead && !((Object)(object)familyMembers[i] == (Object)(object)member))
			{
				familyMembers[i].stats.trauma.Modify((!familyMembers[i].isAway) ? num : num2);
			}
		}
		CheckTheShelterIsManned(member);
		if (!someoneDied)
		{
			UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.Death);
			someoneDied = true;
		}
	}

	private DeadCharacterInfo CreateObituaryInfo(BaseCharacter character)
	{
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		DeadCharacterInfo deadCharacterInfo = new DeadCharacterInfo();
		deadCharacterInfo.first_name = character.firstName;
		deadCharacterInfo.last_name = character.lastName;
		deadCharacterInfo.death_date = GameTime.Day;
		deadCharacterInfo.death_cause = character.lastDamageType;
		deadCharacterInfo.death_extra_info = character.lastDamageExtra;
		FamilyMember familyMember = character as FamilyMember;
		if ((Object)(object)familyMember != (Object)null)
		{
			deadCharacterInfo.catatonic = familyMember.isCatatonic;
		}
		deadCharacterInfo.mesh_id = character.meshId;
		deadCharacterInfo.head_texture = character.headTexture;
		deadCharacterInfo.torso_texture = character.torsoTexture;
		deadCharacterInfo.leg_texture = character.legTexture;
		deadCharacterInfo.hair_colour = character.hairColor;
		deadCharacterInfo.skin_color = character.skinColor;
		deadCharacterInfo.shirt_color = character.shirtColor;
		deadCharacterInfo.pants_color = character.pantsColor;
		return deadCharacterInfo;
	}

	public void CharacterHasLeft(FamilyMember member, Job_LeaveShelter.LeaveShelterType leaveType)
	{
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.UnregisterSaveable(member);
		}
		if ((Object)(object)Instance != (Object)null)
		{
			Instance.UnregisterFamilyMember(member);
		}
		if ((Object)(object)ActivityLog.Instance != (Object)null)
		{
			ActivityLog.Activity type = ActivityLog.Activity.CharacterLeft_Normal;
			switch (leaveType)
			{
			case Job_LeaveShelter.LeaveShelterType.Normal:
				type = ActivityLog.Activity.CharacterLeft_Normal;
				break;
			case Job_LeaveShelter.LeaveShelterType.Steal:
				type = ActivityLog.Activity.CharacterLeft_Steal;
				break;
			case Job_LeaveShelter.LeaveShelterType.DamageObject:
				type = ActivityLog.Activity.CharacterLeft_Damage;
				break;
			case Job_LeaveShelter.LeaveShelterType.Defecate:
				type = ActivityLog.Activity.CharacterLeft_Defecate;
				break;
			case Job_LeaveShelter.LeaveShelterType.Deupgrade:
				type = ActivityLog.Activity.CharacterLeft_Deupgrade;
				break;
			}
			ActivityLog.Instance.Add(type, new ActivityLog.ExtraInfoString(member.firstName, isLocalizationKey: false));
		}
	}

	public Job_LeaveShelter.LeaveShelterType GetRandomLeaveType(EncounterCharacter.PersonalityType personality)
	{
		LeaveTypeWeights leaveTypeWeights = null;
		switch (personality)
		{
		case EncounterCharacter.PersonalityType.Generic:
			leaveTypeWeights = m_leaveWeights_Generic;
			break;
		case EncounterCharacter.PersonalityType.Aggressive:
			leaveTypeWeights = m_leaveWeights_Aggressive;
			break;
		case EncounterCharacter.PersonalityType.Haggler:
			leaveTypeWeights = m_leaveWeights_Haggler;
			break;
		case EncounterCharacter.PersonalityType.Passive:
			leaveTypeWeights = m_leaveWeights_Passive;
			break;
		}
		if (leaveTypeWeights == null)
		{
			return Job_LeaveShelter.LeaveShelterType.Normal;
		}
		List<Job_LeaveShelter.LeaveShelterType> list = new List<Job_LeaveShelter.LeaveShelterType>();
		AddIfValidTargets(list, Job_LeaveShelter.LeaveShelterType.Normal, leaveTypeWeights.normal);
		AddIfValidTargets(list, Job_LeaveShelter.LeaveShelterType.DamageObject, leaveTypeWeights.damage);
		AddIfValidTargets(list, Job_LeaveShelter.LeaveShelterType.Steal, leaveTypeWeights.steal);
		AddIfValidTargets(list, Job_LeaveShelter.LeaveShelterType.Defecate, leaveTypeWeights.defecate);
		AddIfValidTargets(list, Job_LeaveShelter.LeaveShelterType.Deupgrade, leaveTypeWeights.deupgrade);
		Job_LeaveShelter.LeaveShelterType result = Job_LeaveShelter.LeaveShelterType.Normal;
		if (list.Count > 0)
		{
			result = list[Random.Range(0, list.Count)];
		}
		return result;
	}

	private void AddIfValidTargets(List<Job_LeaveShelter.LeaveShelterType> list, Job_LeaveShelter.LeaveShelterType type, int amount)
	{
		List<Obj_Base> validTargetsForLeaveType = Job_LeaveShelter.GetValidTargetsForLeaveType(type);
		if (validTargetsForLeaveType.Count > 0)
		{
			for (int i = 0; i < amount; i++)
			{
				list.Add(type);
			}
		}
	}

	public string GetRandomLeaveSpeech(EncounterCharacter.PersonalityType personality)
	{
		if (m_leaveStrings.Count > 0)
		{
			return m_leaveStrings[Random.Range(0, m_leaveStrings.Count)];
		}
		return string.Empty;
	}

	private void CheckTheShelterIsManned(FamilyMember incapacitatedMember)
	{
		List<FamilyMember> shelteredAndHealthyMembers = GetShelteredAndHealthyMembers(onlyIndoorMembers: false);
		if (shelteredAndHealthyMembers.Count != 0 && (shelteredAndHealthyMembers.Count != 1 || !((Object)(object)shelteredAndHealthyMembers[0] == (Object)(object)incapacitatedMember)))
		{
			return;
		}
		ExplorationManager.Instance.RecallNearestExplorationParty();
		for (int i = 0; i < familyMembers.Count; i++)
		{
			if (!familyMembers[i].isAway || !familyMembers[i].waitingForDoor)
			{
				continue;
			}
			if (!((Object)(object)ObjectManager.Instance != (Object)null))
			{
				break;
			}
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.ShelterDoor);
			if (objectsOfType == null)
			{
				break;
			}
			for (int j = 0; j < objectsOfType.Count; j++)
			{
				Obj_ShelterDoor obj_ShelterDoor = objectsOfType[j] as Obj_ShelterDoor;
				if ((Object)(object)obj_ShelterDoor != (Object)null)
				{
					obj_ShelterDoor.Open();
				}
			}
			break;
		}
	}

	public bool CharacterWillBecomeCatatonic(FamilyMember member)
	{
		if ((Object)(object)member == (Object)null)
		{
			return false;
		}
		if (catatonicFamilyMembers.Contains(member))
		{
			return false;
		}
		if ((Object)(object)InteractionManager.Instance != (Object)null)
		{
			InteractionManager.Instance.UnRegisterFamilyMember(member);
		}
		catatonicFamilyMembers.Add(member);
		return true;
	}

	public bool CharacterHasBecomeCatatonic(FamilyMember member)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)member == (Object)null)
		{
			return false;
		}
		if (!catatonicFamilyMembers.Contains(member))
		{
			return false;
		}
		if (catatonicGhosts.ContainsKey(member))
		{
			return false;
		}
		Obj_Base obj_Base = ObjectManager.Instance.SpawnObject(ObjectManager.ObjectType.CatatonicGhost, Vector2.zero);
		if (obj_Base.GetObjectType() != ObjectManager.ObjectType.CatatonicGhost)
		{
			ObjectManager.Instance.RemoveObject(obj_Base);
			return false;
		}
		Obj_CatatonicGhost obj_CatatonicGhost = (Obj_CatatonicGhost)obj_Base;
		if ((Object)(object)obj_CatatonicGhost == (Object)null)
		{
			ObjectManager.Instance.RemoveObject(obj_Base);
			return false;
		}
		catatonicGhosts.Add(member, obj_CatatonicGhost);
		obj_CatatonicGhost.SetUpGhost(member);
		((Component)obj_CatatonicGhost).transform.parent = ((Component)member).transform;
		((Component)obj_CatatonicGhost).transform.localPosition = Vector3.zero;
		((Component)obj_CatatonicGhost).transform.localScale = Vector3.one;
		CheckTheShelterIsManned(member);
		return true;
	}

	public bool CharacterHasRecoveredFromCatatonic(FamilyMember member)
	{
		if ((Object)(object)member == (Object)null)
		{
			return false;
		}
		if (!catatonicGhosts.ContainsKey(member))
		{
			return false;
		}
		if ((Object)(object)InteractionManager.Instance != (Object)null && !member.isDead)
		{
			InteractionManager.Instance.RegisterFamilyMember(member);
		}
		if (catatonicGhosts.TryGetValue(member, out var value))
		{
			if ((Object)(object)ObjectManager.Instance != (Object)null)
			{
				ObjectManager.Instance.RemoveObject(value);
			}
			catatonicGhosts.Remove(member);
		}
		catatonicFamilyMembers.Remove(member);
		return true;
	}

	public ReadOnlyCollection<FamilyMember> GetCatatonicCharacters()
	{
		return catatonicFamilyMembers.AsReadOnly();
	}

	public int GetNumCatatonicCharacters()
	{
		if (catatonicFamilyMembers != null && catatonicFamilyMembers.Count >= 0)
		{
			return catatonicFamilyMembers.Count;
		}
		return 0;
	}

	public void CharacterHasHarvestedCorpse(FamilyMember member, float base_trauma)
	{
		int num = Mathf.Max(1, MaxHarvestedCorpses);
		float num2 = base_trauma * (1f - Mathf.Clamp01((float)m_corpsesHarvested / (float)num));
		m_corpsesHarvested++;
		member.stats.trauma.Modify(Mathf.Ceil(num2));
	}

	public bool AdoptNpc(NpcVisitor npc)
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)npc == (Object)null)
		{
			return false;
		}
		FamilyMember familyMember = ((Component)npc).gameObject.AddComponent<FamilyMember>();
		if ((Object)(object)familyMember != (Object)null)
		{
			familyMember.AdoptNpc(npc);
			((Component)familyMember).transform.parent = ((Component)this).transform;
			if (m_adoptNodes.Length > 0)
			{
				Vector3 position = m_adoptNodes[0].transform.position;
				familyMember.AddAIJob(new Job_GoToLocation(familyMember, position, cancellableInTransit: false));
			}
			((Component)npc).gameObject.AddComponent<FamilyAI>();
			Object.Destroy((Object)(object)npc);
			return true;
		}
		return false;
	}

	public void SpawnCharacterUI(BaseCharacter character, bool isFamilyMember)
	{
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = ((!isFamilyMember) ? m_npcUIPrefab : m_familyUIPrefab);
		UICamera uICamera = UICamera.FindCameraForLayer(val.layer);
		if (!((Object)(object)uICamera != (Object)null))
		{
			return;
		}
		GameObject gameObject = ((Component)uICamera).gameObject;
		UIAnchor component = gameObject.GetComponent<UIAnchor>();
		if ((Object)(object)component != (Object)null)
		{
			gameObject = ((Component)component).gameObject;
		}
		GameObject val2 = Object.Instantiate<GameObject>(val);
		if ((Object)(object)val2 != (Object)null)
		{
			Transform transform = val2.transform;
			transform.parent = gameObject.transform;
			transform.localScale = Vector3.one;
			transform.localRotation = Quaternion.identity;
			transform.localPosition = Vector3.zero;
			UI_Character component2 = val2.GetComponent<UI_Character>();
			if ((Object)(object)component2 != (Object)null)
			{
				component2.character = ((Component)character).transform;
				component2.baseCharacter = character;
			}
		}
	}

	public void RegisterPet(CompanionAnimal pet)
	{
		m_familyPet = pet;
		if ((Object)(object)pet != (Object)null && ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating))
		{
			m_petType = pet.m_type;
		}
	}

	public void UnregisterPet(CompanionAnimal pet)
	{
		if ((Object)(object)m_familyPet == (Object)(object)pet)
		{
			m_familyPet = null;
		}
	}

	public void RegisterPet(Obj_Pet pet)
	{
		m_objectPet = pet;
		if ((Object)(object)pet != (Object)null && ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating))
		{
			m_petType = pet.m_type;
		}
	}

	public void UnregisterPet(Obj_Pet pet)
	{
		if ((Object)(object)m_objectPet == (Object)(object)pet)
		{
			m_objectPet = null;
		}
	}

	public bool RegisterFamilyMember(FamilyMember member, out int id)
	{
		id = -1;
		if (!familyMembers.Contains(member))
		{
			familyMembers.Add(member);
			SpawnCharacterUI(member, isFamilyMember: true);
			id = uniqueMemberId++;
			return true;
		}
		return false;
	}

	public void UnregisterFamilyMember(FamilyMember member)
	{
		if (familyMembers.Contains(member))
		{
			familyMembers.Remove(member);
		}
	}

	public List<FamilyMember> GetShelteredFamilyMembers(bool onlyIndoorMembers)
	{
		List<FamilyMember> list = new List<FamilyMember>();
		for (int i = 0; i < familyMembers.Count; i++)
		{
			if ((Object)(object)familyMembers[i] != (Object)null && !familyMembers[i].isAway && !familyMembers[i].isHiding && !familyMembers[i].isUncontrollable && !familyMembers[i].isDead && (!onlyIndoorMembers || !familyMembers[i].isOutside))
			{
				list.Add(familyMembers[i]);
			}
		}
		return list;
	}

	public List<FamilyMember> GetShelteredAndHealthyMembers(bool onlyIndoorMembers)
	{
		List<FamilyMember> list = new List<FamilyMember>();
		for (int i = 0; i < familyMembers.Count; i++)
		{
			if ((Object)(object)familyMembers[i] != (Object)null && !familyMembers[i].isAway && !familyMembers[i].isUncontrollable && !familyMembers[i].isDead && !familyMembers[i].isCatatonic && (!onlyIndoorMembers || !familyMembers[i].isOutside))
			{
				list.Add(familyMembers[i]);
			}
		}
		return list;
	}

	public List<FamilyMember> GetAllFamilyMembers()
	{
		return new List<FamilyMember>(familyMembers);
	}

	public FamilyMember GetFamilyMember(int id)
	{
		for (int i = 0; i < familyMembers.Count; i++)
		{
			if (familyMembers[i].GetId() == id)
			{
				return familyMembers[i];
			}
		}
		return null;
	}

	public ReadOnlyCollection<DeadCharacterInfo> GetDeadFamilyMemberInfo()
	{
		return m_deadCharactersInfo.AsReadOnly();
	}

	public void ForceUpdateDeadCharacterInfo()
	{
		for (int i = 0; i < familyMembers.Count; i++)
		{
			if (familyMembers[i].isDying || familyMembers[i].isCatatonic)
			{
				m_deadCharactersInfo.Add(CreateObituaryInfo(familyMembers[i]));
			}
		}
	}

	public void SetNextColourReset(float time)
	{
		m_nextColourReset = time;
	}

	public bool HaveAllFamilyBeenLoaded()
	{
		if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading)
		{
			return true;
		}
		if (SaveManager.instance.HasBeenLoaded(this))
		{
			for (int i = 0; i < familyMembers.Count; i++)
			{
				if ((Object)(object)familyMembers[i] == (Object)null || !SaveManager.instance.HasBeenLoaded(familyMembers[i]))
				{
					return false;
				}
			}
			return true;
		}
		return false;
	}

	public bool IsRelocationEnabled()
	{
		return true;
	}

	private void CheckForStuckPartyMemebers()
	{
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)ExplorationManager.Instance != (Object)null) || ExplorationManager.Instance.isPartyExploring)
		{
			return;
		}
		int num = 0;
		List<FamilyMember> allFamilyMembers = Instance.GetAllFamilyMembers();
		for (int i = 0; i < allFamilyMembers.Count; i++)
		{
			if ((Object)(object)allFamilyMembers[i] != (Object)null && allFamilyMembers[i].isAway)
			{
				num++;
				List<GameObject> entranceNodes = ExplorationManager.Instance.entranceNodes;
				int index = 0;
				Vector3 position = entranceNodes[index].transform.position;
				allFamilyMembers[i].AddAIJob(new Job_GoToLocation(allFamilyMembers[i], position, cancellableInTransit: false, Job_GoToLocation.LocationReachedAction.ReturnedFromExpedition));
				allFamilyMembers[i].isAway = false;
			}
		}
		if (num == 1)
		{
			ActivityLog.Instance.Add(ActivityLog.Activity.LostCharacterReturn);
		}
		else if (num > 1)
		{
			ActivityLog.Instance.Add(ActivityLog.Activity.LostCharactersReturn);
		}
	}

	private void OnDestroy()
	{
		GameTime.newDay -= CheckForStuckPartyMemebers;
	}

	public bool IsReadyForLoad()
	{
		if ((Object)(object)SaveManager.instance != (Object)null && (Object)(object)ObjectManager.Instance != (Object)null && SaveManager.instance.HasBeenLoaded(ObjectManager.Instance))
		{
			return true;
		}
		return false;
	}

	public bool SaveLoad(SaveData data)
	{
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ed: Unknown result type (might be due to invalid IL or missing references)
		data.GroupStart("FamilyManager");
		data.SaveLoadList("members", familyMembers, delegate(int i)
		{
			//IL_0040: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Unknown result type (might be due to invalid IL or missing references)
			int value10 = familyMembers[i].GetId();
			data.SaveLoad("uniqueId", ref value10);
			Vector3 value11 = ((Component)familyMembers[i]).transform.position;
			data.SaveLoad("spawnPos", ref value11);
			string value12 = familyMembers[i].meshId;
			data.SaveLoad("meshId", ref value12);
			bool value13 = familyMembers[i].isDead || familyMembers[i].isDying;
			data.SaveLoad("dead", ref value13);
			bool value14 = familyMembers[i].isCatatonic;
			data.SaveLoad("catatonic", ref value14);
			bool value15 = familyMembers[i].isAway;
			data.SaveLoad("away", ref value15);
			bool value16 = familyMembers[i].isAdopted;
			data.SaveLoad("adopted", ref value16);
		}, delegate
		{
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			int value10 = -1;
			data.SaveLoad("uniqueId", ref value10);
			Vector3 value11 = Vector3.zero;
			data.SaveLoad("spawnPos", ref value11);
			string value12 = string.Empty;
			data.SaveLoad("meshId", ref value12);
			bool value13 = false;
			data.SaveLoad("dead", ref value13);
			bool value14 = false;
			data.SaveLoad("catatonic", ref value14);
			bool value15 = false;
			data.SaveLoad("away", ref value15);
			bool value16 = false;
			data.SaveLoad("adopted", ref value16);
			if ((!data.isRelocating || (!value13 && !value14 && !value15 && !value16)) && (Object)(object)FamilySpawner.instance != (Object)null)
			{
				FamilySpawner.CharacterAttributes attribs = new FamilySpawner.CharacterAttributes
				{
					m_meshId = value12
				};
				FamilyMember familyMember = FamilySpawner.instance.SpawnFamilyMember(attribs, value11);
				if ((Object)(object)familyMember != (Object)null)
				{
					familyMember.SetId(value10);
				}
			}
		});
		data.SaveLoad("uniqueId", ref uniqueMemberId);
		int value = (int)m_petType;
		data.SaveLoad("petType", ref value);
		if (data.isLoading)
		{
			m_petType = (FamilySpawner.PetType)value;
		}
		bool value2 = (Object)(object)m_familyPet != (Object)null;
		data.SaveLoad("livingPet", ref value2);
		bool value3 = !((Object)(object)m_familyPet != (Object)null) || !m_familyPet.isDead;
		data.SaveLoad("petAlive", ref value3);
		if (value2)
		{
			string value4 = ((!((Object)(object)m_familyPet != (Object)null)) ? string.Empty : m_familyPet.petName);
			Vector3 value5 = ((!((Object)(object)m_familyPet != (Object)null)) ? Vector3.zero : ((Component)m_familyPet).transform.position);
			data.SaveLoad("petName", ref value4);
			data.SaveLoad("petPos", ref value5);
			if (data.isLoading && (!data.isRelocating || value3) && m_petType != FamilySpawner.PetType.Max)
			{
				FamilySpawner.instance.SpawnPet(m_petType, value4, value5);
			}
		}
		int value6 = ((!((Object)(object)m_objectPet != (Object)null)) ? (-1) : m_objectPet.objectId);
		data.SaveLoad("objectPetId", ref value6);
		bool value7 = !((Object)(object)m_objectPet != (Object)null) || !m_objectPet.isDead;
		data.SaveLoad("objectPetAlive", ref value7);
		if (value6 >= 0)
		{
			string value8 = ((!((Object)(object)m_objectPet != (Object)null)) ? string.Empty : m_objectPet.petName);
			Vector3 value9 = ((!((Object)(object)m_objectPet != (Object)null)) ? Vector3.zero : ((Component)m_objectPet).transform.position);
			data.SaveLoad("objectPetName", ref value8);
			data.SaveLoad("objectPetPos", ref value9);
			if (data.isLoading && (!data.isRelocating || value7))
			{
				if (m_petType != FamilySpawner.PetType.Max)
				{
					FamilySpawner.instance.SpawnPet(m_petType, value8, value9);
				}
				if ((Object)(object)m_objectPet != (Object)null)
				{
					m_objectPet.SetObjectId(value6, initialObject: false);
				}
			}
		}
		if (data.isLoading && (!value2 || (m_petType != FamilySpawner.PetType.Cat && m_petType != FamilySpawner.PetType.Dog && m_petType != FamilySpawner.PetType.Max)))
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.FoodBowl);
			for (int num = 0; num < objectsOfType.Count; num++)
			{
				if ((Object)(object)objectsOfType[num] != (Object)null)
				{
					Obj_FoodBowl obj_FoodBowl = objectsOfType[num] as Obj_FoodBowl;
					if ((Object)(object)obj_FoodBowl != (Object)null)
					{
						obj_FoodBowl.SetPendingDelete();
					}
				}
			}
		}
		if (!data.isLoading || !data.isRelocating)
		{
			data.SaveLoadList("catatonicMembers", catatonicFamilyMembers, delegate(int i)
			{
				int value10 = ((!((Object)(object)catatonicFamilyMembers[i] != (Object)null)) ? (-1) : catatonicFamilyMembers[i].GetId());
				data.SaveLoad("memberId", ref value10);
			}, delegate
			{
				int value10 = -1;
				data.SaveLoad("memberId", ref value10);
				if (value10 > -1)
				{
					FamilyMember familyMember = GetFamilyMember(value10);
					if ((Object)(object)familyMember != (Object)null)
					{
						catatonicFamilyMembers.Add(familyMember);
					}
				}
			});
			List<FamilyMember> keys = new List<FamilyMember>();
			keys.AddRange(catatonicGhosts.Keys);
			List<Obj_CatatonicGhost> values = new List<Obj_CatatonicGhost>();
			values.AddRange(catatonicGhosts.Values);
			data.SaveLoadList("ghostKeys", keys, delegate(int i)
			{
				int value10 = ((!((Object)(object)keys[i] != (Object)null)) ? (-1) : keys[i].GetId());
				data.SaveLoad("memberId", ref value10);
			}, delegate
			{
				int value10 = -1;
				data.SaveLoad("memberId", ref value10);
				if (value10 > -1)
				{
					FamilyMember familyMember = GetFamilyMember(value10);
					if ((Object)(object)familyMember != (Object)null)
					{
						keys.Add(familyMember);
					}
				}
			});
			data.SaveLoadList("ghostValues", values, delegate(int i)
			{
				int value10 = ((!((Object)(object)values[i] != (Object)null)) ? (-1) : values[i].objectId);
				data.SaveLoad("objectId", ref value10);
			}, delegate
			{
				int value10 = -1;
				data.SaveLoad("objectId", ref value10);
				if (value10 > -1)
				{
					Obj_Base objectWithId = ObjectManager.Instance.GetObjectWithId(value10);
					if ((Object)(object)objectWithId != (Object)null)
					{
						values.Add(objectWithId as Obj_CatatonicGhost);
					}
				}
			});
			if (data.isLoading && keys.Count == values.Count)
			{
				for (int num2 = 0; num2 < keys.Count; num2++)
				{
					catatonicGhosts.Add(keys[num2], values[num2]);
				}
			}
		}
		if (data.isSaving && data.isRelocating)
		{
			ForceUpdateDeadCharacterInfo();
		}
		data.SaveLoadList("deadCharacters", m_deadCharactersInfo, delegate(int i)
		{
			DeadCharacterInfo deadCharacterInfo = m_deadCharactersInfo[i];
			deadCharacterInfo.SaveLoadInfo(data);
		}, delegate
		{
			DeadCharacterInfo deadCharacterInfo = new DeadCharacterInfo();
			deadCharacterInfo.SaveLoadInfo(data);
			m_deadCharactersInfo.Add(deadCharacterInfo);
		});
		data.SaveLoad("corpses_harvested", ref m_corpsesHarvested);
		data.SaveLoadAbsoluteTime("colorResetTime", ref m_nextColourReset);
		data.SaveLoad("particleTint", ref m_particleTint);
		data.SaveLoad("particleTintActive", ref m_particleTintActive);
		data.GroupEnd();
		return true;
	}
}
