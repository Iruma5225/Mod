using UnityEngine;

public class Obj_Radio : Obj_Base
{
	public delegate void TransmissionCallback();

	public GameObject incomingTransmissionIcon;

	public SpriteRenderer mapSprite;

	public TransmissionCallback acceptTransmissionCallback;

	public TransmissionCallback rejectTransmissionCallback;

	private bool m_broadcasting;

	private bool m_scanning;

	[SerializeField]
	private AudioClip transmissionSFX;

	[SerializeField]
	private float transmissionSFXInterval = 10f;

	private float transmissionSFXTimer;

	private int m_users;

	public bool incomingTransmission
	{
		get
		{
			return (Object)(object)incomingTransmissionIcon != (Object)null && incomingTransmissionIcon.activeSelf;
		}
		set
		{
			if ((Object)(object)incomingTransmissionIcon != (Object)null)
			{
				SetIncomingTransmissionIndicator(value);
			}
		}
	}

	public bool broadcasting => m_broadcasting;

	public bool scanning => m_scanning;

	public int Users => m_users;

	public override void Update()
	{
		base.Update();
		if (!incomingTransmissionIcon.activeSelf)
		{
			return;
		}
		transmissionSFXTimer -= Time.deltaTime;
		if (transmissionSFXTimer <= 0f)
		{
			transmissionSFXTimer = transmissionSFXInterval;
			if ((Object)(object)AudioManager.Instance != (Object)null)
			{
				AudioManager.Instance.PlaySFX(transmissionSFX);
			}
		}
	}

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.RadioTransmitter;
	}

	public void AcceptTransmission()
	{
		if (acceptTransmissionCallback != null)
		{
			acceptTransmissionCallback();
		}
		acceptTransmissionCallback = null;
		rejectTransmissionCallback = null;
		incomingTransmission = false;
	}

	public void RejectTransmission()
	{
		if (rejectTransmissionCallback != null)
		{
			rejectTransmissionCallback();
		}
		acceptTransmissionCallback = null;
		rejectTransmissionCallback = null;
		incomingTransmission = false;
	}

	private void SetIncomingTransmissionIndicator(bool isActive)
	{
		incomingTransmissionIcon.SetActive(isActive);
		if (isActive)
		{
			transmissionSFXTimer = 0f;
			if ((Object)(object)ActivityLog.Instance != (Object)null)
			{
				ActivityLog.Instance.Add(ActivityLog.Activity.IncomingRadioTransmission, ((Component)this).gameObject.transform);
			}
			UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.Radio);
		}
	}

	public void StartBroadcastingForTraders()
	{
		if ((Object)(object)NpcVisitManager.Instance != (Object)null)
		{
			NpcVisitManager.Instance.SetTraderBroadcastSpawnChances();
			NpcVisitManager.Instance.SetSpawnFrequency(fast: true, GetRadioUpgradeLevel());
		}
		m_broadcasting = true;
	}

	public void StartBroadcastingForRecruits()
	{
		if ((Object)(object)NpcVisitManager.Instance != (Object)null)
		{
			NpcVisitManager.Instance.SetRecruitBroadcastSpawnChances();
			NpcVisitManager.Instance.SetSpawnFrequency(fast: true, GetRadioUpgradeLevel());
		}
		m_broadcasting = true;
	}

	public void StopBroadcasting()
	{
		if ((Object)(object)NpcVisitManager.Instance != (Object)null)
		{
			NpcVisitManager.Instance.ResetSpawnChances();
			NpcVisitManager.Instance.SetSpawnFrequency(fast: false, GetRadioUpgradeLevel());
		}
		m_broadcasting = false;
	}

	public void StartScanning()
	{
		m_scanning = true;
	}

	public void StopScanning()
	{
		m_scanning = false;
	}

	public override void OnSelected()
	{
		base.OnSelected();
		if ((Object)(object)mapSprite != (Object)null)
		{
			((Renderer)mapSprite).material.EnableKeyword("OUTLINE_ON");
		}
	}

	public override void OnUnSelected()
	{
		base.OnUnSelected();
		if ((Object)(object)mapSprite != (Object)null)
		{
			((Renderer)mapSprite).material.DisableKeyword("OUTLINE_ON");
		}
	}

	public int GetRadioUpgradeLevel()
	{
		int result = 0;
		if ((Object)(object)upgrade_component != (Object)null)
		{
			result = upgrade_component.GetUpgradeLevel(UpgradeObject.PathEnum.Radio);
		}
		return result;
	}

	public void IncreaseUsers()
	{
		m_users++;
	}

	public void DecreaseUsers()
	{
		m_users--;
		if (m_users < 0)
		{
			m_users = 0;
		}
	}
}
