using UnityEngine;

public class UI_Character : MonoBehaviour
{
	public Transform character;

	public FamilyMember familyMember;

	public BaseCharacter baseCharacter;

	[SerializeField]
	private Transform m_aboveHeadRootObject;

	private Camera gameCamera;

	private Camera uiCamera;

	private float normalGameCamSize;

	private float m_height;

	public void Start()
	{
		if ((Object)(object)character == (Object)null)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
			return;
		}
		familyMember = ((Component)character).GetComponent<FamilyMember>();
		if ((Object)(object)baseCharacter != (Object)null)
		{
			m_height = baseCharacter.meshUIHeight;
		}
		GameObject val = GameObject.FindWithTag("MainCamera");
		if ((Object)(object)val != (Object)null)
		{
			gameCamera = val.GetComponent<Camera>();
		}
		uiCamera = ((Component)((Component)this).transform.parent).GetComponent<Camera>();
		BasicCamera component = ((Component)gameCamera).GetComponent<BasicCamera>();
		if ((Object)(object)component != (Object)null)
		{
			normalGameCamSize = component.preZoomSize;
		}
	}

	public void LateUpdate()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)character == (Object)null || (Object)(object)baseCharacter == (Object)null)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
			return;
		}
		Vector3 position = character.position;
		Vector3 val = position + new Vector3(0f, m_height, 0f);
		Vector3 position2 = uiCamera.ViewportToWorldPoint(gameCamera.WorldToViewportPoint(position));
		Vector3 position3 = uiCamera.ViewportToWorldPoint(gameCamera.WorldToViewportPoint(val));
		position2.z = 0f;
		position3.z = 0f;
		((Component)this).transform.position = position2;
		((Component)this).transform.localScale = Vector3.one * (normalGameCamSize / gameCamera.orthographicSize);
		if ((Object)(object)m_aboveHeadRootObject != (Object)null)
		{
			((Component)m_aboveHeadRootObject).transform.position = position3;
		}
	}
}
