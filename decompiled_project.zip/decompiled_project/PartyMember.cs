using System.Collections.Generic;
using UnityEngine;

public class PartyMember : MonoBehaviour
{
	private int m_partyId = -1;

	private FamilyMember m_person;

	private ItemGrid.ItemSlot m_weapon;

	private ItemGrid.ItemSlot m_item1;

	private ItemGrid.ItemSlot m_item2;

	private ItemGrid.ItemSlot m_loadCarrier;

	public FamilyMember person
	{
		get
		{
			return m_person;
		}
		set
		{
			m_person = value;
		}
	}

	public int partyId
	{
		get
		{
			return m_partyId;
		}
		set
		{
			m_partyId = value;
		}
	}

	public bool RemoveFromEquippedItems(ItemManager.ItemType itemType)
	{
		bool result = false;
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(itemType);
		switch (itemDefinition.Category)
		{
		case ItemManager.ItemCategory.Weapon:
			if (m_weapon != null && m_weapon.m_type == itemType)
			{
				m_weapon = null;
				result = true;
			}
			break;
		case ItemManager.ItemCategory.Armour:
		case ItemManager.ItemCategory.Equipment:
			if (m_item1 != null && m_item1.m_type == itemType)
			{
				m_item1 = null;
				result = true;
			}
			else if (m_item2 != null && m_item2.m_type == itemType)
			{
				m_item2 = null;
				result = true;
			}
			break;
		case ItemManager.ItemCategory.LoadCarrying:
			if (m_loadCarrier != null && m_loadCarrier.m_type == itemType)
			{
				m_loadCarrier = null;
				result = true;
			}
			break;
		}
		return result;
	}

	public List<ItemStack> GetEquippedItems()
	{
		List<ItemStack> list = new List<ItemStack>();
		if (m_weapon != null)
		{
			list.Add(new ItemStack(m_weapon.m_type, m_weapon.m_count));
		}
		if (m_item1 != null)
		{
			list.Add(new ItemStack(m_item1.m_type, m_item1.m_count));
		}
		if (m_item2 != null)
		{
			list.Add(new ItemStack(m_item2.m_type, m_item2.m_count));
		}
		if (m_loadCarrier != null)
		{
			list.Add(new ItemStack(m_loadCarrier.m_type, m_loadCarrier.m_count));
		}
		return list;
	}

	public bool SetEquippedWeapon(ItemManager.ItemType itemType)
	{
		bool result = false;
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(itemType);
		if (itemDefinition.Category == ItemManager.ItemCategory.Weapon)
		{
			m_weapon = new ItemGrid.ItemSlot();
			m_weapon.m_type = itemType;
			m_weapon.m_stackSize = 1;
			m_weapon.m_count = 1;
			result = true;
		}
		return result;
	}

	public ItemManager.ItemType GetEquippedWeapon()
	{
		ItemManager.ItemType result = ItemManager.ItemType.Undefined;
		if (m_weapon != null)
		{
			result = m_weapon.m_type;
		}
		return result;
	}

	public bool SetEquippedItem1(ItemManager.ItemType itemType)
	{
		bool result = false;
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(itemType);
		if (itemDefinition.Category == ItemManager.ItemCategory.Armour || itemDefinition.Category == ItemManager.ItemCategory.Equipment)
		{
			m_item1 = new ItemGrid.ItemSlot();
			m_item1.m_type = itemType;
			m_item1.m_stackSize = 1;
			m_item1.m_count = 1;
			result = true;
		}
		return result;
	}

	public ItemManager.ItemType GetEquippedItem1()
	{
		ItemManager.ItemType result = ItemManager.ItemType.Undefined;
		if (m_item1 != null)
		{
			result = m_item1.m_type;
		}
		return result;
	}

	public bool SetEquippedItem2(ItemManager.ItemType itemType)
	{
		bool result = false;
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(itemType);
		if (itemDefinition.Category == ItemManager.ItemCategory.Armour || itemDefinition.Category == ItemManager.ItemCategory.Equipment)
		{
			m_item2 = new ItemGrid.ItemSlot();
			m_item2.m_type = itemType;
			m_item2.m_stackSize = 1;
			m_item2.m_count = 1;
			result = true;
		}
		return result;
	}

	public bool SetEquippedAmmo(ItemManager.ItemType itemType, int count)
	{
		bool result = false;
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(itemType);
		if (itemDefinition.Category == ItemManager.ItemCategory.Ammo)
		{
			m_item2 = new ItemGrid.ItemSlot();
			m_item2.m_type = itemType;
			m_item2.m_stackSize = 1;
			m_item2.m_count = count;
			result = true;
		}
		return result;
	}

	public ItemManager.ItemType GetEquippedItem2()
	{
		ItemManager.ItemType result = ItemManager.ItemType.Undefined;
		if (m_item2 != null)
		{
			result = m_item2.m_type;
		}
		return result;
	}

	public bool SetEquippedLoadCarrier(ItemManager.ItemType itemType)
	{
		bool result = false;
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(itemType);
		if (itemDefinition.Category == ItemManager.ItemCategory.LoadCarrying)
		{
			m_loadCarrier = new ItemGrid.ItemSlot();
			m_loadCarrier.m_type = itemType;
			m_loadCarrier.m_stackSize = 1;
			m_loadCarrier.m_count = 1;
			result = true;
		}
		return result;
	}

	public ItemManager.ItemType GetEquippedLoadCarrier()
	{
		ItemManager.ItemType result = ItemManager.ItemType.Undefined;
		if (m_loadCarrier != null)
		{
			result = m_loadCarrier.m_type;
		}
		return result;
	}

	public void ClearAllEquipment()
	{
		m_weapon = null;
		m_item1 = null;
		m_item2 = null;
		m_loadCarrier = null;
	}

	public bool ReturnAllEquippedItemsToMainInventory()
	{
		if (m_weapon != null)
		{
			InventoryManager.Instance.AddNewItem(m_weapon.m_type);
		}
		if (m_item1 != null)
		{
			InventoryManager.Instance.AddNewItem(m_item1.m_type);
		}
		if (m_item2 != null)
		{
			InventoryManager.Instance.AddNewItem(m_item2.m_type);
		}
		if (m_loadCarrier != null)
		{
			InventoryManager.Instance.AddNewItem(m_loadCarrier.m_type);
		}
		return true;
	}

	public int GetLoadCarryingCapacity()
	{
		int num = 0;
		if ((Object)(object)person != (Object)null)
		{
			num = person.loadCarryingCapacity;
			if (m_loadCarrier != null)
			{
				ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(m_loadCarrier.m_type);
				num += itemDefinition.LoadCarrySlots;
			}
		}
		return num;
	}

	public List<ItemStack> DropCarriedItems()
	{
		List<ItemStack> list = new List<ItemStack>();
		List<ItemStack> partyItems = ExplorationManager.Instance.GetPartyItems(m_partyId);
		int partyMaxCarriedItems = ExplorationManager.Instance.GetPartyMaxCarriedItems(m_partyId);
		int num = partyMaxCarriedItems - GetLoadCarryingCapacity();
		int num2 = partyItems.Count / 2;
		num2 = Mathf.Min(num2, GetLoadCarryingCapacity());
		int num3 = partyItems.Count - num2 - num;
		num2 += Mathf.Max(num3, 0);
		Debug.Log((object)("Party has " + partyItems.Count + "/" + partyMaxCarriedItems + " items"));
		Debug.Log((object)("Dropping " + num2 + " items for player with carrying capacity of " + GetLoadCarryingCapacity()));
		Debug.Log((object)("Party now has " + (partyItems.Count - num2) + "/" + num + " items"));
		while (num2-- > 0 && partyItems.Count > 0)
		{
			int index = Random.Range(0, partyItems.Count);
			ExplorationManager.Instance.RemoveFromPartyItems(m_partyId, partyItems[index].m_type, partyItems[index].m_count);
			list.Add(partyItems[index]);
			partyItems.RemoveAt(index);
		}
		return list;
	}

	public MapRegion GetCurrentRegion()
	{
		return ExplorationManager.Instance.GetPartyRegion(m_partyId);
	}

	public void SaveLoadPartyMember(SaveData data)
	{
		data.GroupStart("PartyMember");
		int value = -1;
		if ((Object)(object)person != (Object)null)
		{
			value = person.GetId();
		}
		data.SaveLoad("familyId", ref value);
		if (data.isLoading && value > -1 && (Object)(object)FamilyManager.Instance != (Object)null)
		{
			person = FamilyManager.Instance.GetFamilyMember(value);
		}
		int value2 = (int)((m_weapon == null) ? ItemManager.ItemType.Undefined : m_weapon.m_type);
		int value3 = ((m_weapon != null) ? m_weapon.m_count : 0);
		data.SaveLoad("weaponType", ref value2);
		data.SaveLoad("weaponCount", ref value3);
		if (data.isLoading)
		{
			if (value2 != -1)
			{
				m_weapon = new ItemGrid.ItemSlot();
				m_weapon.m_type = (ItemManager.ItemType)value2;
				m_weapon.m_count = value3;
			}
			else
			{
				m_weapon = null;
			}
		}
		int value4 = (int)((m_item1 == null) ? ItemManager.ItemType.Undefined : m_item1.m_type);
		int value5 = ((m_item1 != null) ? m_item1.m_count : 0);
		data.SaveLoad("item1Type", ref value4);
		data.SaveLoad("item1Count", ref value5);
		if (data.isLoading)
		{
			if (value4 != -1)
			{
				m_item1 = new ItemGrid.ItemSlot();
				m_item1.m_type = (ItemManager.ItemType)value4;
				m_item1.m_count = value5;
			}
			else
			{
				m_item1 = null;
			}
		}
		int value6 = (int)((m_item2 == null) ? ItemManager.ItemType.Undefined : m_item2.m_type);
		int value7 = ((m_item2 != null) ? m_item2.m_count : 0);
		data.SaveLoad("item2Type", ref value6);
		data.SaveLoad("item2Count", ref value7);
		if (data.isLoading)
		{
			if (value6 != -1)
			{
				m_item2 = new ItemGrid.ItemSlot();
				m_item2.m_type = (ItemManager.ItemType)value6;
				m_item2.m_count = value7;
			}
			else
			{
				m_item2 = null;
			}
		}
		int value8 = (int)((m_loadCarrier == null) ? ItemManager.ItemType.Undefined : m_loadCarrier.m_type);
		int value9 = ((m_loadCarrier != null) ? m_loadCarrier.m_count : 0);
		data.SaveLoad("bagType", ref value8);
		data.SaveLoad("bagCount", ref value9);
		if (data.isLoading)
		{
			if (value8 != -1)
			{
				m_loadCarrier = new ItemGrid.ItemSlot();
				m_loadCarrier.m_type = (ItemManager.ItemType)value8;
				m_loadCarrier.m_count = value9;
			}
			else
			{
				m_loadCarrier = null;
			}
		}
		data.GroupEnd();
	}
}
