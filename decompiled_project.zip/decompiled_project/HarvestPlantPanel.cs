using System.Collections.Generic;
using UnityEngine;

public class HarvestPlantPanel : BasePanel
{
	public ItemGrid m_itemgrid;

	public UILabel m_text;

	private const string TextKey = "ui.text.plantharvested";

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override void OnShow()
	{
		base.OnShow();
	}

	public override void OnCancel()
	{
		base.OnCancel();
		UIPanelManager.Instance().PopPanel(this);
	}

	public void Setup(List<ItemManager.ItemType> items)
	{
		if ((Object)(object)m_text != (Object)null)
		{
			string text = Localization.Get("ui.text.plantharvested");
			m_text.text = text;
		}
		if (!((Object)(object)m_itemgrid == (Object)null) && items != null)
		{
			m_itemgrid.Initialize(null, null, null);
			for (int i = 0; i < items.Count; i++)
			{
				m_itemgrid.AddItem(items[i], 1);
			}
		}
	}
}
