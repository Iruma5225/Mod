using System;
using System.Collections.Generic;
using UnityEngine;

public class EncounterCombatPanel : BasePanel
{
	public enum CombatActionEnum
	{
		Melee,
		Subdue,
		Disarm,
		Steal,
		Defend,
		ShootSingle,
		ShootMulti,
		UseItem,
		PickupWeapon,
		Skip,
		Escape
	}

	public class CombatActionInfo
	{
		public CombatActionEnum action = CombatActionEnum.Skip;

		public EncounterCharacter target;

		public ItemManager.ItemType item = ItemManager.ItemType.Undefined;
	}

	private List<EncounterCharacter> player_characters;

	private List<EncounterCharacter> npc_characters;

	private List<EncounterCharacter> initiative_list = new List<EncounterCharacter>();

	private EncounterCharacter current_character;

	private EncounterCharacter target_character;

	[SerializeField]
	private HealthBar player_health;

	[SerializeField]
	private HealthBar npc_health;

	[SerializeField]
	private Transform mini_healthbar_root;

	[SerializeField]
	private Transform target_marker;

	[SerializeField]
	private Transform turn_marker;

	[SerializeField]
	private Transform change_target_prompt;

	[SerializeField]
	private AudioClip new_target_sound;

	[SerializeField]
	private ContextMenuPanel action_menu;

	private List<MiniHealthBar> mini_health_bars = new List<MiniHealthBar>();

	private bool health_bars_active;

	private bool m_isQuestEncounter;

	private const float EscapeDuration = 4f;

	private float escape_end_time;

	private bool m_pendingCombatOver;

	public EncounterCharacter CurrentCharacter => current_character;

	public EncounterCharacter TargetCharacter => target_character;

	public bool AreHealthBarsShowing()
	{
		return health_bars_active;
	}

	public void ShowHealthBars(bool show)
	{
		health_bars_active = show;
		for (int i = 0; i < mini_health_bars.Count; i++)
		{
			mini_health_bars[i].SetVisible(health_bars_active);
		}
	}

	private bool IsPlayerEscaping()
	{
		return escape_end_time != 0f;
	}

	private void Awake()
	{
		if ((Object)(object)mini_healthbar_root != (Object)null)
		{
			MiniHealthBar[] componentsInChildren = ((Component)mini_healthbar_root).GetComponentsInChildren<MiniHealthBar>();
			if (componentsInChildren != null && componentsInChildren.Length > 0)
			{
				mini_health_bars.AddRange(componentsInChildren);
			}
		}
	}

	private bool IsPlayersTurn()
	{
		if ((Object)(object)current_character != (Object)null && current_character.isPlayerControlled)
		{
			return true;
		}
		return false;
	}

	public bool HasPlayerWon()
	{
		for (int i = 0; i < npc_characters.Count; i++)
		{
			if (npc_characters[i].canStillFight && !npc_characters[i].hasEscaped && !npc_characters[i].isPlayerControlled)
			{
				return false;
			}
		}
		return true;
	}

	public bool HasPlayerLost()
	{
		for (int i = 0; i < player_characters.Count; i++)
		{
			if (player_characters[i].canStillFight && player_characters[i].isPlayerControlled)
			{
				return false;
			}
		}
		return true;
	}

	public bool HasPlayerEscaped()
	{
		for (int i = 0; i < player_characters.Count; i++)
		{
			if (player_characters[i].canStillFight && !player_characters[i].hasEscaped && player_characters[i].isPlayerControlled)
			{
				return false;
			}
		}
		return true;
	}

	public override void OnShow()
	{
		base.OnShow();
		if ((Object)(object)EncounterManager.Instance == (Object)null)
		{
			return;
		}
		player_characters = EncounterManager.Instance.GetPlayerCharacters();
		npc_characters = EncounterManager.Instance.GetNPCs();
		if (player_characters.Count > 0 && npc_characters.Count > 0)
		{
			m_pendingCombatOver = false;
			AssignMiniHealthBars();
			ShowHealthBars(show: false);
			initiative_list.AddRange(player_characters);
			initiative_list.AddRange(npc_characters);
			initiative_list.Sort((EncounterCharacter x, EncounterCharacter y) => y.Dexterity.CompareTo(x.Dexterity));
			for (int num = 0; num < initiative_list.Count; num++)
			{
				initiative_list[num].OnCombatStarted();
			}
			NextTurn();
		}
	}

	public override void OnClose()
	{
		base.OnClose();
	}

	private void NextTurn()
	{
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		if (initiative_list.Count <= 0)
		{
			return;
		}
		if ((Object)(object)current_character != (Object)null)
		{
			current_character.OnTurnEnded();
		}
		if (HasPlayerWon() || HasPlayerLost() || HasPlayerEscaped())
		{
			m_pendingCombatOver = true;
			return;
		}
		current_character = FindNextAliveCharacter(current_character, initiative_list);
		current_character.OnTurnStarted();
		if ((Object)(object)turn_marker != (Object)null)
		{
			turn_marker.position = current_character.uiPosition;
		}
		EncounterCharacter encounterCharacter = current_character.lastTargetedCharacter;
		if ((Object)(object)encounterCharacter == (Object)null || encounterCharacter.isDead || encounterCharacter.isSubdued)
		{
			encounterCharacter = ((!current_character.isPlayerCharacter) ? FindNextAliveCharacter(encounterCharacter, player_characters) : FindNextAliveCharacter(encounterCharacter, npc_characters));
		}
		SetTarget(encounterCharacter);
		if (current_character.isPlayerCharacter)
		{
			player_health.SetCharacter(current_character);
		}
		else
		{
			npc_health.SetCharacter(current_character);
		}
		if (current_character.isPlayerControlled && !current_character.isDead && !current_character.isSubdued)
		{
			ShowActionMenu();
		}
	}

	public override void Update()
	{
		if (PauseManager.isPaused || (Object)(object)EncounterManager.Instance == (Object)null)
		{
			return;
		}
		if (m_pendingCombatOver)
		{
			Update_EndConditions();
			return;
		}
		UpdateInput();
		Update_Characters();
		if (IsPlayerEscaping())
		{
			Update_Escape();
		}
		if (IsPlayersTurn())
		{
			Update_Player();
		}
		else
		{
			Update_AI();
		}
		Update_UI();
	}

	private void Update_Characters()
	{
		for (int i = 0; i < initiative_list.Count; i++)
		{
			initiative_list[i].UpdateCharacter();
		}
		if (IsPlayerEscaping())
		{
			return;
		}
		for (int j = 0; j < initiative_list.Count; j++)
		{
			if (!initiative_list[j].isTurnFinished)
			{
				return;
			}
		}
		NextTurn();
	}

	private void Update_Player()
	{
	}

	public void SetIsQuestEncounter(bool isQuest)
	{
		m_isQuestEncounter = isQuest;
	}

	private void Update_AI()
	{
		if (!((Object)(object)current_character != (Object)null) || !current_character.isIdle || !current_character.canStillFight)
		{
			return;
		}
		CombatActionInfo combatActionInfo = null;
		if (current_character.ai != null)
		{
			List<EncounterCharacter> list = new List<EncounterCharacter>();
			List<EncounterCharacter> list2 = new List<EncounterCharacter>();
			if (current_character.isPlayerCharacter)
			{
				list.AddRange(npc_characters);
				list2.AddRange(player_characters);
			}
			else
			{
				list.AddRange(player_characters);
				list2.AddRange(npc_characters);
			}
			list.RemoveAll((EncounterCharacter x) => !x.aiTargetable);
			combatActionInfo = current_character.ai.GetNextAction(list, list2);
			if (combatActionInfo.action == CombatActionEnum.Escape)
			{
				current_character.wantsToEscape = true;
				bool flag = true;
				List<EncounterCharacter> list3 = ((!current_character.isPlayerCharacter) ? npc_characters : player_characters);
				for (int num = 0; num < list3.Count; num++)
				{
					if (list3[num].canStillFight && !list3[num].hasEscaped && !list3[num].wantsToEscape)
					{
						flag = false;
					}
				}
				if (!current_character.isPlayerCharacter && flag && m_isQuestEncounter)
				{
					flag = false;
				}
				if (!flag)
				{
					combatActionInfo = current_character.ai.GetNextAction(list, list2);
				}
			}
			if (combatActionInfo != null)
			{
				ExecuteAction(current_character, combatActionInfo);
				current_character.ai.OnActionExecuted(combatActionInfo.action, combatActionInfo.target);
				return;
			}
		}
		combatActionInfo.action = CombatActionEnum.Skip;
		ExecuteAction(current_character, combatActionInfo);
	}

	private void Update_UI()
	{
		if ((Object)(object)player_health != (Object)null)
		{
			player_health.UpdateHealthBar();
		}
		if ((Object)(object)npc_health != (Object)null)
		{
			npc_health.UpdateHealthBar();
		}
		if (IsActionMenuShowing() && (current_character.isDead || current_character.isSubdued))
		{
			CloseActionMenu();
		}
	}

	private void Update_Escape()
	{
		if (PausableTime.time < escape_end_time)
		{
			return;
		}
		escape_end_time = 0f;
		List<EncounterCharacter> list = null;
		List<EncounterCharacter> list2 = null;
		if (initiative_list.Count > 0 && initiative_list[0].isEscaping && initiative_list[0].isPlayerCharacter)
		{
			list = player_characters;
			list2 = npc_characters;
		}
		else
		{
			list = npc_characters;
			list2 = player_characters;
		}
		if (EncounterLogic.EscapeRoll(list, list2))
		{
			for (int i = 0; i < initiative_list.Count; i++)
			{
				if (initiative_list[i].isEscaping)
				{
					initiative_list[i].EscapeSuccess();
				}
				if (initiative_list[i].isChasing)
				{
					initiative_list[i].ChaseFailed();
				}
			}
			return;
		}
		for (int j = 0; j < initiative_list.Count; j++)
		{
			if (initiative_list[j].isEscaping)
			{
				initiative_list[j].EscapeFailed();
			}
			else if (initiative_list[j].isChasing)
			{
				initiative_list[j].ChaseSuccess();
			}
			else
			{
				initiative_list[j].MoveOffscreen();
			}
		}
		FadeManager.Instance.FadeFromBlack();
	}

	private void Update_EndConditions()
	{
		bool flag = true;
		for (int i = 0; i < initiative_list.Count; i++)
		{
			initiative_list[i].UpdateCharacter();
			if (!initiative_list[i].isTurnFinished)
			{
				flag = false;
			}
		}
		if (flag)
		{
			for (int j = 0; j < initiative_list.Count; j++)
			{
				initiative_list[j].OnCombatEnded();
			}
			EncounterManager.Instance.OnCombatOver();
		}
	}

	public void ExecuteAction(EncounterCharacter attacker, CombatActionInfo action_info)
	{
		if ((Object)(object)attacker == (Object)null || action_info == null || ((Object)(object)action_info.target == (Object)null && (action_info.action == CombatActionEnum.Melee || action_info.action == CombatActionEnum.Subdue || action_info.action == CombatActionEnum.Steal || action_info.action == CombatActionEnum.Disarm || action_info.action == CombatActionEnum.UseItem || action_info.action == CombatActionEnum.ShootSingle)))
		{
			return;
		}
		switch (action_info.action)
		{
		case CombatActionEnum.Skip:
			attacker.SkipTurn();
			break;
		case CombatActionEnum.Melee:
			attacker.MeleeAttack(action_info.target);
			break;
		case CombatActionEnum.Subdue:
			attacker.Subdue(action_info.target);
			break;
		case CombatActionEnum.Disarm:
			attacker.Disarm(action_info.target);
			break;
		case CombatActionEnum.Steal:
			attacker.Steal(action_info.target);
			break;
		case CombatActionEnum.Defend:
			attacker.Defend();
			break;
		case CombatActionEnum.PickupWeapon:
			attacker.PickupWeapon();
			break;
		case CombatActionEnum.UseItem:
			attacker.UseBackpackItem(action_info.item, action_info.target);
			break;
		case CombatActionEnum.ShootSingle:
			attacker.ShootSingle(action_info.target);
			break;
		case CombatActionEnum.ShootMulti:
		{
			List<EncounterCharacter> list = new List<EncounterCharacter>();
			list.AddRange((!current_character.isPlayerCharacter) ? player_characters : npc_characters);
			if (!attacker.isPlayerControlled)
			{
				list.RemoveAll((EncounterCharacter x) => !x.aiTargetable);
			}
			attacker.ShootMultiple(list);
			break;
		}
		case CombatActionEnum.Escape:
			if (attacker.isPlayerCharacter)
			{
				StartEscape(player_characters, npc_characters);
			}
			else
			{
				StartEscape(npc_characters, player_characters);
			}
			break;
		}
	}

	public void StartEscape(List<EncounterCharacter> escapists, List<EncounterCharacter> chasers)
	{
		for (int i = 0; i < escapists.Count; i++)
		{
			if (!escapists[i].isDead && !escapists[i].isSubdued)
			{
				escapists[i].StartEscape();
			}
		}
		for (int j = 0; j < chasers.Count; j++)
		{
			if (!chasers[j].isDead && !chasers[j].isSubdued)
			{
				chasers[j].Chase();
			}
		}
		escape_end_time = PausableTime.time + 4f;
		FadeManager.Instance.FadeToBlack();
	}

	private EncounterCharacter FindNextAliveCharacter(EncounterCharacter start_char, List<EncounterCharacter> characters, bool forward = true)
	{
		int num = -1;
		if ((Object)(object)start_char != (Object)null)
		{
			for (int i = 0; i < characters.Count; i++)
			{
				if ((Object)(object)characters[i] == (Object)(object)start_char)
				{
					num = i;
					break;
				}
			}
		}
		int num2 = num;
		do
		{
			if (forward)
			{
				if (++num2 >= characters.Count)
				{
					num2 = 0;
				}
			}
			else if (--num2 < 0)
			{
				num2 = characters.Count - 1;
			}
		}
		while (!IsValidTarget(characters[num2]) && num2 != num);
		if (num2 < 0 || num2 >= characters.Count)
		{
			return null;
		}
		return characters[num2];
	}

	private bool IsValidTarget(EncounterCharacter character)
	{
		return !character.isDead && !character.isSubdued && !character.hasEscaped;
	}

	private void SetTarget(EncounterCharacter character)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)character == (Object)null))
		{
			target_character = character;
			if ((Object)(object)target_marker != (Object)null)
			{
				target_marker.position = ((Component)target_character).transform.position;
			}
			if (current_character.isPlayerCharacter)
			{
				npc_health.SetCharacter(target_character);
			}
			else
			{
				player_health.SetCharacter(target_character);
			}
		}
	}

	private bool IsActionMenuShowing()
	{
		if ((Object)(object)action_menu != (Object)null && (Object)(object)UIPanelManager.instance != (Object)null && UIPanelManager.instance.IsPanelOnStack(action_menu))
		{
			return true;
		}
		return false;
	}

	public void ShowActionMenu()
	{
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)action_menu == (Object)null))
		{
			List<string> list = new List<string>();
			list.Add("attack");
			list.Add("defend");
			if (current_character.hasAvailableDroppedWeapon)
			{
				list.Add("pickup");
			}
			if (current_character.GetUsableItems().Count > 0)
			{
				list.Add("item");
			}
			if (!BreachMan.instance.inProgress)
			{
				list.Add("escape");
			}
			action_menu.ShowContextMenu(Vector2.op_Implicit(current_character.menuPosition), "UI.action.title", "UI.action.", list, OnActionSelected);
			ShowHealthBars(show: true);
			if ((Object)(object)target_marker != (Object)null && !BreachMan.instance.inProgress)
			{
				((Component)target_marker).gameObject.SetActive(true);
			}
			if ((Object)(object)turn_marker != (Object)null)
			{
				((Component)turn_marker).gameObject.SetActive(true);
			}
			if ((Object)(object)change_target_prompt != (Object)null && npc_characters.Count >= 2)
			{
				((Component)change_target_prompt).gameObject.SetActive(true);
			}
		}
	}

	public void CloseActionMenu()
	{
		if (IsActionMenuShowing())
		{
			action_menu.Close();
			ShowHealthBars(show: false);
			if ((Object)(object)turn_marker != (Object)null)
			{
				((Component)turn_marker).gameObject.SetActive(false);
			}
			if ((Object)(object)target_marker != (Object)null)
			{
				((Component)target_marker).gameObject.SetActive(false);
			}
			if ((Object)(object)change_target_prompt != (Object)null)
			{
				((Component)change_target_prompt).gameObject.SetActive(false);
			}
		}
	}

	private void OnActionSelected(string option)
	{
		CombatActionInfo combatActionInfo = new CombatActionInfo();
		combatActionInfo.target = target_character;
		switch (option)
		{
		default:
			return;
		case "attack":
			ShowAttackMenu();
			return;
		case "item":
			ShowItemMenu();
			return;
		case "defend":
			combatActionInfo.action = CombatActionEnum.Defend;
			break;
		case "pickup":
			combatActionInfo.action = CombatActionEnum.PickupWeapon;
			break;
		case "escape":
			combatActionInfo.action = CombatActionEnum.Escape;
			break;
		}
		ExecuteAction(current_character, combatActionInfo);
		CloseActionMenu();
	}

	private void ShowAttackMenu()
	{
		List<string> list = new List<string>();
		list.Add("melee");
		if (current_character.hasRangedWeapon && current_character.hasAmmo && !BreachMan.instance.inProgress)
		{
			list.Add("shoot_single");
			list.Add("shoot_multi");
		}
		else if (current_character.hasRangedWeapon && current_character.hasAmmo && BreachMan.instance.inProgress && current_character.hasCorrectAmmo)
		{
			list.Add("shoot_single");
			list.Add("shoot_multi");
		}
		if (!BreachMan.instance.inProgress)
		{
			list.Add("subdue");
		}
		list.Add("disarm");
		if (!BreachMan.instance.inProgress)
		{
			list.Add("steal");
		}
		action_menu.PushNewLayer("UI.action_menu.attack.title", "UI.action_menu.attack.", list, OnAttackSelected);
	}

	private void OnAttackSelected(string option)
	{
		CombatActionInfo combatActionInfo = new CombatActionInfo();
		combatActionInfo.target = target_character;
		switch (option)
		{
		default:
			return;
		case "melee":
			combatActionInfo.action = CombatActionEnum.Melee;
			break;
		case "shoot_single":
			combatActionInfo.action = CombatActionEnum.ShootSingle;
			break;
		case "shoot_multi":
			combatActionInfo.action = CombatActionEnum.ShootMulti;
			break;
		case "subdue":
			combatActionInfo.action = CombatActionEnum.Subdue;
			break;
		case "disarm":
			combatActionInfo.action = CombatActionEnum.Disarm;
			break;
		case "steal":
			combatActionInfo.action = CombatActionEnum.Steal;
			break;
		}
		ExecuteAction(current_character, combatActionInfo);
		CloseActionMenu();
	}

	private void ShowItemMenu()
	{
		if ((Object)(object)current_character == (Object)null)
		{
			return;
		}
		List<ItemStack> usableItems = current_character.GetUsableItems();
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		for (int i = 0; i < usableItems.Count; i++)
		{
			ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(usableItems[i].m_type);
			if ((Object)(object)itemDefinition != (Object)null)
			{
				list.Add(Enum.GetName(typeof(ItemManager.ItemType), usableItems[i].m_type));
				list2.Add(Localization.Get(itemDefinition.NameLocalizationKey) + " x" + usableItems[i].m_count);
			}
		}
		action_menu.PushNewLayer("UI.action_menu.items.title", list, list2, OnItemSelected);
	}

	public void OnItemSelected(string option)
	{
		CloseActionMenu();
		CombatActionInfo combatActionInfo = new CombatActionInfo();
		combatActionInfo.action = CombatActionEnum.UseItem;
		combatActionInfo.target = target_character;
		List<ItemStack> usableItems = current_character.GetUsableItems();
		for (int i = 0; i < usableItems.Count; i++)
		{
			ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(usableItems[i].m_type);
			if (!((Object)(object)itemDefinition == (Object)null))
			{
				string name = Enum.GetName(typeof(ItemManager.ItemType), usableItems[i].m_type);
				if (!string.IsNullOrEmpty(name) && string.Compare(option, name) == 0)
				{
					combatActionInfo.item = usableItems[i].m_type;
					ExecuteAction(current_character, combatActionInfo);
					return;
				}
			}
		}
		combatActionInfo.action = CombatActionEnum.Skip;
		ExecuteAction(current_character, combatActionInfo);
	}

	private void AssignMiniHealthBars()
	{
		int i = 0;
		for (int j = 0; j < player_characters.Count; j++)
		{
			if (i >= mini_health_bars.Count)
			{
				break;
			}
			mini_health_bars[i++].Initialise(player_characters[j]);
		}
		for (int k = 0; k < npc_characters.Count; k++)
		{
			if (i >= mini_health_bars.Count)
			{
				break;
			}
			mini_health_bars[i++].Initialise(npc_characters[k]);
		}
		for (; i < mini_health_bars.Count; i++)
		{
			mini_health_bars[i].SetInactive();
		}
	}

	public void CleanUp()
	{
		player_characters = null;
		npc_characters = null;
		initiative_list.Clear();
		current_character = null;
		target_character = null;
	}

	private void UpdateInput()
	{
	}

	public override void OnTabRight()
	{
		if (IsActionMenuShowing())
		{
			EncounterCharacter encounterCharacter = target_character;
			SetTarget(FindNextAliveCharacter(target_character, npc_characters));
			if ((Object)(object)target_character != (Object)(object)encounterCharacter)
			{
				AudioManager.Instance.PlayUI(new_target_sound);
			}
		}
	}

	public override void OnTabLeft()
	{
		if (IsActionMenuShowing())
		{
			EncounterCharacter encounterCharacter = target_character;
			SetTarget(FindNextAliveCharacter(target_character, npc_characters, forward: false));
			if ((Object)(object)target_character != (Object)(object)encounterCharacter)
			{
				AudioManager.Instance.PlayUI(new_target_sound);
			}
		}
	}

	public void OnCharacterSelected(EncounterCharacter character, bool selected)
	{
		if (!((Object)(object)character == (Object)null) && IsPlayersTurn() && IsValidTarget(character) && IsActionMenuShowing() && current_character.team != character.team)
		{
			character.SetHighlight(selected);
		}
	}

	public void OnCharacterClicked(EncounterCharacter character, bool wasRightClick)
	{
		if (!((Object)(object)character == (Object)null) && !wasRightClick && IsPlayersTurn() && IsValidTarget(character) && IsActionMenuShowing() && current_character.team != character.team)
		{
			EncounterCharacter encounterCharacter = target_character;
			SetTarget(character);
			if ((Object)(object)target_character != (Object)(object)encounterCharacter)
			{
				AudioManager.Instance.PlayUI(new_target_sound);
			}
		}
	}

	public override bool AlwaysShow()
	{
		return true;
	}

	public override bool DestroyOnClose()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override bool PausesGameInput()
	{
		return true;
	}
}
