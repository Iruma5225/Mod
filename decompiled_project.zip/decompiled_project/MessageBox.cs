using System;
using UnityEngine;

public class MessageBox : BasePanel
{
	public enum Response
	{
		No = -1,
		OkayDismiss,
		Yes
	}

	public UILabel m_label_message;

	public UILabel m_label_title;

	public UISprite m_background_image;

	public GameObject m_yes_button;

	public GameObject m_no_button;

	public GameObject m_okay_button;

	public AudioClip m_open_sound;

	public AudioClip m_yes_sound;

	public AudioClip m_no_sound;

	private Sprite m_sprite_image;

	private MessageBoxResponse m_callback;

	private int m_iResponse;

	private bool m_alwaysOnTopOfStack;

	private static bool s_nextAlwaysOnTopOfStack;

	public static bool isOpen;

	public override void OnShow()
	{
		base.OnShow();
		isOpen = true;
		UIButton[] componentsInChildren = ((Component)this).GetComponentsInChildren<UIButton>();
		Array.Sort(componentsInChildren, (UIButton xB, UIButton yB) => (!(((Component)xB).transform.localPosition.x > ((Component)yB).transform.localPosition.x)) ? 1 : (-1));
		int num = componentsInChildren.Length;
		for (int num2 = 0; num2 < num; num2++)
		{
			UIKeyNavigation component = ((Component)componentsInChildren[num2]).GetComponent<UIKeyNavigation>();
			if (Object.op_Implicit((Object)(object)component))
			{
				if (num2 - 1 >= 0)
				{
					component.onRight = ((Component)componentsInChildren[num2 - 1]).gameObject;
				}
				else
				{
					component.onRight = null;
				}
				if (num2 + 1 < num)
				{
					component.onLeft = ((Component)componentsInChildren[num2 + 1]).gameObject;
				}
				else
				{
					component.onLeft = null;
				}
				component.onUp = null;
				component.onDown = null;
				component.constraint = UIKeyNavigation.Constraint.Explicit;
			}
		}
		NGUITools.ExecuteAll<UIWidget>(((Component)this).gameObject, "Update");
		if ((Object)(object)m_no_button != (Object)null && m_no_button.activeInHierarchy)
		{
			UICamera.selectedObject = m_yes_button;
		}
		if ((Object)(object)m_okay_button != (Object)null && m_okay_button.activeInHierarchy)
		{
			UICamera.selectedObject = m_okay_button;
		}
		AudioManager.Instance.PlayUI(m_open_sound);
	}

	public static void NextMessageBoxAlwaysOnTopOfStack()
	{
		s_nextAlwaysOnTopOfStack = true;
	}

	public static MessageBox Show(MessageBoxButtons Buttons, string message, MessageBoxResponse callback = null, AudioClip yes_sound = null, AudioClip no_sound = null, bool localize = true)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		Object messageBoxPrefab = UIPanelManager.Instance().MessageBoxPrefab;
		if (messageBoxPrefab != (Object)null)
		{
			Object obj = Object.Instantiate(messageBoxPrefab);
			MessageBox component = ((GameObject)((obj is GameObject) ? obj : null)).GetComponent<MessageBox>();
			if ((Object)(object)component != (Object)null)
			{
				if (UIRoot.list.Count > 0)
				{
					((Component)component).transform.parent = ((Component)UIRoot.list[0]).transform;
				}
				((Component)component).transform.localScale = Vector3.one;
				((Component)component).transform.localPosition = Vector3.zero;
				component.m_alwaysOnTopOfStack = s_nextAlwaysOnTopOfStack;
				component.InitialiseMessageBox(Buttons, message, localize, callback, yes_sound, no_sound);
				s_nextAlwaysOnTopOfStack = false;
				return component;
			}
			throw new Exception("Failed to Instantiate MessageBox");
		}
		throw new Exception("Message box prefab not set on the UIPanelManager in the editor.");
	}

	public static MessageBox ShowSmall(MessageBoxButtons Buttons, string message, MessageBoxResponse callback = null, AudioClip yes_sound = null, AudioClip no_sound = null, bool localize = true)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		Object smallMessageBoxPrefab = UIPanelManager.Instance().SmallMessageBoxPrefab;
		if (smallMessageBoxPrefab != (Object)null)
		{
			Object obj = Object.Instantiate(smallMessageBoxPrefab);
			MessageBox component = ((GameObject)((obj is GameObject) ? obj : null)).GetComponent<MessageBox>();
			if ((Object)(object)component != (Object)null)
			{
				if (UIRoot.list.Count > 0)
				{
					((Component)component).transform.parent = ((Component)UIRoot.list[0]).transform;
				}
				((Component)component).transform.localScale = Vector3.one;
				((Component)component).transform.localPosition = Vector3.zero;
				component.m_alwaysOnTopOfStack = s_nextAlwaysOnTopOfStack;
				component.InitialiseMessageBox(Buttons, message, localize, callback, yes_sound, no_sound);
				s_nextAlwaysOnTopOfStack = false;
				return component;
			}
			throw new Exception("Failed to Instantiate MessageBox");
		}
		throw new Exception("Message box prefab not set on the UIPanelManager in the editor.");
	}

	public static MessageBox ShowTitle(MessageBoxButtons Buttons, string message, string title, MessageBoxResponse callback = null, AudioClip yes_sound = null, AudioClip no_sound = null)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		Object titledMessageBoxPrefab = UIPanelManager.Instance().TitledMessageBoxPrefab;
		if (titledMessageBoxPrefab != (Object)null)
		{
			Object obj = Object.Instantiate(titledMessageBoxPrefab);
			MessageBox component = ((GameObject)((obj is GameObject) ? obj : null)).GetComponent<MessageBox>();
			if ((Object)(object)component != (Object)null)
			{
				if (UIRoot.list.Count > 0)
				{
					((Component)component).transform.parent = ((Component)UIRoot.list[0]).transform;
				}
				((Component)component).transform.localScale = Vector3.one;
				((Component)component).transform.localPosition = Vector3.zero;
				component.m_alwaysOnTopOfStack = s_nextAlwaysOnTopOfStack;
				component.InitialiseMessageBox(Buttons, message, title, callback, yes_sound, no_sound);
				s_nextAlwaysOnTopOfStack = false;
				return component;
			}
			throw new Exception("Failed to Instantiate MessageBox");
		}
		throw new Exception("Message box prefab not set on the UIPanelManager in the editor.");
	}

	private void InitialiseMessageBox(MessageBoxButtons Buttons, string message, bool localize = true, MessageBoxResponse callback = null, AudioClip yes_sound = null, AudioClip no_sound = null)
	{
		m_callback = callback;
		if ((Object)(object)yes_sound != (Object)null)
		{
			m_yes_sound = yes_sound;
		}
		if ((Object)(object)no_sound != (Object)null)
		{
			m_no_sound = no_sound;
		}
		m_yes_button.SetActive(MessageBoxButtons.YesNo_Buttons == Buttons);
		m_no_button.SetActive(Buttons == MessageBoxButtons.YesNo_Buttons || MessageBoxButtons.OkayNoMaybe_Buttons == Buttons);
		m_okay_button.SetActive(Buttons == MessageBoxButtons.Okay_Button || MessageBoxButtons.OkayNoMaybe_Buttons == Buttons);
		m_label_message.text = ((!localize) ? message : Localization.Get(message));
		UIPanelManager.Instance().PushPanel(this);
	}

	private void InitialiseMessageBox(MessageBoxButtons Buttons, string message, string title, MessageBoxResponse callback = null, AudioClip yes_sound = null, AudioClip no_sound = null)
	{
		m_callback = callback;
		if ((Object)(object)yes_sound != (Object)null)
		{
			m_yes_sound = yes_sound;
		}
		if ((Object)(object)no_sound != (Object)null)
		{
			m_no_sound = no_sound;
		}
		m_yes_button.SetActive(MessageBoxButtons.YesNo_Buttons == Buttons);
		m_no_button.SetActive(Buttons == MessageBoxButtons.YesNo_Buttons || MessageBoxButtons.OkayNoMaybe_Buttons == Buttons);
		m_okay_button.SetActive(Buttons == MessageBoxButtons.Okay_Button || MessageBoxButtons.OkayNoMaybe_Buttons == Buttons);
		m_label_message.text = Localization.Get(message);
		m_label_title.text = Localization.Get(title);
		UIPanelManager.Instance().PushPanel(this);
	}

	public override void OnResume()
	{
		base.OnResume();
	}

	public override void Update()
	{
		if (Input.GetKeyDown((KeyCode)27))
		{
			NoButtonPressed();
		}
	}

	public void NoButtonPressed()
	{
		m_iResponse = -1;
		UIPanelManager.Instance().PopPanel(this);
		AudioManager.Instance.PlayUI(m_no_sound);
	}

	public void YesButtonPressed()
	{
		m_iResponse = 1;
		UIPanelManager.Instance().PopPanel(this);
		AudioManager.Instance.PlayUI(m_yes_sound);
	}

	public void MaybeButtonPressed()
	{
		m_iResponse = 0;
		UIPanelManager.Instance().PopPanel(this);
	}

	public override void OnClose()
	{
		base.OnClose();
		isOpen = false;
		if (m_callback != null)
		{
			m_callback(m_iResponse);
		}
	}

	public override void OnCancel()
	{
		base.OnCancel();
		UIPanelManager.Instance().PopPanel(this);
		AudioManager.Instance.PlayUI(m_no_sound);
	}

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool DestroyOnClose()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool Popup()
	{
		return true;
	}

	public override bool AlwaysOnTopOfStack()
	{
		return m_alwaysOnTopOfStack;
	}
}
