using UnityEngine;

public class InteractionInstance_TakeMeds : InteractionInstance_Base
{
	private Int_TakeMeds interaction;

	private Obj_MedCab medcab_object;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_TakeMeds;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		medcab_object = ((Component)this).GetComponent<Obj_MedCab>();
		if ((Object)(object)medcab_object == (Object)null)
		{
			return false;
		}
		if ((Object)(object)member != (Object)null)
		{
			member.TriggerAnim("Rummage");
		}
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled)
		{
			FamilyAI component = ((Component)member).GetComponent<FamilyAI>();
			if ((Object)(object)component != (Object)null)
			{
				MedicineManager.MedicineType meds = MedicineManager.MedicineType.Undefined;
				Job current = member.job_queue.GetCurrent();
				if (current != null && current is Job_Feed job_Feed)
				{
					meds = job_Feed.GetMedicine();
				}
				ItemManager.ItemType itemType = MedicineManager.MedicineToItem(meds);
				if ((Object)(object)InventoryManager.Instance != (Object)null && InventoryManager.Instance.GetNumItemsOfType(itemType) > 0 && InventoryManager.Instance.RemoveItemOfType(itemType))
				{
					component.CarriedMeds_SetMedsTaken(itemType);
				}
			}
		}
		return true;
	}
}
