using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LoadingScreen : MonoBehaviour
{
	[SerializeField]
	private GameObject m_loadingImage;

	[SerializeField]
	private float m_fadeDuration = 1f;

	[SerializeField]
	private Text m_loadingText;

	[SerializeField]
	private Text m_tipTitleText;

	[SerializeField]
	private Text m_tipText;

	[SerializeField]
	private bool m_testShow;

	[SerializeField]
	private bool m_testHide;

	private int m_showCount;

	private bool m_showScreen;

	private bool m_initialized;

	private static string m_nextLevel = string.Empty;

	private static LoadingScreen m_instance;

	public static string nextLevel => m_nextLevel;

	public bool isShowing => m_initialized && m_showCount > 0;

	public static LoadingScreen Instance => m_instance;

	public static void ClearNextLevel()
	{
		m_nextLevel = string.Empty;
	}

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	public void ShowLoadingScreen(string levelToLoad)
	{
		if (m_initialized && ++m_showCount == 1 && (Object)(object)ScreenFade.instance != (Object)null)
		{
			m_showScreen = true;
			m_nextLevel = levelToLoad;
			ScreenFade.instance.StartFade(m_fadeDuration);
			SetRandomTip();
		}
	}

	public void HideLoadingScreen(bool force = true)
	{
		if (m_initialized)
		{
			if (force)
			{
				m_showCount = 1;
			}
			if (--m_showCount == 0 && (Object)(object)ScreenFade.instance != (Object)null)
			{
				m_showScreen = false;
				ScreenFade.instance.StartFade(m_fadeDuration);
			}
		}
	}

	private void OnFadeComplete()
	{
		if (m_showScreen)
		{
			Time.timeScale = 0f;
		}
		else if ((Object)(object)UIPanelManager.instance == (Object)null || !UIPanelManager.instance.timePaused)
		{
			Time.timeScale = 1f;
		}
		if ((Object)(object)m_loadingImage != (Object)null)
		{
			m_loadingImage.SetActive(m_showScreen);
		}
		if ((Object)(object)ScreenFade.instance != (Object)null)
		{
			ScreenFade.instance.ClearFade(1f);
		}
	}

	private void OnClearComplete()
	{
		if (m_showScreen && m_nextLevel.Length > 0)
		{
			SceneManager.LoadSceneAsync("LoadingScene");
		}
	}

	public void Update()
	{
		if (!m_initialized)
		{
			m_initialized = true;
			if ((Object)(object)ScreenFade.instance != (Object)null)
			{
				ScreenFade.instance.m_fadeComplete += OnFadeComplete;
				ScreenFade.instance.m_clearComplete += OnClearComplete;
			}
		}
		if (m_testShow)
		{
			m_testShow = false;
			ShowLoadingScreen(string.Empty);
		}
		if (m_testHide)
		{
			m_testHide = false;
			HideLoadingScreen();
		}
	}

	private void SetRandomTip()
	{
		if ((Object)(object)m_tipText != (Object)null)
		{
			string text = "LoadingScreen.Tip";
			string randomValueFromKey = Localization.GetRandomValueFromKey(text);
			if (randomValueFromKey != text)
			{
				m_tipText.text = randomValueFromKey;
			}
		}
		if ((Object)(object)m_tipTitleText != (Object)null)
		{
			string text2 = "Text.UI.Tip";
			string randomValueFromKey2 = Localization.GetRandomValueFromKey(text2);
			if (randomValueFromKey2 != text2)
			{
				m_tipTitleText.text = randomValueFromKey2;
			}
		}
		if ((Object)(object)m_loadingText != (Object)null)
		{
			string text3 = "Text.UI.Loading";
			string randomValueFromKey3 = Localization.GetRandomValueFromKey(text3);
			if (randomValueFromKey3 != text3)
			{
				m_loadingText.text = randomValueFromKey3;
			}
		}
	}
}
