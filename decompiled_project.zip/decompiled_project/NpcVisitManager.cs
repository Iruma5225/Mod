using System;
using System.Collections.Generic;
using UnityEngine;

public class NpcVisitManager : BaseManager, ISaveable
{
	[Serializable]
	private class PersonalityWeight
	{
		public EncounterCharacter.PersonalityType personality;

		[Range(0f, 10f)]
		public int bias = 1;

		public int startDate;

		public int endDate;
	}

	private class SpawnInfo
	{
		public NpcVisitor.NpcType type = NpcVisitor.NpcType.Recruit;

		public List<FamilySpawner.CharacterAttributes> npcAttributes = new List<FamilySpawner.CharacterAttributes>();

		public float spawnTimer;

		public int questId = -1;

		public void SaveLoadSpawn(SaveData data)
		{
			int value = (int)type;
			data.SaveLoad("type", ref value);
			if (data.isLoading)
			{
				type = (NpcVisitor.NpcType)value;
			}
			data.SaveLoadList("attributes", npcAttributes, delegate(int i)
			{
				FamilySpawner.CharacterAttributes characterAttributes = npcAttributes[i];
				characterAttributes.SaveLoadAttributes(data);
			}, delegate
			{
				FamilySpawner.CharacterAttributes characterAttributes = new FamilySpawner.CharacterAttributes();
				characterAttributes.SaveLoadAttributes(data);
				if (!string.IsNullOrEmpty(characterAttributes.m_meshId))
				{
					npcAttributes.Add(characterAttributes);
				}
			});
			data.SaveLoad("spawnTimer", ref spawnTimer);
			data.SaveLoad("questId", ref questId);
		}
	}

	private class OngoingSpawn
	{
		public SpawnInfo spawnInfo;

		public List<NpcVisitor> npcs = new List<NpcVisitor>();

		public List<bool> finished = new List<bool>();

		public void SaveLoadSpawn(SaveData data)
		{
			if (data.isLoading)
			{
				spawnInfo = new SpawnInfo();
			}
			spawnInfo.SaveLoadSpawn(data);
			data.SaveLoadList("finished_spawn", finished, delegate(int i)
			{
				bool value = finished[i];
				data.SaveLoad("finished", ref value);
			}, delegate
			{
				bool value = false;
				data.SaveLoad("finished", ref value);
				finished.Add(value);
			});
		}
	}

	private static NpcVisitManager m_instance;

	[SerializeField]
	private Transform m_surfaceLeftPoint;

	[SerializeField]
	private Transform m_surfaceRightPoint;

	[SerializeField]
	private Transform m_tradePoint;

	[SerializeField]
	private Transform m_recruitPoint;

	[SerializeField]
	private List<Transform> m_followerPoints = new List<Transform>();

	private float m_minInterval = 200f;

	private float m_maxInterval = 1000f;

	private float m_nextSpawnTime;

	[SerializeField]
	private float m_notBroadcastingMinInterval = 200f;

	[SerializeField]
	private float m_notBroadcastingMaxInterval = 1000f;

	[SerializeField]
	private float m_broadcastingMinInterval = 100f;

	[SerializeField]
	private float m_broadcastingMaxInterval = 250f;

	[SerializeField]
	[Range(0f, 1f)]
	private List<float> m_radioLevelBroadcastMultipliers = new List<float>();

	private float m_traderSpawnChance = 0.33f;

	private float m_joinerSpawnChance = 0.66f;

	[SerializeField]
	private float m_traderNormalSpawnChance = 0.33f;

	[SerializeField]
	private float m_joinerNormalSpawnChance = 0.66f;

	[SerializeField]
	private float m_broadcastHighSpawnChance = 0.95f;

	[SerializeField]
	private float m_broadcastLowSpawnChance = 0.05f;

	[SerializeField]
	private List<PersonalityWeight> m_personalityWeights_Inspector = new List<PersonalityWeight>();

	private List<EncounterCharacter.PersonalityType> m_activePersonalities = new List<EncounterCharacter.PersonalityType>();

	[SerializeField]
	private List<Color> m_skinColors = new List<Color>();

	[SerializeField]
	private List<Color> m_hairColors = new List<Color>();

	[SerializeField]
	private List<Color> m_shirtColors = new List<Color>();

	[SerializeField]
	private List<Color> m_pantsColors = new List<Color>();

	private string m_kickstarterBackerId = string.Empty;

	[SerializeField]
	private bool m_spawnPasserby;

	[SerializeField]
	private bool m_spawnTrader;

	[SerializeField]
	private bool m_spawnJoiner;

	[SerializeField]
	private bool m_spawnKickstarterBacker;

	private int m_ongoingSpawnId;

	private List<SpawnInfo> m_pendingSpawns = new List<SpawnInfo>();

	private List<OngoingSpawn> m_ongoingSpawns = new List<OngoingSpawn>();

	private List<NpcVisitor> m_visitors = new List<NpcVisitor>();

	private int m_uniqueVisitorId;

	public static NpcVisitManager Instance => m_instance;

	public bool npcPresent => m_visitors.Count > 0;

	public void SpawnPasserby()
	{
		if ((Object)(object)UI_DebugInventory.instance != (Object)null && UI_DebugInventory.instance.AllowDebugging && m_visitors.Count == 0)
		{
			SpawnNpc(NpcVisitor.NpcType.Passerby, null);
		}
	}

	public void SpawnTrader()
	{
		if ((Object)(object)UI_DebugInventory.instance != (Object)null && UI_DebugInventory.instance.AllowDebugging && m_visitors.Count == 0)
		{
			SpawnNpc(NpcVisitor.NpcType.Trader, null);
		}
	}

	public void SpawnJoiner()
	{
		if ((Object)(object)UI_DebugInventory.instance != (Object)null && UI_DebugInventory.instance.AllowDebugging && m_visitors.Count == 0)
		{
			SpawnNpc(NpcVisitor.NpcType.Joiner, null);
		}
	}

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
		}
	}

	public void OnDestroy()
	{
		GameTime.newDay -= OnNewDay;
	}

	public override void StartManager()
	{
		GameTime.newDay += OnNewDay;
		ResetSpawnTimer();
		UpdateActivePersonalities();
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
	}

	public Color GetRandomNpcColor(CharacterMesh.ColorCustomization color)
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		List<Color> list = null;
		switch (color)
		{
		case CharacterMesh.ColorCustomization.HairColor:
			list = m_hairColors;
			break;
		case CharacterMesh.ColorCustomization.PantsColor:
			list = m_pantsColors;
			break;
		case CharacterMesh.ColorCustomization.ShirtColor:
			list = m_shirtColors;
			break;
		case CharacterMesh.ColorCustomization.SkinColor:
			list = m_skinColors;
			break;
		}
		if (list == null || list.Count == 0)
		{
			return Color.white;
		}
		return list[Random.Range(0, list.Count)];
	}

	public Vector3 GetRandomExitPosition()
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		if (Random.value >= 0.5f && (Object)(object)m_surfaceLeftPoint != (Object)null)
		{
			return m_surfaceLeftPoint.position;
		}
		if ((Object)(object)m_surfaceRightPoint != (Object)null)
		{
			return m_surfaceRightPoint.position;
		}
		return Vector3.zero;
	}

	public void UnregisterNpcVisitor(NpcVisitor npc)
	{
		if (m_visitors.Contains(npc))
		{
			m_visitors.Remove(npc);
		}
	}

	public void Update_Debugging()
	{
	}

	public override void UpdateManager()
	{
		if (((Object)(object)TutorialManager.Instance != (Object)null && TutorialManager.Instance.TutorialActive) || ((Object)(object)BreachMan.instance != (Object)null && BreachMan.instance.inProgress))
		{
			m_nextSpawnTime += Time.deltaTime;
			return;
		}
		Update_Debugging();
		UpdateOngoingSpawns();
		UpdatePendingSpawns();
		if (!(Time.time >= m_nextSpawnTime))
		{
			return;
		}
		ResetSpawnTimer();
		if (m_visitors.Count != 0)
		{
			return;
		}
		NpcVisitor.NpcType npcType = NpcVisitor.NpcType.Passerby;
		float value = Random.value;
		if (m_traderSpawnChance < m_joinerSpawnChance)
		{
			if (value < m_traderSpawnChance)
			{
				npcType = NpcVisitor.NpcType.Trader;
			}
			else if (value > m_joinerSpawnChance)
			{
				npcType = NpcVisitor.NpcType.Joiner;
			}
		}
		else if (value < m_joinerSpawnChance)
		{
			npcType = NpcVisitor.NpcType.Joiner;
		}
		else if (value > m_traderSpawnChance)
		{
			npcType = NpcVisitor.NpcType.Trader;
		}
		if (npcType == NpcVisitor.NpcType.Passerby && Random.Range(0, 3) == 0)
		{
			npcType = NpcVisitor.NpcType.KickstarterBacker;
		}
		SpawnNpc(npcType, null);
	}

	private void OnNewDay()
	{
		UpdateActivePersonalities();
	}

	private void UpdateActivePersonalities()
	{
		m_activePersonalities.Clear();
		PersonalityWeight personalityWeight = null;
		for (int i = 0; i < m_personalityWeights_Inspector.Count; i++)
		{
			personalityWeight = m_personalityWeights_Inspector[i];
			if (personalityWeight != null && personalityWeight.startDate <= GameTime.Day && (personalityWeight.endDate > GameTime.Day || personalityWeight.endDate == 0) && !m_activePersonalities.Contains(personalityWeight.personality))
			{
				for (int j = 0; j < personalityWeight.bias; j++)
				{
					m_activePersonalities.Add(personalityWeight.personality);
				}
			}
		}
	}

	public EncounterCharacter.PersonalityType GetRandomPersonality()
	{
		if (m_activePersonalities.Count > 0)
		{
			return m_activePersonalities[Random.Range(0, m_activePersonalities.Count)];
		}
		return EncounterCharacter.PersonalityType.Generic;
	}

	private FamilySpawner.CharacterAttributes CreateAttributesFromCharacter(EncounterCharacter npc)
	{
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		FamilySpawner.CharacterAttributes characterAttributes = new FamilySpawner.CharacterAttributes();
		characterAttributes.m_firstName = npc.Name_Short;
		characterAttributes.m_lastName = npc.Surname;
		characterAttributes.m_meshId = npc.meshId;
		if ((Object)(object)npc.mesh != (Object)null)
		{
			characterAttributes.m_headTexture = npc.mesh.headTexture;
			characterAttributes.m_torsoTexture = npc.mesh.torsoTexture;
			characterAttributes.m_legTexture = npc.mesh.legTexture;
			characterAttributes.m_hairColor = npc.mesh.hairColor;
			characterAttributes.m_skinColor = npc.mesh.skinColor;
			characterAttributes.m_shirtColor = npc.mesh.shirtColor;
			characterAttributes.m_pantsColor = npc.mesh.pantsColor;
		}
		characterAttributes.m_strengthLevel = npc.Stats.Strength.Level;
		characterAttributes.m_strengthMax = npc.Stats.Strength.LevelCap;
		characterAttributes.m_dexterityLevel = npc.Stats.Dexterity.Level;
		characterAttributes.m_dexterityMax = npc.Stats.Dexterity.LevelCap;
		characterAttributes.m_charismaLevel = npc.Stats.Charisma.Level;
		characterAttributes.m_charismaMax = npc.Stats.Charisma.LevelCap;
		characterAttributes.m_perceptionLevel = npc.Stats.Perception.Level;
		characterAttributes.m_perceptionMax = npc.Stats.Perception.LevelCap;
		characterAttributes.m_intelligenceLevel = npc.Stats.Intelligence.Level;
		characterAttributes.m_intelligenceMax = npc.Stats.Intelligence.LevelCap;
		characterAttributes.m_personality = npc.Personality;
		return characterAttributes;
	}

	public FamilySpawner.CharacterAttributes CreateAttributesFromPreset(CharacterMeshOptions.QuestCharacterPreset preset)
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		FamilySpawner.CharacterAttributes characterAttributes = new FamilySpawner.CharacterAttributes();
		if (preset == null)
		{
			return characterAttributes;
		}
		characterAttributes.m_meshId = preset.m_meshId;
		characterAttributes.m_firstName = preset.m_firstName;
		characterAttributes.m_lastName = preset.m_lastName;
		characterAttributes.m_headTexture = preset.m_headTexture;
		characterAttributes.m_torsoTexture = preset.m_torsoTexture;
		characterAttributes.m_legTexture = preset.m_legTexture;
		characterAttributes.m_hairColor = preset.m_hairColor;
		characterAttributes.m_skinColor = preset.m_skinColor;
		characterAttributes.m_shirtColor = preset.m_shirtColor;
		characterAttributes.m_pantsColor = preset.m_pantsColor;
		characterAttributes.m_personality = GetRandomPersonality();
		return characterAttributes;
	}

	public FamilySpawner.CharacterAttributes CreateAttributesFromPreset(CharacterMeshOptions.CharacterPreset preset)
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		FamilySpawner.CharacterAttributes characterAttributes = new FamilySpawner.CharacterAttributes();
		if (preset == null)
		{
			return characterAttributes;
		}
		characterAttributes.m_meshId = preset.m_meshId;
		characterAttributes.m_firstName = preset.m_firstName;
		characterAttributes.m_lastName = preset.m_lastName;
		characterAttributes.m_headTexture = preset.m_headTexture;
		characterAttributes.m_torsoTexture = preset.m_torsoTexture;
		characterAttributes.m_legTexture = preset.m_legTexture;
		characterAttributes.m_hairColor = preset.m_hairColor;
		characterAttributes.m_skinColor = preset.m_skinColor;
		characterAttributes.m_shirtColor = preset.m_shirtColor;
		characterAttributes.m_pantsColor = preset.m_pantsColor;
		characterAttributes.m_personality = GetRandomPersonality();
		return characterAttributes;
	}

	private NpcVisitor CreateNpcVisitor(NpcVisitor.NpcType type, FamilySpawner.CharacterAttributes attribsOverride, Vector3 pos)
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)FamilySpawner.instance == (Object)null)
		{
			return null;
		}
		FamilySpawner.CharacterAttributes characterAttributes = null;
		if (attribsOverride == null)
		{
			characterAttributes = new FamilySpawner.CharacterAttributes();
			characterAttributes.Randomize();
			characterAttributes.m_hairColor = (Color)((m_hairColors.Count <= 0) ? new Color(0.6f, 0.3f, 0.1f) : m_hairColors[Random.Range(0, m_hairColors.Count)]);
			characterAttributes.m_skinColor = (Color)((m_skinColors.Count <= 0) ? new Color(1f, 0.8f, 0.8f) : m_skinColors[Random.Range(0, m_skinColors.Count)]);
			characterAttributes.m_shirtColor = (Color)((m_shirtColors.Count <= 0) ? new Color(Random.value, Random.value, Random.value, 1f) : m_shirtColors[Random.Range(0, m_shirtColors.Count)]);
			characterAttributes.m_pantsColor = (Color)((m_pantsColors.Count <= 0) ? new Color(Random.value, Random.value, Random.value, 1f) : m_pantsColors[Random.Range(0, m_pantsColors.Count)]);
			List<int> list = new List<int>();
			list.Add(0);
			list.Add(0);
			list.Add(1);
			list.Add(1);
			list.Add(3);
			List<int> list2 = list;
			list = new List<int>();
			list.Add(2);
			list.Add(2);
			list.Add(2);
			list.Add(2);
			list.Add(2);
			List<int> list3 = list;
			int num = 2 + Mathf.Min(GameTime.Day / 10, 5);
			for (int i = 0; i < num; i++)
			{
				list2.Shuffle();
				for (int j = 0; j < Mathf.Min(list2.Count, list3.Count); j++)
				{
					list3[j] += list2[j];
				}
			}
			if (list3.Count == 5)
			{
				characterAttributes.m_charismaLevel = list3[0];
				characterAttributes.m_strengthLevel = list3[1];
				characterAttributes.m_dexterityLevel = list3[2];
				characterAttributes.m_perceptionLevel = list3[3];
				characterAttributes.m_intelligenceLevel = list3[4];
			}
			if ((Object)(object)CharacterMeshOptions.instance != (Object)null)
			{
				CharacterMeshOptions.CharacterMeshType characterMeshType = CharacterMeshOptions.instance.FindCharacterMesh(characterAttributes.m_meshId);
				if (characterMeshType != null)
				{
					characterAttributes.m_headTexture = characterMeshType.GetRandomTexture(CharacterMesh.TextureType.Head);
					characterAttributes.m_torsoTexture = characterMeshType.GetRandomTexture(CharacterMesh.TextureType.Torso);
					characterAttributes.m_legTexture = characterMeshType.GetRandomTexture(CharacterMesh.TextureType.Legs);
				}
			}
			characterAttributes.m_personality = GetRandomPersonality();
		}
		else
		{
			characterAttributes = new FamilySpawner.CharacterAttributes(attribsOverride);
		}
		if (characterAttributes == null)
		{
			return null;
		}
		NpcVisitor npcVisitor = FamilySpawner.instance.SpawnNpc(characterAttributes, pos);
		if ((Object)(object)npcVisitor != (Object)null)
		{
			((Component)npcVisitor).transform.parent = ((Component)this).transform;
			if ((Object)(object)FamilyManager.Instance != (Object)null)
			{
				FamilyManager.Instance.SpawnCharacterUI(npcVisitor, isFamilyMember: false);
			}
			m_visitors.Add(npcVisitor);
			return npcVisitor;
		}
		return null;
	}

	public void StartShelterBreach(int numNpcs, List<ItemManager.ItemType> weapons, List<ItemManager.ItemType> armors)
	{
		List<NpcVisitor> spawned = null;
		SpawnNpcs(NpcVisitor.NpcType.Breacher, null, numNpcs, out spawned);
		if (spawned == null)
		{
			return;
		}
		bool isPartOfBreachGang = spawned.Count > 1;
		for (int i = 0; i < spawned.Count; i++)
		{
			if ((Object)(object)spawned[i] != (Object)null)
			{
				spawned[i].SetIsPartOfBreachGang(isPartOfBreachGang);
				ItemManager.ItemType weapon = ItemManager.ItemType.Undefined;
				ItemManager.ItemType armor = ItemManager.ItemType.Undefined;
				if (weapons.Count > 0)
				{
					weapon = weapons[Random.Range(0, weapons.Count)];
				}
				if (armors.Count > 0)
				{
					armor = armors[Random.Range(0, armors.Count)];
				}
				spawned[i].SetWeaponAndArmor(weapon, armor);
			}
		}
	}

	public NpcVisitor FindVisitorWithId(int id)
	{
		for (int i = 0; i < m_visitors.Count; i++)
		{
			if ((Object)(object)m_visitors[i] != (Object)null && m_visitors[i].npcId == id)
			{
				return m_visitors[i];
			}
		}
		return null;
	}

	private bool SpawnNpc(NpcVisitor.NpcType type, FamilySpawner.CharacterAttributes attribsOverride)
	{
		List<FamilySpawner.CharacterAttributes> attribsOverride2 = null;
		if (attribsOverride != null)
		{
			List<FamilySpawner.CharacterAttributes> list = new List<FamilySpawner.CharacterAttributes>();
			list.Add(attribsOverride);
			attribsOverride2 = list;
		}
		if (type == NpcVisitor.NpcType.KickstarterBacker && (Object)(object)CharacterMeshOptions.instance != (Object)null)
		{
			CharacterMeshOptions.CharacterPreset nextKickstarterCharacterPreset = CharacterMeshOptions.instance.GetNextKickstarterCharacterPreset();
			if (nextKickstarterCharacterPreset != null)
			{
				List<FamilySpawner.CharacterAttributes> list = new List<FamilySpawner.CharacterAttributes>();
				list.Add(CreateAttributesFromPreset(nextKickstarterCharacterPreset));
				attribsOverride2 = list;
				m_kickstarterBackerId = nextKickstarterCharacterPreset.m_id;
			}
		}
		List<NpcVisitor> spawned = null;
		if (type == NpcVisitor.NpcType.Joiner || type == NpcVisitor.NpcType.KickstarterBacker)
		{
			return SpawnNpcs(type, attribsOverride2, 1, out spawned);
		}
		return SpawnNpcs(type, attribsOverride2, Random.Range(1, 3), out spawned);
	}

	private bool SpawnNpcs(NpcVisitor.NpcType type, List<FamilySpawner.CharacterAttributes> attribsOverride, int quantity, out List<NpcVisitor> spawned)
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		spawned = new List<NpcVisitor>();
		if ((Object)(object)m_surfaceLeftPoint == (Object)null || (Object)(object)m_surfaceRightPoint == (Object)null || (Object)(object)m_tradePoint == (Object)null || (Object)(object)m_recruitPoint == (Object)null)
		{
			return false;
		}
		Vector3 position = m_surfaceLeftPoint.position;
		Vector3 val = m_surfaceRightPoint.position;
		if (Random.value > 0.5f || type == NpcVisitor.NpcType.Breacher)
		{
			position = m_surfaceRightPoint.position;
			val = m_surfaceLeftPoint.position;
		}
		Vector3 zero = Vector3.zero;
		switch (type)
		{
		case NpcVisitor.NpcType.Trader:
		case NpcVisitor.NpcType.Joiner:
		case NpcVisitor.NpcType.Scenario:
			zero = ((Component)m_tradePoint).transform.position;
			val = ((!(Random.value >= 0.5f)) ? val : position);
			break;
		case NpcVisitor.NpcType.Recruit:
		case NpcVisitor.NpcType.Breacher:
		case NpcVisitor.NpcType.Family:
			zero = ((Component)m_recruitPoint).transform.position;
			break;
		default:
			zero = val;
			break;
		}
		NpcVisitor npcVisitor = null;
		npcVisitor = ((attribsOverride == null || attribsOverride.Count <= 0) ? CreateNpcVisitor(type, null, position) : CreateNpcVisitor(type, attribsOverride[0], position));
		if ((Object)(object)npcVisitor == (Object)null)
		{
			return false;
		}
		npcVisitor.Initialize(zero, val, type, null, m_uniqueVisitorId++);
		spawned.Add(npcVisitor);
		if (type == NpcVisitor.NpcType.KickstarterBacker && !string.IsNullOrEmpty(m_kickstarterBackerId))
		{
			string text = Localization.Get("text.speech." + m_kickstarterBackerId);
			if (!string.IsNullOrEmpty(text) && text != m_kickstarterBackerId)
			{
				npcVisitor.SetKickstarterBackerSpeech(text);
			}
		}
		m_kickstarterBackerId = string.Empty;
		NpcVisitor.NpcType npcType = NpcVisitor.NpcType.Follower;
		if (type == NpcVisitor.NpcType.Breacher || type == NpcVisitor.NpcType.Recruit || type == NpcVisitor.NpcType.Family)
		{
			npcType = type;
		}
		for (int i = 1; i < quantity; i++)
		{
			NpcVisitor npcVisitor2 = null;
			npcVisitor2 = ((attribsOverride == null || i >= attribsOverride.Count) ? CreateNpcVisitor(npcType, null, position) : CreateNpcVisitor(npcType, attribsOverride[i], position));
			if ((Object)(object)npcVisitor2 == (Object)null)
			{
				continue;
			}
			if (type == NpcVisitor.NpcType.Trader || type == NpcVisitor.NpcType.Joiner || type == NpcVisitor.NpcType.Scenario)
			{
				int num = i - 1;
				if (num >= 0 && num < m_followerPoints.Count)
				{
					zero = m_followerPoints[num].position;
				}
			}
			npcVisitor2.Initialize(zero, val, npcType, npcVisitor, m_uniqueVisitorId++);
			spawned.Add(npcVisitor2);
		}
		return true;
	}

	private bool SpawnNpcs(NpcVisitor.NpcType type, List<FamilySpawner.CharacterAttributes> attribsOverride, out List<NpcVisitor> spawned)
	{
		return SpawnNpcs(type, attribsOverride, attribsOverride.Count, out spawned);
	}

	private void UpdateOngoingSpawns()
	{
		for (int i = 0; i < m_ongoingSpawns.Count; i++)
		{
			bool flag = true;
			for (int j = 0; j < m_ongoingSpawns[i].finished.Count; j++)
			{
				if (!m_ongoingSpawns[i].finished[j])
				{
					flag = false;
					break;
				}
			}
			if (flag)
			{
				m_ongoingSpawns.RemoveAt(i);
				i--;
			}
		}
	}

	private void UpdatePendingSpawns()
	{
		for (int num = m_pendingSpawns.Count - 1; num >= 0; num--)
		{
			SpawnInfo spawnInfo = m_pendingSpawns[num];
			spawnInfo.spawnTimer -= Time.deltaTime;
			if (!(spawnInfo.spawnTimer > 0f) && m_visitors.Count <= 0)
			{
				List<NpcVisitor> spawned = null;
				if (SpawnNpcs(spawnInfo.type, spawnInfo.npcAttributes, out spawned))
				{
					for (int i = 0; i < spawned.Count; i++)
					{
						spawned[i].SetScenarioId(spawnInfo.questId);
					}
					if (spawnInfo.type != NpcVisitor.NpcType.Scenario)
					{
						OngoingSpawn ongoingSpawn = new OngoingSpawn();
						ongoingSpawn.spawnInfo = spawnInfo;
						ongoingSpawn.npcs = spawned;
						ongoingSpawn.finished = new List<bool>();
						for (int j = 0; j < spawned.Count; j++)
						{
							ongoingSpawn.finished.Add(item: false);
						}
						m_ongoingSpawns.Add(ongoingSpawn);
					}
					m_pendingSpawns.RemoveAt(num);
				}
			}
		}
	}

	public void AddNewRecruits(List<EncounterCharacter> npcs, float arrivalDelay)
	{
		SpawnInfo spawnInfo = new SpawnInfo();
		for (int i = 0; i < npcs.Count; i++)
		{
			FamilySpawner.CharacterAttributes characterAttributes = CreateAttributesFromCharacter(npcs[i]);
			characterAttributes.RandomizeTraits();
			spawnInfo.npcAttributes.Add(characterAttributes);
		}
		spawnInfo.type = NpcVisitor.NpcType.Recruit;
		spawnInfo.spawnTimer = arrivalDelay;
		m_pendingSpawns.Add(spawnInfo);
	}

	public void AddNewRecruit(EncounterCharacter npc, float arrivalDelay)
	{
		AddNewRecruits(new List<EncounterCharacter> { npc }, arrivalDelay);
	}

	public void AddNewQuestRecruits(List<QuestManager.QuestCharacterInfo> charInfo, float arrivalDelay, bool recruitAsFamily = false)
	{
		SpawnInfo spawnInfo = new SpawnInfo();
		for (int i = 0; i < charInfo.Count; i++)
		{
			FamilySpawner.CharacterAttributes characterAttributes = CreateAttributesFromPreset(charInfo[i].m_preset);
			characterAttributes.m_strengthLevel = charInfo[i].m_strength;
			characterAttributes.m_dexterityLevel = charInfo[i].m_dexterity;
			characterAttributes.m_intelligenceLevel = charInfo[i].m_intelligence;
			characterAttributes.m_charismaLevel = charInfo[i].m_charisma;
			characterAttributes.m_perceptionLevel = charInfo[i].m_perception;
			characterAttributes.RandomizeTraits();
			spawnInfo.npcAttributes.Add(characterAttributes);
		}
		spawnInfo.type = ((!recruitAsFamily) ? NpcVisitor.NpcType.Recruit : NpcVisitor.NpcType.Family);
		spawnInfo.spawnTimer = arrivalDelay;
		m_pendingSpawns.Add(spawnInfo);
	}

	public void AddNewQuestRecruit(QuestManager.QuestCharacterInfo charInfo, float arrivalDelay)
	{
		AddNewQuestRecruits(new List<QuestManager.QuestCharacterInfo> { charInfo }, arrivalDelay);
	}

	public void AddNewScenario(List<QuestManager.QuestCharacterInfo> charInfo, int scenarioId)
	{
		SpawnInfo spawnInfo = new SpawnInfo();
		for (int i = 0; i < charInfo.Count; i++)
		{
			FamilySpawner.CharacterAttributes characterAttributes = CreateAttributesFromPreset(charInfo[i].m_preset);
			characterAttributes.m_strengthLevel = charInfo[i].m_strength;
			characterAttributes.m_dexterityLevel = charInfo[i].m_dexterity;
			characterAttributes.m_intelligenceLevel = charInfo[i].m_intelligence;
			characterAttributes.m_charismaLevel = charInfo[i].m_charisma;
			characterAttributes.m_perceptionLevel = charInfo[i].m_perception;
			characterAttributes.RandomizeTraits();
			spawnInfo.npcAttributes.Add(characterAttributes);
		}
		spawnInfo.type = NpcVisitor.NpcType.Scenario;
		spawnInfo.spawnTimer = 0f;
		spawnInfo.questId = scenarioId;
		m_pendingSpawns.Add(spawnInfo);
	}

	public void OnNpcFinished(NpcVisitor npc)
	{
		OngoingSpawn ongoingSpawn = null;
		int num = -1;
		for (int i = 0; i < m_ongoingSpawns.Count; i++)
		{
			num = m_ongoingSpawns[i].npcs.FindIndex((NpcVisitor x) => (Object)(object)x == (Object)(object)npc);
			if (num >= 0)
			{
				ongoingSpawn = m_ongoingSpawns[i];
				break;
			}
		}
		if (ongoingSpawn != null && num >= 0)
		{
			ongoingSpawn.finished[num] = true;
		}
	}

	public int GetNumBreacherNpcsRemaining()
	{
		int num = 0;
		for (int i = 0; i < m_visitors.Count; i++)
		{
			if ((Object)(object)m_visitors[i] != (Object)null && !m_visitors[i].isDead && m_visitors[i].npcType == NpcVisitor.NpcType.Breacher)
			{
				num++;
			}
		}
		return num;
	}

	public void OnBreachCancelled()
	{
		for (int i = 0; i < m_visitors.Count; i++)
		{
			if ((Object)(object)m_visitors[i] != (Object)null && !m_visitors[i].isDead && m_visitors[i].GetCharacterType() == BaseCharacter.CharacterType.Npc_Breach)
			{
				m_visitors[i].OnBreachCancelled();
			}
		}
	}

	public void SetTraderBroadcastSpawnChances()
	{
		m_traderSpawnChance = m_broadcastHighSpawnChance;
		m_joinerSpawnChance = m_broadcastLowSpawnChance;
	}

	public void SetRecruitBroadcastSpawnChances()
	{
		m_traderSpawnChance = m_broadcastLowSpawnChance;
		m_joinerSpawnChance = m_broadcastHighSpawnChance;
	}

	public void ResetSpawnChances()
	{
		m_traderSpawnChance = m_traderNormalSpawnChance;
		m_joinerSpawnChance = m_joinerNormalSpawnChance;
	}

	public void SetSpawnFrequency(bool fast, int radioLevel)
	{
		if (fast)
		{
			m_minInterval = m_broadcastingMinInterval * m_radioLevelBroadcastMultipliers[radioLevel];
			m_maxInterval = m_broadcastingMaxInterval * m_radioLevelBroadcastMultipliers[radioLevel];
			if (m_nextSpawnTime > Time.time + m_maxInterval)
			{
				ResetSpawnTimer();
			}
		}
		else
		{
			m_minInterval = m_notBroadcastingMinInterval;
			m_maxInterval = m_notBroadcastingMaxInterval;
		}
	}

	private void ResetSpawnTimer()
	{
		m_nextSpawnTime = Time.time + m_minInterval + Random.value * (m_maxInterval - m_minInterval);
	}

	public bool IsRelocationEnabled()
	{
		return false;
	}

	public bool IsReadyForLoad()
	{
		return true;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("NpcVisitManager");
		data.SaveLoad("visitorId", ref m_uniqueVisitorId);
		data.SaveLoadAbsoluteTime("nextSpawnTime", ref m_nextSpawnTime);
		List<NpcVisitor> npcs = new List<NpcVisitor>();
		for (int i = 0; i < m_visitors.Count; i++)
		{
			if ((Object)(object)m_visitors[i] != (Object)null && m_visitors[i].npcType == NpcVisitor.NpcType.Breacher)
			{
				npcs.Add(m_visitors[i]);
			}
		}
		data.SaveLoadList("visitors", npcs, delegate(int index)
		{
			int value = (int)npcs[index].npcType;
			int value2 = npcs[index].npcId;
			string value3 = npcs[index].meshId;
			data.SaveLoad("id", ref value2);
			data.SaveLoad("type", ref value);
			data.SaveLoad("mesh", ref value3);
		}, delegate
		{
			//IL_006c: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0091: Unknown result type (might be due to invalid IL or missing references)
			int value = -1;
			int value2 = -1;
			string value3 = "man";
			data.SaveLoad("id", ref value);
			data.SaveLoad("type", ref value2);
			data.SaveLoad("mesh", ref value3);
			if (value > -1 && value2 > -1)
			{
				FamilySpawner.CharacterAttributes characterAttributes = new FamilySpawner.CharacterAttributes();
				characterAttributes.Randomize();
				characterAttributes.m_meshId = value3;
				NpcVisitor npcVisitor = CreateNpcVisitor((NpcVisitor.NpcType)value2, characterAttributes, Vector3.zero);
				if (!((Object)(object)npcVisitor == (Object)null))
				{
					npcVisitor.Initialize(Vector3.zero, Vector3.zero, (NpcVisitor.NpcType)value2, null, value);
				}
			}
		});
		List<SpawnInfo> pending = new List<SpawnInfo>();
		for (int num = 0; num < m_pendingSpawns.Count; num++)
		{
			if (m_pendingSpawns[num] != null && m_pendingSpawns[num].type != NpcVisitor.NpcType.Scenario)
			{
				pending.Add(m_pendingSpawns[num]);
			}
		}
		try
		{
			data.SaveLoadList("pending", pending, delegate(int index)
			{
				SpawnInfo spawnInfo2 = pending[index];
				spawnInfo2.SaveLoadSpawn(data);
			}, delegate
			{
				SpawnInfo spawnInfo2 = new SpawnInfo();
				spawnInfo2.SaveLoadSpawn(data);
				if (spawnInfo2.npcAttributes.Count > 0)
				{
					m_pendingSpawns.Add(spawnInfo2);
				}
			});
		}
		catch (SaveData.MissingGroupException)
		{
		}
		try
		{
			data.SaveLoadList("ongoing", m_ongoingSpawns, delegate(int index)
			{
				OngoingSpawn ongoingSpawn = m_ongoingSpawns[index];
				ongoingSpawn.SaveLoadSpawn(data);
			}, delegate
			{
				OngoingSpawn ongoingSpawn = new OngoingSpawn();
				ongoingSpawn.SaveLoadSpawn(data);
				if (ongoingSpawn.spawnInfo != null && ongoingSpawn.spawnInfo.npcAttributes.Count > 0)
				{
					m_ongoingSpawns.Add(ongoingSpawn);
				}
			});
		}
		catch (SaveData.MissingGroupException)
		{
		}
		if (data.isLoading)
		{
			List<OngoingSpawn> list = new List<OngoingSpawn>(m_ongoingSpawns);
			m_ongoingSpawns.Clear();
			foreach (OngoingSpawn item in list)
			{
				if (item.spawnInfo == null || item.spawnInfo.npcAttributes.Count <= 0)
				{
					continue;
				}
				SpawnInfo spawnInfo = item.spawnInfo;
				List<FamilySpawner.CharacterAttributes> list2 = new List<FamilySpawner.CharacterAttributes>();
				for (int num2 = 0; num2 < spawnInfo.npcAttributes.Count; num2++)
				{
					if (num2 < item.finished.Count && !item.finished[num2])
					{
						list2.Add(item.spawnInfo.npcAttributes[num2]);
					}
				}
				List<NpcVisitor> spawned = null;
				if (!SpawnNpcs(spawnInfo.type, list2, out spawned))
				{
					continue;
				}
				for (int num3 = 0; num3 < spawned.Count; num3++)
				{
					spawned[num3].SetScenarioId(spawnInfo.questId);
				}
				if (spawnInfo.type != NpcVisitor.NpcType.Scenario)
				{
					item.npcs = spawned;
					item.finished = new List<bool>();
					for (int num4 = 0; num4 < spawned.Count; num4++)
					{
						item.finished.Add(item: false);
					}
					m_ongoingSpawns.Add(item);
				}
			}
		}
		data.GroupEnd();
		return true;
	}
}
