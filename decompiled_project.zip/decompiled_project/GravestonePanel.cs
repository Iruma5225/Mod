public class GravestonePanel : BasePanel
{
	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool DestroyOnClose()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override void OnShow()
	{
		base.OnShow();
	}

	public void SetGrave(Obj_Base grave)
	{
	}
}
