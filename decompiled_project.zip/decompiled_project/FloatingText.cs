using System.Collections.Generic;
using UnityEngine;

public class FloatingText : MonoBehaviour
{
	private UILabel label;

	private List<UITweener> tweens = new List<UITweener>();

	private FloatingTextPool text_pool;

	private void Awake()
	{
		label = ((Component)this).GetComponentInChildren<UILabel>();
		UITweener[] componentsInChildren = ((Component)this).GetComponentsInChildren<UITweener>();
		if (componentsInChildren != null && componentsInChildren.Length > 0)
		{
			tweens.AddRange(componentsInChildren);
		}
	}

	public void Initialise(FloatingTextPool pool)
	{
		text_pool = pool;
		for (int i = 0; i < tweens.Count; i++)
		{
			tweens[i].ResetToBeginning();
		}
		((Component)this).gameObject.SetActive(false);
	}

	public void ShowText(string text)
	{
		((Component)this).gameObject.SetActive(true);
		if ((Object)(object)label != (Object)null)
		{
			label.text = text;
		}
		for (int i = 0; i < tweens.Count; i++)
		{
			tweens[i].PlayForward();
		}
	}

	public void OnTweensFinished()
	{
		for (int i = 0; i < tweens.Count; i++)
		{
			tweens[i].ResetToBeginning();
		}
		((Component)this).gameObject.SetActive(false);
		if ((Object)(object)text_pool != (Object)null)
		{
			text_pool.OnTextFinished(this);
		}
	}
}
