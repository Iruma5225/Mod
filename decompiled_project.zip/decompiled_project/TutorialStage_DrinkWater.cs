using System.Collections.Generic;
using UnityEngine;

public class TutorialStage_DrinkWater : BaseTutorial
{
	private FamilyMember m_member;

	private float m_initialThirst;

	private Obj_WaterTank m_waterTank;

	public override TutorialManager.TutorialStage GetTutorialStage()
	{
		return TutorialManager.TutorialStage.DrinkWater;
	}

	public override void OnEnterStage(bool showPanel)
	{
		base.OnEnterStage(showPanel);
		if ((Object)(object)InteractionManager.Instance != (Object)null)
		{
			m_member = InteractionManager.Instance.GetSelectedFamilyMember();
			if ((Object)(object)m_member != (Object)null)
			{
				m_member.stats.thirst.Set(80f);
				m_initialThirst = m_member.stats.thirst.Value;
			}
		}
		if ((Object)(object)ObjectManager.Instance != (Object)null)
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.WaterTank);
			if (objectsOfType != null && objectsOfType.Count > 0)
			{
				m_waterTank = objectsOfType[0] as Obj_WaterTank;
			}
		}
		if (!((Object)(object)m_waterTank != (Object)null))
		{
			return;
		}
		m_waterTank.selectable = true;
		m_waterTank.disablable = false;
		Int_Base[] components = ((Component)m_waterTank).GetComponents<Int_Base>();
		for (int i = 0; i < components.Length; i++)
		{
			if (components[i].GetInteractionType() != "drink_water")
			{
				components[i].InteractionEnabled = false;
			}
		}
		if ((Object)(object)m_waterTank != (Object)null && (Object)(object)ObjectiveArrowMan.Instance != (Object)null)
		{
			ObjectiveArrowMan.Instance.AddObjective(m_waterTank.objectiveTarget);
		}
	}

	public override bool IsStageComplete()
	{
		if ((Object)(object)m_member != (Object)null && m_member.stats.thirst.Value < m_initialThirst - 1f)
		{
			return true;
		}
		return false;
	}

	public override void OnExitStage()
	{
		base.OnExitStage();
		if ((Object)(object)m_waterTank != (Object)null)
		{
			m_waterTank.disablable = true;
			m_waterTank.selectable = false;
			Int_Base[] components = ((Component)m_waterTank).GetComponents<Int_Base>();
			for (int i = 0; i < components.Length; i++)
			{
				components[i].InteractionEnabled = true;
			}
			if ((Object)(object)m_waterTank != (Object)null && (Object)(object)ObjectiveArrowMan.Instance != (Object)null)
			{
				ObjectiveArrowMan.Instance.RemoveObjective(m_waterTank.objectiveTarget);
			}
		}
	}
}
