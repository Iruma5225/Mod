using UnityEngine;

public class Obj_WaterFilter : Obj_Integrity
{
	[SerializeField]
	private float m_Throughput = 1f;

	[Range(0f, 10f)]
	[SerializeField]
	private float[] m_ThroughputPerLevel = new float[5] { 1f, 1.1f, 1.2f, 1.3f, 1.5f };

	private float baseDegradeInterval;

	[SerializeField]
	[Range(1f, 1000f)]
	private float[] m_DegradeIntervalPerLevel = new float[5] { 23f, 25.3f, 27.6f, 29.9f, 34.5f };

	public float Throughput => m_Throughput;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.WaterFilter;
	}

	public override void OnCheck()
	{
	}

	public override void Start()
	{
		base.Start();
		baseDegradeInterval = m_DegradeInterval;
		if ((Object)(object)WaterManager.Instance != (Object)null)
		{
			WaterManager.Instance.RegisterFilter(this);
		}
		int amount = Random.Range(25, 51);
		Degrade(amount);
	}

	public override void Update()
	{
		int upgradeLevel = upgrade_component.GetUpgradeLevel(UpgradeObject.PathEnum.Durability);
		baseDegradeInterval = m_DegradeIntervalPerLevel[upgradeLevel];
		if (WeatherManager.Instance.currentState == WeatherManager.WeatherState.MediumSand)
		{
			m_DegradeInterval = baseDegradeInterval * 0.9f;
		}
		else if (WeatherManager.Instance.currentState == WeatherManager.WeatherState.HeavySand)
		{
			m_DegradeInterval = baseDegradeInterval * 0.75f;
		}
		else if (m_DegradeInterval != baseDegradeInterval)
		{
			m_DegradeInterval = baseDegradeInterval;
		}
		base.Update();
	}

	protected override void OnBroken()
	{
		base.OnBroken();
		UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.WaterFilter);
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		data.SaveLoad("baseDegradeInterval", ref baseDegradeInterval);
	}
}
