using UnityEngine;

public class Obj_RoomGhost : Obj_GhostBase
{
	[SerializeField]
	[Header("Room Sprites")]
	private Transform rubble_Left;

	[SerializeField]
	private Transform rubble_Right;

	[SerializeField]
	[Header("Room Sprites")]
	private Sprite roomSprite_Open;

	[SerializeField]
	private Sprite roomSprite_LeftClosed;

	[SerializeField]
	private Sprite roomSprite_RightClosed;

	[SerializeField]
	private Sprite roomSprite_BothClosed;

	private Vector3 last_position = Vector3.zero;

	private ShelterRoomGrid.GridCell cell;

	private Obj_GhostBase m_LadderGhost;

	private CraftingManager.Recipe m_LadderRecipe;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.RoomGhost;
	}

	public override CursorBase.CursorType GetCursorType()
	{
		return CursorBase.CursorType.RoomPlacement;
	}

	public override bool GetCameraZoom()
	{
		return true;
	}

	public void LateUpdate()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		if (base.State == PlacementState.Placed || ((Component)this).transform.position == last_position)
		{
			return;
		}
		last_position = ((Component)this).transform.position;
		if ((Object)(object)ShelterRoomGrid.Instance == (Object)null)
		{
			return;
		}
		cell = ShelterRoomGrid.Instance.GetCell(((Component)this).transform.position);
		if (cell == null)
		{
			return;
		}
		if (IsPlacable())
		{
			if (cell.type != ShelterRoomGrid.CellType.Dirt)
			{
				SetPlacable(placable: false);
				return;
			}
			if (cell.neighbours == null)
			{
				SetPlacable(placable: false);
				return;
			}
			bool flag = false;
			for (int i = 0; i < cell.neighbours.Length; i++)
			{
				if (i != 1 && cell.neighbours[i] != null && IsValidRoom(cell.neighbours[i]))
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				SetPlacable(placable: false);
			}
		}
		else if (cell.type == ShelterRoomGrid.CellType.Dirt && cell.neighbours != null)
		{
			for (int j = 0; j < cell.neighbours.Length; j++)
			{
				if (j != 1 && cell.neighbours[j] != null && IsValidRoom(cell.neighbours[j]))
				{
					SetPlacable(placable: true);
					break;
				}
			}
		}
		if (IsValidRoom(cell.neighbours[2]))
		{
			if (IsValidRoom(cell.neighbours[3]))
			{
				m_SpriteRenderer.sprite = roomSprite_Open;
			}
			else
			{
				m_SpriteRenderer.sprite = roomSprite_RightClosed;
			}
		}
		else if (IsValidRoom(cell.neighbours[3]))
		{
			m_SpriteRenderer.sprite = roomSprite_LeftClosed;
		}
		else
		{
			m_SpriteRenderer.sprite = roomSprite_BothClosed;
		}
	}

	public override bool IsValidRoom(ShelterRoomGrid.GridCell cell)
	{
		if (cell != null && (cell.type == ShelterRoomGrid.CellType.Room || cell.type == ShelterRoomGrid.CellType.RoomTop))
		{
			return true;
		}
		return false;
	}

	public override void OnSelected()
	{
		base.OnSelected();
		if ((Object)(object)m_LadderGhost != (Object)null)
		{
			m_LadderGhost.OnSelected();
		}
	}

	public override void OnUnSelected()
	{
		base.OnUnSelected();
		if ((Object)(object)m_LadderGhost != (Object)null)
		{
			m_LadderGhost.OnUnSelected();
		}
	}

	public void SetLadder(Obj_GhostBase ladder, CraftingManager.Recipe recipe)
	{
		m_LadderRecipe = recipe;
		m_LadderGhost = ladder;
		if ((Object)(object)m_LadderGhost != (Object)null)
		{
			m_LadderGhost.selectable = false;
		}
	}

	public override void PauseConstruction()
	{
		base.PauseConstruction();
	}

	public override bool ResumeConstruction(FamilyMember member)
	{
		if (!IsPaused() || !IsPausable() || (Object)(object)member == (Object)null || string.IsNullOrEmpty(m_CraftRecipeID))
		{
			return false;
		}
		CraftingManager.Recipe recipeByID = CraftingManager.Instance.GetRecipeByID(m_CraftRecipeID);
		if (member.job_queue.isFull)
		{
			return false;
		}
		Job_CraftRoom job_CraftRoom = new Job_CraftRoom(member, recipeByID, this);
		if (!member.AddPlayerJob(job_CraftRoom))
		{
			return false;
		}
		if ((Object)(object)m_LadderGhost != (Object)null)
		{
			job_CraftRoom.AddLadder(m_LadderRecipe, m_LadderGhost);
		}
		m_ConstructionPaused = false;
		base.selectable = false;
		return true;
	}

	public override bool CancelConstruction()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		if (!ShelterRoomGrid.Instance.WorldCoordsToCellCoords(((Component)this).transform.position, out var cell_x, out var cell_y))
		{
			return false;
		}
		ShelterRoomGrid.Instance.SetCellType(cell_x, cell_y, ShelterRoomGrid.CellType.Dirt);
		bool flag = false;
		if ((Object)(object)m_LadderGhost == (Object)null)
		{
			if (ShelterRoomGrid.Instance.HasLadder(cell_x, cell_y - 1))
			{
				flag = ShelterRoomGrid.Instance.RemoveLadders(cell_x, cell_y - 1);
			}
		}
		else
		{
			ObjectManager.Instance.RemoveObject(m_LadderGhost);
			flag = true;
		}
		if (flag && m_LadderRecipe != null)
		{
			CraftingManager.CancelCraft(m_LadderRecipe);
		}
		return base.CancelConstruction();
	}

	protected override void SaveLoadGhost(SaveData data)
	{
		base.SaveLoadGhost(data);
		int value = ((!((Object)(object)m_LadderGhost != (Object)null)) ? (-1) : m_LadderGhost.objectId);
		data.SaveLoad("ladderID", ref value);
		if (!data.isLoading)
		{
			return;
		}
		if ((Object)(object)CraftingManager.Instance != (Object)null)
		{
			m_LadderRecipe = CraftingManager.FreeLadderRecipe;
		}
		if ((Object)(object)ObjectManager.Instance != (Object)null)
		{
			m_LadderGhost = null;
			if (value > -1)
			{
				Obj_Base objectWithId = ObjectManager.Instance.GetObjectWithId(value);
				if ((Object)(object)objectWithId != (Object)null)
				{
					m_LadderGhost = objectWithId as Obj_LadderGhost;
				}
			}
		}
		SetLadder(m_LadderGhost, m_LadderRecipe);
	}
}
