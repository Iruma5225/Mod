public class NpcDialogueRecruit : NpcDialogueBase
{
	public NpcDialogueRecruit(NpcDialoguePanel panel)
		: base(panel)
	{
		SetState(RecruitStage_Initial);
	}

	private DialogueResult RecruitStage_Initial()
	{
		dialoguePanel.PushNpcText("npc.dialogue.joiner", autoContinue: true);
		SetState(RecruitStage_WaitForUI);
		return DialogueResult.Continue;
	}

	private DialogueResult RecruitStage_WaitForUI()
	{
		if (!dialoguePanel.IsTextDone())
		{
			return DialogueResult.Continue;
		}
		UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.Recruit);
		return DialogueResult.Recruit;
	}
}
