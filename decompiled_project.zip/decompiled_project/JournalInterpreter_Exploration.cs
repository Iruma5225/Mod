using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class JournalInterpreter_Exploration : JournalInterpreter_Base
{
	public override JournalManager.JournalEntryType GetEntryType()
	{
		return JournalManager.JournalEntryType.Exploration;
	}

	public override string CreateJournalEntry(JournalEvents events, JournalStatus status)
	{
		StringBuilder stringBuilder = new StringBuilder();
		JournalEvents.EventRecord eventRecord = null;
		JournalEvents.EventRecord eventRecord2 = null;
		JournalEvents.EventRecord eventRecord3 = null;
		List<JournalEvents.EventRecord> eventsOfType = events.GetEventsOfType(JournalEvents.Event.ExplorationEnded);
		if (eventsOfType.Count > 0)
		{
			eventRecord = eventsOfType[0];
		}
		List<JournalEvents.EventRecord> eventsOfType2 = events.GetEventsOfType(JournalEvents.Event.ExplorationNPC);
		for (int i = 0; i < eventsOfType2.Count; i++)
		{
			if (eventsOfType2[i].extra1.m_text == eventRecord.extra1.m_text)
			{
				eventRecord2 = eventsOfType2[i];
				break;
			}
		}
		List<JournalEvents.EventRecord> eventsOfType3 = events.GetEventsOfType(JournalEvents.Event.ExplorationLocation);
		for (int j = 0; j < eventsOfType3.Count; j++)
		{
			if (eventsOfType3[j].extra1.m_text == eventRecord.extra1.m_text)
			{
				eventRecord3 = eventsOfType3[j];
				break;
			}
		}
		if (Random.Range(0, 2) == 0)
		{
			if (eventRecord3 != null)
			{
				if (Random.Range(0, 2) == 0)
				{
					int num = Random.Range(1, 10);
					int num2 = Random.Range(1, 6);
					stringBuilder.Append(Localization.Get("Journal.DiaryPrefix" + num2));
					stringBuilder.AppendLine();
					stringBuilder.Append("\"");
					stringBuilder.Append(Localization.Get("Journal.Event.ExplorationDiary" + num));
					stringBuilder.Append("\"");
				}
				else
				{
					int num3 = Random.Range(1, 6);
					stringBuilder.Append(Localization.Get("Journal.Event.ExplorationBody" + num3));
				}
				stringBuilder.AppendLine();
				stringBuilder.AppendLine();
			}
		}
		else if (eventRecord2 != null)
		{
			int num4 = Random.Range(1, 6);
			int num5 = Random.Range(1, 5);
			stringBuilder.Append(Localization.Get("Journal.Event.ExplorationNPC" + num4));
			stringBuilder.Append(Localization.Get("Journal.GameplayHint" + num5));
		}
		return stringBuilder.ToString();
	}
}
