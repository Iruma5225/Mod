using UnityEngine;

public class CompanionAnimal_Snake : CompanionAnimal
{
	private BaseCharacter m_target;

	[SerializeField]
	private int m_attackDamage;

	[SerializeField]
	private float m_hungerPerBite;

	[SerializeField]
	private float m_timeBetweenAttacks;

	private float m_nextAttackTime;

	protected override AIState GetNextState()
	{
		return GetRandomState();
	}

	protected override void EnterState_Hunting()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		ClearPath();
		if ((Object)(object)m_target == (Object)null)
		{
			PickNextState();
			return;
		}
		float num = ((Component)m_target).transform.position.x - ((Component)this).transform.position.x;
		if ((num < 0f && ((Component)base.sprite).transform.localScale.x < 0f) || (num > 0f && ((Component)base.sprite).transform.localScale.x > 0f))
		{
			TriggerAnim("attack");
			if (Random.value <= m_huntSuccessChance)
			{
				m_target.Damage(m_attackDamage, BaseCharacter.DamageType.Pet, string.Empty);
				m_hunger -= m_hungerPerBite;
				if (m_huntSuccessSounds.Count > 0)
				{
					PlaySound(m_huntSuccessSounds[Random.Range(0, m_huntSuccessSounds.Count)]);
				}
			}
			else if (m_huntFailureSounds.Count > 0 && Time.time >= m_huntFailureSoundTimeout)
			{
				PlaySound(m_huntFailureSounds[Random.Range(0, m_huntFailureSounds.Count)]);
				m_huntFailureSoundTimeout = Time.time + 6f;
			}
			m_nextAttackTime = Time.time + m_timeBetweenAttacks;
			m_stateTimer = Time.time + 1f;
			m_update = Update_Hunting;
		}
		else
		{
			m_target = null;
			PickNextState();
		}
	}

	protected override void Update_Hunting()
	{
		if (!(Time.time < m_stateTimer))
		{
			m_target = null;
			PickNextState();
		}
	}

	protected override void OnTriggerEnter2D(Collider2D collider)
	{
		base.OnTriggerEnter2D(collider);
		if (((Component)collider).CompareTag("NPC"))
		{
			FamilyMember component = ((Component)collider).GetComponent<FamilyMember>();
			if ((Object)(object)component != (Object)null && !component.isAway && !component.isHiding && !component.isUncontrollable && !component.isDead && (m_state == AIState.Idle || m_pathState == PathState.Started) && m_hunger >= 100f && Time.time >= m_nextAttackTime)
			{
				m_target = component;
				SetState(AIState.Hunting);
			}
		}
	}

	public void ResetState()
	{
		ClearPath();
		m_update = null;
		SetState(AIState.Idle);
	}

	public void SetupFromTank(float health, float hunger, bool starving, float starvationTimer, bool poisoned)
	{
		m_health = health;
		m_hunger = hunger;
		m_starving = starving;
		m_starvationTimer = starvationTimer;
		m_poisoned = poisoned;
	}

	public void GetTankAttributes(out float health, out float hunger, out bool starving, out float starvationTimer, out bool poisoned)
	{
		health = m_health;
		hunger = m_hunger;
		starving = m_starving;
		starvationTimer = m_starvationTimer;
		poisoned = m_poisoned;
	}

	public bool IsCatchable()
	{
		return !base.isDead && (m_state == AIState.Idle || (m_state == AIState.Wandering && base.isVisible));
	}

	public override bool IsRelocationEnabled()
	{
		return true;
	}

	protected override void SaveLoadPet(SaveData data)
	{
		base.SaveLoadPet(data);
		data.SaveLoadAbsoluteTime("attackTime", ref m_nextAttackTime);
	}
}
