using System.Collections.Generic;
using UnityEngine;

public class Obj_Door : Obj_Integrity
{
	private bool m_open;

	[SerializeField]
	private bool m_locked;

	[SerializeField]
	private Transform m_interactionPos;

	private Dictionary<DoorCollider.DoorColliderType, DoorCollider> m_DoorColliders = new Dictionary<DoorCollider.DoorColliderType, DoorCollider>();

	private int[] m_CollidedNPCs = new int[3];

	public bool IsLocked => m_locked;

	public bool IsOpen()
	{
		return m_open;
	}

	public bool IsClosed()
	{
		return !m_open;
	}

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.Door;
	}

	public bool IsDoorColliderActive(DoorCollider.DoorColliderType triggerType)
	{
		if ((triggerType == DoorCollider.DoorColliderType.CursorClosed && !m_open) || (triggerType == DoorCollider.DoorColliderType.CursorOpen && m_open))
		{
			return true;
		}
		return false;
	}

	public virtual void OnDoorTriggerEntered(DoorCollider.DoorColliderType doorTriggerType, Collider2D other)
	{
		if (doorTriggerType != DoorCollider.DoorColliderType.CharacterPath && !IsDoorColliderActive(doorTriggerType))
		{
			return;
		}
		if (((Component)other).CompareTag("NPC"))
		{
			m_CollidedNPCs[(int)doorTriggerType]++;
		}
		if (((Component)other).CompareTag("Object"))
		{
			Obj_Base component = ((Component)other).GetComponent<Obj_Base>();
			if ((Object)(object)component != (Object)null && (component.GetObjectType() == ObjectManager.ObjectType.CatatonicGhost || component.GetObjectType() == ObjectManager.ObjectType.Corpse))
			{
				m_CollidedNPCs[(int)doorTriggerType]++;
			}
		}
	}

	public virtual void OnDoorTriggerExited(DoorCollider.DoorColliderType doorTriggerType, Collider2D other)
	{
		if (doorTriggerType != DoorCollider.DoorColliderType.CharacterPath && !IsDoorColliderActive(doorTriggerType))
		{
			return;
		}
		if (((Component)other).CompareTag("NPC"))
		{
			if (m_CollidedNPCs[(int)doorTriggerType] == 0)
			{
				return;
			}
			m_CollidedNPCs[(int)doorTriggerType]--;
		}
		if (((Component)other).CompareTag("Object"))
		{
			Obj_Base component = ((Component)other).GetComponent<Obj_Base>();
			if ((Object)(object)component != (Object)null && (component.GetObjectType() == ObjectManager.ObjectType.CatatonicGhost || component.GetObjectType() == ObjectManager.ObjectType.Corpse) && m_CollidedNPCs[(int)doorTriggerType] != 0)
			{
				m_CollidedNPCs[(int)doorTriggerType]--;
			}
		}
	}

	public override void Awake()
	{
		base.Awake();
		DoorCollider[] componentsInChildren = ((Component)this).GetComponentsInChildren<DoorCollider>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			if (!m_DoorColliders.ContainsKey(componentsInChildren[i].GetDoorColliderType()))
			{
				m_DoorColliders.Add(componentsInChildren[i].GetDoorColliderType(), componentsInChildren[i]);
				if (componentsInChildren[i].GetDoorColliderType() == DoorCollider.DoorColliderType.CursorOpen)
				{
					((Component)componentsInChildren[i]).gameObject.SetActive(false);
				}
			}
		}
	}

	protected virtual void OnOpened()
	{
	}

	protected virtual void OnClosed()
	{
	}

	public void SetLocked(bool locked)
	{
		m_locked = locked;
	}

	public virtual bool Open()
	{
		if (m_open || (m_locked && !IsBroken()))
		{
			return false;
		}
		if (m_DoorColliders.TryGetValue(DoorCollider.DoorColliderType.CursorClosed, out var value))
		{
			((Component)value).gameObject.SetActive(false);
			m_CollidedNPCs[1] = 0;
		}
		if (m_DoorColliders.TryGetValue(DoorCollider.DoorColliderType.CursorOpen, out value))
		{
			((Component)value).gameObject.SetActive(true);
		}
		m_open = true;
		OnOpened();
		return true;
	}

	public virtual bool Close()
	{
		if (!m_open || IsBroken())
		{
			return false;
		}
		if (m_CollidedNPCs[2] > 0)
		{
			return false;
		}
		if (m_DoorColliders.TryGetValue(DoorCollider.DoorColliderType.CursorOpen, out var value))
		{
			((Component)value).gameObject.SetActive(false);
			m_CollidedNPCs[0] = 0;
		}
		if (m_DoorColliders.TryGetValue(DoorCollider.DoorColliderType.CursorClosed, out value))
		{
			((Component)value).gameObject.SetActive(true);
		}
		m_open = false;
		OnClosed();
		return true;
	}

	public bool ShouldAllowWaypoint(Vector3 waypoint)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		if (m_DoorColliders.TryGetValue(DoorCollider.DoorColliderType.CharacterPath, out var value) && (Object)(object)((Component)value).GetComponent<Collider2D>() != (Object)null && ((Component)value).GetComponent<Collider2D>().OverlapPoint(Vector2.op_Implicit(waypoint)))
		{
			return false;
		}
		return true;
	}

	public override Vector3 GetInteractionPosition()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		return (!((Object)(object)m_interactionPos != (Object)null)) ? base.GetInteractionPosition() : m_interactionPos.position;
	}

	public override List<string> GetTooltipExtraInfo()
	{
		List<string> list = new List<string>();
		string key = ((!m_open) ? "UI.Closed" : "UI.Open");
		if (IsBroken())
		{
			key = "Text.UI.DoorBroken";
		}
		else if (m_locked)
		{
			key = "Text.UI.DoorLocked";
		}
		list.AddRange(base.GetTooltipExtraInfo());
		list.Add(Localization.Get("Text.UI.Status"));
		list.Add(Localization.Get(key));
		return list;
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		bool value = m_open;
		data.SaveLoad("open", ref value);
		data.SaveLoad("locked", ref m_locked);
		if (data.isLoading)
		{
			if (value)
			{
				Open();
			}
			m_open = value;
			if (IsBroken())
			{
				OnBroken();
			}
			Close();
		}
	}
}
