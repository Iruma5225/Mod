using UnityEngine;

public class CustomizationHelpPanel : BasePanel
{
	public AudioClip closeSound;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override bool Popup()
	{
		return true;
	}

	public override void OnCancel()
	{
		CloseHelpPanel();
	}

	public void CloseHelpPanel()
	{
		if ((Object)(object)UIPanelManager.instance != (Object)null)
		{
			if ((Object)(object)closeSound != (Object)null)
			{
				UISound.instance.Play(closeSound);
			}
			UIPanelManager.instance.PopPanel(this);
		}
	}
}
