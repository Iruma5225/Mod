using System.Collections.Generic;
using UnityEngine;

public class InteractionInstance_CatatonicHazmatRemove : InteractionInstance_Base
{
	private Int_CatatonicHazmatRemove interaction;

	private Obj_CatatonicGhost corpse_object;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_CatatonicHazmatRemove;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		corpse_object = ((Component)this).GetComponent<Obj_CatatonicGhost>();
		if ((Object)(object)corpse_object == (Object)null)
		{
			return false;
		}
		if (!corpse_object.HasHazmatSuit())
		{
			return false;
		}
		member.SetAnimBool("Crouch", truth: true);
		member.TriggerAnim("Rummage");
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		member.SetAnimBool("crouch", truth: false);
		member.TriggerAnim("Idle");
		if (!base.cancelled)
		{
			Obj_HazmatSuit.HazmatSuit hazmatSuit = null;
			if ((Object)(object)corpse_object.GetFamilyMember() != (Object)null)
			{
				hazmatSuit = corpse_object.GetFamilyMember().RemoveHazmatSuit();
			}
			if (hazmatSuit != null)
			{
				List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.HazmatSuits);
				if (objectsOfType != null && objectsOfType.Count > 0)
				{
					Obj_HazmatSuit obj_HazmatSuit = null;
					for (int i = 0; i < objectsOfType.Count; i++)
					{
						obj_HazmatSuit = objectsOfType[i] as Obj_HazmatSuit;
						if ((Object)(object)obj_HazmatSuit != (Object)null && !obj_HazmatSuit.IsFullOfSuits())
						{
							obj_HazmatSuit.ReturnSuit(hazmatSuit);
							return true;
						}
					}
				}
			}
		}
		return true;
	}
}
