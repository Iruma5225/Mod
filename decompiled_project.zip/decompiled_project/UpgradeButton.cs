using UnityEngine;

public class UpgradeButton : MonoBehaviour
{
	public delegate void UpgradeButtonEvent(UpgradeButton button, bool selected);

	public delegate void UpgradeButtonClickEvent(UpgradeButton button, bool right);

	public UpgradeButtonEvent onSelected;

	public UpgradeButtonClickEvent onClicked;

	public UIButton m_button;

	public UISprite m_sprite;

	public UILabel m_label;

	public UISprite m_crafted_sprite;

	public UISprite m_locked_sprite;

	private int m_slotIndex = -1;

	private UpgradeObject.LevelInfo m_info;

	private int m_level = -1;

	private bool m_crafted;

	private bool m_isNext;

	public int slotIndex => m_slotIndex;

	public int level => m_level;

	public bool crafted => m_crafted;

	public bool isNext => m_isNext;

	public void SetSlotIndex(int index)
	{
		bool flag = false;
		if ((Object)(object)UICamera.selectedObject == (Object)(object)((Component)this).gameObject)
		{
			flag = true;
		}
		m_slotIndex = index;
		if ((Object)(object)UICamera.selectedObject == (Object)(object)((Component)this).gameObject && !flag)
		{
			OnClick(selected: true);
		}
	}

	public void SetUpgrade(UpgradeObject.LevelInfo info, int level, bool crafted, bool next)
	{
		bool flag = m_info != info;
		m_info = info;
		m_level = level;
		m_crafted = crafted;
		m_isNext = next;
		UpdateLabel();
		if (flag || info == null)
		{
			UpdateSprite();
			if ((Object)(object)UICamera.selectedObject == (Object)(object)((Component)this).gameObject)
			{
				OnClick(selected: true);
			}
		}
	}

	public void OnClick(bool selected)
	{
		UICamera.selectedObject.GetComponent<UIButton>().OnClick();
		OnHover(selected);
	}

	public void OnHover(bool selected)
	{
		if (onSelected != null)
		{
			onSelected(this, selected);
		}
	}

	protected virtual void UpdateSprite()
	{
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		if (m_info == null)
		{
			if ((Object)(object)m_sprite != (Object)null)
			{
				m_sprite.spriteName = string.Empty;
			}
		}
		else if ((Object)(object)m_sprite != (Object)null && !string.IsNullOrEmpty(m_info.ui_sprite))
		{
			m_sprite.spriteName = m_info.ui_sprite;
		}
		if ((Object)(object)m_crafted_sprite != (Object)null)
		{
			((Behaviour)m_crafted_sprite).enabled = m_crafted;
		}
		if ((Object)(object)m_locked_sprite != (Object)null)
		{
			((Behaviour)m_locked_sprite).enabled = !m_crafted && !m_isNext;
		}
		if ((Object)(object)m_button != (Object)null)
		{
			float num = (m_crafted ? 1f : ((!m_isNext) ? 0.5f : 1f));
			m_button.defaultColor = new Color(m_button.defaultColor.r, m_button.defaultColor.g, m_button.defaultColor.b, num);
			m_button.hover = new Color(m_button.hover.r, m_button.hover.g, m_button.hover.b, num);
			m_button.pressed = new Color(m_button.pressed.r, m_button.pressed.g, m_button.pressed.b, num);
			m_button.disabledColor = new Color(m_button.disabledColor.r, m_button.disabledColor.g, m_button.disabledColor.b, num);
			m_button.UpdateColor(instant: true);
		}
	}

	protected virtual void UpdateLabel()
	{
		if ((Object)(object)m_label != (Object)null)
		{
			string text = string.Empty;
			if (m_info != null)
			{
				text = Localization.Get(m_info.name);
			}
			m_label.text = text;
		}
	}
}
