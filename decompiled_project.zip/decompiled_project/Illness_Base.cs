using System;

[Serializable]
public abstract class Illness_Base
{
	protected FamilyMember m_member;

	private bool m_active;

	public bool isActive => m_active;

	public virtual void UpdateIllness()
	{
	}

	protected virtual void OnContractIllness()
	{
	}

	protected virtual void OnCureIllness()
	{
	}

	public virtual void Initialize(FamilyMember member)
	{
		m_member = member;
	}

	public void SetActive(bool active)
	{
		if (active && !m_active)
		{
			OnContractIllness();
		}
		else if (!active && m_active)
		{
			OnCureIllness();
		}
		m_active = active;
	}

	public virtual void SaveLoadIllness(SaveData data)
	{
		data.SaveLoad("active", ref m_active);
	}
}
