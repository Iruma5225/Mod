using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

public class IncineratorPanel : BasePanel
{
	public ItemGrid m_inventoryItems;

	public ItemGrid m_inventoryChosen;

	public UILabel m_itemNameLabel;

	public UILabel m_itemDescLabel;

	public UILabel m_totalValueLabel;

	private ItemGrid m_selectedGrid;

	private ItemManager.ItemType m_selectedType = ItemManager.ItemType.Undefined;

	private int m_selectedSlotIndex = -1;

	private ItemGrid m_previousGrid;

	private ItemManager.ItemType m_previoustype = ItemManager.ItemType.Undefined;

	private int m_previousSlotIndex = -1;

	public UIButton m_BurnButton;

	public AudioClip openSound;

	public AudioClip closeSound;

	public AudioClip transferSound;

	public AudioClip transferFailSound;

	public LegendContainer m_legend;

	private float m_FuelValue;

	private bool m_burnAvailable;

	private Obj_Incinerator incinerator;

	[SerializeField]
	private UISprite dragSprite;

	[SerializeField]
	private GameObject dragObj;

	[SerializeField]
	private UILabel dragLabel;

	private bool doubleTap;

	private bool tweenActivated;

	private List<ItemButtonBase> activateList = new List<ItemButtonBase>();

	private List<ItemButtonBase> deactivateList = new List<ItemButtonBase>();

	private bool dragItemSet;

	private bool waitUntilNextTouch;

	private bool dragItemInc;

	private int dragItemMaxNum;

	private int dragItemCurrentNum;

	private float dragHoldTimer;

	private float dragTimerIncrement = 0.2f;

	private Vector3 dragInitialPos = Vector3.zero;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override void Update()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (Input.touchCount == 1)
		{
			Touch touch = Input.GetTouch(0);
			if (((Touch)(ref touch)).tapCount == 2)
			{
				doubleTap = true;
			}
		}
		if (dragObj.activeInHierarchy)
		{
			DragObjUpdate();
		}
		if (Input.touchCount == 0 && tweenActivated)
		{
			DeactivateTween();
			tweenActivated = false;
		}
	}

	public override void OnShow()
	{
		base.OnShow();
		AudioManager.Instance.PlayUI(openSound);
		m_selectedGrid = null;
		m_selectedType = ItemManager.ItemType.Undefined;
		m_selectedSlotIndex = -1;
		incinerator = null;
		List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Incinerator);
		if (objectsOfType != null && objectsOfType.Count > 0)
		{
			incinerator = objectsOfType[0] as Obj_Incinerator;
		}
		if ((Object)(object)incinerator == (Object)null)
		{
			UIPanelManager.Instance().PopPanel(this);
		}
		ResetScreen();
		UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.IncineratorPanel);
	}

	public override void OnClose()
	{
		base.OnClose();
		AudioManager.Instance.PlayUI(closeSound);
	}

	private void ResetScreen()
	{
		m_FuelValue = 0f;
		if ((Object)(object)m_inventoryItems != (Object)null)
		{
			m_inventoryItems.Initialize(OnItemSelected, OnItemDeselected, OnItemClicked);
			m_inventoryItems.SelectFirstButton();
			if ((Object)(object)InventoryManager.Instance != (Object)null)
			{
				AddPlayerItems(InventoryManager.Instance.GetItems());
			}
		}
		if ((Object)(object)m_inventoryChosen != (Object)null)
		{
			m_inventoryChosen.Initialize(OnItemSelected, OnItemDeselected, OnItemClicked);
		}
		UpdateBurn();
		UpdateSelectionLabels();
	}

	public void Revert()
	{
		ResetScreen();
	}

	public void AddPlayerItems(List<ItemStack> items)
	{
		if ((Object)(object)InventoryManager.Instance != (Object)null)
		{
			m_inventoryItems.m_maxSlots = InventoryManager.Instance.storageCapacity;
		}
		if ((Object)(object)m_inventoryItems != (Object)null && items != null)
		{
			for (int i = 0; i < items.Count; i++)
			{
				m_inventoryItems.AddItem(items[i].m_type, items[i].m_count);
			}
		}
	}

	public override void OnCancel()
	{
		base.OnCancel();
		UIPanelManager.Instance().PopPanel(this);
	}

	private void OnItemSelected(ItemGrid grid, ItemManager.ItemType type, int slotIndex)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Invalid comparison between Unknown and I4
		m_selectedGrid = grid;
		m_selectedType = type;
		m_selectedSlotIndex = slotIndex;
		if ((Object)(object)m_previousGrid != (Object)null && Input.touchCount == 1)
		{
			Touch touch = Input.GetTouch(0);
			if ((int)((Touch)(ref touch)).phase == 3 && (Object)(object)m_previousGrid != (Object)(object)m_selectedGrid)
			{
				if ((Object)(object)m_previousGrid == (Object)(object)m_inventoryItems && (Object)(object)m_selectedGrid == (Object)(object)m_inventoryChosen)
				{
					if (doubleTap)
					{
						TransferSelectedItems(m_inventoryItems, m_inventoryChosen, m_previousGrid.GetNumItemsInSlot(m_previousSlotIndex));
					}
					else
					{
						TransferSelectedItems(m_inventoryItems, m_inventoryChosen, dragItemCurrentNum);
					}
				}
				else if ((Object)(object)m_previousGrid == (Object)(object)m_inventoryChosen && (Object)(object)m_selectedGrid == (Object)(object)m_inventoryItems)
				{
					if (doubleTap)
					{
						TransferSelectedItems(m_inventoryChosen, m_inventoryItems, m_previousGrid.GetNumItemsInSlot(m_previousSlotIndex));
					}
					else
					{
						TransferSelectedItems(m_inventoryChosen, m_inventoryItems, dragItemCurrentNum);
					}
				}
			}
		}
		DragObjSelection();
		UpdateBurn();
		UpdateSelectionLabels();
	}

	private void OnItemDeselected(ItemGrid grid)
	{
		m_previousGrid = m_selectedGrid;
		m_previoustype = m_selectedType;
		m_previousSlotIndex = m_selectedSlotIndex;
		m_selectedGrid = null;
		m_selectedType = ItemManager.ItemType.Undefined;
		m_selectedSlotIndex = -1;
	}

	public void OnItemClicked(ItemGrid grid, ItemManager.ItemType type, int slotIndex, bool rightClick)
	{
		if (rightClick)
		{
			OnExtra2();
		}
		else
		{
			OnSelect();
		}
	}

	public void ActivateTween()
	{
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		if (m_selectedType == ItemManager.ItemType.Undefined)
		{
			return;
		}
		activateList.Clear();
		if ((Object)(object)m_selectedGrid == (Object)(object)m_inventoryItems)
		{
			activateList.AddRange(m_inventoryChosen.GetButtons);
		}
		else if ((Object)(object)m_selectedGrid == (Object)(object)m_inventoryChosen)
		{
			activateList.AddRange(m_inventoryItems.GetButtons);
		}
		if (activateList.Count <= 0)
		{
			return;
		}
		for (int i = 0; i < activateList.Count; i++)
		{
			if ((Object)(object)activateList[i].colourTween != (Object)null && !activateList[i].IsLocked)
			{
				activateList[i].colourTween.from = activateList[i].defaultColour.defaultColor;
				activateList[i].colourTween.to = Color.white;
				activateList[i].colourTween.duration = 1f;
				activateList[i].colourTween.style = UITweener.Style.Loop;
				((Behaviour)activateList[i].colourTween).enabled = true;
			}
		}
	}

	public void DeactivateTween()
	{
		if (deactivateList.Count <= 0)
		{
			deactivateList.AddRange(m_inventoryChosen.GetButtons);
			deactivateList.AddRange(m_inventoryItems.GetButtons);
		}
		if (deactivateList.Count <= 0)
		{
			return;
		}
		for (int i = 0; i < deactivateList.Count; i++)
		{
			if ((Object)(object)deactivateList[i].colourTween != (Object)null && !deactivateList[i].IsLocked)
			{
				deactivateList[i].colourTween.style = UITweener.Style.Once;
			}
		}
	}

	private void DragObjSelection()
	{
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(m_selectedType);
		if ((Object)(object)itemDefinition != (Object)null && (Object)(object)dragSprite != (Object)null)
		{
			UISprite component = ((Component)itemDefinition).GetComponent<UISprite>();
			if ((Object)(object)component != (Object)null)
			{
				dragSprite.atlas = component.atlas;
				dragSprite.spriteName = component.spriteName;
				dragObj.SetActive(true);
			}
			else
			{
				dragObj.SetActive(false);
			}
		}
	}

	private void DragObjUpdate()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Invalid comparison between Unknown and I4
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Invalid comparison between Unknown and I4
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		if (Input.touchCount == 1)
		{
			Touch touch = Input.GetTouch(0);
			if ((int)((Touch)(ref touch)).phase != 0)
			{
				Touch touch2 = Input.GetTouch(0);
				if ((int)((Touch)(ref touch2)).phase != 3)
				{
					Transform transform = dragObj.transform;
					Camera mainCamera = UICamera.mainCamera;
					Touch touch3 = Input.GetTouch(0);
					float x = mainCamera.ScreenToWorldPoint(Vector2.op_Implicit(((Touch)(ref touch3)).position)).x;
					Camera mainCamera2 = UICamera.mainCamera;
					Touch touch4 = Input.GetTouch(0);
					transform.position = new Vector3(x, mainCamera2.ScreenToWorldPoint(Vector2.op_Implicit(((Touch)(ref touch4)).position)).y, 0f);
					if (!waitUntilNextTouch)
					{
						if (!dragItemSet)
						{
							dragItemMaxNum = m_selectedGrid.GetNumItemsInSlot(m_selectedSlotIndex);
							dragHoldTimer = RealTime.time + 1f;
							dragItemCurrentNum = 1;
							dragTimerIncrement = 0.2f;
							dragItemSet = true;
							dragInitialPos = dragObj.transform.position;
						}
						if (dragItemSet && (dragInitialPos.x - dragObj.transform.position.x > 0.1f || dragInitialPos.x - dragObj.transform.position.x < -0.1f || dragInitialPos.y - dragObj.transform.position.y > 0.1f || dragInitialPos.y - dragObj.transform.position.y < -0.1f))
						{
							waitUntilNextTouch = true;
						}
						if (dragItemSet && RealTime.time > dragHoldTimer && dragItemCurrentNum < dragItemMaxNum)
						{
							dragItemInc = true;
							dragItemCurrentNum++;
							dragLabel.text = dragItemCurrentNum.ToString();
							dragHoldTimer = RealTime.time + (1f - dragTimerIncrement);
							if (dragTimerIncrement + 0.2f < 0.9f)
							{
								dragTimerIncrement += 0.2f;
							}
						}
					}
					if (!tweenActivated)
					{
						ActivateTween();
						tweenActivated = true;
					}
				}
			}
		}
		if (Input.touchCount == 1)
		{
			Touch touch5 = Input.GetTouch(0);
			if ((int)((Touch)(ref touch5)).phase == 3)
			{
				dragObj.SetActive(false);
				doubleTap = false;
				dragItemSet = false;
				dragItemInc = false;
				waitUntilNextTouch = false;
			}
		}
		if (doubleTap && dragObj.activeInHierarchy)
		{
			if (!string.Equals(dragLabel.text, m_selectedGrid.GetNumItemsInSlot(m_selectedSlotIndex).ToString()))
			{
				dragLabel.text = m_selectedGrid.GetNumItemsInSlot(m_selectedSlotIndex).ToString();
			}
		}
		else if (!doubleTap && dragObj.activeInHierarchy && !dragItemInc && !string.Equals(dragLabel.text, "1"))
		{
			dragLabel.text = 1.ToString();
		}
	}

	private void UpdateSelectionLabels()
	{
		if (m_selectedType == ItemManager.ItemType.Undefined && (Object)(object)m_itemNameLabel != (Object)null)
		{
			m_itemNameLabel.text = string.Empty;
		}
		if (!((Object)(object)ItemManager.Instance != (Object)null))
		{
			return;
		}
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(m_selectedType);
		if ((Object)(object)itemDefinition != (Object)null)
		{
			if ((Object)(object)m_itemNameLabel != (Object)null)
			{
				m_itemNameLabel.text = Localization.Get(itemDefinition.NameLocalizationKey);
				helpName = m_itemNameLabel.text;
			}
			if ((Object)(object)m_itemDescLabel != (Object)null)
			{
				m_itemDescLabel.text = Localization.Get(itemDefinition.DescLocalizationKey);
				helpDescription = m_itemDescLabel.text;
			}
			if ((Object)(object)ItemHelpButton.instance != (Object)null)
			{
				ItemHelpButton.instance.EnableButton();
			}
		}
		else if ((Object)(object)ItemHelpButton.instance != (Object)null)
		{
			ItemHelpButton.instance.DisableButton();
		}
	}

	private void TransferSelectedItems(ItemGrid from, ItemGrid to, int quantity = 1)
	{
		if (!((Object)(object)from == (Object)null) && !((Object)(object)to == (Object)null) && quantity > 0)
		{
			if (from.TransferItems(to, m_previousSlotIndex, quantity))
			{
				AudioManager.Instance.PlayUI(transferSound);
			}
			else
			{
				AudioManager.Instance.PlayUI(transferFailSound);
			}
		}
	}

	public override void OnSelect()
	{
		if ((Object)(object)m_selectedGrid == (Object)(object)m_inventoryItems)
		{
			TransferSelectedItems(m_inventoryItems, m_inventoryChosen);
			UpdateBurn();
		}
		if ((Object)(object)m_selectedGrid == (Object)(object)m_inventoryChosen)
		{
			TransferSelectedItems(m_inventoryChosen, m_inventoryItems);
			UpdateBurn();
		}
	}

	public override void OnExtra2()
	{
		if ((Object)(object)m_selectedGrid == (Object)(object)m_inventoryItems)
		{
			TransferSelectedItems(m_inventoryItems, m_inventoryChosen, m_inventoryItems.GetNumItemsInSlot(m_selectedSlotIndex));
			UpdateBurn();
		}
		if ((Object)(object)m_selectedGrid == (Object)(object)m_inventoryChosen)
		{
			TransferSelectedItems(m_inventoryChosen, m_inventoryItems, m_inventoryChosen.GetNumItemsInSlot(m_selectedSlotIndex));
			UpdateBurn();
		}
	}

	private void UpdateBurn()
	{
		m_burnAvailable = true;
		ReadOnlyCollection<ItemGrid.ItemSlot> items = m_inventoryChosen.GetItems();
		m_FuelValue = 0f;
		if ((Object)(object)ItemManager.Instance != (Object)null)
		{
			for (int i = 0; i < items.Count; i++)
			{
				ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(items[i].m_type);
				if ((Object)(object)itemDefinition != (Object)null)
				{
					m_FuelValue += (float)items[i].m_count * itemDefinition.BurnValue;
				}
			}
		}
		if (items.Count <= 0)
		{
			m_burnAvailable = false;
		}
		if ((Object)(object)m_BurnButton != (Object)null)
		{
			m_BurnButton.isEnabled = m_burnAvailable;
		}
		if ((Object)(object)m_legend != (Object)null)
		{
			m_legend.SetButtonEnabled(LegendContainer.ButtonEnum.XButton, m_burnAvailable);
		}
		if ((Object)(object)m_totalValueLabel != (Object)null && (Object)(object)incinerator != (Object)null)
		{
			float num = incinerator.FuelBurn * incinerator.OutputRate;
			float real_seconds = m_FuelValue / num;
			int num2 = Mathf.FloorToInt(GameTime.RealSecondsToGameSeconds(real_seconds) / 60f / 60f);
			m_totalValueLabel.text = num2 + " " + Localization.Get("UI.Incinerator.Hours");
		}
	}

	public override void OnExtra1()
	{
		if ((Object)(object)incinerator == (Object)null || (Object)(object)InventoryManager.Instance == (Object)null)
		{
			return;
		}
		UpdateBurn();
		if (!m_burnAvailable)
		{
			return;
		}
		ReadOnlyCollection<ItemGrid.ItemSlot> items = m_inventoryChosen.GetItems();
		for (int i = 0; i < items.Count; i++)
		{
			ItemGrid.ItemSlot itemSlot = items[i];
			ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(itemSlot.m_type);
			if ((Object)(object)itemDefinition != (Object)null)
			{
				InventoryManager.Instance.RemoveItemsOfType(itemSlot.m_type, itemSlot.m_count);
			}
			incinerator.AddItemToBurn(itemSlot.m_type, itemSlot.m_count);
		}
		m_inventoryChosen.ClearItems();
		UpdateBurn();
	}

	public void ShowItemDescriptionPanel()
	{
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(m_selectedType);
		if ((Object)(object)itemDefinition != (Object)null)
		{
			UISprite component = ((Component)itemDefinition).GetComponent<UISprite>();
			if ((Object)(object)component != (Object)null)
			{
				ItemHelpPanel.CreateItemHelpPanel(component, helpName, helpQuantity, helpDescription);
			}
		}
	}

	public void CancelHighlightOnScroll()
	{
		OnItemDeselected(null);
		UpdateSelectionLabels();
	}
}
