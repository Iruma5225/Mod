using System.Collections.Generic;
using UnityEngine;

public class CombatAIAggressive : CombatAIBase
{
	private Dictionary<EncounterCharacter, int> damage_dealers = new Dictionary<EncounterCharacter, int>();

	private List<EncounterCharacter> disarmed_chars = new List<EncounterCharacter>();

	private bool hasShotMulti;

	public CombatAIAggressive(EncounterCharacter character)
		: base(character)
	{
	}

	public override EncounterCombatPanel.CombatActionInfo GetNextAction(List<EncounterCharacter> enemies, List<EncounterCharacter> friends)
	{
		EncounterCombatPanel.CombatActionInfo combatActionInfo = new EncounterCombatPanel.CombatActionInfo();
		if ((float)character.Health / (float)character.maxHealth <= 0.25f && character.hasRangedWeapon && character.hasAmmo && !hasShotMulti)
		{
			combatActionInfo.action = EncounterCombatPanel.CombatActionEnum.ShootMulti;
			return combatActionInfo;
		}
		if ((float)character.Health / (float)character.maxHealth <= 0.5f)
		{
			for (int i = 0; i < enemies.Count; i++)
			{
				if (enemies[i].canStillFight && !enemies[i].hasEscaped && !disarmed_chars.Contains(enemies[i]))
				{
					combatActionInfo.action = EncounterCombatPanel.CombatActionEnum.Disarm;
					combatActionInfo.target = enemies[i];
					return combatActionInfo;
				}
			}
		}
		if ((float)character.Health / (float)character.maxHealth > 0.5f && character.hasAvailableDroppedWeapon)
		{
			combatActionInfo.action = EncounterCombatPanel.CombatActionEnum.PickupWeapon;
			return combatActionInfo;
		}
		combatActionInfo.action = EncounterCombatPanel.CombatActionEnum.Melee;
		KeyValuePair<EncounterCharacter, int> keyValuePair = default(KeyValuePair<EncounterCharacter, int>);
		foreach (KeyValuePair<EncounterCharacter, int> damage_dealer in damage_dealers)
		{
			if (damage_dealer.Key.aiTargetable && damage_dealer.Value > keyValuePair.Value && damage_dealer.Key.canStillFight && !damage_dealer.Key.hasEscaped)
			{
				keyValuePair = damage_dealer;
			}
		}
		combatActionInfo.target = keyValuePair.Key;
		if ((Object)(object)combatActionInfo.target == (Object)null)
		{
			List<EncounterCharacter> list = new List<EncounterCharacter>(enemies);
			list.RemoveAll((EncounterCharacter x) => !x.canStillFight || x.hasEscaped);
			combatActionInfo.target = list[Random.Range(0, list.Count)];
		}
		return combatActionInfo;
	}

	public override void OnTurnEnded()
	{
		base.OnTurnEnded();
		damage_dealers.Clear();
	}

	public override void OnTakeDamage(int dmg, ItemDefinition_Combat.DamageTypeEnum dmgType = ItemDefinition_Combat.DamageTypeEnum.Undefined, ItemManager.ItemType dmgSource = ItemManager.ItemType.Undefined, EncounterCharacter attacker = null)
	{
		base.OnTakeDamage(dmg, dmgType, dmgSource, attacker);
		if ((Object)(object)attacker != (Object)null)
		{
			int value = 0;
			if (!damage_dealers.TryGetValue(attacker, out value))
			{
				damage_dealers.Add(attacker, dmg);
			}
			damage_dealers[attacker] = value + dmg;
		}
	}

	public override void OnActionExecuted(EncounterCombatPanel.CombatActionEnum action, EncounterCharacter target)
	{
		base.OnActionExecuted(action, target);
		if (action == EncounterCombatPanel.CombatActionEnum.ShootMulti && !hasShotMulti)
		{
			hasShotMulti = true;
		}
		if (action == EncounterCombatPanel.CombatActionEnum.Disarm)
		{
			disarmed_chars.Add(target);
		}
	}
}
