using System;
using UnityEngine;

public class SunRise : MonoBehaviour
{
	public float riseSpeed;

	public SpriteRenderer glareSpr;

	private float start_time = 0.25f;

	private float end_time = 7f / 24f;

	private bool rise;

	private Camera mainCam;

	private float m_sunSpeedMultiplier = 1f;

	private void Start()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.localPosition = new Vector3(0f, -4.9f, 0f);
		mainCam = Camera.main;
		m_sunSpeedMultiplier = riseSpeed / GameTime.GameSecondsToRealSeconds(3600f);
	}

	private void Update()
	{
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		if (GameTime.DayProgress >= start_time && GameTime.DayProgress < end_time && !rise && ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading) && ((Object)(object)TutorialManager.Instance == (Object)null || !TutorialManager.Instance.TutorialActive))
		{
			rise = true;
		}
		if (rise)
		{
			((Component)this).transform.Translate(0f, m_sunSpeedMultiplier * Time.deltaTime, 0f);
			float dayProgress = GameTime.DayProgress;
			float num = Mathf.Clamp((dayProgress - start_time) / (end_time - start_time), 0f, 1f);
			num = Mathf.Sin(num * 2f * (float)Math.PI);
			glareSpr.color = new Color(1f, 1f, 1f, num);
			if (((Component)this).transform.localPosition.y >= 2.5f)
			{
				((Component)this).transform.localPosition = new Vector3(((Component)this).transform.localPosition.x, -4.9f, ((Component)this).transform.localPosition.z);
				rise = false;
			}
		}
	}

	private void LateUpdate()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		Vector3 localPosition = ((Component)mainCam).transform.localPosition;
		((Component)this).transform.localPosition = new Vector3(localPosition.x, ((Component)this).transform.localPosition.y, ((Component)this).transform.localPosition.z);
	}
}
