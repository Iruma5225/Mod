using System;
using UnityEngine;

[Serializable]
public class Illness_Malnourishment : Illness_Base
{
	private float m_hungrySinceTime;

	private float m_thirstySinceTime;

	private float m_requiredHungerDuration;

	private float m_requiredThirstDuration;

	private bool m_hungry;

	private bool m_thirsty;

	private int m_healthDamageAmount;

	private float m_healthDamageInterval;

	private float m_healthDamageTime;

	public bool isDangerouslyHungry => m_hungry;

	public bool isDangerouslyThirsty => m_thirsty;

	public bool isStarving => m_hungry && Time.time >= m_hungrySinceTime + m_requiredHungerDuration;

	public bool isDehydrated => m_thirsty && Time.time >= m_thirstySinceTime + m_requiredThirstDuration;

	public override void Initialize(FamilyMember member)
	{
		base.Initialize(member);
		m_requiredHungerDuration = 0f;
		m_requiredThirstDuration = 0f;
		m_healthDamageInterval = 6f;
		m_healthDamageAmount = 1;
		m_healthDamageTime = 0f;
	}

	public override void UpdateIllness()
	{
		if (!base.isActive)
		{
			if (m_hungry && Time.time >= m_hungrySinceTime + m_requiredHungerDuration)
			{
				SetActive(active: true);
			}
			if (m_thirsty && Time.time >= m_thirstySinceTime + m_requiredThirstDuration)
			{
				SetActive(active: true);
			}
		}
		else if (Time.time >= m_healthDamageTime)
		{
			BaseCharacter.DamageType type = BaseCharacter.DamageType.Malnourishment;
			if (isStarving && !isDehydrated)
			{
				type = BaseCharacter.DamageType.Hunger;
			}
			else if (isDehydrated && !isStarving)
			{
				type = BaseCharacter.DamageType.Thirst;
			}
			m_member.Damage(m_healthDamageAmount, type, string.Empty);
			m_healthDamageTime = Time.time + m_healthDamageInterval;
		}
	}

	public void SetIsThirsty(bool thirsty)
	{
		if (thirsty && !m_thirsty)
		{
			m_thirstySinceTime = Time.time;
		}
		else if (!thirsty && m_thirsty)
		{
			if (!m_hungry)
			{
				SetActive(active: false);
			}
			OnCureDehydration();
		}
		m_thirsty = thirsty;
	}

	public void SetIsHungry(bool hungry)
	{
		if (hungry && !m_hungry)
		{
			m_hungrySinceTime = Time.time;
		}
		else if (!hungry && m_hungry)
		{
			if (!m_thirsty)
			{
				SetActive(active: false);
			}
			OnCureMalnourishment();
		}
		m_hungry = hungry;
	}

	public void OnCureDehydration()
	{
		if ((Object)(object)ActivityLog.Instance != (Object)null)
		{
			ActivityLog.Instance.Add(ActivityLog.Activity.CureIllness_Dehydration, ((Component)m_member).transform, new ActivityLog.ExtraInfoString(m_member.firstName, isLocalizationKey: false));
		}
	}

	public void OnCureMalnourishment()
	{
		if ((Object)(object)ActivityLog.Instance != (Object)null)
		{
			ActivityLog.Instance.Add(ActivityLog.Activity.CureIllness_Malnourishment, ((Component)m_member).transform, new ActivityLog.ExtraInfoString(m_member.firstName, isLocalizationKey: false));
		}
	}

	protected override void OnContractIllness()
	{
		m_healthDamageTime = Time.time + m_healthDamageInterval;
		if ((Object)(object)ActivityLog.Instance != (Object)null && isStarving)
		{
			ActivityLog.Instance.Add(ActivityLog.Activity.ContractIllness_Malnourishment, ((Component)m_member).transform, new ActivityLog.ExtraInfoString(m_member.firstName, isLocalizationKey: false));
		}
		if ((Object)(object)ActivityLog.Instance != (Object)null && isDehydrated)
		{
			ActivityLog.Instance.Add(ActivityLog.Activity.ContractIllness_Dehydration, ((Component)m_member).transform, new ActivityLog.ExtraInfoString(m_member.firstName, isLocalizationKey: false));
		}
		if (isStarving)
		{
			UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.Starvation);
		}
		if ((Object)(object)FamilyManager.Instance != (Object)null && isDehydrated)
		{
			UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.Dehydration);
		}
	}

	protected override void OnCureIllness()
	{
	}

	public override void SaveLoadIllness(SaveData data)
	{
		data.GroupStart("Malnourishment");
		base.SaveLoadIllness(data);
		data.SaveLoad("hungry", ref m_hungry);
		data.SaveLoad("thirsty", ref m_thirsty);
		data.SaveLoadAbsoluteTime("hungrySince", ref m_hungrySinceTime);
		data.SaveLoadAbsoluteTime("thirstySince", ref m_thirstySinceTime);
		data.SaveLoadAbsoluteTime("damageTime", ref m_healthDamageTime);
		data.GroupEnd();
	}
}
