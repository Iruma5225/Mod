using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class UISound : MonoBehaviour
{
	public enum PresetSound
	{
		Accept,
		Cancel,
		Navigate,
		TutorialPopupDismiss
	}

	[SerializeField]
	private AudioClip m_acceptSound;

	[SerializeField]
	private AudioClip m_cancelSound;

	[SerializeField]
	private AudioClip m_navigateSound;

	[SerializeField]
	private AudioClip m_tutorialDismissSound;

	[SerializeField]
	private AudioMixerGroup m_pool_mixer;

	private List<AudioSource> m_sources = new List<AudioSource>();

	[SerializeField]
	private int m_maxSounds = 6;

	private static UISound m_instance;

	public static UISound instance => m_instance;

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
			return;
		}
		for (int i = 0; i < m_maxSounds; i++)
		{
			AudioSource val = ((Component)this).gameObject.AddComponent<AudioSource>();
			if ((Object)(object)val != (Object)null)
			{
				val.playOnAwake = false;
				val.ignoreListenerPause = true;
				val.outputAudioMixerGroup = m_pool_mixer;
				m_sources.Add(val);
			}
		}
	}

	private AudioSource FindFreeSource()
	{
		for (int i = 0; i < m_sources.Count; i++)
		{
			if (!m_sources[i].isPlaying)
			{
				return m_sources[i];
			}
		}
		return null;
	}

	private AudioSource FindSourcePlayingClip(AudioClip clip)
	{
		for (int i = 0; i < m_sources.Count; i++)
		{
			if (m_sources[i].isPlaying && (Object)(object)m_sources[i].clip == (Object)(object)clip)
			{
				return m_sources[i];
			}
		}
		return null;
	}

	public bool Play(AudioClip clip)
	{
		AudioSource val = FindSourcePlayingClip(clip);
		if ((Object)(object)val != (Object)null && val.time < 0.05f)
		{
			return false;
		}
		val = FindFreeSource();
		if ((Object)(object)val != (Object)null)
		{
			val.clip = clip;
			val.Play();
			return true;
		}
		return false;
	}

	public bool PlayPreset(PresetSound sound)
	{
		AudioClip val = null;
		switch (sound)
		{
		case PresetSound.Accept:
			val = m_acceptSound;
			break;
		case PresetSound.Cancel:
			val = m_cancelSound;
			break;
		case PresetSound.Navigate:
			val = m_navigateSound;
			break;
		case PresetSound.TutorialPopupDismiss:
			val = m_tutorialDismissSound;
			break;
		}
		if ((Object)(object)val != (Object)null)
		{
			return Play(val);
		}
		return false;
	}
}
