using System.Collections.Generic;
using UnityEngine;

public class Obj_CamperVan : Obj_Base
{
	public enum CarState
	{
		Unrepaired,
		Stationary,
		Started,
		Moving,
		Stopped
	}

	private CarState m_State = CarState.Stationary;

	[SerializeField]
	[Header("Vehicle Parts")]
	private List<ItemStack> partsNeededInspector = new List<ItemStack>();

	private Dictionary<ItemManager.ItemType, int> PartsNeeded = new Dictionary<ItemManager.ItemType, int>();

	private Dictionary<ItemManager.ItemType, int> Parts = new Dictionary<ItemManager.ItemType, int>();

	[Header("Vehicle Sprite")]
	[SerializeField]
	private Animator m_VehicleAnimator;

	private string current_anim = string.Empty;

	private float m_WaitTimer;

	[Header("Shelter Values")]
	[SerializeField]
	private float move_speed = 2.4f;

	private Vector3 home_position = Vector3.zero;

	private Vector3 start_move_position = Vector3.zero;

	private Vector3 target_move_position = Vector3.zero;

	private float move_start_time;

	private float move_finished_time;

	private float move_percentage;

	[SerializeField]
	private float m_StartupDuration = 4f;

	[SerializeField]
	private Transform m_BoardingPoint;

	private Transform m_ExpeditionPoint;

	private Transform m_ReturnFromPoint;

	[SerializeField]
	[Header("Quest Values")]
	private string m_DrivableMilestone = string.Empty;

	[SerializeField]
	private string m_MissingMilestone = string.Empty;

	[SerializeField]
	[Header("Expedition Values")]
	private float m_TravelSpeed = 9f;

	[SerializeField]
	private float m_PetrolPerPersonPerMile = 0.25f;

	[SerializeField]
	private int m_InventorySlots = 32;

	private bool m_onExpedition;

	[SerializeField]
	[Header("Expedition UI")]
	private string m_UINameKey = string.Empty;

	[SerializeField]
	private string m_UISpriteName = string.Empty;

	private bool m_lostSaveCheck;

	public bool isMoving => m_State == CarState.Moving;

	public bool isStationary => m_State == CarState.Stationary || m_State == CarState.Unrepaired;

	public int maxInventorySlots => m_InventorySlots;

	public float TravelSpeed => m_TravelSpeed;

	public float PetrolPerPersonPerMile => m_PetrolPerPersonPerMile;

	public bool isAvailableForExpedition => !m_onExpedition && isStationary;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.CamperVan;
	}

	public string GetUIName()
	{
		return Localization.Get(m_UINameKey);
	}

	public string GetUISpriteName()
	{
		return m_UISpriteName;
	}

	public override void Awake()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		base.Awake();
		SetupPartsNeeded();
		SetupParts();
		home_position = ((Component)this).transform.position;
		m_VehicleAnimator = ((Component)this).GetComponentInChildren<Animator>();
		SetState(CarState.Unrepaired);
		if (IsDrivable())
		{
			SetState(CarState.Stationary);
		}
	}

	public override void Start()
	{
		base.Start();
		if ((Object)(object)ExplorationManager.Instance != (Object)null)
		{
			m_ExpeditionPoint = ExplorationManager.Instance.vehicleExpeditionNode.transform;
			m_ReturnFromPoint = ExplorationManager.Instance.vehicleReturnNode.transform;
		}
	}

	public override void Update()
	{
		UpdateState();
		if (m_lostSaveCheck || (!((Object)(object)SaveManager.instance == (Object)null) && SaveManager.instance.isLoading))
		{
			return;
		}
		m_lostSaveCheck = true;
		if (!m_onExpedition)
		{
			return;
		}
		bool flag = false;
		List<ExplorationParty> allExplorarionParties = ExplorationManager.Instance.GetAllExplorarionParties();
		for (int i = 0; i < allExplorarionParties.Count; i++)
		{
			if ((Object)(object)allExplorarionParties[i].GetVehicle() == (Object)(object)this)
			{
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			OnExpeditionLost();
		}
	}

	private void TriggerAnim(string animTrigger, bool reset = true)
	{
		if ((Object)(object)m_VehicleAnimator != (Object)null)
		{
			if (!string.IsNullOrEmpty(current_anim) && reset)
			{
				m_VehicleAnimator.ResetTrigger(current_anim);
			}
			m_VehicleAnimator.SetTrigger(animTrigger);
			current_anim = animTrigger;
		}
	}

	private void SetupPartsNeeded()
	{
		int value = 0;
		for (int i = 0; i < partsNeededInspector.Count; i++)
		{
			if (PartsNeeded.TryGetValue(partsNeededInspector[i].m_type, out value))
			{
				PartsNeeded[partsNeededInspector[i].m_type] = value + partsNeededInspector[i].m_count;
			}
			else
			{
				PartsNeeded.Add(partsNeededInspector[i].m_type, partsNeededInspector[i].m_count);
			}
		}
	}

	private void SetupParts()
	{
		foreach (KeyValuePair<ItemManager.ItemType, int> item in PartsNeeded)
		{
			Parts.Add(item.Key, 0);
		}
	}

	public List<ItemManager.ItemType> GetListOfRequiredParts()
	{
		return new List<ItemManager.ItemType>(PartsNeeded.Keys);
	}

	public int GetRequiredNumberOfParts(ItemManager.ItemType part)
	{
		if (PartsNeeded.TryGetValue(part, out var value))
		{
			return value;
		}
		return 0;
	}

	public int GetRemainingRequiredPart(ItemManager.ItemType part)
	{
		if (Parts.TryGetValue(part, out var value) && PartsNeeded.TryGetValue(part, out var value2))
		{
			return Mathf.Max(value2 - value, 0);
		}
		return 0;
	}

	public bool NeedMoreOfPart(ItemManager.ItemType part)
	{
		return GetRemainingRequiredPart(part) > 0;
	}

	public bool HasSomeOfPart(ItemManager.ItemType part)
	{
		return GetRequiredNumberOfParts(part) > GetRemainingRequiredPart(part);
	}

	public bool IsDrivable()
	{
		foreach (KeyValuePair<ItemManager.ItemType, int> item in PartsNeeded)
		{
			if (NeedMoreOfPart(item.Key))
			{
				return false;
			}
		}
		return true;
	}

	private float GetPercentageComplete()
	{
		int num = 0;
		int num2 = 0;
		foreach (KeyValuePair<ItemManager.ItemType, int> item in PartsNeeded)
		{
			num += item.Value;
			num2 += Parts[item.Key];
		}
		return Mathf.Clamp01((float)num2 / (float)num);
	}

	public bool PlayerHasParts()
	{
		if ((Object)(object)InventoryManager.Instance == (Object)null)
		{
			return false;
		}
		foreach (KeyValuePair<ItemManager.ItemType, int> item in PartsNeeded)
		{
			if (NeedMoreOfPart(item.Key) && InventoryManager.Instance.GetNumItemsOfType(item.Key) > 0)
			{
				return true;
			}
		}
		return false;
	}

	public bool AddPart(ItemManager.ItemType part, int quantity = 1)
	{
		if (!NeedMoreOfPart(part))
		{
			return false;
		}
		Parts[part] += quantity;
		if (IsDrivable())
		{
			if ((Object)(object)QuestManager.instance != (Object)null)
			{
				QuestManager.instance.SetGlobalMilestone(m_DrivableMilestone);
			}
			SetState(CarState.Stationary);
		}
		return true;
	}

	public bool RemovePart(ItemManager.ItemType part, int quantity = 1)
	{
		if (!HasSomeOfPart(part))
		{
			return false;
		}
		bool flag = IsDrivable();
		Parts[part] -= quantity;
		if (!IsDrivable() && flag)
		{
			if ((Object)(object)QuestManager.instance != (Object)null)
			{
				QuestManager.instance.ClearGlobalMilestone(m_DrivableMilestone);
			}
			SetState(CarState.Unrepaired);
		}
		return true;
	}

	public Vector3 GetBoardingPosition()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)m_BoardingPoint != (Object)null)
		{
			return m_BoardingPoint.position;
		}
		return Vector3.zero;
	}

	private void SetState(CarState new_state)
	{
		if (m_State == CarState.Unrepaired && new_state != m_State)
		{
			ExitState_Unrepaired();
		}
		m_State = new_state;
		switch (m_State)
		{
		case CarState.Unrepaired:
			EnterState_Unrepaired();
			break;
		case CarState.Stationary:
			EnterState_Stationary();
			break;
		case CarState.Started:
			EnterState_Started();
			break;
		case CarState.Moving:
			EnterState_Moving();
			break;
		case CarState.Stopped:
			EnterState_Stopped();
			break;
		}
	}

	private void UpdateState()
	{
		switch (m_State)
		{
		case CarState.Unrepaired:
			break;
		case CarState.Stationary:
			break;
		case CarState.Started:
			UpdateState_Started();
			break;
		case CarState.Moving:
			UpdateState_Moving();
			break;
		case CarState.Stopped:
			UpdateState_Stopped();
			break;
		}
	}

	private void EnterState_Unrepaired()
	{
		TriggerAnim("Break", reset: false);
	}

	private void ExitState_Unrepaired()
	{
		TriggerAnim("Repair");
	}

	private void EnterState_Stationary()
	{
		base.selectable = true;
	}

	private void EnterState_Started()
	{
		m_WaitTimer = Time.time + m_StartupDuration;
		TriggerAnim("Start");
		base.selectable = false;
	}

	private void UpdateState_Started()
	{
		if (!(Time.time < m_WaitTimer))
		{
			SetState(CarState.Moving);
		}
	}

	private void EnterState_Moving()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		move_start_time = Time.time;
		move_finished_time = Time.time + Vector3.Distance(target_move_position, start_move_position) / move_speed;
		TriggerAnim("Move", reset: false);
		SpriteRenderer[] componentsInChildren = ((Component)this).GetComponentsInChildren<SpriteRenderer>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			((Renderer)componentsInChildren[i]).sortingLayerName = "Foreground";
		}
	}

	private void UpdateState_Moving()
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		move_percentage = Mathf.Clamp01((Time.time - move_start_time) / (move_finished_time - move_start_time));
		if (move_percentage >= 1f)
		{
			TriggerAnim("EndMove");
			((Component)this).transform.position = target_move_position;
			SetState(CarState.Stopped);
		}
		else
		{
			((Component)this).transform.position = Vector3.Lerp(start_move_position, target_move_position, move_percentage);
		}
	}

	private void EnterState_Stopped()
	{
		m_WaitTimer = Time.time + m_StartupDuration;
	}

	private void UpdateState_Stopped()
	{
		if (!(Time.time < m_WaitTimer))
		{
			TriggerAnim("Stop");
			SpriteRenderer[] componentsInChildren = ((Component)this).GetComponentsInChildren<SpriteRenderer>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				((Renderer)componentsInChildren[i]).sortingLayerName = "Background";
			}
			SetState(CarState.Stationary);
			if (!IsDrivable())
			{
				SetState(CarState.Unrepaired);
			}
		}
	}

	public void SetOnExpedition(bool truth)
	{
		m_onExpedition = truth;
	}

	public void GoOnExpedition()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		start_move_position = ((Component)this).transform.position;
		target_move_position = m_ExpeditionPoint.position;
		SetState(CarState.Started);
	}

	public void ReturnFromExpedition()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.position = m_ReturnFromPoint.position;
		start_move_position = ((Component)this).transform.position;
		target_move_position = home_position;
		SetState(CarState.Started);
		SetState(CarState.Moving);
	}

	public void OnExpeditionLost()
	{
		if ((Object)(object)QuestManager.instance != (Object)null)
		{
			QuestManager.instance.SetGlobalMilestone(m_MissingMilestone);
		}
	}

	public void OnLostVehicleFound()
	{
		if ((Object)(object)QuestManager.instance != (Object)null)
		{
			QuestManager.instance.ClearGlobalMilestone(m_MissingMilestone);
		}
	}

	public override bool IsRelocationEnabled()
	{
		return true;
	}

	public override bool IsReadyForLoad()
	{
		if ((Object)(object)SaveManager.instance != (Object)null && (Object)(object)ExplorationManager.Instance != (Object)null && SaveManager.instance.HasBeenLoaded(ExplorationManager.Instance))
		{
			return base.IsReadyForLoad();
		}
		return false;
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		List<ItemStack> saveParts = new List<ItemStack>();
		foreach (KeyValuePair<ItemManager.ItemType, int> part in Parts)
		{
			saveParts.Add(new ItemStack(part.Key, part.Value));
		}
		data.SaveLoadList("parts", saveParts, delegate(int i)
		{
			int value2 = (int)saveParts[i].m_type;
			data.SaveLoad("type", ref value2);
			data.SaveLoad("count", ref saveParts[i].m_count);
		}, delegate
		{
			ItemStack itemStack = new ItemStack();
			int value2 = -1;
			data.SaveLoad("type", ref value2);
			data.SaveLoad("count", ref itemStack.m_count);
			itemStack.m_type = (ItemManager.ItemType)value2;
			if (itemStack.m_type != ItemManager.ItemType.Undefined && itemStack.m_count > 0)
			{
				Parts[itemStack.m_type] = itemStack.m_count;
			}
		});
		data.SaveLoad("homePos", ref home_position);
		bool flag = data.isLoading && data.isRelocating;
		if (!flag)
		{
			data.SaveLoad("onExpedition", ref m_onExpedition);
			data.SaveLoad("startMovePos", ref start_move_position);
			data.SaveLoad("targetMovePos", ref target_move_position);
			data.SaveLoad("movePct", ref move_percentage);
			data.SaveLoadAbsoluteTime("moveStartTime", ref move_start_time);
			data.SaveLoadAbsoluteTime("moveFinishedTime", ref move_finished_time);
		}
		int value = (int)m_State;
		data.SaveLoad("state", ref value);
		if (data.isLoading)
		{
			SetState((CarState)value);
		}
		if (flag)
		{
			SetState(IsDrivable() ? CarState.Stationary : CarState.Unrepaired);
		}
	}
}
