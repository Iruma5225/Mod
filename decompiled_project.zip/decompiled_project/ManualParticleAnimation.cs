using System.Collections.Generic;
using UnityEngine;

public class ManualParticleAnimation : MonoBehaviour
{
	private List<ParticleSystem> particles = new List<ParticleSystem>();

	private void Awake()
	{
		particles.AddRange(((Component)this).GetComponents<ParticleSystem>());
	}

	private void Update()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < particles.Count; i++)
		{
			if (((Component)particles[i]).gameObject.activeInHierarchy)
			{
				EmissionModule emission = particles[i].emission;
				if (((EmissionModule)(ref emission)).enabled && particles[i].particleCount >= 0)
				{
					particles[i].Simulate(RealTime.deltaTime, false, false);
				}
			}
		}
	}
}
