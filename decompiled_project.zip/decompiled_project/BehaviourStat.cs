using System;
using UnityEngine;

[Serializable]
public class BehaviourStat
{
	public enum BehaviourStatType
	{
		Fatigue,
		Dirtiness,
		Hunger,
		Thirst,
		Toilet,
		Stress,
		Max
	}

	private const float HighStatValue = 0.7f;

	private const float LowStatValue = 0.7f;

	private const float StressTutorialThreshold = 0.1f;

	private BehaviourStatType type = BehaviourStatType.Max;

	[SerializeField]
	private float value = 50f;

	[SerializeField]
	private float max_value = 100f;

	[SerializeField]
	private float increase_interval = 10f;

	public float increaseIntervalMultiplier = 1f;

	[SerializeField]
	private float increase_amount = 1f;

	[SerializeField]
	private float stat_increase_threshold = 75f;

	[SerializeField]
	private float stat_decrease_threshold = 25f;

	[SerializeField]
	private float stat_change_min = 1f;

	[SerializeField]
	private float stat_change_max = 10f;

	[SerializeField]
	private float stat_change_interval = 60f;

	private float next_increase_time;

	private float next_stat_change_time;

	private bool m_paused;

	public float Value => value;

	public float MaxValue => max_value;

	[SerializeField]
	public float NormalizedValue => (!(max_value > Mathf.Epsilon)) ? 0f : (value / max_value);

	public float stressIncreaseThreshold => stat_increase_threshold;

	public bool isPaused => m_paused;

	public BehaviourStat(BehaviourStatType stat_type)
	{
		type = stat_type;
	}

	public void Initialise()
	{
		next_increase_time = Time.time + increase_interval * increaseIntervalMultiplier;
		if (value > stat_increase_threshold || value < stat_decrease_threshold)
		{
			next_stat_change_time = Time.time + stat_change_interval;
		}
	}

	public void Update(out float stat_change)
	{
		stat_change = 0f;
		float time = Time.time;
		if (time >= next_stat_change_time)
		{
			next_stat_change_time = time + stat_change_interval;
			if (value >= stat_increase_threshold)
			{
				stat_change = stat_change_min + (value - stat_increase_threshold) / (max_value - stat_increase_threshold) * (stat_change_max - stat_change_min);
			}
			if (value < stat_decrease_threshold)
			{
				stat_change = 0f - (stat_change_min + (stat_decrease_threshold - value) / stat_decrease_threshold * (stat_change_max - stat_change_min));
			}
		}
		if (!(increase_interval * increaseIntervalMultiplier > 0f))
		{
			return;
		}
		if (m_paused)
		{
			next_increase_time = time + increase_interval * increaseIntervalMultiplier;
		}
		else if (time > next_increase_time)
		{
			next_increase_time = time + increase_interval * increaseIntervalMultiplier;
			float num = Mathf.Clamp(value + increase_amount, 0f, max_value);
			if (num > value)
			{
				OnStatIncreased(num);
			}
			value = num;
		}
	}

	private void OnStatIncreased(float new_value)
	{
		if (type == BehaviourStatType.Stress)
		{
			if (new_value / max_value >= 0.1f)
			{
				UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.Stress);
			}
		}
		else if (new_value / max_value >= 0.7f)
		{
			TutorialManager.PopupType popupType = TutorialManager.PopupType.LostHealth;
			switch (type)
			{
			case BehaviourStatType.Fatigue:
				popupType = TutorialManager.PopupType.Tired;
				break;
			case BehaviourStatType.Dirtiness:
				popupType = TutorialManager.PopupType.Shower;
				break;
			case BehaviourStatType.Hunger:
				popupType = TutorialManager.PopupType.Hunger;
				break;
			case BehaviourStatType.Thirst:
				popupType = TutorialManager.PopupType.Thirsty;
				break;
			case BehaviourStatType.Toilet:
				popupType = TutorialManager.PopupType.Toilet;
				break;
			case BehaviourStatType.Stress:
				popupType = TutorialManager.PopupType.Stress;
				break;
			}
			UI_TutorialPanels.ShowTutorialPopup(popupType);
		}
	}

	public float Modify(float change)
	{
		float num = Mathf.Clamp(value + change, 0f, max_value);
		if (num > value)
		{
			OnStatIncreased(num);
		}
		value = num;
		return value;
	}

	public void Set(float new_value)
	{
		value = Mathf.Clamp(new_value, 0f, max_value);
	}

	public void Pause()
	{
		m_paused = true;
	}

	public void Unpause()
	{
		m_paused = false;
	}

	public void SaveLoadBehaviourStat(SaveData data, string groupName)
	{
		data.GroupStart(groupName);
		data.SaveLoad("value", ref value);
		data.SaveLoad("paused", ref m_paused);
		data.SaveLoad("incMultiplier", ref increaseIntervalMultiplier);
		data.SaveLoadAbsoluteTime("nextIncreaseTime", ref next_increase_time);
		data.SaveLoadAbsoluteTime("nextChangeTime", ref next_stat_change_time);
		data.GroupEnd();
	}
}
