using UnityEngine;

public class Int_EndSuffering : Int_Base
{
	private Obj_CatatonicGhost obj_catatonic;

	[SerializeField]
	private int extraTrauma = 25;

	public int ExtraTrauma => extraTrauma;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_EndSuffering";
	}

	public override string GetInteractionType()
	{
		return "end_suffering";
	}

	public override int GetInteractionPriority()
	{
		return 5;
	}

	public override void Awake()
	{
		base.Awake();
		if (obj.GetObjectType() == ObjectManager.ObjectType.CatatonicGhost)
		{
			obj_catatonic = obj as Obj_CatatonicGhost;
		}
	}

	public override bool IsPlayerSelectable()
	{
		if (base.InteractionEnabled && (Object)(object)obj_catatonic != (Object)null && (Object)(object)obj_catatonic.GetFamilyMember() != (Object)null && obj_catatonic.GetFamilyMember().isCatatonicPermanent)
		{
			return true;
		}
		return false;
	}

	public override bool IsAvailable()
	{
		if ((Object)(object)obj_catatonic == (Object)null)
		{
			return false;
		}
		if ((Object)(object)obj_catatonic.GetFamilyMember() == (Object)null)
		{
			return false;
		}
		if (!obj_catatonic.GetFamilyMember().isCatatonic)
		{
			return false;
		}
		return true;
	}
}
