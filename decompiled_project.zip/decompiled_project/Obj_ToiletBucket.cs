using UnityEngine;

public class Obj_ToiletBucket : Obj_Toilet
{
	private bool m_Used;

	private Int_Toilet toilet_interaction;

	public bool Used => m_Used;

	public override void Awake()
	{
		base.Awake();
		toilet_interaction = ((Component)this).GetComponent<Int_Toilet>();
	}

	protected override bool IsInteractionAllowed(FamilyMember member, string type)
	{
		if (!base.IsInteractionAllowed(member, type))
		{
			return false;
		}
		if (type == "toilet" && m_Used)
		{
			return false;
		}
		return true;
	}

	public override void OnFlush()
	{
		m_Used = true;
		if ((Object)(object)toilet_interaction != (Object)null)
		{
			toilet_interaction.InteractionEnabled = false;
		}
	}

	public void WashOut()
	{
		m_Used = false;
		if ((Object)(object)toilet_interaction != (Object)null)
		{
			toilet_interaction.InteractionEnabled = true;
		}
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		data.SaveLoad("used", ref m_Used);
		if (data.isLoading && m_Used)
		{
			OnFlush();
		}
	}
}
