using System;
using UnityEngine;

public class SunGlareRotation : MonoBehaviour
{
	public Transform SunMoonCentre;

	public float GlareStart;

	public float GlareMid;

	public float GlareEnd;

	private SpriteRenderer glareSpr;

	private void Start()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		glareSpr = ((Component)this).GetComponent<SpriteRenderer>();
		glareSpr.color = new Color(1f, 1f, 1f, 0f);
	}

	private void Update()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.rotation = Quaternion.identity;
		float z = SunMoonCentre.rotation.z;
		z = 57.29578f * z * 2f;
		float num = 0.27916667f;
		float num2 = 0.3125f;
		float dayProgress = GameTime.DayProgress;
		float num3 = Mathf.Clamp((dayProgress - num) / (num2 - num), 0f, 1f);
		num3 = Mathf.Sin(num3 * 2f * (float)Math.PI);
		glareSpr.color = new Color(1f, 1f, 1f, num3);
	}
}
