public enum GraphUpdateThreading
{
	UnityThread,
	SeparateThread,
	SeparateAndUnityInit
}
