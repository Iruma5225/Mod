public enum LeaderboardFilter
{
	Overall,
	MyScore,
	Friends
}
