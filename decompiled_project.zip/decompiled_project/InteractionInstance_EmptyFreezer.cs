using UnityEngine;

public class InteractionInstance_EmptyFreezer : InteractionInstance_Base
{
	private Int_EmptyFreezer interaction;

	private Obj_Freezer freezer_object;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_EmptyFreezer;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		freezer_object = ((Component)this).GetComponent<Obj_Freezer>();
		if ((Object)(object)freezer_object == (Object)null)
		{
			return false;
		}
		if (!freezer_object.IsMeatContaminated())
		{
			return false;
		}
		if ((Object)(object)member != (Object)null)
		{
			member.TriggerAnim("Rummage");
		}
		return true;
	}

	protected override bool UpdateInteractionTimer()
	{
		if (base.UpdateInteractionTimer())
		{
			return true;
		}
		return false;
	}

	protected override bool OnInteractionComplete()
	{
		if ((Object)(object)freezer_object != (Object)null)
		{
			freezer_object.EmptyFridge();
		}
		return true;
	}
}
