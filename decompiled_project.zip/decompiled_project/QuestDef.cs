using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

[Serializable]
public class QuestDef : QuestDefBase
{
	public enum QuestType
	{
		Quest,
		Subquest,
		Floating
	}

	[Serializable]
	public class QuestSpawnOptions
	{
		public enum SpawnLocationOptions
		{
			AnyLocation,
			SpecificLocations
		}

		[SerializeField]
		private int m_minDistance = 5;

		[SerializeField]
		private int m_maxDistance = 10;

		[SerializeField]
		private SpawnLocationOptions m_locationOptions;

		[SerializeField]
		private List<MapRegion.Topography> m_specificLocations = new List<MapRegion.Topography>();

		public int minDistance => m_minDistance;

		public int maxDistance => m_maxDistance;

		public SpawnLocationOptions locationOptions => m_locationOptions;

		public ReadOnlyCollection<MapRegion.Topography> specificLocations => m_specificLocations.AsReadOnly();
	}

	[Serializable]
	public class QuestEncounterOptions
	{
		public enum BackgroundLocationOptions
		{
			Default,
			SpecificLocations
		}

		[Serializable]
		public class BackgroundLocation
		{
			public MapRegion.Topography location;

			public Sprite background;
		}

		[SerializeField]
		private string m_radioOverrideKey = string.Empty;

		[SerializeField]
		private BackgroundLocationOptions m_locationOptions;

		[SerializeField]
		private List<BackgroundLocation> m_locationBackgrounds = new List<BackgroundLocation>();

		[SerializeField]
		private List<BackgroundLocation> m_locationBackgroundsLayer2 = new List<BackgroundLocation>();

		[SerializeField]
		private bool m_animateBackground;

		public string radioOverrideKey => m_radioOverrideKey;

		public BackgroundLocationOptions backgroundOptions => m_locationOptions;

		public ReadOnlyCollection<BackgroundLocation> backgrounds => m_locationBackgrounds.AsReadOnly();

		public ReadOnlyCollection<BackgroundLocation> backgroundsLayer2 => m_locationBackgroundsLayer2.AsReadOnly();

		public bool animate => m_animateBackground;
	}

	[SerializeField]
	private QuestType m_questType;

	[SerializeField]
	private bool m_invisible;

	[SerializeField]
	private QuestSpawnOptions m_spawnOptions = new QuestSpawnOptions();

	[SerializeField]
	private QuestEncounterOptions m_encounterOptions = new QuestEncounterOptions();

	[SerializeField]
	private List<ItemStack> m_itemsToSpawn = new List<ItemStack>();

	[SerializeField]
	private List<string> m_characterIds = new List<string>();

	[SerializeField]
	private List<QuestEncounterStage> m_encounterStages = new List<QuestEncounterStage>();

	public QuestType questType => m_questType;

	public bool invisible => m_invisible;

	public QuestSpawnOptions spawnOptions => m_spawnOptions;

	public QuestEncounterOptions encounterOptions => m_encounterOptions;

	public ReadOnlyCollection<ItemStack> itemsToSpawn => m_itemsToSpawn.AsReadOnly();

	public ReadOnlyCollection<string> characterIds => m_characterIds.AsReadOnly();

	public ReadOnlyCollection<QuestEncounterStage> encounterStages => m_encounterStages.AsReadOnly();

	public override bool IsQuest()
	{
		return true;
	}

	public override bool IsScenario()
	{
		return false;
	}

	public bool IsSubquest()
	{
		return m_questType == QuestType.Subquest;
	}

	public bool IsFloating()
	{
		return m_questType == QuestType.Floating;
	}
}
