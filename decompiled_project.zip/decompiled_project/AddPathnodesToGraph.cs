using UnityEngine;

public class AddPathnodesToGraph : MonoBehaviour
{
	public GameObject pathnodes;

	public void Start()
	{
		GameObject pathnodeRoot = PathnodeRoot.Instance.GetPathnodeRoot();
		if ((Object)(object)pathnodes != (Object)null && (Object)(object)pathnodeRoot != (Object)null)
		{
			PathNode[] componentsInChildren = pathnodes.GetComponentsInChildren<PathNode>();
			PathNode[] array = componentsInChildren;
			foreach (PathNode pathNode in array)
			{
				((Component)pathNode).transform.parent = pathnodeRoot.transform;
			}
		}
		AstarPath.active.Scan();
	}
}
