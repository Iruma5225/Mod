using System;
using UnityEngine;

[Serializable]
public class Illness_Infection : Illness_Base
{
	private const float health_threshold = 0.5f;

	private bool infected = true;

	private float infection_check_time;

	private float infection_check_duration = 5f;

	private float infection_roll_time;

	private float infection_roll_duration = GameTime.RealSecondsPerDay;

	private float immunity_duration = GameTime.RealSecondsPerDay * 4f;

	private float immunity_expire_time;

	private float infection_expiry_time;

	private float infection_duration = GameTime.RealSecondsPerDay * 7f;

	private bool isBelowThreshold;

	public bool isInfected => infected;

	public bool isImmune => Time.time < immunity_expire_time;

	public override void Initialize(FamilyMember member)
	{
		base.Initialize(member);
		infection_check_time = Time.time + infection_check_duration;
		infection_roll_time = 0f;
	}

	public override void UpdateIllness()
	{
		if (isImmune)
		{
			return;
		}
		if (Time.time >= infection_check_time)
		{
			if (!isBelowThreshold)
			{
				if ((float)(m_member.health / m_member.maxHealth) <= 0.5f)
				{
					isBelowThreshold = true;
					infection_roll_time = Time.time;
				}
			}
			else if ((float)(m_member.health / m_member.maxHealth) > 0.5f)
			{
				isBelowThreshold = false;
			}
			infection_check_time = Time.time + infection_check_duration;
		}
		if (Time.time >= infection_roll_time && isBelowThreshold && !base.isActive)
		{
			if (!base.isActive && isBelowThreshold && DoInfectionCheck())
			{
				SetActive(active: true);
				infection_expiry_time = Time.time + infection_duration;
			}
			infection_roll_time = Time.time + infection_roll_duration;
		}
		if (base.isActive && Time.time >= infection_expiry_time)
		{
			SetActive(active: false);
			infection_roll_time = Time.time + infection_roll_duration;
		}
	}

	public bool DoInfectionCheck()
	{
		if (base.isActive)
		{
			return false;
		}
		if (!isBelowThreshold)
		{
			return false;
		}
		if (m_member.illness.radiation.isActive || m_member.illness.malnourishment.isActive)
		{
			return false;
		}
		float num = 1f - (float)m_member.health / (float)m_member.maxHealth / 0.5f;
		if (Random.value <= num)
		{
			return true;
		}
		return false;
	}

	public void OnAntibioticsTaken()
	{
		immunity_expire_time = Time.time + immunity_duration;
		SetActive(active: false);
	}

	protected override void OnContractIllness()
	{
		m_member.SetWalkSpeedMultiplier(0.5f);
		if ((Object)(object)ActivityLog.Instance != (Object)null)
		{
			ActivityLog.Instance.Add(ActivityLog.Activity.ContractIllness_Infection, ((Component)m_member).transform, new ActivityLog.ExtraInfoString(m_member.firstName, isLocalizationKey: false));
		}
		UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.Infection);
	}

	protected override void OnCureIllness()
	{
		infection_check_time = Time.time + infection_check_duration;
		m_member.SetWalkSpeedMultiplier(1f);
		if ((Object)(object)ActivityLog.Instance != (Object)null)
		{
			ActivityLog.Instance.Add(ActivityLog.Activity.CureIllness_Infection, ((Component)m_member).transform, new ActivityLog.ExtraInfoString(m_member.firstName, isLocalizationKey: false));
		}
	}

	public override void SaveLoadIllness(SaveData data)
	{
		data.GroupStart("Infection");
		base.SaveLoadIllness(data);
		data.SaveLoad("belowThreshold", ref isBelowThreshold);
		data.SaveLoadAbsoluteTime("checkTime", ref infection_check_time);
		data.SaveLoadAbsoluteTime("rollTime", ref infection_roll_time);
		data.SaveLoadAbsoluteTime("immuneUntil", ref immunity_expire_time);
		data.GroupEnd();
	}
}
