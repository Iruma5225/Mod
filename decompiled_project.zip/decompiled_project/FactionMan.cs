using System;
using System.Collections.Generic;
using UnityEngine;

public class FactionMan : BaseManager, ISaveable
{
	[Serializable]
	private class FactionArea
	{
		public Vector2 m_mapPosition = Vector2.zero;

		public float m_radius = 1f;

		public int m_children;

		public FactionArea m_parent;

		public GameObject m_object;

		public FactionArea(Vector2 mapPos, float rad, GameObject prefab, Material material)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0056: Unknown result type (might be due to invalid IL or missing references)
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
			m_mapPosition = mapPos;
			m_radius = rad;
			m_children = 0;
			m_parent = null;
			if (!((Object)(object)prefab != (Object)null) || !((Object)(object)ExplorationManager.Instance != (Object)null))
			{
				return;
			}
			m_object = Object.Instantiate<GameObject>(prefab, Vector3.zero, Quaternion.identity);
			if (!((Object)(object)m_object != (Object)null))
			{
				return;
			}
			m_object.transform.parent = ((Component)ExplorationManager.Instance.mapSourceSprite).gameObject.transform;
			m_object.transform.localScale = Vector3.one;
			m_object.transform.localPosition = Vector2.op_Implicit(m_mapPosition);
			UI2DSprite component = m_object.GetComponent<UI2DSprite>();
			if ((Object)(object)component != (Object)null)
			{
				float num = ExplorationManager.Instance.WorldToMapPixelsX(ExplorationManager.Instance.worldWidth / ExpeditionMap.Instance.width);
				component.width = Mathf.CeilToInt(m_radius * num * 2f);
				component.height = Mathf.CeilToInt(m_radius * num * 2f);
				if ((Object)(object)material != (Object)null)
				{
					component.material = material;
				}
			}
		}

		public void SetVisible(bool visible)
		{
			if ((Object)(object)m_object != (Object)null)
			{
				UI2DSprite component = m_object.GetComponent<UI2DSprite>();
				if ((Object)(object)component != (Object)null)
				{
					((Behaviour)component).enabled = visible;
				}
			}
		}
	}

	[Serializable]
	private class FactionZone
	{
		public int m_zoneId = -1;

		public int m_factionId = -1;

		public int m_materialIndex = -1;

		public Color m_color = Color.white;

		public bool m_revealed;

		public List<FactionArea> m_areas = new List<FactionArea>();

		public void SetVisible(bool visible)
		{
			for (int i = 0; i < m_areas.Count; i++)
			{
				m_areas[i].SetVisible(visible);
			}
		}
	}

	[Serializable]
	private class FactionInstance
	{
		public int m_factionId = -1;

		public int m_factionDefIndex = -1;

		public int m_materialIndex = -1;

		public int m_colorIndex = -1;

		public List<int> m_zoneIds = new List<int>();

		public float m_nextGrowTime;
	}

	[Serializable]
	private class FactionDifficultySetup
	{
		public int m_spawnDay;

		public int m_numZones = 1;

		public int m_maxAreasPerZone = 10;

		public float m_growthIntervalDays = 5f;

		public int m_minNpcs = 1;

		public int m_maxNpcs = 4;

		public int m_averageStatLevel = 10;

		public List<ItemManager.ItemType> m_possibleWeapons = new List<ItemManager.ItemType>();

		public int m_minCommonItems = 3;

		public int m_maxCommonItems = 6;
	}

	[Serializable]
	private class FactionDef
	{
		[SerializeField]
		private string m_name = string.Empty;

		public string m_nameKey = string.Empty;

		public string m_meshId = "man";

		public string m_dialogueId = string.Empty;

		public List<string> m_headTextureIds = new List<string>();

		public List<string> m_torsoTextureIds = new List<string>();

		public List<string> m_legTextureIds = new List<string>();

		public List<Color> m_skinColorOverride = new List<Color>();

		public List<Color> m_hairColorOverride = new List<Color>();

		public List<Color> m_shirtColorOverride = new List<Color>();

		public List<Color> m_pantsColorOverride = new List<Color>();
	}

	public class ActiveFactionInfo
	{
		public int m_factionId = -1;

		public string m_name = string.Empty;

		public Color m_color = Color.white;
	}

	public class FactionCharacterInfo
	{
		public CharacterMeshOptions.CharacterPreset m_preset;

		public ItemManager.ItemType m_weapon = ItemManager.ItemType.Weapon_Fists;

		public List<ItemManager.ItemType> m_items = new List<ItemManager.ItemType>();

		public int m_strength;

		public int m_dexterity;

		public int m_perception;

		public int m_charisma;

		public int m_intelligence;
	}

	[SerializeField]
	private int m_day = 1;

	private List<FactionZone> m_zones = new List<FactionZone>();

	private int m_nextZoneId;

	private List<FactionInstance> m_instances = new List<FactionInstance>();

	[SerializeField]
	private List<FactionDifficultySetup> m_factionSpawnSetup = new List<FactionDifficultySetup>();

	[SerializeField]
	private List<FactionDef> m_factions = new List<FactionDef>();

	[SerializeField]
	private List<Material> m_materials = new List<Material>();

	[SerializeField]
	private List<Color> m_possibleColors = new List<Color>();

	[SerializeField]
	private GameObject m_zonePrefab;

	[SerializeField]
	private int m_maxAreaConnections = 3;

	[SerializeField]
	private int m_minZoneSeparation = 1;

	[SerializeField]
	private int m_minDistanceFromShelter = 10;

	[SerializeField]
	private float m_newAreaDistance = 1.3f;

	[SerializeField]
	private float m_minAreaRadius = 1f;

	[SerializeField]
	private float m_maxAreaRadius = 5f;

	private static FactionMan m_instance;

	public int currentDay => m_day;

	public static FactionMan instance => m_instance;

	public void SetDay(int new_day)
	{
		m_day = new_day - 1;
		OnNewDay();
	}

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
		}
	}

	public override void StartManager()
	{
		GameTime.newDay -= OnNewDay;
		GameTime.newDay += OnNewDay;
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
		SetFactionDifficultySettings();
	}

	public void OnDestroy()
	{
		GameTime.newDay -= OnNewDay;
	}

	private void OnNewDay()
	{
		m_day++;
		for (int i = 0; i < m_factionSpawnSetup.Count; i++)
		{
			if (m_day >= m_factionSpawnSetup[i].m_spawnDay)
			{
				SpawnNewFaction(i);
			}
		}
	}

	private FactionInstance GetFactionInstance(int factionId)
	{
		if (factionId < 0)
		{
			return null;
		}
		for (int i = 0; i < m_instances.Count; i++)
		{
			if (m_instances[i].m_factionId == factionId)
			{
				return m_instances[i];
			}
		}
		return null;
	}

	private FactionDifficultySetup GetFactionDifficulty(FactionInstance inst)
	{
		if (inst != null && inst.m_factionId < m_factionSpawnSetup.Count)
		{
			return m_factionSpawnSetup[inst.m_factionId];
		}
		return null;
	}

	private FactionDef GetFactionDef(FactionInstance inst)
	{
		if (inst != null && inst.m_factionDefIndex >= 0 && inst.m_factionDefIndex < m_factions.Count)
		{
			return m_factions[inst.m_factionDefIndex];
		}
		return null;
	}

	public override void UpdateManager()
	{
		List<int> list = new List<int>();
		for (int i = 0; i < m_instances.Count; i++)
		{
			if (m_instances[i].m_nextGrowTime >= 0f && Time.time >= m_instances[i].m_nextGrowTime)
			{
				FactionDifficultySetup factionDifficulty = GetFactionDifficulty(m_instances[i]);
				if (factionDifficulty != null)
				{
					m_instances[i].m_nextGrowTime = Time.time + factionDifficulty.m_growthIntervalDays * GameTime.RealSecondsPerDay;
					list.AddRange(m_instances[i].m_zoneIds);
				}
				else
				{
					m_instances[i].m_nextGrowTime = -1f;
				}
			}
		}
		for (int j = 0; j < list.Count; j++)
		{
			for (int k = 0; k < m_zones.Count; k++)
			{
				if (m_zones[k].m_zoneId == list[j])
				{
					GrowFactionZone(m_zones[k]);
					break;
				}
			}
		}
	}

	public void RevealFactionZone(int zoneId)
	{
		for (int i = 0; i < m_zones.Count; i++)
		{
			if (m_zones[i] != null && m_zones[i].m_zoneId == zoneId)
			{
				m_zones[i].m_revealed = true;
				m_zones[i].SetVisible(visible: true);
			}
		}
	}

	public bool RevealRandomFactionZone()
	{
		List<FactionZone> list = new List<FactionZone>();
		for (int i = 0; i < m_zones.Count; i++)
		{
			if (m_zones[i] != null && !m_zones[i].m_revealed)
			{
				list.Add(m_zones[i]);
			}
		}
		if (list.Count > 0)
		{
			int index = Random.Range(0, list.Count);
			list[index].m_revealed = true;
			list[index].SetVisible(visible: true);
			return true;
		}
		return false;
	}

	public bool HasUnrevealedFactionZones()
	{
		m_zones.Find((FactionZone x) => x != null && !x.m_revealed);
		for (int num = 0; num < m_zones.Count; num++)
		{
			if (m_zones[num] != null && !m_zones[num].m_revealed)
			{
				return true;
			}
		}
		return false;
	}

	public bool IsFactionTerritory(Vector2 mapPos, out int factionId, out int zoneId)
	{
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		zoneId = -1;
		factionId = -1;
		if ((Object)(object)ExplorationManager.Instance == (Object)null)
		{
			return false;
		}
		float num = ExplorationManager.Instance.WorldToMapPixelsX(ExplorationManager.Instance.worldWidth / ExpeditionMap.Instance.width);
		for (int i = 0; i < m_zones.Count; i++)
		{
			for (int j = 0; j < m_zones[i].m_areas.Count; j++)
			{
				FactionArea factionArea = m_zones[i].m_areas[j];
				if (Vector2.Distance(mapPos, factionArea.m_mapPosition) <= factionArea.m_radius * num)
				{
					zoneId = m_zones[i].m_zoneId;
					factionId = m_zones[i].m_factionId;
					return true;
				}
			}
		}
		return false;
	}

	public bool WillOverlapFactionZone(Vector2 mapPos, float radius)
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)ExplorationManager.Instance == (Object)null)
		{
			return false;
		}
		float num = ExplorationManager.Instance.WorldToMapPixelsX(ExplorationManager.Instance.worldWidth / ExpeditionMap.Instance.width);
		for (int i = 0; i < m_zones.Count; i++)
		{
			for (int j = 0; j < m_zones[i].m_areas.Count; j++)
			{
				FactionArea factionArea = m_zones[i].m_areas[j];
				if (Vector2.Distance(mapPos, factionArea.m_mapPosition) <= (factionArea.m_radius + (float)m_minZoneSeparation + radius) * num)
				{
					return true;
				}
			}
		}
		return false;
	}

	public void FindOverlappingFactionIds(Vector2 mapPos, float radius, out List<int> ids)
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		ids = new List<int>();
		if (!((Object)(object)ExplorationManager.Instance != (Object)null))
		{
			return;
		}
		float num = ExplorationManager.Instance.WorldToMapPixelsX(ExplorationManager.Instance.worldWidth / ExpeditionMap.Instance.width);
		for (int i = 0; i < m_zones.Count; i++)
		{
			for (int j = 0; j < m_zones[i].m_areas.Count; j++)
			{
				FactionArea factionArea = m_zones[i].m_areas[j];
				if (Vector2.Distance(mapPos, factionArea.m_mapPosition) <= (factionArea.m_radius + (float)m_minZoneSeparation + radius) * num)
				{
					ids.Add(m_zones[i].m_factionId);
					break;
				}
			}
		}
	}

	public string GetFactionDialogueId(int factionId)
	{
		FactionInstance factionInstance = GetFactionInstance(factionId);
		FactionDef factionDef = GetFactionDef(factionInstance);
		if (factionInstance != null && factionDef != null)
		{
			return factionDef.m_dialogueId;
		}
		return string.Empty;
	}

	public List<ActiveFactionInfo> GetActiveFactionInfo()
	{
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		List<ActiveFactionInfo> list = new List<ActiveFactionInfo>();
		for (int i = 0; i < m_zones.Count; i++)
		{
			if (!m_zones[i].m_revealed)
			{
				continue;
			}
			FactionInstance factionInstance = GetFactionInstance(m_zones[i].m_factionId);
			FactionDef factionDef = GetFactionDef(factionInstance);
			if (factionInstance == null || factionDef == null)
			{
				continue;
			}
			bool flag = false;
			for (int j = 0; j < list.Count; j++)
			{
				if (list[j].m_factionId == factionInstance.m_factionId)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				ActiveFactionInfo activeFactionInfo = new ActiveFactionInfo();
				activeFactionInfo.m_factionId = factionInstance.m_factionId;
				activeFactionInfo.m_color = m_zones[i].m_color;
				activeFactionInfo.m_name = Localization.Get(factionDef.m_nameKey);
				list.Add(activeFactionInfo);
			}
		}
		return list;
	}

	public int GetNumFactionNpcsToSpawn(int factionId)
	{
		int result = 1;
		FactionInstance factionInstance = GetFactionInstance(factionId);
		if (factionInstance != null)
		{
			FactionDifficultySetup factionDifficulty = GetFactionDifficulty(factionInstance);
			if (factionDifficulty != null)
			{
				int num = Mathf.Clamp(factionDifficulty.m_minNpcs, 1, 4);
				int num2 = Mathf.Clamp(factionDifficulty.m_maxNpcs, num, 4);
				result = Random.Range(num, num2 + 1);
			}
		}
		return result;
	}

	public bool GetFactionCharacterInfo(int factionId, out FactionCharacterInfo info)
	{
		//IL_048a: Unknown result type (might be due to invalid IL or missing references)
		//IL_047a: Unknown result type (might be due to invalid IL or missing references)
		//IL_048f: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_051c: Unknown result type (might be due to invalid IL or missing references)
		//IL_050c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0521: Unknown result type (might be due to invalid IL or missing references)
		//IL_0565: Unknown result type (might be due to invalid IL or missing references)
		//IL_0555: Unknown result type (might be due to invalid IL or missing references)
		//IL_056a: Unknown result type (might be due to invalid IL or missing references)
		info = new FactionCharacterInfo();
		FactionInstance factionInstance = GetFactionInstance(factionId);
		if (factionInstance == null)
		{
			return false;
		}
		FactionDef factionDef = GetFactionDef(factionInstance);
		if (factionDef == null)
		{
			return false;
		}
		FactionDifficultySetup factionDifficulty = GetFactionDifficulty(factionInstance);
		if (factionDifficulty == null)
		{
			return false;
		}
		if (factionDifficulty.m_possibleWeapons.Count > 0)
		{
			info.m_weapon = factionDifficulty.m_possibleWeapons[Random.Range(0, factionDifficulty.m_possibleWeapons.Count)];
		}
		int num = Random.Range(factionDifficulty.m_minCommonItems, factionDifficulty.m_maxCommonItems + 1);
		if ((Object)(object)ExpeditionMap.Instance != (Object)null)
		{
			for (int i = 0; i < num; i++)
			{
				info.m_items.Add(ExpeditionMap.Instance.GetRandomCommonItemType());
			}
		}
		if ((Object)(object)ItemManager.Instance != (Object)null && (info.m_weapon == ItemManager.ItemType.Weapon_Pistol || info.m_weapon == ItemManager.ItemType.Weapon_Shotgun || info.m_weapon == ItemManager.ItemType.Weapon_Rifle))
		{
			ItemDefinition_Combat combatDefinition = ItemManager.Instance.GetCombatDefinition(info.m_weapon);
			if ((Object)(object)combatDefinition != (Object)null)
			{
				int num2 = Random.Range(Mathf.CeilToInt((float)combatDefinition.ClipSize / 2f), combatDefinition.ClipSize + 1);
				for (int j = 0; j < num2; j++)
				{
					ItemManager.ItemType itemType = ItemManager.ItemType.Undefined;
					switch (info.m_weapon)
					{
					case ItemManager.ItemType.Weapon_Pistol:
						itemType = ItemManager.ItemType.Ammo_Pistol;
						break;
					case ItemManager.ItemType.Weapon_Shotgun:
						itemType = ItemManager.ItemType.Ammo_Shotgun;
						break;
					case ItemManager.ItemType.Weapon_Rifle:
						itemType = ItemManager.ItemType.Ammo_Rifle;
						break;
					}
					if (itemType != ItemManager.ItemType.Undefined)
					{
						info.m_items.Add(itemType);
					}
				}
			}
		}
		int[] array = new int[5];
		for (int k = 0; k < 5; k++)
		{
			array[k] = Mathf.Clamp(factionDifficulty.m_averageStatLevel, 1, 20);
		}
		List<int> list2;
		if (Random.Range(0, 2) == 0)
		{
			List<int> list = new List<int>();
			list.Add(-2);
			list.Add(-1);
			list.Add(0);
			list.Add(1);
			list.Add(2);
			list2 = list;
		}
		else
		{
			List<int> list = new List<int>();
			list.Add(-1);
			list.Add(-1);
			list.Add(0);
			list.Add(1);
			list.Add(1);
			list2 = list;
		}
		List<int> list3 = list2;
		list3.Shuffle();
		for (int l = 0; l < 5; l++)
		{
			array[l] += list3[l];
		}
		info.m_strength = Mathf.Clamp(array[0], 1, 20);
		info.m_dexterity = Mathf.Clamp(array[1], 1, 20);
		info.m_charisma = Mathf.Clamp(array[2], 1, 20);
		info.m_perception = Mathf.Clamp(array[3], 1, 20);
		info.m_intelligence = Mathf.Clamp(array[4], 1, 20);
		info.m_preset = new CharacterMeshOptions.CharacterPreset();
		info.m_preset.m_id = "factionCharacter";
		info.m_preset.m_firstName = NameGenerator.GetFirstName((!(factionDef.m_meshId == "man") && !(factionDef.m_meshId == "boy")) ? NameGenerator.Gender.Female : NameGenerator.Gender.Male);
		info.m_preset.m_lastName = NameGenerator.GetSurname();
		info.m_preset.m_meshId = factionDef.m_meshId;
		info.m_preset.m_headTexture = ((factionDef.m_headTextureIds.Count <= 0) ? "default" : factionDef.m_headTextureIds[Random.Range(0, factionDef.m_headTextureIds.Count)]);
		info.m_preset.m_torsoTexture = ((factionDef.m_torsoTextureIds.Count <= 0) ? "default" : factionDef.m_torsoTextureIds[Random.Range(0, factionDef.m_torsoTextureIds.Count)]);
		info.m_preset.m_legTexture = ((factionDef.m_legTextureIds.Count <= 0) ? "default" : factionDef.m_legTextureIds[Random.Range(0, factionDef.m_legTextureIds.Count)]);
		info.m_preset.m_hairColor = ((factionDef.m_hairColorOverride.Count <= 0) ? NpcVisitManager.Instance.GetRandomNpcColor(CharacterMesh.ColorCustomization.HairColor) : factionDef.m_hairColorOverride[Random.Range(0, factionDef.m_hairColorOverride.Count)]);
		info.m_preset.m_skinColor = ((factionDef.m_skinColorOverride.Count <= 0) ? NpcVisitManager.Instance.GetRandomNpcColor(CharacterMesh.ColorCustomization.SkinColor) : factionDef.m_skinColorOverride[Random.Range(0, factionDef.m_skinColorOverride.Count)]);
		info.m_preset.m_shirtColor = ((factionDef.m_shirtColorOverride.Count <= 0) ? NpcVisitManager.Instance.GetRandomNpcColor(CharacterMesh.ColorCustomization.ShirtColor) : factionDef.m_shirtColorOverride[Random.Range(0, factionDef.m_shirtColorOverride.Count)]);
		info.m_preset.m_pantsColor = ((factionDef.m_pantsColorOverride.Count <= 0) ? NpcVisitManager.Instance.GetRandomNpcColor(CharacterMesh.ColorCustomization.PantsColor) : factionDef.m_pantsColorOverride[Random.Range(0, factionDef.m_pantsColorOverride.Count)]);
		return true;
	}

	public bool SpawnNewFaction(int factionSpawnIndex)
	{
		FactionDifficultySetup factionDifficultySetup = ((factionSpawnIndex < 0 || factionSpawnIndex >= m_factionSpawnSetup.Count) ? null : m_factionSpawnSetup[factionSpawnIndex]);
		if (factionDifficultySetup == null)
		{
			return false;
		}
		if (GetFactionInstance(factionSpawnIndex) != null)
		{
			return false;
		}
		FactionInstance factionInstance = new FactionInstance();
		factionInstance.m_factionId = factionSpawnIndex;
		FactionDifficultySetup factionDifficulty = GetFactionDifficulty(factionInstance);
		if (factionDifficulty != null)
		{
			factionInstance.m_nextGrowTime = Time.time + factionDifficulty.m_growthIntervalDays * GameTime.RealSecondsPerDay;
		}
		else
		{
			factionInstance.m_nextGrowTime = -1f;
		}
		List<int> list = new List<int>();
		for (int i = 0; i < m_possibleColors.Count; i++)
		{
			list.Add(i);
		}
		factionInstance.m_colorIndex = -1;
		for (int j = 0; j < list.Count; j++)
		{
			bool flag = false;
			for (int k = 0; k < m_instances.Count; k++)
			{
				if (m_instances[k].m_colorIndex == list[j])
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				factionInstance.m_colorIndex = list[j];
				break;
			}
		}
		factionInstance.m_materialIndex = -1;
		for (int l = 0; l < m_materials.Count; l++)
		{
			bool flag2 = false;
			for (int m = 0; m < m_instances.Count; m++)
			{
				if (m_instances[m].m_materialIndex == l)
				{
					flag2 = true;
					break;
				}
			}
			if (!flag2)
			{
				factionInstance.m_materialIndex = l;
				break;
			}
		}
		List<int> list2 = new List<int>();
		for (int n = 0; n < m_factions.Count; n++)
		{
			list2.Add(n);
		}
		factionInstance.m_factionDefIndex = -1;
		for (int num = 0; num < list2.Count; num++)
		{
			bool flag3 = false;
			for (int num2 = 0; num2 < m_instances.Count; num2++)
			{
				if (m_instances[num2].m_factionDefIndex == list2[num])
				{
					flag3 = true;
					break;
				}
			}
			if (!flag3)
			{
				factionInstance.m_factionDefIndex = list2[num];
				break;
			}
		}
		if (factionInstance.m_factionDefIndex == -1)
		{
			return false;
		}
		m_instances.Add(factionInstance);
		int num3 = 0;
		if (factionDifficulty != null)
		{
			num3 = factionDifficulty.m_numZones;
		}
		for (int num4 = 0; num4 < num3; num4++)
		{
			int newZoneId = -1;
			FactionZone factionZone = SpawnFactionZone(factionInstance, out newZoneId);
			if (factionZone != null && newZoneId > -1)
			{
				factionInstance.m_zoneIds.Add(newZoneId);
			}
		}
		return true;
	}

	private FactionZone SpawnFactionZone(FactionInstance inst, out int newZoneId)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		newZoneId = -1;
		if (inst == null)
		{
			return null;
		}
		List<Vector2> possibleFactionZoneLocations = ExpeditionMap.Instance.GetPossibleFactionZoneLocations(m_minDistanceFromShelter);
		possibleFactionZoneLocations.Shuffle();
		float num = 0f;
		Vector2 mapPos = Vector2.zero;
		bool flag = false;
		for (int i = 0; i < possibleFactionZoneLocations.Count; i++)
		{
			num = m_minAreaRadius + Random.value * (m_maxAreaRadius - m_minAreaRadius);
			mapPos = possibleFactionZoneLocations[i];
			if (!WillOverlapFactionZone(mapPos, num))
			{
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			return null;
		}
		FactionZone factionZone = new FactionZone();
		factionZone.m_zoneId = m_nextZoneId++;
		factionZone.m_factionId = inst.m_factionId;
		factionZone.m_color = ((inst.m_colorIndex < 0 || inst.m_colorIndex >= m_possibleColors.Count) ? Color.white : m_possibleColors[inst.m_colorIndex]);
		factionZone.m_materialIndex = inst.m_materialIndex;
		m_zones.Add(factionZone);
		Material val = ((factionZone.m_materialIndex < 0 || factionZone.m_materialIndex >= m_materials.Count) ? null : m_materials[factionZone.m_materialIndex]);
		if ((Object)(object)val != (Object)null)
		{
			val.SetColor("_Color", factionZone.m_color);
		}
		FactionArea item = new FactionArea(mapPos, num, m_zonePrefab, val);
		factionZone.m_areas.Add(item);
		newZoneId = factionZone.m_zoneId;
		return factionZone;
	}

	private bool GrowFactionZone(FactionZone zone)
	{
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
		FactionInstance factionInstance = GetFactionInstance(zone.m_factionId);
		if (factionInstance != null)
		{
			FactionDifficultySetup factionDifficulty = GetFactionDifficulty(factionInstance);
			if (factionDifficulty != null && zone.m_areas.Count >= factionDifficulty.m_maxAreasPerZone)
			{
				return false;
			}
		}
		float num = ExplorationManager.Instance.WorldToMapPixelsX(ExplorationManager.Instance.worldWidth / ExpeditionMap.Instance.width);
		ExpeditionMap.GridRef gridRef = ExpeditionMap.Instance.WorldPosToGridRef(Vector2.zero);
		List<FactionArea> list = new List<FactionArea>();
		for (int i = 0; i < zone.m_areas.Count; i++)
		{
			if (zone.m_areas[i].m_children < m_maxAreaConnections)
			{
				list.Add(zone.m_areas[i]);
			}
		}
		if (list.Count == 0)
		{
			return false;
		}
		FactionArea factionArea = null;
		Vector2 mapPos = Vector2.zero;
		float num2 = 0f;
		bool flag = false;
		Vector2 val = default(Vector2);
		for (int j = 0; j < 50; j++)
		{
			factionArea = list[Random.Range(0, list.Count)];
			((Vector2)(ref val))._002Ector((Random.value - 0.5f) * 2f, (Random.value - 0.5f) * 2f);
			mapPos = factionArea.m_mapPosition + ((Vector2)(ref val)).normalized * factionArea.m_radius * num * m_newAreaDistance;
			num2 = m_minAreaRadius + Random.value * (m_maxAreaRadius - m_minAreaRadius);
			ExpeditionMap.GridRef gridRef2 = ExpeditionMap.Instance.WorldPosToGridRef(ExplorationManager.Instance.MapPixelsToWorld(mapPos));
			mapPos = ExplorationManager.Instance.WorldToMapPixels(ExpeditionMap.Instance.GridRefToWorldPos(gridRef2));
			int factionId = -1;
			int zoneId = -1;
			if (IsFactionTerritory(mapPos, out factionId, out zoneId) || (Mathf.Abs(gridRef.x - gridRef2.x) < m_minDistanceFromShelter && Mathf.Abs(gridRef.y - gridRef2.y) < m_minDistanceFromShelter))
			{
				continue;
			}
			List<int> ids = new List<int>();
			FindOverlappingFactionIds(mapPos, num2, out ids);
			flag = true;
			for (int k = 0; k < ids.Count; k++)
			{
				if (ids[k] != zone.m_factionId)
				{
					flag = false;
					break;
				}
			}
			if (flag)
			{
				break;
			}
		}
		if (flag)
		{
			Material material = ((zone.m_materialIndex < 0 || zone.m_materialIndex >= m_materials.Count) ? null : m_materials[zone.m_materialIndex]);
			FactionArea factionArea2 = new FactionArea(mapPos, num2, m_zonePrefab, material);
			factionArea2.m_parent = factionArea;
			zone.m_areas.Add(factionArea2);
			factionArea.m_children++;
		}
		return flag;
	}

	public void SetFactionDifficultySettings()
	{
		if ((Object)(object)DifficultyManager.instance != (Object)null)
		{
			for (int i = 0; i < m_factionSpawnSetup.Count; i++)
			{
				m_factionSpawnSetup[i].m_spawnDay -= DifficultyManager.instance.GetFactionSpawnDayReduction();
				m_factionSpawnSetup[i].m_numZones += DifficultyManager.instance.GetFactionZoneIncrease();
			}
		}
	}

	public bool IsRelocationEnabled()
	{
		return false;
	}

	public bool IsReadyForLoad()
	{
		if ((Object)(object)DifficultyManager.instance != (Object)null && SaveManager.instance.HasBeenLoaded(DifficultyManager.instance))
		{
			return true;
		}
		return false;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("FactionMan");
		data.SaveLoad("nextZoneId", ref m_nextZoneId);
		data.SaveLoadList("zones", m_zones, delegate(int i)
		{
			data.SaveLoad("factionId", ref m_zones[i].m_factionId);
			data.SaveLoad("zoneId", ref m_zones[i].m_zoneId);
			data.SaveLoad("color", ref m_zones[i].m_color);
			data.SaveLoad("materialId", ref m_zones[i].m_materialIndex);
			data.SaveLoad("revealed", ref m_zones[i].m_revealed);
			data.SaveLoadList("areas", m_zones[i].m_areas, delegate(int j)
			{
				FactionArea factionArea = m_zones[i].m_areas[j];
				data.SaveLoad("pos", ref factionArea.m_mapPosition);
				data.SaveLoad("radius", ref factionArea.m_radius);
				data.SaveLoad("children", ref factionArea.m_children);
			}, null);
		}, delegate
		{
			//IL_0134: Unknown result type (might be due to invalid IL or missing references)
			FactionZone zone = new FactionZone();
			data.SaveLoad("factionId", ref zone.m_factionId);
			data.SaveLoad("zoneId", ref zone.m_zoneId);
			data.SaveLoad("color", ref zone.m_color);
			data.SaveLoad("materialId", ref zone.m_materialIndex);
			data.SaveLoad("revealed", ref zone.m_revealed);
			m_zones.Add(zone);
			Material mat = ((zone.m_materialIndex < 0 || zone.m_materialIndex >= m_materials.Count) ? null : m_materials[zone.m_materialIndex]);
			if ((Object)(object)mat != (Object)null)
			{
				mat.SetColor("_Color", zone.m_color);
			}
			data.SaveLoadList("areas", zone.m_areas, null, delegate
			{
				//IL_0000: Unknown result type (might be due to invalid IL or missing references)
				//IL_0005: Unknown result type (might be due to invalid IL or missing references)
				//IL_003c: Unknown result type (might be due to invalid IL or missing references)
				Vector2 value = Vector2.zero;
				float value2 = 0f;
				data.SaveLoad("pos", ref value);
				data.SaveLoad("radius", ref value2);
				FactionArea factionArea = new FactionArea(value, value2, m_zonePrefab, mat);
				if (factionArea != null)
				{
					data.SaveLoad("children", ref factionArea.m_children);
					zone.m_areas.Add(factionArea);
				}
			});
			zone.SetVisible(zone.m_revealed);
		});
		data.SaveLoadList("instances", m_instances, delegate(int i)
		{
			data.SaveLoad("instanceId", ref m_instances[i].m_factionId);
			data.SaveLoad("defIndex", ref m_instances[i].m_factionDefIndex);
			data.SaveLoad("matIndex", ref m_instances[i].m_materialIndex);
			data.SaveLoad("colIndex", ref m_instances[i].m_colorIndex);
			data.SaveLoadAbsoluteTime("nextGrowthTime", ref m_instances[i].m_nextGrowTime);
			data.SaveLoadList("zoneIds", m_instances[i].m_zoneIds, delegate(int j)
			{
				int value = m_instances[i].m_zoneIds[j];
				data.SaveLoad("id", ref value);
			}, null);
		}, delegate
		{
			FactionInstance inst = new FactionInstance();
			data.SaveLoad("instanceId", ref inst.m_factionId);
			data.SaveLoad("defIndex", ref inst.m_factionDefIndex);
			data.SaveLoad("matIndex", ref inst.m_materialIndex);
			data.SaveLoad("colIndex", ref inst.m_colorIndex);
			data.SaveLoadAbsoluteTime("nextGrowthTime", ref inst.m_nextGrowTime);
			data.SaveLoadList("zoneIds", inst.m_zoneIds, null, delegate
			{
				int value = -1;
				data.SaveLoad("id", ref value);
				inst.m_zoneIds.Add(value);
			});
			m_instances.Add(inst);
		});
		bool flag = data.SaveLoad("day", ref m_day);
		if (data.isLoading && !flag)
		{
			m_day = GameTime.Day;
		}
		data.GroupEnd();
		return true;
	}
}
