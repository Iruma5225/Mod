using System.Collections.Generic;
using UnityEngine;

public class Obj_AntiBreachTrap : Obj_Base
{
	private class PendingKill
	{
		public NpcVisitor m_npc;

		public float m_killTime;
	}

	private bool m_armed;

	[SerializeField]
	private Animator m_animator;

	[SerializeField]
	private float m_killDelay;

	[SerializeField]
	private float m_cooldown;

	private float m_cooldownRemaining;

	private List<PendingKill> m_pendingKills = new List<PendingKill>();

	[SerializeField]
	[Range(0f, 100f)]
	private float m_successChance = 50f;

	[SerializeField]
	private int m_maxTriggerCount = 1;

	private int m_triggersRemaining;

	private bool m_triggeredOnce;

	[Range(0f, 100f)]
	[SerializeField]
	private int m_minDamage;

	[Range(0f, 100f)]
	[SerializeField]
	private int m_maxDamage;

	[SerializeField]
	private bool m_playDisarmAnimAfterAllTriggers = true;

	[SerializeField]
	private bool m_autoArm;

	[SerializeField]
	private List<ItemManager.ItemType> m_itemsToArm = new List<ItemManager.ItemType>();

	private AudioSource m_audio;

	[SerializeField]
	private AudioClip m_triggeredSound;

	[SerializeField]
	private AudioClip m_armedSound;

	public bool armed => m_armed;

	public bool canBeArmed => m_triggersRemaining < m_maxTriggerCount;

	public bool autoArm => m_autoArm;

	public List<ItemManager.ItemType> itemsToArm
	{
		get
		{
			List<ItemManager.ItemType> list = new List<ItemManager.ItemType>();
			list.AddRange(m_itemsToArm);
			return list;
		}
	}

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.AntiBreachTrap;
	}

	public override void Start()
	{
		base.Start();
		m_audio = ((Component)this).GetComponent<AudioSource>();
		if ((Object)(object)m_animator != (Object)null)
		{
			m_animator.SetTrigger("Reset_Untriggered");
		}
	}

	public override void Update()
	{
		base.Update();
		if (m_cooldownRemaining >= 0f)
		{
			m_cooldownRemaining = Mathf.Max(0f, m_cooldownRemaining - Time.deltaTime);
		}
		for (int num = m_pendingKills.Count - 1; num >= 0; num--)
		{
			if (Time.time >= m_pendingKills[num].m_killTime)
			{
				if ((Object)(object)m_pendingKills[num].m_npc != (Object)null)
				{
					m_pendingKills[num].m_npc.Kill(BaseCharacter.DamageType.Undefined, string.Empty);
				}
				m_pendingKills.RemoveAt(num);
			}
		}
		if (!m_autoArm)
		{
			return;
		}
		bool flag = true;
		flag = ((IsEnabled() && HasEnoughPower()) ? true : false);
		if (itemsToArm.Count > 0 && (Object)(object)ItemManager.Instance != (Object)null)
		{
			Dictionary<ItemManager.ItemType, int> dictionary = new Dictionary<ItemManager.ItemType, int>();
			for (int i = 0; i < itemsToArm.Count; i++)
			{
				if (dictionary.ContainsKey(itemsToArm[i]))
				{
					dictionary[itemsToArm[i]]++;
				}
				else
				{
					dictionary.Add(itemsToArm[i], 1);
				}
			}
			foreach (KeyValuePair<ItemManager.ItemType, int> item in dictionary)
			{
				if (InventoryManager.Instance.GetNumItemsOfType(item.Key) < item.Value)
				{
					flag = false;
				}
			}
		}
		if (flag)
		{
			if (!m_armed || m_triggeredOnce)
			{
				ArmTrap();
			}
		}
		else
		{
			DisarmTrap();
		}
	}

	public void ArmTrap()
	{
		if (((Object)(object)BreachMan.instance != (Object)null && BreachMan.instance.inProgress) || m_autoArm)
		{
			m_armed = true;
			m_triggeredOnce = false;
			m_cooldownRemaining = 0f;
			m_triggersRemaining = Mathf.Min(m_triggersRemaining + 1, m_maxTriggerCount);
			m_pendingKills.Clear();
			if ((Object)(object)m_animator != (Object)null)
			{
				m_animator.SetTrigger("Armed");
			}
			if ((Object)(object)m_audio != (Object)null && (Object)(object)m_armedSound != (Object)null)
			{
				m_audio.PlayOneShot(m_armedSound);
			}
		}
		if ((Object)(object)BreachMan.instance != (Object)null && BreachMan.instance.inProgress && !m_autoArm && (Object)(object)InventoryManager.Instance != (Object)null)
		{
			for (int i = 0; i < m_itemsToArm.Count; i++)
			{
				InventoryManager.Instance.RemoveItemOfType(m_itemsToArm[i]);
			}
		}
	}

	public void DisarmTrap()
	{
		if ((Object)(object)m_animator != (Object)null && m_armed)
		{
			m_animator.SetTrigger((!m_triggeredOnce) ? "Reset_Untriggered" : "Reset_Triggered");
		}
		if ((Object)(object)InventoryManager.Instance != (Object)null && !m_autoArm)
		{
			for (int i = 0; i < m_triggersRemaining; i++)
			{
				for (int j = 0; j < m_itemsToArm.Count; j++)
				{
					InventoryManager.Instance.AddNewItem(m_itemsToArm[j]);
				}
			}
		}
		m_armed = false;
		m_triggeredOnce = false;
		m_cooldownRemaining = 0f;
		m_triggersRemaining = 0;
	}

	public void OnTrapTriggered(NpcVisitor npc)
	{
		if ((Object)(object)npc == (Object)null || (Object)(object)BreachMan.instance == (Object)null || !BreachMan.instance.inProgress || (!m_autoArm && !m_armed) || m_cooldownRemaining > 0f || (!IsEnabled() && !HasEnoughPower()))
		{
			return;
		}
		if (m_autoArm)
		{
			if (itemsToArm.Count > 0 && (Object)(object)ItemManager.Instance == (Object)null)
			{
				return;
			}
			Dictionary<ItemManager.ItemType, int> dictionary = new Dictionary<ItemManager.ItemType, int>();
			for (int i = 0; i < itemsToArm.Count; i++)
			{
				if (dictionary.ContainsKey(itemsToArm[i]))
				{
					dictionary[itemsToArm[i]]++;
				}
				else
				{
					dictionary.Add(itemsToArm[i], 1);
				}
			}
			foreach (KeyValuePair<ItemManager.ItemType, int> item in dictionary)
			{
				if (InventoryManager.Instance.GetNumItemsOfType(item.Key) < item.Value)
				{
					return;
				}
			}
			if ((Object)(object)InventoryManager.Instance != (Object)null)
			{
				for (int j = 0; j < m_itemsToArm.Count; j++)
				{
					InventoryManager.Instance.RemoveItemOfType(m_itemsToArm[j]);
				}
			}
		}
		if (m_triggersRemaining > 0)
		{
			if (!m_autoArm)
			{
				m_triggersRemaining--;
			}
			m_triggeredOnce = true;
			bool flag = Random.value <= m_successChance * 0.01f;
			if (flag)
			{
				int num = Random.Range(m_minDamage, m_maxDamage);
				npc.onTrapHit(num);
				npc.Damage(num, BaseCharacter.DamageType.Undefined, string.Empty);
			}
			else
			{
				npc.onTrapMiss();
			}
			if ((Object)(object)m_animator != (Object)null)
			{
				m_animator.SetTrigger((!flag) ? "TriggerMiss" : "TriggerHit");
			}
			if ((Object)(object)m_audio != (Object)null && (Object)(object)m_triggeredSound != (Object)null)
			{
				m_audio.PlayOneShot(m_triggeredSound);
			}
			m_cooldownRemaining = m_cooldown;
			if (m_triggersRemaining == 0 && (Object)(object)m_animator != (Object)null && m_playDisarmAnimAfterAllTriggers)
			{
				m_animator.SetTrigger("Reset_Triggered");
			}
		}
	}

	public override List<string> GetTooltipExtraInfo()
	{
		List<string> list = new List<string>();
		List<string> tooltipExtraInfo = base.GetTooltipExtraInfo();
		if (tooltipExtraInfo != null)
		{
			list.AddRange(tooltipExtraInfo);
		}
		list.Add(Localization.Get("Text.UI.Status"));
		list.Add(Localization.Get((!m_armed) ? "Text.UI.Disarmed" : "Text.UI.Armed"));
		if (!m_autoArm)
		{
			list.Add(Localization.Get("Text.UI.ActivationsRemaining"));
			list.Add(m_triggersRemaining + "/" + m_maxTriggerCount);
		}
		else
		{
			list.Add(Localization.Get("Text.UI.ActivationsRemaining"));
			int num = 0;
			for (int i = 0; i < itemsToArm.Count; i++)
			{
				num += InventoryManager.Instance.GetNumItemsOfType(itemsToArm[i]);
			}
			list.Add((num / itemsToArm.Count).ToString());
		}
		return list;
	}

	public override bool IsReadyForLoad()
	{
		if (base.IsReadyForLoad() && (Object)(object)NpcVisitManager.Instance != (Object)null && (Object)(object)SaveManager.instance != (Object)null && SaveManager.instance.HasBeenLoaded(NpcVisitManager.Instance))
		{
			return true;
		}
		return false;
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		data.SaveLoad("armed", ref m_armed);
		data.SaveLoad("cooldown", ref m_cooldownRemaining);
		data.SaveLoad("triggersRemaining", ref m_triggersRemaining);
		data.SaveLoad("triggeredOnce", ref m_triggeredOnce);
		data.SaveLoad("autoArm", ref m_autoArm);
		data.SaveLoadList("pendingKills", m_pendingKills, delegate(int i)
		{
			int value = ((!((Object)(object)m_pendingKills[i].m_npc != (Object)null)) ? (-1) : m_pendingKills[i].m_npc.npcId);
			data.SaveLoadAbsoluteTime("killTime", ref m_pendingKills[i].m_killTime);
			data.SaveLoad("npcId", ref value);
		}, delegate
		{
			int value = -1;
			float value2 = 0f;
			data.SaveLoadAbsoluteTime("killTime", ref value2);
			data.SaveLoad("npcId", ref value);
			if (value > -1 && (Object)(object)NpcVisitManager.Instance != (Object)null)
			{
				NpcVisitor npcVisitor = NpcVisitManager.Instance.FindVisitorWithId(value);
				if ((Object)(object)npcVisitor != (Object)null)
				{
					PendingKill item = new PendingKill
					{
						m_npc = npcVisitor,
						m_killTime = value2
					};
					m_pendingKills.Add(item);
				}
			}
		});
		if (!data.isLoading || !((Object)(object)m_animator != (Object)null))
		{
			return;
		}
		if (m_armed)
		{
			if (m_triggeredOnce)
			{
				m_animator.SetTrigger("TriggerHit");
			}
			else
			{
				m_animator.SetTrigger("Armed");
			}
		}
		else
		{
			m_animator.SetTrigger("Reset_Untriggered");
		}
	}
}
