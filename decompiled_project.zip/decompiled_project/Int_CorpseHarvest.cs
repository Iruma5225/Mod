using System.Collections.Generic;
using UnityEngine;

public class Int_CorpseHarvest : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "corpse_harvest";
	}

	public override int GetInteractionPriority()
	{
		return 3;
	}

	public override bool IsPlayerSelectable()
	{
		FamilyMember selectedFamilyMember = InteractionManager.Instance.GetSelectedFamilyMember();
		if ((Object)(object)selectedFamilyMember == (Object)null || selectedFamilyMember.isCarryingCorpse || obj.isBurningOrBurntOut)
		{
			return false;
		}
		if ((Object)(object)ObjectManager.Instance != (Object)null)
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Freezer);
			if (objectsOfType.Count == 0)
			{
				return true;
			}
			if (FoodManager.Instance.MaxMeat - FoodManager.Instance.TotalMeat == 0)
			{
				return false;
			}
		}
		return true;
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		if (member.job_queue.isFull)
		{
			return false;
		}
		List<Obj_Base> nearestObjectsOfType = ObjectManager.Instance.GetNearestObjectsOfType(ObjectManager.ObjectType.Freezer, ((Component)obj).transform.position);
		Obj_Freezer target_obj = null;
		for (int i = 0; i < nearestObjectsOfType.Count; i++)
		{
			Obj_Freezer obj_Freezer = nearestObjectsOfType[i] as Obj_Freezer;
			if ((Object)(object)obj_Freezer != (Object)null && obj_Freezer.Meat + obj_Freezer.DesperateMeat < obj_Freezer.TotalMeatCapacity)
			{
				target_obj = obj_Freezer;
			}
		}
		return member.AddPlayerJob(new Job_MoveCorpse(member, obj as Obj_Corpse, target_obj, "harvest_corpse"));
	}
}
