using UnityEngine;

public class InteractionInstance_AddSaddle : InteractionInstance_Base
{
	private Int_AddSaddle interaction;

	private Obj_Horse obj_Vehicle;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_AddSaddle;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		obj_Vehicle = ((Component)this).GetComponent<Obj_Horse>();
		if ((Object)(object)obj_Vehicle == (Object)null)
		{
			return false;
		}
		if ((Object)(object)InventoryManager.Instance == (Object)null)
		{
			return false;
		}
		if (!obj_Vehicle.PlayerHasSaddle())
		{
			return false;
		}
		if (obj_Vehicle.hasSaddle)
		{
			return false;
		}
		member.TriggerAnim("Rummage");
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled)
		{
			InventoryManager.Instance.RemoveItemsOfType(ItemManager.ItemType.Horse_Saddle, 1);
			obj_Vehicle.SetSaddled(saddle: true);
		}
		return true;
	}
}
