using UnityEngine;

public abstract class ClipboardPage : MonoBehaviour
{
	public virtual void OnClipboardShown()
	{
	}

	public virtual void OnShowPage()
	{
	}

	public virtual void OnHidePage()
	{
	}
}
