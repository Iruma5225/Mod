public class Int_RadioBroadcastTrader : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_RadioBroadcastTrader";
	}

	public override string GetInteractionType()
	{
		return "radio_broadcast_trader";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		return false;
	}
}
