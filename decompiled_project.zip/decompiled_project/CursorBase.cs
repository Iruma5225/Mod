using UnityEngine;

public abstract class CursorBase : MonoBehaviour
{
	public enum CursorType
	{
		None,
		Standard,
		ObjectPlacement,
		RoomPlacement,
		ObjectSelect
	}

	[SerializeField]
	private float m_CursorSpeed = 13f;

	[SerializeField]
	private float m_CursorFastSpeed = 26f;

	[SerializeField]
	[Range(0f, 1f)]
	private float deadzone = 0.1f;

	[SerializeField]
	protected float acceleration = 4f;

	private Vector3 velocity = Vector3.zero;

	[SerializeField]
	protected float deceleration = 8f;

	protected Camera game_cam;

	protected BasicCamera cameraScript;

	public float CursorSpeed => m_CursorSpeed;

	public float CursorFastSpeed => m_CursorFastSpeed;

	public float Deadzone => deadzone;

	public float Acceleration => acceleration;

	public float Deceleration => deceleration;

	public abstract CursorType GetCursorType();

	public virtual Vector3 GetCameraFollowPosition()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		return ((Component)this).transform.position;
	}

	public virtual void Awake()
	{
		game_cam = Camera.main;
		cameraScript = ((Component)game_cam).GetComponent<BasicCamera>();
	}

	protected void ClampToScreen(ref Vector3 pos)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = game_cam.ScreenToWorldPoint(new Vector3(0f, 0f, 0f));
		Vector3 val2 = game_cam.ScreenToWorldPoint(new Vector3((float)game_cam.pixelWidth, (float)game_cam.pixelHeight));
		pos.x = Mathf.Clamp(pos.x, val.x, val2.x);
		pos.y = Mathf.Clamp(pos.y, val.y, val2.y);
	}

	protected Vector3 GetDefaultMovement(Vector3 pos)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.zero;
		if (!cameraScript.isConsoleMode)
		{
			if ((Object)(object)game_cam != (Object)null)
			{
				val = game_cam.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0f)) - pos;
			}
		}
		else if (cameraScript.isConsoleMode)
		{
			float cursorSensitivity = SaveGlobal.Instance.cursorSensitivity;
			bool flag = false;
			if (!cameraScript.isZoomed && flag)
			{
				FamilyMember selectedFamilyMember = InteractionManager.Instance.GetSelectedFamilyMember();
				if ((Object)(object)selectedFamilyMember != (Object)null)
				{
					val = ((Component)selectedFamilyMember).transform.position - pos;
				}
			}
			else if (!flag)
			{
				if (velocity.x > 0f)
				{
					ref Vector3 reference = ref velocity;
					reference.x -= deceleration * RealTime.deltaTime * cursorSensitivity;
					velocity.x = Mathf.Max(velocity.x, 0f);
				}
				else if (velocity.x < 0f)
				{
					ref Vector3 reference2 = ref velocity;
					reference2.x += deceleration * RealTime.deltaTime * cursorSensitivity;
					velocity.x = Mathf.Min(velocity.x, 0f);
				}
				if (velocity.y > 0f)
				{
					ref Vector3 reference3 = ref velocity;
					reference3.y -= deceleration * RealTime.deltaTime * cursorSensitivity;
					velocity.y = Mathf.Max(velocity.y, 0f);
				}
				else if (velocity.y < 0f)
				{
					ref Vector3 reference4 = ref velocity;
					reference4.y += deceleration * RealTime.deltaTime * cursorSensitivity;
					velocity.y = Mathf.Min(velocity.y, 0f);
				}
				velocity.x = Mathf.Clamp(velocity.x, (0f - CursorSpeed) * cursorSensitivity, CursorSpeed * cursorSensitivity);
				velocity.y = Mathf.Clamp(velocity.y, (0f - CursorSpeed) * cursorSensitivity, CursorSpeed * cursorSensitivity);
				val += velocity * RealTime.deltaTime;
			}
		}
		return val;
	}

	public virtual void OnCursorActivated()
	{
	}

	public virtual void OnCursorDeactivated()
	{
	}
}
