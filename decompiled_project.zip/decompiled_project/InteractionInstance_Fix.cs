using UnityEngine;

public class InteractionInstance_Fix : InteractionInstance_Base
{
	private Int_Fix interaction;

	private Obj_Integrity obj;

	private float fixPerSecond;

	private float fixCurrent;

	private float fixPerSecondDark;

	private float fixPerSecondLight;

	protected override bool CanCancelImmediately()
	{
		return true;
	}

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_Fix;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		obj = ((Component)this).GetComponent<Obj_Integrity>();
		if ((Object)(object)obj == (Object)null)
		{
			return false;
		}
		if (obj.Integrity >= 100)
		{
			return false;
		}
		if ((Object)(object)InventoryManager.Instance == (Object)null)
		{
			return false;
		}
		StartRepair(InventoryManager.Instance.ToolCount);
		return true;
	}

	protected override void OnInteractionUpdated()
	{
		if (member.IsInDarkness())
		{
			fixPerSecond = fixPerSecondDark;
		}
		else
		{
			fixPerSecond = fixPerSecondLight;
		}
		fixCurrent += fixPerSecond * Time.deltaTime;
		if (fixCurrent >= 1f)
		{
			obj.Repair(Mathf.FloorToInt(fixCurrent));
			fixCurrent -= Mathf.Floor(fixCurrent);
		}
	}

	protected override bool OnInteractionComplete()
	{
		FinishRepair();
		return true;
	}

	private void StartRepair(int toolCount)
	{
		if (interaction.m_CrouchAnim)
		{
			member.SetAnimBool("Crouch", truth: true);
		}
		if (Random.value >= 0.5f)
		{
			member.TriggerAnim("Fix");
			member.PlaySound(BaseCharacter.AnimSounds.Blowtorch, loop: true);
		}
		else
		{
			member.TriggerAnim("Hammer");
			member.PlaySound(BaseCharacter.AnimSounds.Hammer, loop: true);
		}
		float num = 1f;
		if (member.traits.HasStrength(Traits.Strength.HandsOn))
		{
			num = 0.75f;
		}
		else if (member.traits.HasWeakness(Traits.Weakness.HandsOff))
		{
			num = 1.25f;
		}
		float num2 = (float)(100 - obj.Integrity) / 100f * Obj_Integrity.GetFullRepairTime(InventoryManager.Instance.ToolCount) * num;
		fixPerSecondLight = (float)(100 - obj.Integrity) / num2;
		fixPerSecondDark = fixPerSecondLight / 2f;
		if ((Object)(object)TutorialManager.Instance != (Object)null && TutorialManager.Instance.TutorialActive && TutorialManager.Instance.currentStage == TutorialManager.TutorialStage.FixGenerator)
		{
			float num3 = Mathf.Max(0.01f, TutorialManager.Instance.fixSpeedMultiplier);
			fixPerSecondLight *= num3;
			fixPerSecondDark *= num3;
			num2 /= num3;
		}
		if (member.IsInDarkness())
		{
			num2 *= 2f;
			fixPerSecond = fixPerSecondDark;
		}
		else
		{
			fixPerSecond = fixPerSecondLight;
		}
		ResetInteractionTimer(num2);
		SetProgress(member, (float)obj.Integrity / 100f);
		obj.SetIsBeingFixed(fixing: true);
	}

	private void FinishRepair()
	{
		if (!base.cancelled)
		{
			obj.Repair(100 - obj.Integrity);
			member.OnFixCompleted();
		}
		member.SetAnimBool("Crouch", truth: false);
		member.StopSound();
		obj.SetIsBeingFixed(fixing: false);
	}
}
