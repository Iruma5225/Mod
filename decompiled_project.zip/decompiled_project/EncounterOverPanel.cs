using System.Collections.Generic;
using UnityEngine;

public class EncounterOverPanel : BasePanel
{
	[SerializeField]
	private UILabel result_label;

	private List<EncounterCharacter> m_playerCharacters;

	private List<EncounterCharacter> m_npcCharacters;

	[SerializeField]
	private ItemTransferPanel m_itemTransferPanel;

	private bool m_playerWon;

	private bool m_playerEscaped;

	private bool m_closePanel;

	private bool m_hasVehicle;

	private int m_partyId = -1;

	private List<ItemStack> m_lootItems = new List<ItemStack>();

	public AudioClip victoryMusic;

	public AudioClip escapeMusic;

	public AudioClip lostMusic;

	private AudioClip music;

	public void SetResultText(string text)
	{
		if ((Object)(object)result_label != (Object)null)
		{
			result_label.text = text;
		}
	}

	public void SetCombatResult(EncounterManager.EncounterCombatResult result)
	{
		m_playerWon = result == EncounterManager.EncounterCombatResult.Win;
		m_playerEscaped = result == EncounterManager.EncounterCombatResult.Escape;
		if (m_playerWon)
		{
			SetResultText("You Win!");
			music = victoryMusic;
		}
		else if (m_playerEscaped)
		{
			SetResultText("You coward!");
			music = escapeMusic;
		}
		else
		{
			SetResultText("You Lose!");
			music = lostMusic;
		}
	}

	public void CleanUp()
	{
	}

	public override void Update()
	{
		if (m_closePanel)
		{
			FadeManager.Instance.FadeFromBlack();
			UIPanelManager.Instance().PopPanel(this);
			EncounterManager.Instance.EndEncounter();
			m_closePanel = false;
		}
	}

	private void DismissMessage()
	{
		m_closePanel = true;
		if (m_playerWon)
		{
			GatherLootItems();
			if (m_lootItems.Count > 0)
			{
				m_closePanel = !ShowItemTransferScreen();
			}
		}
		else
		{
			if (!m_playerEscaped || m_hasVehicle)
			{
				return;
			}
			foreach (EncounterCharacter playerCharacter in m_playerCharacters)
			{
				if (playerCharacter.partyMember.person.isDead)
				{
					playerCharacter.partyMember.DropCarriedItems();
				}
			}
		}
	}

	private void GatherLootItems()
	{
		m_lootItems.Clear();
		foreach (EncounterCharacter npcCharacter in m_npcCharacters)
		{
			m_lootItems.AddRange(npcCharacter.GetAllItems());
		}
		foreach (EncounterCharacter playerCharacter in m_playerCharacters)
		{
			if ((Object)(object)playerCharacter.partyMember != (Object)null && playerCharacter.partyMember.person.isDead)
			{
				m_lootItems.AddRange(playerCharacter.GetEquippedItems());
				if (!m_hasVehicle)
				{
					List<ItemStack> collection = playerCharacter.partyMember.DropCarriedItems();
					m_lootItems.AddRange(collection);
				}
			}
		}
	}

	private bool ShowItemTransferScreen()
	{
		if ((Object)(object)m_itemTransferPanel != (Object)null && m_playerCharacters.Count > 0)
		{
			ItemTransferPanel.rightSideIsShelterItems = false;
			ItemTransferPanel.numLeftSideInventories = 1;
			ItemTransferPanel.getLeftSideItems = GetPartyItems;
			ItemTransferPanel.leftSideItemsChanged = PartyItemsChanged;
			ItemTransferPanel.getRightSideItems = GetNpcItems;
			ItemTransferPanel.rightSideItemsChanged = NpcItemsChanged;
			ItemTransferPanel.getLeftPerson = GetPartyMemberDetailsForTransfer;
			ItemTransferPanel.getRightPerson = GetNpcDetailsForTransfer;
			UIPanelManager.Instance().PushPanel(m_itemTransferPanel);
			return true;
		}
		return false;
	}

	public override void OnShow()
	{
		base.OnShow();
		m_playerCharacters = new List<EncounterCharacter>(EncounterManager.Instance.GetPlayerCharacters());
		m_playerCharacters.RemoveAll((EncounterCharacter x) => !x.isPlayerControlled);
		m_npcCharacters = EncounterManager.Instance.GetNPCs();
		if (m_playerCharacters.Count > 0 && (Object)(object)m_playerCharacters[0].partyMember != (Object)null)
		{
			m_partyId = m_playerCharacters[0].partyMember.partyId;
			m_hasVehicle = (Object)(object)ExplorationManager.Instance.GetPartyVehicle(m_partyId) != (Object)null;
		}
		AudioManager.Instance.PlayMusic(null, encounter: true);
		AudioManager.Instance.PlaySFX(music, AudioManager.MixerEnum.Encounter);
		FadeManager.Instance.FadeToBlack();
	}

	public override void OnClose()
	{
		base.OnClose();
	}

	private List<ItemStack> GetPartyItems(int inventoryIndex)
	{
		List<ItemStack> list = new List<ItemStack>();
		return ExplorationManager.Instance.GetPartyItems(m_partyId);
	}

	private List<ItemStack> GetNpcItems(int inventoryIndex)
	{
		return m_lootItems;
	}

	public void GetPartyMemberDetailsForTransfer(int inventoryIndex, out string personDisplayName, out string personSpriteName, out int maxSlots)
	{
		personDisplayName = Localization.Get("expedition.party.header") + " :";
		personSpriteName = string.Empty;
		maxSlots = 0;
		foreach (EncounterCharacter playerCharacter in m_playerCharacters)
		{
			if (!playerCharacter.partyMember.person.isDead)
			{
				personSpriteName = playerCharacter.partyMember.person.avatarSpriteName;
				maxSlots += playerCharacter.partyMember.GetLoadCarryingCapacity();
			}
		}
		Obj_CamperVan partyVehicle = ExplorationManager.Instance.GetPartyVehicle(m_partyId);
		if ((Object)(object)partyVehicle != (Object)null)
		{
			maxSlots = partyVehicle.maxInventorySlots;
		}
		Obj_Horse partyHorse = ExplorationManager.Instance.GetPartyHorse(m_partyId);
		if ((Object)(object)partyHorse != (Object)null)
		{
			maxSlots += partyHorse.maxInventorySlots;
		}
	}

	public void GetNpcDetailsForTransfer(int inventoryIndex, out string personDisplayName, out string personSpriteName, out int maxSlots)
	{
		personDisplayName = string.Empty;
		personSpriteName = string.Empty;
		maxSlots = Mathf.Max(50, m_lootItems.Count);
		EncounterCharacter leadNpc = EncounterManager.Instance.GetLeadNpc();
		if ((Object)(object)leadNpc != (Object)null)
		{
			personDisplayName = leadNpc.Name_Short + " :";
		}
	}

	private void PartyItemsChanged(int inventoryIndex, List<ItemStack> itemsAdded, List<ItemStack> itemsRemoved)
	{
		string text = string.Empty;
		string text2 = string.Empty;
		foreach (ItemStack item in itemsRemoved)
		{
			ExplorationManager.Instance.RemoveFromPartyItems(m_partyId, item.m_type, item.m_count);
			text2 = text2 + item.m_type.ToString() + ", ";
		}
		foreach (ItemStack item2 in itemsAdded)
		{
			ExplorationManager.Instance.AddToPartyItems(m_partyId, item2.m_type, item2.m_count);
			text = text + item2.m_type.ToString() + ", ";
		}
		Debug.Log((object)("Party  picked up : " + text));
		Debug.Log((object)("Party  left behind : " + text2));
		m_closePanel = true;
	}

	private void NpcItemsChanged(int inventoryIndex, List<ItemStack> itemsAdded, List<ItemStack> itemsRemoved)
	{
	}

	public override void OnSelect()
	{
		DismissMessage();
	}

	public override void OnCancel()
	{
		DismissMessage();
	}

	public override void OnExtra1()
	{
		DismissMessage();
	}

	public override void OnExtra2()
	{
		DismissMessage();
	}

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool DestroyOnClose()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override bool PausesGameInput()
	{
		return true;
	}
}
