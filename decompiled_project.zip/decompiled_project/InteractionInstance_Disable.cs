using UnityEngine;

public class InteractionInstance_Disable : InteractionInstance_Base
{
	protected override bool OnInteractionStarted()
	{
		if ((Object)(object)obj_base == (Object)null || !obj_base.IsEnabled())
		{
			return false;
		}
		if ((Object)(object)member != (Object)null)
		{
			member.TriggerAnim("Rummage");
		}
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled)
		{
			if ((Object)(object)obj_base != (Object)null)
			{
				obj_base.DisableObject();
			}
			Int_Disable int_Disable = base_interaction as Int_Disable;
			if ((Object)(object)int_Disable != (Object)null)
			{
				int_Disable.PlayDisableSound();
			}
		}
		return true;
	}
}
