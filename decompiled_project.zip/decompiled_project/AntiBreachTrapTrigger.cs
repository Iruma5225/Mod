using UnityEngine;

public class AntiBreachTrapTrigger : MonoBehaviour
{
	private Obj_AntiBreachTrap m_trap;

	public void Awake()
	{
		if ((Object)(object)((Component)this).transform.parent != (Object)null)
		{
			m_trap = ((Component)((Component)this).transform.parent).GetComponent<Obj_AntiBreachTrap>();
		}
	}

	public void OnTriggerEnter2D(Collider2D other)
	{
		if (!((Object)(object)((Component)this).GetComponent<MovementObject>() != (Object)null) && (Object)(object)m_trap != (Object)null && (Object)(object)other != (Object)null && ((Component)other).CompareTag("NPC"))
		{
			NpcVisitor component = ((Component)other).GetComponent<NpcVisitor>();
			if ((Object)(object)component != (Object)null)
			{
				m_trap.OnTrapTriggered(component);
			}
		}
	}
}
