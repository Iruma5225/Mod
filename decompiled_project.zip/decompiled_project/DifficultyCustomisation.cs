using System;
using System.Collections.Generic;
using UnityEngine;

public class DifficultyCustomisation : ClipboardPage
{
	[Serializable]
	public class DifficultySetting
	{
		public int rain = 1;

		public int resources = 1;

		public int breach = 1;

		public int faction = 1;

		public int mood = 1;

		public int mapSize;

		public bool fog;
	}

	[SerializeField]
	private UILabel DifficultyText;

	[SerializeField]
	private UILabel RainText;

	[SerializeField]
	private UILabel ResourcesText;

	[SerializeField]
	private UILabel BreachText;

	[SerializeField]
	private UILabel FactionText;

	[SerializeField]
	private UILabel MoodText;

	[SerializeField]
	private UILabel MapSizeText;

	[SerializeField]
	private UILabel FogText;

	[SerializeField]
	private UILabel LeaderboardNoticeText;

	public AudioClip buttonSound;

	[SerializeField]
	private GameObject m_focus_button;

	[SerializeField]
	private List<DifficultySetting> m_difficultyPresets = new List<DifficultySetting>();

	private int m_currentDifficulty = 1;

	private int m_currentRain = 1;

	private int m_currentResources = 1;

	private int m_currentBreach = 1;

	private int m_currentFaction = 1;

	private int m_currentMood = 1;

	private int m_currentMapSize;

	private bool m_currentFog;

	private int m_maxDifficulty = 3;

	private int m_maxRainSetting = 3;

	private int m_maxResourcesSetting = 3;

	private int m_maxBreachSetting = 3;

	private int m_maxFactionSetting = 3;

	private int m_maxMoodSetting = 3;

	private int m_maxMapSizeSetting = 2;

	private bool m_firstShow = true;

	public int currentRain => m_currentRain;

	public int currentResources => m_currentResources;

	public int currentBreach => m_currentBreach;

	public int currentFaction => m_currentFaction;

	public int currentMood => m_currentMood;

	public int currentMapSize => m_currentMapSize;

	public bool currentFog => m_currentFog;

	public void NextDifficulty()
	{
		if (m_currentDifficulty >= m_maxDifficulty)
		{
			m_currentDifficulty = 0;
		}
		else
		{
			m_currentDifficulty++;
		}
		UpdateDifficultyLabel();
		UpdateLeaderboardNoticeLabel();
		UpdateSettingsBasedOnCurrentDifficulty();
		PlayButtonSound();
	}

	public void PrevDifficulty()
	{
		if (m_currentDifficulty == 0)
		{
			m_currentDifficulty = m_maxDifficulty;
		}
		else
		{
			m_currentDifficulty--;
		}
		UpdateDifficultyLabel();
		UpdateLeaderboardNoticeLabel();
		UpdateSettingsBasedOnCurrentDifficulty();
		PlayButtonSound();
	}

	public void NextRainDifficulty()
	{
		if (m_currentRain == m_maxRainSetting)
		{
			m_currentRain = 0;
		}
		else
		{
			m_currentRain++;
		}
		UpdateRainLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	public void PrevRainDifficulty()
	{
		if (m_currentRain == 0)
		{
			m_currentRain = m_maxRainSetting;
		}
		else
		{
			m_currentRain--;
		}
		UpdateRainLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	public void NextResourceDifficulty()
	{
		if (m_currentResources == m_maxResourcesSetting)
		{
			m_currentResources = 0;
		}
		else
		{
			m_currentResources++;
		}
		UpdateResourcesLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	public void PrevResourceDifficulty()
	{
		if (m_currentResources == 0)
		{
			m_currentResources = m_maxResourcesSetting;
		}
		else
		{
			m_currentResources--;
		}
		UpdateResourcesLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	public void NextBreachDifficulty()
	{
		if (m_currentBreach == m_maxBreachSetting)
		{
			m_currentBreach = 0;
		}
		else
		{
			m_currentBreach++;
		}
		UpdateBreachLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	public void PrevBreachDifficulty()
	{
		if (m_currentBreach == 0)
		{
			m_currentBreach = m_maxBreachSetting;
		}
		else
		{
			m_currentBreach--;
		}
		UpdateBreachLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	public void NextFactionDifficulty()
	{
		if (m_currentFaction == m_maxFactionSetting)
		{
			m_currentFaction = 0;
		}
		else
		{
			m_currentFaction++;
		}
		UpdateFactionLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	public void PrevFactionDifficulty()
	{
		if (m_currentFaction == 0)
		{
			m_currentFaction = m_maxFactionSetting;
		}
		else
		{
			m_currentFaction--;
		}
		UpdateFactionLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	public void NextMoodDifficulty()
	{
		if (m_currentMood == m_maxMoodSetting)
		{
			m_currentMood = 0;
		}
		else
		{
			m_currentMood++;
		}
		UpdateMoodLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	public void PrevMoodDifficulty()
	{
		if (m_currentMood == 0)
		{
			m_currentMood = m_maxMoodSetting;
		}
		else
		{
			m_currentMood--;
		}
		UpdateMoodLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	public void NextMapSize()
	{
		if (m_currentMapSize == m_maxMapSizeSetting)
		{
			m_currentMapSize = 0;
		}
		else
		{
			m_currentMapSize++;
		}
		UpdateMapSizeLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	public void PrevMapSize()
	{
		if (m_currentMapSize == 0)
		{
			m_currentMapSize = m_maxMapSizeSetting;
		}
		else
		{
			m_currentMapSize--;
		}
		UpdateMapSizeLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	public void NextFogDifficulty()
	{
		m_currentFog = !m_currentFog;
		UpdateFogLabel();
		CheckForCustomDifficulty();
		PlayButtonSound();
	}

	private void UpdateDifficultyLabel()
	{
		if ((Object)(object)DifficultyText != (Object)null)
		{
			switch (m_currentDifficulty)
			{
			case 0:
				DifficultyText.text = Localization.Get("ui.difficulty.difficultyeasy");
				break;
			case 1:
				DifficultyText.text = Localization.Get("ui.difficulty.difficultynormal");
				break;
			case 2:
				DifficultyText.text = Localization.Get("ui.difficulty.difficultyhard");
				break;
			case 3:
				DifficultyText.text = Localization.Get("ui.difficulty.difficultyhardcore");
				break;
			case 4:
				DifficultyText.text = Localization.Get("ui.difficulty.difficultycustom");
				break;
			}
		}
	}

	private void UpdateRainLabel()
	{
		if ((Object)(object)RainText != (Object)null)
		{
			switch (m_currentRain)
			{
			case 0:
				RainText.text = Localization.Get("ui.difficulty.raineasy");
				break;
			case 1:
				RainText.text = Localization.Get("ui.difficulty.rainnormal");
				break;
			case 2:
				RainText.text = Localization.Get("ui.difficulty.rainhard");
				break;
			case 3:
				RainText.text = Localization.Get("ui.difficulty.rainhardcore");
				break;
			}
		}
	}

	private void UpdateResourcesLabel()
	{
		if ((Object)(object)ResourcesText != (Object)null)
		{
			switch (m_currentResources)
			{
			case 0:
				ResourcesText.text = Localization.Get("ui.difficulty.resourceseasy");
				break;
			case 1:
				ResourcesText.text = Localization.Get("ui.difficulty.resourcesnormal");
				break;
			case 2:
				ResourcesText.text = Localization.Get("ui.difficulty.resourceshard");
				break;
			case 3:
				ResourcesText.text = Localization.Get("ui.difficulty.resourceshardcore");
				break;
			}
		}
	}

	private void UpdateBreachLabel()
	{
		if ((Object)(object)BreachText != (Object)null)
		{
			switch (m_currentBreach)
			{
			case 0:
				BreachText.text = Localization.Get("ui.difficulty.breacheasy");
				break;
			case 1:
				BreachText.text = Localization.Get("ui.difficulty.breachnormal");
				break;
			case 2:
				BreachText.text = Localization.Get("ui.difficulty.breachhard");
				break;
			case 3:
				BreachText.text = Localization.Get("ui.difficulty.breachhardcore");
				break;
			}
		}
	}

	private void UpdateFactionLabel()
	{
		if ((Object)(object)FactionText != (Object)null)
		{
			switch (m_currentFaction)
			{
			case 0:
				FactionText.text = Localization.Get("ui.difficulty.factioneasy");
				break;
			case 1:
				FactionText.text = Localization.Get("ui.difficulty.factionnormal");
				break;
			case 2:
				FactionText.text = Localization.Get("ui.difficulty.factionhard");
				break;
			case 3:
				FactionText.text = Localization.Get("ui.difficulty.factionhardcore");
				break;
			}
		}
	}

	private void UpdateMoodLabel()
	{
		if ((Object)(object)MoodText != (Object)null)
		{
			switch (m_currentMood)
			{
			case 0:
				MoodText.text = Localization.Get("ui.difficulty.moodeasy");
				break;
			case 1:
				MoodText.text = Localization.Get("ui.difficulty.moodnormal");
				break;
			case 2:
				MoodText.text = Localization.Get("ui.difficulty.moodhard");
				break;
			case 3:
				MoodText.text = Localization.Get("ui.difficulty.moodhardcore");
				break;
			}
		}
	}

	private void UpdateMapSizeLabel()
	{
		if ((Object)(object)MapSizeText != (Object)null)
		{
			switch (m_currentMapSize)
			{
			case 0:
				MapSizeText.text = Localization.Get("ui.difficulty.mapsizenormal");
				break;
			case 1:
				MapSizeText.text = Localization.Get("ui.difficulty.mapsizehard");
				break;
			case 2:
				MapSizeText.text = Localization.Get("ui.difficulty.mapsizehardcore");
				break;
			}
		}
	}

	private void UpdateFogLabel()
	{
		if ((Object)(object)FogText != (Object)null)
		{
			if (m_currentFog)
			{
				FogText.text = Localization.Get("ui.difficulty.fogon");
			}
			else
			{
				FogText.text = Localization.Get("ui.difficulty.fogoff");
			}
		}
	}

	private void UpdateLeaderboardNoticeLabel()
	{
		if ((Object)(object)LeaderboardNoticeText != (Object)null)
		{
			if (m_currentDifficulty == 0 || m_currentDifficulty == 4)
			{
				((Component)LeaderboardNoticeText).gameObject.SetActive(true);
			}
			else
			{
				((Component)LeaderboardNoticeText).gameObject.SetActive(false);
			}
		}
	}

	private void UpdateAllSettingsLabels()
	{
		UpdateRainLabel();
		UpdateResourcesLabel();
		UpdateBreachLabel();
		UpdateFactionLabel();
		UpdateMoodLabel();
		UpdateMapSizeLabel();
		UpdateFogLabel();
		UpdateLeaderboardNoticeLabel();
	}

	private void UpdateSettingsBasedOnCurrentDifficulty()
	{
		if (m_difficultyPresets.Count > 0)
		{
			m_currentRain = m_difficultyPresets[m_currentDifficulty].rain;
			m_currentResources = m_difficultyPresets[m_currentDifficulty].resources;
			m_currentBreach = m_difficultyPresets[m_currentDifficulty].breach;
			m_currentFaction = m_difficultyPresets[m_currentDifficulty].faction;
			m_currentMood = m_difficultyPresets[m_currentDifficulty].mood;
			m_currentMapSize = m_difficultyPresets[m_currentDifficulty].mapSize;
			m_currentFog = m_difficultyPresets[m_currentDifficulty].fog;
			UpdateAllSettingsLabels();
		}
	}

	private void CheckForCustomDifficulty()
	{
		int num = m_currentRain;
		if (m_difficultyPresets.Count > 0)
		{
			if (m_currentBreach != m_difficultyPresets[num].breach || m_currentResources != m_difficultyPresets[num].resources || m_currentFaction != m_difficultyPresets[num].faction || m_currentMood != m_difficultyPresets[num].mood || m_currentMapSize != m_difficultyPresets[num].mapSize || m_currentFog != m_difficultyPresets[num].fog)
			{
				m_currentDifficulty = 4;
			}
			else if (m_currentDifficulty != num)
			{
				m_currentDifficulty = num;
			}
			UpdateDifficultyLabel();
			UpdateLeaderboardNoticeLabel();
		}
	}

	public override void OnShowPage()
	{
		if ((Object)(object)m_focus_button != (Object)null)
		{
			UICamera.selectedObject = m_focus_button;
		}
		base.OnShowPage();
		UpdateAllSettingsLabels();
		UpdateDifficultyLabel();
		UpdateLeaderboardNoticeLabel();
	}

	public void PlayButtonSound()
	{
		if ((Object)(object)buttonSound != (Object)null)
		{
			UISound.instance.Play(buttonSound);
		}
	}
}
