using System;
using System.Collections.Generic;
using UnityEngine;

public class ExplorationParty : MonoBehaviour, ISaveable
{
	public enum ePartyState
	{
		None,
		GettingReady,
		LeavingShelter,
		VehicleLeaving,
		Traveling,
		ReportingLocation,
		ReportingLocationWaitUser,
		ReportingDiversionsStart,
		ReportingDiversions,
		ReportingDiversionsWaitUser,
		SearchingLocation,
		EncounteredItemsStart,
		EncounteredItems,
		EncounteredItemsWaitUser,
		EncounteredItemsRequestTransferPanel,
		EncounteredItemsWaitItemTransfer,
		EncounteredNPCsStart,
		EncounteredNPCs,
		EncounteredNPCsWaitUser,
		EncounteredNPCsRequestNewEncounter,
		EncounteredNPCsWaitFinished,
		EncounteredNPCsAutoResolve,
		OpenGroundNpcEncounterStart,
		OpenGroundNpcEncounter,
		OpenGroundNpcEncounterWaitUser,
		OpenGroundNpcEncounterRequestNewEncounter,
		OpenGroundNpcEncounterWaitFinished,
		OpenGroundNpcEncounterAutoResolve,
		QuestEncounterStart,
		QuestEncounterWaitFinished,
		VehicleReturning,
		EnteringShelter,
		ReturnedShowExperienceGained,
		ReturnedRequestTransferPanel,
		ReturnedWaitItemTransfer,
		Finished,
		EncounteredQuestNPCs,
		EncounteredQuestNPCsWaitUser,
		HorseLeaving,
		HorseReturning,
		EnteringShelterNextUpdate
	}

	private delegate void UpdateFunc();

	private struct StateDef
	{
		public ePartyState state;

		public UpdateFunc updateFunc;
	}

	public const int kInvalidPartyId = -1;

	public bool allowDiversions = true;

	public int remainingDiversions = 1;

	private readonly float m_defaultSightRange = 2f;

	private readonly float m_sightRangeWithBinoculars = 4f;

	private float m_sightRange;

	private float m_perception;

	private readonly float m_defaultPerception = 60f;

	private Stack<StateDef> m_stateStack = new Stack<StateDef>();

	[SerializeField]
	private List<PartyMember> m_partyMembers = new List<PartyMember>();

	private int m_id = -1;

	[SerializeField]
	public Vector2 m_location = Vector2.zero;

	private List<Vector2> m_route = new List<Vector2>();

	private int m_lastWaypoint;

	private int m_currWaypoint;

	[SerializeField]
	private float m_travelSpeed = 0.75f;

	private float m_speedModifier = 1f;

	[SerializeField]
	private float m_waypointDistance;

	[SerializeField]
	private float m_waypointProgress;

	[SerializeField]
	private float m_water;

	private float m_waterContamination;

	private Obj_CamperVan m_vehicle;

	[SerializeField]
	private float m_petrol;

	private Obj_Horse m_horse;

	private CompanionAnimal m_pet;

	private Vector2 m_currentLeg = Vector2.zero;

	private MapRegion m_currentRegion;

	private List<MapRegion> m_nearbyDiversions = new List<MapRegion>();

	private List<ExpeditionMap.GridRef> m_visitedThisTrip = new List<ExpeditionMap.GridRef>();

	private List<string> m_searchedThisTrip = new List<string>();

	private bool m_encounteredNpcsThisTrip;

	private ExplorationManager.RadioDialogParams m_radioParams;

	private RadioDialogPanel.RadioResponse m_radioResponse;

	private int m_membersReadyCount;

	private bool m_petReady;

	private MapRegion m_diversionRegion;

	private int m_diversionEndWaypoint = -1;

	private float m_timer;

	private float m_distanceTraveled;

	private float m_distanceUntilOGEncounter;

	private float m_waterUsePerWorldUnit;

	private float m_petrolUsePerWorldUnit;

	private int m_searchExperienceGained;

	private bool m_isRecalled;

	private bool m_itemTransferComplete;

	private bool m_openGroundEncounterIsAnimal;

	private bool m_experienceDisplayComplete;

	private bool m_participatedInCombat;

	private bool m_partyReturning;

	private bool m_waitingToReturn;

	private bool m_partyWalkingToShelter;

	private bool m_waitingToRadio;

	private int m_factionId = -1;

	private List<ItemGrid.ItemSlot> m_carriedItems = new List<ItemGrid.ItemSlot>();

	private string m_encounteredStorm = string.Empty;

	private bool repelAnimal;

	private bool m_EncounterIsPlayerControlled;

	public int membersCount => m_partyMembers.Count;

	public int id
	{
		get
		{
			return m_id;
		}
		set
		{
			if (m_id != -1)
			{
				throw new Exception("Trying to change a party id that has already been set");
			}
			m_id = value;
		}
	}

	public ePartyState state => (m_stateStack.Count > 0) ? m_stateStack.Peek().state : ePartyState.None;

	public Vector2 location => m_location;

	public bool hasRoute => m_route.Count > 0;

	public bool isDiverting => m_diversionEndWaypoint != -1;

	public bool isRecalled => m_isRecalled;

	private bool inVehicle => (Object)(object)m_vehicle != (Object)null;

	private bool onHorse => (Object)(object)m_horse != (Object)null;

	private bool hasPet => (Object)(object)m_pet != (Object)null;

	public MapRegion currentRegion => m_currentRegion;

	public int searchExperience => m_searchExperienceGained;

	public int locationsSearched => m_searchedThisTrip.Count;

	public float sightRange => m_sightRange;

	public float perception => m_perception;

	public bool isReturning => m_partyReturning;

	public bool isWalkingToShelter => m_partyWalkingToShelter;

	public string EncounteredStorm => m_encounteredStorm;

	private void Awake()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		m_location = Vector2.zero;
		m_perception = m_defaultPerception;
		m_sightRange = m_defaultSightRange;
		if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading)
		{
			PushState(ePartyState.GettingReady);
		}
	}

	private void UpdatePerceptionValue()
	{
		bool flag = false;
		int num = 0;
		for (int i = 0; i < m_partyMembers.Count; i++)
		{
			if (!((Object)(object)m_partyMembers[i] != (Object)null))
			{
				continue;
			}
			int num2 = (((Object)(object)m_partyMembers[i].person != (Object)null) ? m_partyMembers[i].person.BaseStats.Perception.Level : 0);
			if (num2 > num)
			{
				num = num2;
			}
			if (flag)
			{
				continue;
			}
			List<ItemStack> equippedItems = m_partyMembers[i].GetEquippedItems();
			if (equippedItems == null)
			{
				continue;
			}
			for (int j = 0; j < equippedItems.Count; j++)
			{
				if (equippedItems[j].m_type == ItemManager.ItemType.MetalDetector)
				{
					flag = true;
					break;
				}
			}
		}
		m_perception = m_defaultPerception + (float)num;
		if (flag)
		{
			m_perception += 20f;
		}
		if (hasPet && m_pet.m_type == FamilySpawner.PetType.Dog)
		{
			m_perception += 10f;
		}
		m_perception = Mathf.Min(m_perception, 100f);
	}

	private void UpdateSightRangeValue()
	{
		bool flag = false;
		for (int i = 0; i < m_partyMembers.Count; i++)
		{
			if (!((Object)(object)m_partyMembers[i] != (Object)null))
			{
				continue;
			}
			List<ItemStack> equippedItems = m_partyMembers[i].GetEquippedItems();
			if (equippedItems == null)
			{
				continue;
			}
			for (int j = 0; j < equippedItems.Count; j++)
			{
				if (equippedItems[j].m_type == ItemManager.ItemType.Binoculars)
				{
					flag = true;
					break;
				}
			}
			if (flag)
			{
				break;
			}
		}
		m_sightRange = ((!flag) ? m_defaultSightRange : m_sightRangeWithBinoculars);
	}

	public void Start()
	{
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
	}

	private void Update()
	{
		if (m_stateStack.Count > 0)
		{
			StateDef stateDef = m_stateStack.Peek();
			if (stateDef.updateFunc != null)
			{
				stateDef.updateFunc();
			}
		}
	}

	private void OnDestroy()
	{
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.UnregisterSaveable(this);
		}
	}

	public bool AddMember(PartyMember member)
	{
		if ((Object)(object)member != (Object)null)
		{
			member.partyId = m_id;
			m_partyMembers.Add(member);
			return true;
		}
		return false;
	}

	public bool RemoveMember(PartyMember member)
	{
		if ((Object)(object)member != (Object)null)
		{
			member.partyId = -1;
			return m_partyMembers.Remove(member);
		}
		return false;
	}

	public bool ContainsFamilyMember(FamilyMember person)
	{
		foreach (PartyMember partyMember in m_partyMembers)
		{
			if ((Object)(object)partyMember.person == (Object)(object)person)
			{
				return true;
			}
		}
		return false;
	}

	public PartyMember GetMember(int index)
	{
		if (index < membersCount)
		{
			return m_partyMembers[index];
		}
		return null;
	}

	public IList<Vector2> GetRoute()
	{
		return m_route.AsReadOnly();
	}

	public void SetRoute(List<Vector2> waypoints)
	{
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		m_route = new List<Vector2>(waypoints);
		if (m_route.Count > 0)
		{
			Vector2 val = m_route[0];
			if (((Vector2)(ref val)).magnitude > Mathf.Epsilon)
			{
				m_route.Insert(0, new Vector2(0f, 0f));
			}
			if (Vector2.Distance(m_route[0], m_route[m_route.Count - 1]) > Mathf.Epsilon)
			{
				m_route.Add(new Vector2(0f, 0f));
			}
		}
		m_lastWaypoint = 0;
		m_currWaypoint = 0;
		m_currentLeg = Vector2.zero;
		m_location = Vector2.zero;
		m_currentRegion = ExpeditionMap.Instance.GetRegionInWorld(m_location);
	}

	public float GetWater(out float contamination)
	{
		contamination = m_waterContamination;
		return m_water;
	}

	public void SetWater(float waterAmount, float contamination)
	{
		m_water = waterAmount;
		m_waterContamination = contamination;
	}

	public Obj_CamperVan GetVehicle()
	{
		return m_vehicle;
	}

	public void SetVehicle(Obj_CamperVan vehicle)
	{
		m_vehicle = vehicle;
	}

	public Obj_Horse GetHorse()
	{
		return m_horse;
	}

	public void SetHorse(Obj_Horse horse)
	{
		m_horse = horse;
	}

	public CompanionAnimal GetPet()
	{
		return m_pet;
	}

	public void SetPet(CompanionAnimal pet)
	{
		m_pet = pet;
	}

	public float GetPetrol()
	{
		return m_petrol;
	}

	public void SetPetrol(int amount)
	{
		m_petrol = amount;
	}

	public void SetBeenInCombat(bool state)
	{
		m_participatedInCombat = state;
	}

	public bool HasBeenInCombat()
	{
		return m_participatedInCombat;
	}

	public float GetDistanceTravelled()
	{
		return m_distanceTraveled;
	}

	public int GetMaxCarriedItems()
	{
		int num = 0;
		foreach (PartyMember partyMember in m_partyMembers)
		{
			num += partyMember.GetLoadCarryingCapacity();
		}
		if ((Object)(object)m_vehicle != (Object)null)
		{
			num = m_vehicle.maxInventorySlots;
		}
		else if ((Object)(object)m_horse != (Object)null)
		{
			num += m_horse.maxInventorySlots;
		}
		return num;
	}

	public bool AddToCarriedItems(ItemManager.ItemType itemType, int count)
	{
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(itemType);
		int maxCarriedItems = GetMaxCarriedItems();
		int num = -1;
		for (int i = 0; i < m_carriedItems.Count; i++)
		{
			if (m_carriedItems[i].m_type == itemType)
			{
				num = i;
				break;
			}
		}
		if (num == -1)
		{
			if (m_carriedItems.Count >= maxCarriedItems)
			{
				return false;
			}
			ItemGrid.ItemSlot itemSlot = new ItemGrid.ItemSlot();
			itemSlot.m_type = itemType;
			itemSlot.m_count = 0;
			itemSlot.m_stackSize = itemDefinition.StackSize;
			m_carriedItems.Add(itemSlot);
			num = m_carriedItems.Count - 1;
		}
		int num2 = count;
		while (num2 > 0)
		{
			ItemGrid.ItemSlot itemSlot2 = m_carriedItems[num];
			if (itemSlot2.m_stackSize <= 0)
			{
				itemSlot2.m_count += num2;
				num2 = 0;
			}
			else
			{
				int num3 = Mathf.Min(num2, itemSlot2.m_stackSize - itemSlot2.m_count);
				itemSlot2.m_count += num3;
				num2 -= num3;
			}
			if (num2 <= 0 || itemSlot2.m_count != itemSlot2.m_stackSize)
			{
				continue;
			}
			if (num >= m_carriedItems.Count - 1 || m_carriedItems[num + 1].m_type != itemType)
			{
				if (m_carriedItems.Count >= maxCarriedItems)
				{
					return false;
				}
				int num4 = m_carriedItems.Count;
				if (num < m_carriedItems.Count - 1)
				{
					num4 = num + 1;
				}
				ItemGrid.ItemSlot itemSlot3 = new ItemGrid.ItemSlot();
				itemSlot3.m_type = itemType;
				itemSlot3.m_stackSize = itemDefinition.StackSize;
				itemSlot3.m_count = 0;
				m_carriedItems.Insert(num4, itemSlot3);
				num = num4;
			}
			else
			{
				num++;
			}
		}
		return true;
	}

	public int RemoveFromCarriedItems(ItemManager.ItemType type, int count)
	{
		int num = count;
		int num2 = m_carriedItems.Count - 1;
		while (num2 >= 0 && num > 0)
		{
			if (m_carriedItems[num2].m_type == type)
			{
				int num3 = Mathf.Min(m_carriedItems[num2].m_count, num);
				m_carriedItems[num2].m_count -= num3;
				num -= num3;
				if (m_carriedItems[num2].m_count == 0)
				{
					m_carriedItems.RemoveAt(num2);
				}
			}
			num2--;
		}
		return count - num;
	}

	public List<ItemStack> GetCarriedItems()
	{
		List<ItemStack> list = new List<ItemStack>();
		foreach (ItemGrid.ItemSlot carriedItem in m_carriedItems)
		{
			ItemStack item = new ItemStack(carriedItem.m_type, carriedItem.m_count);
			list.Add(item);
		}
		return list;
	}

	public bool HasCarriedItem(ItemManager.ItemType item)
	{
		foreach (ItemGrid.ItemSlot carriedItem in m_carriedItems)
		{
			if (carriedItem.m_type == item && carriedItem.m_count > 0)
			{
				return true;
			}
		}
		return false;
	}

	public bool BeginExploring()
	{
		if (state != ePartyState.GettingReady)
		{
			return false;
		}
		if (!hasRoute)
		{
			return false;
		}
		foreach (PartyMember partyMember in m_partyMembers)
		{
			partyMember.person.isAway = true;
		}
		m_encounteredNpcsThisTrip = false;
		m_searchedThisTrip.Clear();
		Begin_LeavingShelter();
		return true;
	}

	public void RecallToShelter()
	{
		m_isRecalled = true;
	}

	public void OnShelterLeft(FamilyMember member)
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		if (inVehicle)
		{
			List<GameObject> offScreenNodes = ExplorationManager.Instance.offScreenNodes;
			if (m_membersReadyCount >= 0 && m_membersReadyCount < offScreenNodes.Count)
			{
				((Component)member).transform.position = offScreenNodes[m_membersReadyCount].transform.position;
			}
		}
		m_membersReadyCount++;
		member.job_queue.ForceClear();
		member.ai_queue.ForceClear();
	}

	public void OnShelterEntered(FamilyMember member)
	{
		m_membersReadyCount++;
		member.job_queue.ForceClear();
		member.ai_queue.ForceClear();
	}

	public void OnShelterLeft(CompanionAnimal pet)
	{
		m_petReady = true;
	}

	public void OnShelterEntered(CompanionAnimal pet)
	{
		m_petReady = true;
	}

	public void OnExerienceDisplayComplete()
	{
		m_experienceDisplayComplete = true;
	}

	private void AdvanceCurrentWaypoint()
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		if (m_currWaypoint < m_route.Count - 1)
		{
			m_lastWaypoint = m_currWaypoint;
			m_currWaypoint++;
			if (m_lastWaypoint == m_diversionEndWaypoint)
			{
				m_diversionEndWaypoint = -1;
			}
			m_currentLeg = m_route[m_currWaypoint] - m_route[m_lastWaypoint];
			m_waypointDistance = ((Vector2)(ref m_currentLeg)).magnitude;
			m_waypointProgress = 0f;
		}
	}

	private void OnEnteredRegion(ExpeditionMap.GridRef gridRef)
	{
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		MapRegion regionOnMap = ExpeditionMap.Instance.GetRegionOnMap(gridRef);
		if ((Object)(object)regionOnMap == (Object)null)
		{
			return;
		}
		m_currentRegion = regionOnMap;
		if (!m_currentRegion.discovered)
		{
			m_currentRegion.discovered = true;
			if (m_currentRegion.topography == MapRegion.Topography.NowhereSpecial)
			{
			}
		}
		else if (m_currentRegion.topography == MapRegion.Topography.NowhereSpecial)
		{
		}
		m_currentRegion.OnVisited();
		m_factionId = -1;
		if ((Object)(object)ExplorationManager.Instance != (Object)null && (Object)(object)ExpeditionMap.Instance != (Object)null && (Object)(object)FactionMan.instance != (Object)null)
		{
			Vector2 mapPos = ExplorationManager.Instance.WorldToMapPixels(ExpeditionMap.Instance.GridRefToWorldPos(m_currentRegion.gridReference));
			int zoneId = -1;
			if (FactionMan.instance.IsFactionTerritory(mapPos, out m_factionId, out zoneId) && zoneId > -1 && m_factionId > -1)
			{
				FactionMan.instance.RevealFactionZone(zoneId);
				m_distanceUntilOGEncounter = Mathf.Min(m_distanceUntilOGEncounter, EncounterManager.Instance.distanceUntilNextFactionEncounter * ExplorationManager.Instance.worldUnitsPerMile);
			}
			else
			{
				m_factionId = -1;
			}
		}
		bool flag = false;
		if (m_currentRegion.topography != MapRegion.Topography.NowhereSpecial && m_visitedThisTrip.Find((ExpeditionMap.GridRef x) => x.isEqualTo(m_currentRegion.gridReference)) != null)
		{
			flag = true;
		}
		List<MapRegion> undiscoveredRegionsInSightRange = GetUndiscoveredRegionsInSightRange();
		m_nearbyDiversions.Clear();
		bool flag2 = allowDiversions && remainingDiversions > 0 && !isDiverting && !m_isRecalled;
		foreach (MapRegion item in undiscoveredRegionsInSightRange)
		{
			if (flag2 && !item.isVisibleOnMap && item.isSearchable)
			{
				Vector2 zero = Vector2.zero;
				zero.x = item.gridReference.x - m_currentRegion.gridReference.x;
				zero.y = item.gridReference.y - m_currentRegion.gridReference.y;
				float num = Vector2.Angle(m_currentLeg, zero);
				if ((double)num > 45.0)
				{
					m_nearbyDiversions.Add(item);
				}
			}
			item.SetShownOnMap(shown: true);
		}
		if (m_nearbyDiversions.Count > 0)
		{
			PushState(ePartyState.ReportingDiversionsStart);
		}
		if ((Object)(object)m_currentRegion != (Object)null && m_currentRegion.questInstanceId == -1 && (Object)(object)QuestManager.instance != (Object)null && QuestManager.instance.GetNumActiveFloatingQuests() > 0)
		{
			QuestManager.instance.SpawnFloatingQuest(m_currentRegion);
		}
		bool flag3 = false;
		if (!flag && m_currentRegion.questInstanceId > -1 && (Object)(object)QuestManager.instance != (Object)null)
		{
			QuestInstance questInstance = QuestManager.instance.GetQuestInstance(m_currentRegion.questInstanceId);
			if (questInstance != null && questInstance.IsActive() && questInstance.definition is QuestDef questDef && questDef.encounterStages.Count > 0)
			{
				flag3 = true;
				PushState(ePartyState.EncounteredQuestNPCs);
			}
		}
		if (flag3 || flag)
		{
			return;
		}
		if (m_currentRegion.isSearchable)
		{
			if (m_currentRegion.isEqualTo(m_diversionRegion))
			{
				Begin_SearchingLocation();
			}
			else
			{
				Begin_ReportingLocation();
			}
		}
		else if (OpenGroundEncounterCheck() && EncounterManager.Instance.CanHaveEncounter() && m_currentRegion.topography != MapRegion.Topography.HelicopterCrashSite && m_currentRegion.topography != MapRegion.Topography.ConvoyCrashSite)
		{
			PushState(ePartyState.OpenGroundNpcEncounterStart);
		}
	}

	private void OnLeftRegion(ExpeditionMap.GridRef gridRef)
	{
		MapRegion regionOnMap = ExpeditionMap.Instance.GetRegionOnMap(gridRef);
		if ((Object)(object)regionOnMap != (Object)null && regionOnMap.topography != MapRegion.Topography.NowhereSpecial && m_visitedThisTrip.Find((ExpeditionMap.GridRef x) => x.isEqualTo(gridRef)) == null)
		{
			m_visitedThisTrip.Add(gridRef);
		}
	}

	private List<MapRegion> GetUndiscoveredRegionsInSightRange()
	{
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		List<MapRegion> list = new List<MapRegion>();
		int num = Mathf.CeilToInt(sightRange);
		int num2 = Mathf.Max(0, m_currentRegion.gridReference.x - num);
		int num3 = Mathf.Max(0, m_currentRegion.gridReference.y - num);
		int num4 = Mathf.Min(ExpeditionMap.Instance.width - 1, m_currentRegion.gridReference.x + num);
		int num5 = Mathf.Min(ExpeditionMap.Instance.height - 1, m_currentRegion.gridReference.y + num);
		for (int i = num3; i <= num5; i++)
		{
			for (int j = num2; j <= num4; j++)
			{
				MapRegion regionOnMap = ExpeditionMap.Instance.GetRegionOnMap(new ExpeditionMap.GridRef(j, i));
				if (!regionOnMap.discovered && regionOnMap.topography != MapRegion.Topography.NowhereSpecial)
				{
					Vector2 zero = Vector2.zero;
					zero.x = regionOnMap.gridReference.x - m_currentRegion.gridReference.x;
					zero.y = regionOnMap.gridReference.y - m_currentRegion.gridReference.y;
					if (((Vector2)(ref zero)).magnitude <= sightRange)
					{
						list.Add(regionOnMap);
					}
				}
			}
		}
		return list;
	}

	private void CreateRadioDialogParametersForQuery(string queryType)
	{
		m_radioParams = new ExplorationManager.RadioDialogParams();
		if (m_partyMembers.Count > 1)
		{
			m_radioParams.questionTextId = "Radio." + queryType + ".Plural.Question";
		}
		else
		{
			m_radioParams.questionTextId = "Radio." + queryType + ".Singular.Question";
		}
		m_radioParams.callback = OnRadioResponseRecieved;
		m_radioParams.answer1TextId = "Radio." + queryType + ".Answer.Positive";
		m_radioParams.answer2TextId = "Radio." + queryType + ".Answer.Negative";
		m_radioParams.response1TextId = "Radio." + queryType + ".Response.Positive";
		m_radioParams.response2TextId = "Radio." + queryType + ".Response.Negative";
		m_radioParams.subjectTextId = string.Empty;
		m_radioParams.indefSubjectTextId = string.Empty;
		m_radioParams.acceptButtonTextId = "Radio." + queryType + ".Accept";
		m_radioParams.rejectButtonTextId = "Radio." + queryType + ".Reject";
		int index = Random.Range(0, m_partyMembers.Count);
		m_radioParams.caller = m_partyMembers[index].person;
		for (int i = 0; i < InteractionManager.Instance.GetNumFamilyMembers(); i++)
		{
			FamilyMember familyMemberByIndex = InteractionManager.Instance.GetFamilyMemberByIndex(i);
			if (!familyMemberByIndex.isAway)
			{
				m_radioParams.receiver = familyMemberByIndex;
				break;
			}
		}
	}

	private void OnRadioResponseRecieved(RadioDialogPanel.RadioResponse response)
	{
		Debug.Log((object)("Party got a radio response of " + response));
		m_radioResponse = response;
	}

	public List<ItemStack> GetPartyItemsForTransfer(int inventoryIndex)
	{
		return GetCarriedItems();
	}

	public void GetPartyMemberDetailsForTransfer(int inventoryIndex, out string personDisplayName, out string personSpriteName, out int maxSlots)
	{
		personDisplayName = string.Empty;
		personSpriteName = string.Empty;
		maxSlots = 0;
		personDisplayName = Localization.Get("expedition.party.header") + " :";
		personSpriteName = m_partyMembers[0].person.avatarSpriteName;
		maxSlots = GetMaxCarriedItems();
	}

	public void GetRegionDetailsForTransfer(int inventoryIndex, out string regionDisplayName, out string regionSpriteName, out int maxSlots)
	{
		regionDisplayName = string.Empty;
		regionSpriteName = string.Empty;
		maxSlots = 0;
		regionDisplayName = m_currentRegion.GetLocalisedName() + " :";
		maxSlots = m_currentRegion.maxItemSlots;
	}

	public void ItemTransferResult(int inventoryIndex, List<ItemStack> itemsAdded, List<ItemStack> itemsRemoved)
	{
		m_itemTransferComplete = true;
		string text = string.Empty;
		string text2 = string.Empty;
		foreach (ItemStack item in itemsRemoved)
		{
			RemoveFromCarriedItems(item.m_type, item.m_count);
			text2 = text2 + item.m_type.ToString() + ", ";
		}
		foreach (ItemStack item2 in itemsAdded)
		{
			AddToCarriedItems(item2.m_type, item2.m_count);
			text = text + item2.m_type.ToString() + ", ";
		}
		Debug.Log((object)("Party  picked up : " + text));
		Debug.Log((object)("Party  left behind : " + text2));
	}

	private void DeteriorateStatsFromTravel(float distanceWorldUnits)
	{
		if ((Object)(object)ExplorationManager.Instance == (Object)null)
		{
			return;
		}
		float num = distanceWorldUnits / ExplorationManager.Instance.worldUnitsPerMile;
		float num2 = 1f;
		if (PartyHasBedRoll())
		{
			num2 -= 0.25f;
		}
		if (PartyHasTent())
		{
			num2 -= 0.5f;
		}
		float change = ExplorationManager.Instance.fatiguePerMile * num * num2;
		float change2 = ExplorationManager.Instance.dirtinessPerMile * num * num2;
		float num3 = ExplorationManager.Instance.hungerPerMile * num * num2;
		float change3 = ExplorationManager.Instance.toiletPerMile * num * num2;
		foreach (PartyMember partyMember in m_partyMembers)
		{
			partyMember.person.stats.fatigue.Modify(change);
			partyMember.person.stats.dirtiness.Modify(change2);
			partyMember.person.stats.toilet.Modify(change3);
			if (partyMember.person.stats.hunger.Value + num3 <= ExplorationManager.Instance.maxHungerWhileExploring)
			{
				partyMember.person.stats.hunger.Modify(num3);
			}
		}
	}

	private bool RemoveDeadPartyMembers()
	{
		for (int num = m_partyMembers.Count - 1; num >= 0; num--)
		{
			if (m_partyMembers[num].person.isDead)
			{
				m_partyMembers.RemoveAt(num);
			}
		}
		if (hasPet && m_pet.isDead)
		{
			m_pet = null;
		}
		if (m_partyMembers.Count == 0)
		{
			if ((Object)(object)AchievementManager.instance != (Object)null)
			{
				AchievementManager.instance.OnExpeditionOver(id);
			}
			m_stateStack.Clear();
			ExplorationManager.Instance.DisbandExplorationParty(m_id);
			LoseVehicle();
			DismissPet();
			DismissHorse();
			return true;
		}
		return false;
	}

	private void LoseVehicle()
	{
		if (inVehicle)
		{
			m_vehicle.OnExpeditionLost();
			m_vehicle = null;
		}
	}

	private void DismissPet()
	{
		if (hasPet)
		{
			m_pet.ReturnToShelter(GetDistanceFromShelter() * m_travelSpeed);
			m_pet = null;
		}
	}

	private void DismissHorse()
	{
		if (onHorse)
		{
			m_horse.ReturnToShelter(GetDistanceFromShelter() * m_travelSpeed);
			m_horse = null;
		}
	}

	public void AddVehicleDuringExpedition(Obj_CamperVan vehicle)
	{
		m_vehicle = vehicle;
		DismissHorse();
		m_travelSpeed = m_vehicle.TravelSpeed;
	}

	public float GetDistanceFromShelter()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		return Vector3.Distance(Vector2.op_Implicit(m_location), Vector2.op_Implicit(m_route[m_route.Count - 1])) / ExplorationManager.Instance.worldUnitsPerMile;
	}

	public float GetTimeToReturn()
	{
		return GetDistanceFromShelter() * m_travelSpeed;
	}

	private bool OpenGroundEncounterCheck()
	{
		bool flag = m_factionId > -1;
		if (inVehicle)
		{
			return false;
		}
		if (m_distanceUntilOGEncounter > Mathf.Epsilon)
		{
			return false;
		}
		float num = ((Vector2)(ref m_location)).magnitude / ExplorationManager.Instance.worldUnitsPerMile;
		if (num <= EncounterManager.Instance.openGroundEncounterMinDistanceFromShelter)
		{
			return false;
		}
		bool flag2 = IsPartyWearingCamo();
		bool flag3 = PartyHasMotionDetector();
		if (flag2 && flag3)
		{
			if (Random.Range(1, 101) <= EncounterManager.Instance.openGroundEncounterCamouflageModifier + EncounterManager.Instance.encounterMotionDetectorModifer)
			{
				return false;
			}
		}
		else
		{
			if (flag2 && Random.Range(1, 101) <= EncounterManager.Instance.openGroundEncounterCamouflageModifier)
			{
				return false;
			}
			if (flag3 && Random.Range(1, 101) <= EncounterManager.Instance.encounterMotionDetectorModifer)
			{
				return false;
			}
		}
		int num2 = Random.Range(1, 101);
		if (onHorse)
		{
			num2 += EncounterManager.Instance.openGroundEncounterHorseModifier;
		}
		if (flag)
		{
			return num2 <= m_currentRegion.chanceOfOpenGroundFactionEncounter;
		}
		return num2 <= m_currentRegion.chanceOfOpenGroundEncounter;
	}

	private bool IsPartyWearingCamo()
	{
		bool result = false;
		for (int i = 0; i < m_partyMembers.Count && (m_partyMembers[i].GetEquippedItem1() == ItemManager.ItemType.Camouflage || m_partyMembers[i].GetEquippedItem2() == ItemManager.ItemType.Camouflage); i++)
		{
			if (i == m_partyMembers.Count - 1)
			{
				result = true;
			}
		}
		return result;
	}

	private bool PartyHasMotionDetector()
	{
		for (int i = 0; i < m_partyMembers.Count; i++)
		{
			if (m_partyMembers[i].GetEquippedItem1() == ItemManager.ItemType.MotionDetector || m_partyMembers[i].GetEquippedItem2() == ItemManager.ItemType.MotionDetector)
			{
				return true;
			}
		}
		return false;
	}

	private bool PartyHasBedRoll()
	{
		for (int i = 0; i < m_partyMembers.Count; i++)
		{
			if (m_partyMembers[i].GetEquippedItem1() == ItemManager.ItemType.BedRoll || m_partyMembers[i].GetEquippedItem2() == ItemManager.ItemType.BedRoll)
			{
				return true;
			}
		}
		return false;
	}

	private bool PartyHasTent()
	{
		for (int i = 0; i < m_partyMembers.Count; i++)
		{
			if (m_partyMembers[i].GetEquippedItem1() == ItemManager.ItemType.Tent || m_partyMembers[i].GetEquippedItem2() == ItemManager.ItemType.Tent)
			{
				return true;
			}
		}
		return false;
	}

	private void PushState(ePartyState stateType)
	{
		StateDef item = new StateDef
		{
			state = stateType,
			updateFunc = null
		};
		switch (stateType)
		{
		case ePartyState.EncounteredItems:
			item.updateFunc = Update_EncounteredItems;
			break;
		case ePartyState.EncounteredItemsRequestTransferPanel:
			item.updateFunc = Update_EncounteredItems_RequestTransferPanel;
			break;
		case ePartyState.EncounteredItemsStart:
			item.updateFunc = Update_EncounteredItems_Start;
			break;
		case ePartyState.EncounteredItemsWaitItemTransfer:
			item.updateFunc = Update_EncounteredItems_WaitItemTransfer;
			break;
		case ePartyState.EncounteredItemsWaitUser:
			item.updateFunc = Update_EncounteredItems_WaitUser;
			break;
		case ePartyState.EncounteredNPCs:
			item.updateFunc = Update_EncounteredNPCs;
			break;
		case ePartyState.EncounteredNPCsRequestNewEncounter:
			item.updateFunc = Update_EncounteredNPCs_RequestNewEncounter;
			break;
		case ePartyState.EncounteredNPCsStart:
			item.updateFunc = Update_EncounteredNPCs_Start;
			break;
		case ePartyState.EncounteredNPCsWaitFinished:
			item.updateFunc = Update_EncounteredNPCs_WaitFinished;
			break;
		case ePartyState.EncounteredNPCsWaitUser:
			item.updateFunc = Update_EncounteredNPCs_WaitUser;
			break;
		case ePartyState.EncounteredNPCsAutoResolve:
			item.updateFunc = Update_NpcEncounter_AutoResolve;
			break;
		case ePartyState.EncounteredQuestNPCs:
			item.updateFunc = Update_EncounteredQuestNPCs;
			break;
		case ePartyState.EncounteredQuestNPCsWaitUser:
			item.updateFunc = Update_EncounteredQuestNPCs_WaitUser;
			break;
		case ePartyState.EnteringShelter:
			item.updateFunc = Update_EnteringShelter;
			break;
		case ePartyState.Finished:
			item.updateFunc = Update_Finished;
			break;
		case ePartyState.GettingReady:
			item.updateFunc = null;
			break;
		case ePartyState.LeavingShelter:
			item.updateFunc = Update_LeavingShelter;
			break;
		case ePartyState.VehicleLeaving:
			item.updateFunc = Update_VehicleLeaving;
			break;
		case ePartyState.VehicleReturning:
			item.updateFunc = Update_VehicleReturning;
			break;
		case ePartyState.HorseLeaving:
			item.updateFunc = Update_HorseLeaving;
			break;
		case ePartyState.HorseReturning:
			item.updateFunc = Update_HorseReturning;
			break;
		case ePartyState.None:
			item.updateFunc = null;
			break;
		case ePartyState.OpenGroundNpcEncounter:
			item.updateFunc = Update_OpenGroundNpcEncounter;
			break;
		case ePartyState.OpenGroundNpcEncounterAutoResolve:
			item.updateFunc = Update_NpcEncounter_AutoResolve;
			break;
		case ePartyState.OpenGroundNpcEncounterRequestNewEncounter:
			item.updateFunc = Update_OpenGroundNpcEncounter_RequestNewEncounter;
			break;
		case ePartyState.OpenGroundNpcEncounterStart:
			item.updateFunc = Update_OpenGroundNpcEncounter_Start;
			break;
		case ePartyState.OpenGroundNpcEncounterWaitFinished:
			item.updateFunc = Update_OpenGroundNpcEncounter_WaitFinished;
			break;
		case ePartyState.OpenGroundNpcEncounterWaitUser:
			item.updateFunc = Update_OpenGroundNpcEncounter_WaitUser;
			break;
		case ePartyState.QuestEncounterStart:
			item.updateFunc = Update_QuestEncounterStart;
			break;
		case ePartyState.QuestEncounterWaitFinished:
			item.updateFunc = Update_QuestEncounterWaitFinished;
			break;
		case ePartyState.ReportingDiversions:
			item.updateFunc = Update_ReportingDiversions;
			break;
		case ePartyState.ReportingDiversionsStart:
			item.updateFunc = Update_ReportingDiversions_Start;
			break;
		case ePartyState.ReportingDiversionsWaitUser:
			item.updateFunc = Update_ReportingDiversions_WaitUser;
			break;
		case ePartyState.ReportingLocation:
			item.updateFunc = Update_ReportingLocation;
			break;
		case ePartyState.ReportingLocationWaitUser:
			item.updateFunc = Update_ReportingLocation_WaitUser;
			break;
		case ePartyState.ReturnedShowExperienceGained:
			item.updateFunc = Update_Returned_ShowExperienceGained;
			break;
		case ePartyState.ReturnedRequestTransferPanel:
			item.updateFunc = Update_Returned_RequestTransferPanel;
			break;
		case ePartyState.ReturnedWaitItemTransfer:
			item.updateFunc = Update_Returned_WaitItemTransfer;
			break;
		case ePartyState.SearchingLocation:
			item.updateFunc = Update_SearchingLocation;
			break;
		case ePartyState.Traveling:
			item.updateFunc = Update_Traveling;
			break;
		case ePartyState.EnteringShelterNextUpdate:
			item.updateFunc = Update_EnteringShelterNextUpdate;
			break;
		}
		m_stateStack.Push(item);
	}

	private StateDef PopState()
	{
		StateDef result = default(StateDef);
		if (m_stateStack.Count > 0)
		{
			return m_stateStack.Pop();
		}
		return result;
	}

	private void Begin_LeavingShelter()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		m_membersReadyCount = 0;
		m_petReady = false;
		List<GameObject> offScreenNodes = ExplorationManager.Instance.offScreenNodes;
		int num = 0;
		foreach (PartyMember partyMember in m_partyMembers)
		{
			Vector3 target_location = offScreenNodes[num].transform.position;
			if (inVehicle)
			{
				target_location = m_vehicle.GetBoardingPosition();
			}
			else if (onHorse)
			{
				target_location = m_horse.GetLeadPosition();
			}
			if ((Object)(object)partyMember != (Object)null && (Object)(object)partyMember.person != (Object)null)
			{
				if (partyMember.person.isWearingHazmatSuit && (Object)(object)ObjectManager.Instance != (Object)null)
				{
					List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.HazmatSuits);
					if (objectsOfType.Count > 0)
					{
						partyMember.person.AddAIJob(new Job("return_hazmat_suit", ((Component)objectsOfType[0]).transform.position, partyMember.person, objectsOfType[0]));
					}
				}
				partyMember.person.AddAIJob(new Job_GoToLocation(partyMember.person, target_location, cancellableInTransit: false, Job_GoToLocation.LocationReachedAction.LeftForExpedition));
			}
			if (++num >= offScreenNodes.Count)
			{
				num = 0;
			}
		}
		if (hasPet)
		{
			m_petReady = true;
			m_pet.LeaveShelter();
		}
		if ((Object)(object)m_vehicle != (Object)null)
		{
			m_vehicle.SetOnExpedition(truth: true);
		}
		if ((Object)(object)m_horse != (Object)null)
		{
			m_horse.SetOnExpedition(truth: true);
		}
		for (int i = 0; i < m_partyMembers.Count; i++)
		{
			if (!((Object)(object)m_partyMembers[i] != (Object)null) || !((Object)(object)m_partyMembers[i].person != (Object)null))
			{
				continue;
			}
			List<ItemManager.ItemType> list = new List<ItemManager.ItemType>();
			list.Add(m_partyMembers[i].GetEquippedItem1());
			list.Add(m_partyMembers[i].GetEquippedItem2());
			string overlayTexture = "none";
			for (int j = 0; j < list.Count; j++)
			{
				switch (list[j])
				{
				case ItemManager.ItemType.BulletProofVest_poor:
					overlayTexture = "armor1";
					break;
				case ItemManager.ItemType.BulletProofVest_good:
					overlayTexture = "armor2";
					break;
				case ItemManager.ItemType.BulletProofVest_great:
					overlayTexture = "armor3";
					break;
				}
			}
			for (int k = 0; k < list.Count; k++)
			{
				switch (list[k])
				{
				case ItemManager.ItemType.GasMask:
					m_partyMembers[i].person.WearGasMask("GasMask");
					break;
				case ItemManager.ItemType.AdvancedGasMask:
					m_partyMembers[i].person.WearGasMask("AdvancedGasMask");
					break;
				}
			}
			m_partyMembers[i].person.SetOverlayTexture(overlayTexture);
		}
		PopState();
		PushState(ePartyState.LeavingShelter);
	}

	private void Update_LeavingShelter()
	{
		if (m_membersReadyCount >= m_partyMembers.Count && (!hasPet || m_petReady))
		{
			PopState();
			if (inVehicle)
			{
				Begin_VehicleLeaving();
			}
			else if (onHorse)
			{
				Begin_HorseLeaving();
			}
			else
			{
				Begin_Traveling();
			}
		}
	}

	private void Begin_VehicleLeaving()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		List<GameObject> offScreenNodes = ExplorationManager.Instance.offScreenNodes;
		int num = 0;
		foreach (PartyMember partyMember in m_partyMembers)
		{
			Vector3 position = offScreenNodes[num].transform.position;
			((Component)partyMember.person).transform.position = position;
			if (++num >= offScreenNodes.Count)
			{
				num = 0;
			}
		}
		if ((Object)(object)m_vehicle != (Object)null)
		{
			m_vehicle.GoOnExpedition();
		}
		PopState();
		PushState(ePartyState.VehicleLeaving);
	}

	private void Update_VehicleLeaving()
	{
		if (m_vehicle.isStationary)
		{
			PopState();
			Begin_Traveling();
		}
	}

	private void Begin_HorseLeaving()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		List<GameObject> offScreenNodes = ExplorationManager.Instance.offScreenNodes;
		int num = 0;
		foreach (PartyMember partyMember in m_partyMembers)
		{
			Vector3 position = offScreenNodes[num].transform.position;
			partyMember.person.AddAIJob(new Job_GoToLocation(partyMember.person, position, cancellableInTransit: false));
			if (++num >= offScreenNodes.Count)
			{
				num = 0;
			}
		}
		m_horse.GoOnExpedition(m_partyMembers[0].person);
		PopState();
		PushState(ePartyState.HorseLeaving);
	}

	private void Update_HorseLeaving()
	{
		if (m_horse.isStationary)
		{
			PopState();
			Begin_Traveling();
		}
	}

	private void Begin_Traveling()
	{
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)AchievementManager.instance != (Object)null)
		{
			AchievementManager.instance.OnExpeditionStarted(id);
		}
		if (inVehicle)
		{
			m_travelSpeed = m_vehicle.TravelSpeed;
		}
		else if (onHorse)
		{
			m_travelSpeed = m_horse.TravelSpeed;
		}
		int num = 0;
		for (int i = 0; i < m_partyMembers.Count; i++)
		{
			if (m_partyMembers[i].person.traits.HasStrength(Traits.Strength.Proactive))
			{
				num++;
			}
			else if (m_partyMembers[i].person.traits.HasWeakness(Traits.Weakness.Lazy))
			{
				num--;
			}
		}
		if (num > 0)
		{
			m_speedModifier = 1.25f;
		}
		else if (num < 0)
		{
			m_speedModifier = 0.75f;
		}
		else
		{
			m_speedModifier = 1f;
		}
		m_lastWaypoint = 0;
		m_currWaypoint = 0;
		m_distanceTraveled = 0f;
		m_distanceUntilOGEncounter = 0f;
		m_searchExperienceGained = 0;
		m_waterUsePerWorldUnit = ExplorationManager.Instance.waterPerPersonPerMile * (float)m_partyMembers.Count / ExplorationManager.Instance.worldUnitsPerMile;
		if (inVehicle)
		{
			m_petrolUsePerWorldUnit = m_vehicle.PetrolPerPersonPerMile / ExplorationManager.Instance.worldUnitsPerMile;
			m_waterUsePerWorldUnit *= ExplorationManager.Instance.RVWaterModifier;
		}
		if (onHorse)
		{
			m_waterUsePerWorldUnit *= ExplorationManager.Instance.HorseWaterModifier;
		}
		m_location = m_route[m_currWaypoint];
		m_currentRegion = ExpeditionMap.Instance.GetRegionInWorld(m_location);
		m_visitedThisTrip.Clear();
		AdvanceCurrentWaypoint();
		UpdateSightRangeValue();
		PushState(ePartyState.Traveling);
	}

	private void Update_Traveling()
	{
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_031d: Unknown result type (might be due to invalid IL or missing references)
		float num = 1f;
		if ((Object)(object)WeatherManager.Instance != (Object)null && (Object)(object)ExplorationManager.Instance != (Object)null)
		{
			if (WeatherManager.Instance.currentState == WeatherManager.WeatherState.LightSand)
			{
				num = ExplorationManager.Instance.LightStormSpeedModifier;
				if (m_encounteredStorm == string.Empty)
				{
					m_encounteredStorm = "light";
				}
			}
			else if (WeatherManager.Instance.currentState == WeatherManager.WeatherState.MediumSand)
			{
				num = ExplorationManager.Instance.MediumStormSpeedModifier;
				if (m_encounteredStorm == string.Empty || m_encounteredStorm == "light")
				{
					m_encounteredStorm = "medium";
				}
			}
			else if (WeatherManager.Instance.currentState == WeatherManager.WeatherState.HeavySand)
			{
				num = ExplorationManager.Instance.HeavyStormSpeedModifier;
				if (m_encounteredStorm != "heavy")
				{
					m_encounteredStorm = "heavy";
				}
			}
		}
		float num2 = m_travelSpeed * m_speedModifier * ExplorationManager.Instance.worldUnitsPerMile * num;
		float num3 = num2 / 3600f * Time.deltaTime * GameTime.RealSecondsToGameSeconds(1f);
		if (!m_waitingToReturn)
		{
			m_waypointProgress += num3 / m_waypointDistance;
			m_waypointProgress = Mathf.Clamp01(m_waypointProgress);
			m_distanceTraveled += num3;
			m_distanceUntilOGEncounter -= num3;
			if (!isDiverting)
			{
				m_water -= num3 * m_waterUsePerWorldUnit;
				if (inVehicle)
				{
					m_petrol -= num3 * m_petrolUsePerWorldUnit;
				}
			}
			DeteriorateStatsFromTravel(num3);
			m_location = m_route[m_lastWaypoint] + m_currentLeg * m_waypointProgress;
			ExpeditionMap.GridRef gridRef = ExpeditionMap.Instance.WorldPosToGridRef(m_location);
			if (!gridRef.isEqualTo(m_currentRegion.gridReference))
			{
				OnLeftRegion(m_currentRegion.gridReference);
				OnEnteredRegion(gridRef);
				return;
			}
		}
		if (m_waypointProgress >= 1f)
		{
			if (m_currWaypoint < m_route.Count - 1)
			{
				AdvanceCurrentWaypoint();
			}
			else if ((Object)(object)BreachMan.instance != (Object)null && BreachMan.instance.inProgress)
			{
				m_waitingToReturn = true;
			}
			else
			{
				PopState();
				if (inVehicle)
				{
					Begin_VehicleReturning();
				}
				else if (onHorse)
				{
					Begin_HorseReturning();
				}
				else
				{
					Begin_EnteringShelter();
				}
			}
		}
		if (m_isRecalled && m_currWaypoint < m_route.Count - 1)
		{
			m_route[m_currWaypoint] = m_location;
			m_route[m_currWaypoint + 1] = m_route[m_route.Count - 1];
			m_route.RemoveRange(m_currWaypoint + 2, m_route.Count - (m_currWaypoint + 2));
			AdvanceCurrentWaypoint();
		}
	}

	private void Begin_ReportingLocation()
	{
		CreateRadioDialogParametersForQuery("Location");
		m_radioParams.subjectTextId = "Region.Name." + m_currentRegion.regionName;
		m_radioParams.indefSubjectTextId = "Region.Name.Indefinite." + m_currentRegion.regionName;
		PushState(ePartyState.ReportingLocation);
	}

	private void Update_ReportingLocation()
	{
		if ((Object)(object)BreachMan.instance != (Object)null && !BreachMan.instance.inProgress && ExplorationManager.Instance.ShowRadioDialog(m_radioParams))
		{
			ExplorationManager.Instance.SetPendingSearchTutorial();
			m_radioResponse = RadioDialogPanel.RadioResponse.None;
			PopState();
			PushState(ePartyState.ReportingLocationWaitUser);
		}
	}

	private void Update_ReportingLocation_WaitUser()
	{
		if (m_isRecalled)
		{
			ExplorationManager.Instance.CancelPendingRadioTransmission();
			PopState();
		}
		else if (m_radioResponse != RadioDialogPanel.RadioResponse.None)
		{
			PopState();
			if (m_radioResponse == RadioDialogPanel.RadioResponse.Accept)
			{
				Begin_SearchingLocation();
			}
		}
	}

	private void Begin_SearchingLocation()
	{
		m_searchedThisTrip.Add(m_currentRegion.regionName);
		BaseStat baseStat = null;
		foreach (PartyMember partyMember in m_partyMembers)
		{
			BaseStat statByEnum = partyMember.person.BaseStats.GetStatByEnum(BaseStats.StatType.Perception);
			if (baseStat == null || statByEnum.Level > baseStat.Level)
			{
				baseStat = statByEnum;
			}
		}
		float num = 1f - Mathf.InverseLerp(1f, (float)baseStat.LevelCap, (float)baseStat.Level);
		m_timer = Mathf.Lerp(m_currentRegion.minSearchTime, m_currentRegion.maxSearchTime, num);
		m_searchExperienceGained += ExplorationManager.Instance.exploreExperience;
		if ((Object)(object)AchievementManager.instance != (Object)null)
		{
			AchievementManager.instance.OnLocationSearched(m_currentRegion);
		}
		PushState(ePartyState.SearchingLocation);
	}

	private void Update_SearchingLocation()
	{
		m_timer -= Time.deltaTime;
		if (m_timer > 0f)
		{
			return;
		}
		PopState();
		if (m_currentRegion.hasItems)
		{
			PushState(ePartyState.EncounteredItemsStart);
		}
		if (EncounterManager.Instance.CanHaveHumanEncounter())
		{
			int num = m_currentRegion.chanceThatSearchRevealsNpcs;
			if (m_factionId > -1 && (Object)(object)EncounterManager.Instance != (Object)null)
			{
				num = EncounterManager.Instance.m_chanceThatSearchRevealsFactionNpcs;
			}
			if (Random.Range(1, 101) <= num)
			{
				PushState(ePartyState.EncounteredNPCsStart);
			}
		}
	}

	private void Update_ReportingDiversions_Start()
	{
		PopState();
		if (m_nearbyDiversions.Count != 0)
		{
			int index = Random.Range(0, m_nearbyDiversions.Count);
			m_diversionRegion = m_nearbyDiversions[index];
			CreateRadioDialogParametersForQuery("Diversion");
			m_radioParams.subjectTextId = "Region.Name." + m_diversionRegion.regionName;
			m_radioParams.indefSubjectTextId = "Region.Name.Indefinite." + m_diversionRegion.regionName;
			PushState(ePartyState.ReportingDiversions);
		}
	}

	private void Update_ReportingDiversions()
	{
		if ((Object)(object)BreachMan.instance != (Object)null && !BreachMan.instance.inProgress && ExplorationManager.Instance.ShowRadioDialog(m_radioParams))
		{
			m_radioResponse = RadioDialogPanel.RadioResponse.None;
			PopState();
			PushState(ePartyState.ReportingDiversionsWaitUser);
		}
	}

	private void Update_ReportingDiversions_WaitUser()
	{
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		if (m_isRecalled)
		{
			ExplorationManager.Instance.CancelPendingRadioTransmission();
			PopState();
		}
		else if (m_radioResponse != RadioDialogPanel.RadioResponse.None)
		{
			PopState();
			if (m_radioResponse == RadioDialogPanel.RadioResponse.Accept)
			{
				Vector2 item = default(Vector2);
				((Vector2)(ref item))._002Ector(m_location.x, m_location.y);
				Vector2 gridRefCentreWorldPos = ExpeditionMap.Instance.GetGridRefCentreWorldPos(m_diversionRegion.gridReference);
				Vector2 item2 = default(Vector2);
				((Vector2)(ref item2))._002Ector(m_location.x, m_location.y);
				m_route.Insert(m_currWaypoint, item2);
				m_route.Insert(m_currWaypoint, gridRefCentreWorldPos);
				m_route.Insert(m_currWaypoint, item);
				m_diversionEndWaypoint = m_currWaypoint + 2;
				AdvanceCurrentWaypoint();
				remainingDiversions--;
			}
		}
	}

	private void Update_EncounteredItems_Start()
	{
		PopState();
		CreateRadioDialogParametersForQuery("FoundItems");
		m_radioParams.subjectTextId = "Region.Name." + m_currentRegion.regionName;
		PushState(ePartyState.EncounteredItems);
	}

	private void Update_EncounteredItems()
	{
		if ((Object)(object)BreachMan.instance != (Object)null && !BreachMan.instance.inProgress && ExplorationManager.Instance.ShowRadioDialog(m_radioParams))
		{
			m_radioResponse = RadioDialogPanel.RadioResponse.None;
			PopState();
			PushState(ePartyState.EncounteredItemsWaitUser);
		}
	}

	private void Update_EncounteredItems_WaitUser()
	{
		if (m_isRecalled)
		{
			ExplorationManager.Instance.CancelPendingRadioTransmission();
			PopState();
		}
		else if (m_radioResponse != RadioDialogPanel.RadioResponse.None)
		{
			PopState();
			if (m_radioResponse == RadioDialogPanel.RadioResponse.Accept)
			{
				PushState(ePartyState.EncounteredItemsRequestTransferPanel);
				DiscoverLocationItems();
			}
		}
	}

	private void Update_EncounteredItems_RequestTransferPanel()
	{
		ExplorationManager.TransferPanelParams transferPanelParams = new ExplorationManager.TransferPanelParams();
		transferPanelParams.rightSideIsShelter = false;
		transferPanelParams.numPartyMembers = 1;
		transferPanelParams.getPartyItemsFn = GetPartyItemsForTransfer;
		transferPanelParams.getLeftPersonFn = GetPartyMemberDetailsForTransfer;
		transferPanelParams.getRegionInfoFn = GetRegionDetailsForTransfer;
		transferPanelParams.changedPartyItemsFn = ItemTransferResult;
		transferPanelParams.getRegionItemsFn = m_currentRegion.GetDiscoveredItems;
		transferPanelParams.changedRegionItemsFn = m_currentRegion.OnItemsChanged;
		if (ExplorationManager.Instance.ShowItemTransferPanel(transferPanelParams))
		{
			PopState();
			m_itemTransferComplete = false;
			PushState(ePartyState.EncounteredItemsWaitItemTransfer);
		}
	}

	private void DiscoverLocationItems()
	{
		UpdatePerceptionValue();
		if ((Object)(object)m_currentRegion != (Object)null)
		{
			m_currentRegion.AttemptToDiscoverItems(perception);
			List<ItemManager.ItemType> list = new List<ItemManager.ItemType>();
			for (int i = 0; i < m_partyMembers.Count; i++)
			{
				list.Add(m_partyMembers[i].GetEquippedItem1());
				list.Add(m_partyMembers[i].GetEquippedItem2());
				list.Add(m_partyMembers[i].GetEquippedWeapon());
			}
			m_currentRegion.AttemptToRevealHiddenItems(list);
		}
	}

	private void Update_EncounteredItems_WaitItemTransfer()
	{
		if (!m_itemTransferComplete)
		{
			return;
		}
		PopState();
		if ((Object)(object)m_currentRegion != (Object)null && m_currentRegion.hasQuest && (Object)(object)QuestLibrary.instance != (Object)null && (Object)(object)QuestManager.instance != (Object)null)
		{
			QuestInstance questInstance = QuestManager.instance.GetQuestInstance(m_currentRegion.questInstanceId);
			if (questInstance != null && questInstance.definition != null && questInstance.IsActive() && questInstance.definition is QuestDef questDef && (questDef.encounterStages.Count == 0 || questDef.characterIds.Count == 0))
			{
				QuestManager.instance.FinishQuest(questInstance.id, success: true);
			}
		}
	}

	private void Update_EncounteredNPCs_Start()
	{
		PopState();
		if (m_factionId == -1 && Random.value <= 0.5f)
		{
			m_EncounterIsPlayerControlled = true;
			CreateRadioDialogParametersForQuery("FoundNPCs");
		}
		else
		{
			m_EncounterIsPlayerControlled = false;
			CreateRadioDialogParametersForQuery("MetNPCs");
		}
		m_radioParams.subjectTextId = "Region.Name." + m_currentRegion.regionName;
		PushState(ePartyState.EncounteredNPCs);
	}

	private void Update_EncounteredNPCs()
	{
		if ((Object)(object)BreachMan.instance != (Object)null && !BreachMan.instance.inProgress && ExplorationManager.Instance.ShowRadioDialog(m_radioParams))
		{
			m_radioResponse = RadioDialogPanel.RadioResponse.None;
			PopState();
			PushState(ePartyState.EncounteredNPCsWaitUser);
		}
	}

	private void Update_EncounteredNPCs_WaitUser()
	{
		if (m_isRecalled)
		{
			ExplorationManager.Instance.CancelPendingRadioTransmission();
			PopState();
		}
		else if (m_radioResponse != RadioDialogPanel.RadioResponse.None)
		{
			PopState();
			if (m_radioResponse == RadioDialogPanel.RadioResponse.Accept)
			{
				PushState(ePartyState.EncounteredNPCsRequestNewEncounter);
				m_encounteredNpcsThisTrip = true;
			}
			else if (!m_EncounterIsPlayerControlled)
			{
				PushState(ePartyState.EncounteredNPCsAutoResolve);
				m_encounteredNpcsThisTrip = true;
			}
			else
			{
				PopUntilTravelling();
			}
		}
	}

	private void Update_EncounteredQuestNPCs()
	{
		if ((Object)(object)QuestManager.instance != (Object)null && (Object)(object)m_currentRegion != (Object)null)
		{
			QuestInstance questInstance = QuestManager.instance.GetQuestInstance(m_currentRegion.questInstanceId);
			if (questInstance == null || !questInstance.IsActive())
			{
				PopState();
				bool flag = false;
				if (m_currentRegion.topography != MapRegion.Topography.NowhereSpecial && m_visitedThisTrip.Find((ExpeditionMap.GridRef x) => x.isEqualTo(m_currentRegion.gridReference)) != null)
				{
					flag = true;
				}
				if (flag)
				{
					return;
				}
				if (m_currentRegion.isSearchable)
				{
					if (m_currentRegion.isEqualTo(m_diversionRegion))
					{
						Begin_SearchingLocation();
					}
					else
					{
						Begin_ReportingLocation();
					}
				}
				else if (OpenGroundEncounterCheck() && EncounterManager.Instance.CanHaveEncounter())
				{
					PushState(ePartyState.OpenGroundNpcEncounterStart);
				}
				return;
			}
		}
		string text = string.Empty;
		bool flag2 = false;
		if ((Object)(object)QuestManager.instance != (Object)null)
		{
			QuestInstance questInstance2 = QuestManager.instance.GetQuestInstance(m_currentRegion.questInstanceId);
			QuestDef questDef = null;
			if (questInstance2 != null)
			{
				questDef = questInstance2.definition as QuestDef;
			}
			if (questDef != null)
			{
				flag2 = questDef.IsFloating();
				if (!string.IsNullOrEmpty(questDef.encounterOptions.radioOverrideKey))
				{
					text = questDef.encounterOptions.radioOverrideKey;
				}
			}
		}
		if (string.IsNullOrEmpty(text))
		{
			text = ((!flag2) ? "MetQuestNPCs" : "AmbushedByNPCs");
		}
		CreateRadioDialogParametersForQuery(text);
		m_radioParams.subjectTextId = "Region.Name." + m_currentRegion.regionName;
		if ((Object)(object)BreachMan.instance != (Object)null && !BreachMan.instance.inProgress && ExplorationManager.Instance.ShowRadioDialog(m_radioParams))
		{
			m_radioResponse = RadioDialogPanel.RadioResponse.None;
			PopState();
			PushState(ePartyState.EncounteredQuestNPCsWaitUser);
		}
	}

	private void Update_EncounteredQuestNPCs_WaitUser()
	{
		if ((Object)(object)QuestManager.instance != (Object)null && (Object)(object)m_currentRegion != (Object)null)
		{
			QuestInstance questInstance = QuestManager.instance.GetQuestInstance(m_currentRegion.questInstanceId);
			if (questInstance == null || !questInstance.IsActive())
			{
				PopState();
				bool flag = false;
				if (m_currentRegion.topography != MapRegion.Topography.NowhereSpecial && m_visitedThisTrip.Find((ExpeditionMap.GridRef x) => x.isEqualTo(m_currentRegion.gridReference)) != null)
				{
					flag = true;
				}
				if (flag)
				{
					return;
				}
				if (m_currentRegion.isSearchable)
				{
					if (m_currentRegion.isEqualTo(m_diversionRegion))
					{
						Begin_SearchingLocation();
					}
					else
					{
						Begin_ReportingLocation();
					}
				}
				else if (OpenGroundEncounterCheck() && EncounterManager.Instance.CanHaveEncounter())
				{
					PushState(ePartyState.OpenGroundNpcEncounterStart);
				}
				return;
			}
		}
		if (m_isRecalled)
		{
			ExplorationManager.Instance.CancelPendingRadioTransmission();
			PopState();
		}
		else
		{
			if (m_radioResponse == RadioDialogPanel.RadioResponse.None)
			{
				return;
			}
			PopState();
			if (m_radioResponse == RadioDialogPanel.RadioResponse.Accept)
			{
				PushState(ePartyState.QuestEncounterStart);
				m_encounteredNpcsThisTrip = true;
				return;
			}
			bool flag2 = false;
			if ((Object)(object)QuestManager.instance != (Object)null)
			{
				QuestInstance questInstance2 = QuestManager.instance.GetQuestInstance(m_currentRegion.questInstanceId);
				QuestDef questDef = null;
				if (questInstance2 != null)
				{
					questDef = questInstance2.definition as QuestDef;
				}
				if (questDef != null && questDef.IsFloating())
				{
					flag2 = true;
					QuestManager.instance.FinishQuest(questInstance2.id, success: false);
				}
			}
			if (flag2)
			{
				if (m_visitedThisTrip.Find((ExpeditionMap.GridRef x) => x.isEqualTo(m_currentRegion.gridReference)) == null && m_currentRegion.isSearchable)
				{
					Begin_SearchingLocation();
				}
				PushState(ePartyState.EncounteredNPCsAutoResolve);
				m_encounteredNpcsThisTrip = true;
			}
			else
			{
				PopUntilTravelling();
			}
		}
	}

	private void Update_EncounteredNPCs_RequestNewEncounter()
	{
		if (EncounterManager.Instance.StartEncounter(m_partyMembers, m_EncounterIsPlayerControlled, animalEncounter: false, m_id, m_factionId))
		{
			PopState();
			PushState(ePartyState.EncounteredNPCsWaitFinished);
		}
	}

	private void Update_EncounteredNPCs_WaitFinished()
	{
		if (EncounterManager.Instance.GetEncounterState() == EncounterManager.EncounterState.NotStarted)
		{
			PopState();
			if ((EncounterManager.Instance.didCombatHappen && EncounterManager.Instance.lastCombatResult != EncounterManager.EncounterCombatResult.Win) || EncounterManager.Instance.lastDialogueResult == EncounterManager.EncounterDialogueOutcome.Withdraw)
			{
				PopUntilTravelling();
			}
			if (RemoveDeadPartyMembers())
			{
				JournalManager.Instance.RecordEvent(JournalEvents.Event.ExplorersNotReturning, new ActivityLog.ExtraInfoString("human", isLocalizationKey: false), new ActivityLog.ExtraInfoString("false", isLocalizationKey: false));
				JournalManager.Instance.setExplorerNotReturnJournalEntryTimer();
			}
		}
	}

	private void Update_OpenGroundNpcEncounter_Start()
	{
		PopState();
		if (EncounterManager.Instance.CanHaveHumanEncounter() && EncounterManager.Instance.CanHaveAnimalEncounter())
		{
			m_openGroundEncounterIsAnimal = Random.Range(0, 100) < m_currentRegion.chanceThatEncounterIsAnimal;
		}
		else if (EncounterManager.Instance.CanHaveHumanEncounter())
		{
			m_openGroundEncounterIsAnimal = false;
		}
		else
		{
			if (!EncounterManager.Instance.CanHaveAnimalEncounter())
			{
				throw new Exception("OpenGroundEncounter - There are no human and no animal encounters to choose from!");
			}
			repelAnimal = false;
			for (int i = 0; i < m_partyMembers.Count; i++)
			{
				if (m_partyMembers[i].GetEquippedItem1() == ItemManager.ItemType.AnimalRepellent)
				{
					repelAnimal = true;
				}
				else if (m_partyMembers[i].GetEquippedItem2() == ItemManager.ItemType.AnimalRepellent)
				{
					repelAnimal = true;
				}
			}
			if (repelAnimal)
			{
				float value = Random.value;
				if ((double)value > 0.9)
				{
					m_openGroundEncounterIsAnimal = true;
				}
			}
		}
		if (m_factionId > -1)
		{
			m_openGroundEncounterIsAnimal = false;
		}
		m_distanceUntilOGEncounter = EncounterManager.Instance.distanceUntilNextOpenGroundEncounter * ExplorationManager.Instance.worldUnitsPerMile;
		if (m_factionId > -1)
		{
			m_distanceUntilOGEncounter = EncounterManager.Instance.distanceUntilNextFactionEncounter * ExplorationManager.Instance.worldUnitsPerMile;
		}
		if (m_openGroundEncounterIsAnimal)
		{
			m_EncounterIsPlayerControlled = true;
			CreateRadioDialogParametersForQuery("OpenGroundEncounter.Animal");
		}
		else
		{
			m_encounteredNpcsThisTrip = true;
			if (m_factionId == -1 && Random.value <= 0.5f)
			{
				m_EncounterIsPlayerControlled = true;
				CreateRadioDialogParametersForQuery("OpenGroundEncounter.Human.Found");
			}
			else
			{
				m_EncounterIsPlayerControlled = false;
				CreateRadioDialogParametersForQuery("OpenGroundEncounter.Human.Met");
			}
		}
		PushState(ePartyState.OpenGroundNpcEncounter);
	}

	private void Update_OpenGroundNpcEncounter()
	{
		if ((Object)(object)BreachMan.instance != (Object)null && !BreachMan.instance.inProgress && ExplorationManager.Instance.ShowRadioDialog(m_radioParams))
		{
			m_radioResponse = RadioDialogPanel.RadioResponse.None;
			PopState();
			PushState(ePartyState.OpenGroundNpcEncounterWaitUser);
		}
	}

	private void Update_OpenGroundNpcEncounter_WaitUser()
	{
		if (m_isRecalled)
		{
			ExplorationManager.Instance.CancelPendingRadioTransmission();
			PopState();
		}
		else if (m_radioResponse != RadioDialogPanel.RadioResponse.None)
		{
			PopState();
			if (m_radioResponse == RadioDialogPanel.RadioResponse.Accept)
			{
				PushState(ePartyState.OpenGroundNpcEncounterRequestNewEncounter);
			}
			else if (!m_EncounterIsPlayerControlled)
			{
				PushState(ePartyState.OpenGroundNpcEncounterAutoResolve);
			}
			else
			{
				PopUntilTravelling();
			}
		}
	}

	private void Update_OpenGroundNpcEncounter_RequestNewEncounter()
	{
		if (EncounterManager.Instance.StartEncounter(m_partyMembers, m_EncounterIsPlayerControlled, m_openGroundEncounterIsAnimal, m_id, m_factionId))
		{
			PopState();
			PushState(ePartyState.OpenGroundNpcEncounterWaitFinished);
		}
	}

	private void Update_OpenGroundNpcEncounter_WaitFinished()
	{
		if (EncounterManager.Instance.GetEncounterState() != EncounterManager.EncounterState.NotStarted)
		{
			return;
		}
		PopState();
		if (RemoveDeadPartyMembers())
		{
			if (m_openGroundEncounterIsAnimal)
			{
				JournalManager.Instance.RecordEvent(JournalEvents.Event.ExplorersNotReturning, new ActivityLog.ExtraInfoString("animal", isLocalizationKey: false), new ActivityLog.ExtraInfoString("false", isLocalizationKey: false));
			}
			else
			{
				JournalManager.Instance.RecordEvent(JournalEvents.Event.ExplorersNotReturning, new ActivityLog.ExtraInfoString("human", isLocalizationKey: false), new ActivityLog.ExtraInfoString("false", isLocalizationKey: false));
			}
			JournalManager.Instance.setExplorerNotReturnJournalEntryTimer();
		}
	}

	private void Update_NpcEncounter_AutoResolve()
	{
		PopState();
		if (!m_openGroundEncounterIsAnimal && Random.Range(1, 101) > EncounterManager.Instance.autoResolveEncounterChanceOfHumanCombat)
		{
			return;
		}
		foreach (PartyMember partyMember in m_partyMembers)
		{
			int num = 0;
			num = ((!m_openGroundEncounterIsAnimal) ? EncounterManager.Instance.autoResolveEncounterChanceOfDeathByHuman : EncounterManager.Instance.autoResolveEncounterChanceOfDeathByAnimal);
			if (Random.Range(1, 101) <= num)
			{
				partyMember.person.Kill(BaseCharacter.DamageType.Wasteland, string.Empty);
			}
		}
		if (RemoveDeadPartyMembers())
		{
			JournalManager.Instance.RecordEvent(JournalEvents.Event.ExplorersNotReturning, new ActivityLog.ExtraInfoString("auto", isLocalizationKey: false), new ActivityLog.ExtraInfoString("false", isLocalizationKey: false));
			JournalManager.Instance.setExplorerNotReturnJournalEntryTimer();
		}
	}

	private void Begin_VehicleReturning()
	{
		if ((Object)(object)m_vehicle != (Object)null)
		{
			m_vehicle.ReturnFromExpedition();
			m_vehicle.SetOnExpedition(truth: false);
		}
		PushState(ePartyState.VehicleReturning);
	}

	private void Update_VehicleReturning()
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)m_vehicle == (Object)null)
		{
			PopState();
			Begin_EnteringShelter();
		}
		else
		{
			if (!m_vehicle.isStationary)
			{
				return;
			}
			PopState();
			foreach (PartyMember partyMember in m_partyMembers)
			{
				((Component)partyMember.person).transform.position = m_vehicle.GetBoardingPosition();
			}
			Begin_EnteringShelter();
		}
	}

	private void Begin_HorseReturning()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		List<GameObject> offScreenNodesRight = ExplorationManager.Instance.offScreenNodesRight;
		int num = 0;
		foreach (PartyMember partyMember in m_partyMembers)
		{
			Vector3 position = offScreenNodesRight[num].transform.position;
			((Component)partyMember.person).transform.position = position;
			if (++num >= offScreenNodesRight.Count)
			{
				num = 0;
			}
		}
		List<GameObject> entranceNodes = ExplorationManager.Instance.entranceNodes;
		num = 0;
		for (int i = 0; i < m_partyMembers.Count; i++)
		{
			Vector3 target_location = entranceNodes[num].transform.position;
			if (i == 0)
			{
				target_location = m_horse.GetLeadPosition();
			}
			m_partyMembers[i].person.AddAIJob(new Job_GoToLocation(m_partyMembers[i].person, target_location, cancellableInTransit: false));
			if (++num >= entranceNodes.Count)
			{
				num = 0;
			}
		}
		m_horse.ReturnFromExpedition(m_partyMembers[0].person);
		m_horse.SetOnExpedition(truth: false);
		PushState(ePartyState.HorseReturning);
	}

	private void Update_HorseReturning()
	{
		if (m_horse.isStationary)
		{
			PopState();
			Begin_EnteringShelter();
		}
	}

	private void Begin_EnteringShelter()
	{
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		m_membersReadyCount = 0;
		m_petReady = false;
		m_partyWalkingToShelter = true;
		if ((Object)(object)m_horse == (Object)null && (Object)(object)m_vehicle == (Object)null)
		{
			List<GameObject> offScreenNodesRight = ExplorationManager.Instance.offScreenNodesRight;
			int num = 0;
			if (offScreenNodesRight.Count > 0)
			{
				for (int i = 0; i < m_partyMembers.Count; i++)
				{
					if (!((Object)(object)m_partyMembers[i].person == (Object)null))
					{
						Vector3 position = offScreenNodesRight[num].transform.position;
						((Component)m_partyMembers[i].person).transform.position = position;
						if (++num >= offScreenNodesRight.Count)
						{
							num = 0;
						}
					}
				}
			}
		}
		List<GameObject> entranceNodes = ExplorationManager.Instance.entranceNodes;
		int num2 = 0;
		foreach (PartyMember partyMember in m_partyMembers)
		{
			if (!((Object)(object)partyMember.person == (Object)null))
			{
				Vector3 position2 = entranceNodes[num2].transform.position;
				partyMember.person.AddAIJob(new Job_GoToLocation(partyMember.person, position2, cancellableInTransit: false, Job_GoToLocation.LocationReachedAction.ReturnedFromExpedition));
				if (++num2 >= entranceNodes.Count)
				{
					num2 = 0;
				}
			}
		}
		if (hasPet)
		{
			m_pet.ReturnToShelter(2f);
		}
		PushState(ePartyState.EnteringShelter);
		for (int j = 0; j < m_partyMembers.Count; j++)
		{
			FamilyMember person = m_partyMembers[j].person;
			if ((Object)(object)person != (Object)null && (Object)(object)ExplorationManager.Instance != (Object)null)
			{
				person.AddDistanceTravelled(m_distanceTraveled / ExplorationManager.Instance.worldUnitsPerMile);
				if (person.traits.HasWeakness(Traits.Weakness.Lazy) && person.distanceTravelled > 20f)
				{
					person.traits.TurnWeaknessToStrength(Traits.Weakness.Lazy);
				}
			}
		}
		for (int k = 0; k < m_partyMembers.Count; k++)
		{
			bool flag = false;
			List<ItemStack> equippedItems = m_partyMembers[k].GetEquippedItems();
			if (equippedItems != null)
			{
				for (int l = 0; l < equippedItems.Count; l++)
				{
					if ((equippedItems[l].m_type == ItemManager.ItemType.GasMask || equippedItems[l].m_type == ItemManager.ItemType.AdvancedGasMask) && equippedItems[l].m_count > 0)
					{
						flag = true;
					}
				}
			}
			if (flag || !((Object)(object)m_partyMembers[k].person != (Object)null) || m_partyMembers[k].person.illness.radiation.isImmune)
			{
				continue;
			}
			float value = Random.value;
			if (m_encounteredStorm == "light")
			{
				if ((double)value < 0.25)
				{
					m_partyMembers[k].person.illness.radiation.SetActive(active: true);
				}
			}
			else if (m_encounteredStorm == "medium")
			{
				if ((double)value < 0.5)
				{
					m_partyMembers[k].person.illness.radiation.SetActive(active: true);
				}
			}
			else if (m_encounteredStorm == "heavy" && (double)value < 0.75)
			{
				m_partyMembers[k].person.illness.radiation.SetActive(active: true);
			}
		}
	}

	private void Update_EnteringShelterNextUpdate()
	{
		PopState();
		PushState(ePartyState.EnteringShelter);
	}

	private void Update_EnteringShelter()
	{
		if (m_membersReadyCount < m_partyMembers.Count || (hasPet && !m_petReady) || !ExplorationManager.Instance.CanStartReturn())
		{
			return;
		}
		PopState();
		m_partyReturning = true;
		for (int i = 0; i < m_partyMembers.Count; i++)
		{
			List<ItemStack> equippedItems = m_partyMembers[i].GetEquippedItems();
			if (equippedItems == null)
			{
				continue;
			}
			for (int j = 0; j < equippedItems.Count; j++)
			{
				if (equippedItems[j].m_type == ItemManager.ItemType.GasMask && equippedItems[j].m_count > 0)
				{
					m_partyMembers[i].RemoveFromEquippedItems(ItemManager.ItemType.GasMask);
					m_partyMembers[i].person.RemoveGasMask();
				}
				else if (equippedItems[j].m_type == ItemManager.ItemType.AdvancedGasMask && equippedItems[j].m_count > 0)
				{
					m_partyMembers[i].person.RemoveGasMask();
				}
			}
		}
		for (int k = 0; k < m_partyMembers.Count; k++)
		{
			if ((Object)(object)m_partyMembers[k] != (Object)null && (Object)(object)m_partyMembers[k].person != (Object)null)
			{
				m_partyMembers[k].person.SetOverlayTexture("none");
			}
		}
		m_experienceDisplayComplete = false;
		ExplorationManager.Instance.ShowExplorationSummaryPanel(this);
		PushState(ePartyState.ReturnedShowExperienceGained);
	}

	private void Update_Returned_ShowExperienceGained()
	{
		if (!m_experienceDisplayComplete)
		{
			return;
		}
		PopState();
		foreach (PartyMember partyMember in m_partyMembers)
		{
			partyMember.ReturnAllEquippedItemsToMainInventory();
		}
		List<ItemStack> partyItems = ExplorationManager.Instance.GetPartyItems(id);
		if (partyItems.Count > 0)
		{
			PushState(ePartyState.ReturnedRequestTransferPanel);
		}
		else
		{
			Begin_Finished();
		}
	}

	private void Update_Returned_RequestTransferPanel()
	{
		ExplorationManager.TransferPanelParams transferPanelParams = new ExplorationManager.TransferPanelParams();
		transferPanelParams.rightSideIsShelter = true;
		transferPanelParams.numPartyMembers = 1;
		transferPanelParams.getPartyItemsFn = GetPartyItemsForTransfer;
		transferPanelParams.getLeftPersonFn = GetPartyMemberDetailsForTransfer;
		transferPanelParams.changedPartyItemsFn = ItemTransferResult;
		if (ExplorationManager.Instance.ShowItemTransferPanel(transferPanelParams))
		{
			PopState();
			m_itemTransferComplete = false;
			PushState(ePartyState.ReturnedWaitItemTransfer);
		}
	}

	private void Update_Returned_WaitItemTransfer()
	{
		if (m_itemTransferComplete)
		{
			PopState();
			Begin_Finished();
		}
	}

	private void Begin_Finished()
	{
		if ((Object)(object)AchievementManager.instance != (Object)null)
		{
			AchievementManager.instance.OnExpeditionOver(id);
		}
		foreach (PartyMember partyMember in m_partyMembers)
		{
			partyMember.person.isAway = false;
			partyMember.person.BaseStats.GetStatByEnum(BaseStats.StatType.Perception).IncreaseExp(m_searchExperienceGained);
		}
		ExplorationManager.Instance.PartyHasReturned(m_id);
		m_partyReturning = false;
		m_partyWalkingToShelter = false;
		if (m_participatedInCombat)
		{
			JournalManager.Instance.CreateJournalEntry(JournalManager.JournalEntryType.Combat);
		}
		else if ((m_searchedThisTrip.Count > 0 || m_encounteredNpcsThisTrip) && Random.Range(0, 4) == 0)
		{
			if (m_searchedThisTrip.Count > 0)
			{
				int index = Random.Range(0, m_searchedThisTrip.Count);
				JournalManager.Instance.RecordEvent(JournalEvents.Event.ExplorationLocation, new ActivityLog.ExtraInfoString(string.Empty + m_id, isLocalizationKey: false), new ActivityLog.ExtraInfoString(m_searchedThisTrip[index], isLocalizationKey: false));
			}
			if (m_encounteredNpcsThisTrip)
			{
				JournalManager.Instance.RecordEvent(JournalEvents.Event.ExplorationNPC, new ActivityLog.ExtraInfoString(string.Empty + m_id, isLocalizationKey: false));
			}
			JournalManager.Instance.RecordEvent(JournalEvents.Event.ExplorationEnded, new ActivityLog.ExtraInfoString(string.Empty + m_id, isLocalizationKey: false));
			JournalManager.Instance.CreateJournalEntry(JournalManager.JournalEntryType.Exploration);
		}
		PushState(ePartyState.Finished);
	}

	private void Update_Finished()
	{
	}

	private void Update_QuestEncounterStart()
	{
		if (EncounterManager.Instance.StartQuestEncounter(m_partyMembers, m_id))
		{
			PopState();
			PushState(ePartyState.QuestEncounterWaitFinished);
		}
	}

	private void Update_QuestEncounterWaitFinished()
	{
		if (EncounterManager.Instance.GetEncounterState() == EncounterManager.EncounterState.NotStarted)
		{
			PopState();
			if (RemoveDeadPartyMembers())
			{
				JournalManager.Instance.RecordEvent(JournalEvents.Event.ExplorersNotReturning, new ActivityLog.ExtraInfoString("human", isLocalizationKey: false), new ActivityLog.ExtraInfoString("false", isLocalizationKey: false));
				JournalManager.Instance.setExplorerNotReturnJournalEntryTimer();
			}
			if ((EncounterManager.Instance.didCombatHappen && EncounterManager.Instance.lastCombatResult != EncounterManager.EncounterCombatResult.Win) || EncounterManager.Instance.lastDialogueResult == EncounterManager.EncounterDialogueOutcome.Withdraw)
			{
				PopUntilTravelling();
			}
			if (m_currentRegion.questInstanceId > -1)
			{
				PopUntilTravelling();
			}
			else if (m_visitedThisTrip.Find((ExpeditionMap.GridRef x) => x.isEqualTo(m_currentRegion.gridReference)) == null && m_currentRegion.isSearchable)
			{
				Begin_SearchingLocation();
			}
		}
	}

	private void PopUntilTravelling()
	{
		while (m_stateStack.Count > 0 && m_stateStack.Peek().state != ePartyState.Traveling)
		{
			m_stateStack.Pop();
		}
	}

	public bool IsRelocationEnabled()
	{
		return false;
	}

	public bool IsReadyForLoad()
	{
		return true;
	}

	public bool SaveLoad(SaveData data)
	{
		//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c2: Unknown result type (might be due to invalid IL or missing references)
		data.GroupStart("Party_" + m_id.ToString("D3"));
		data.SaveLoad("partyId", ref m_id);
		data.SaveLoad("factionId", ref m_factionId);
		data.SaveLoad("membersReady", ref m_membersReadyCount);
		data.SaveLoadList("PartyMembers", m_partyMembers, delegate(int i)
		{
			m_partyMembers[i].SaveLoadPartyMember(data);
		}, delegate
		{
			if ((Object)(object)ExplorationManager.Instance != (Object)null)
			{
				PartyMember partyMember = ExplorationManager.Instance.AddMemberToParty(m_id);
				if ((Object)(object)partyMember != (Object)null)
				{
					partyMember.SaveLoadPartyMember(data);
					if ((Object)(object)partyMember.person == (Object)null)
					{
						ExplorationManager.Instance.RemoveMemberFromParty(m_id, partyMember);
					}
				}
			}
		});
		bool value = (Object)(object)m_pet != (Object)null;
		data.SaveLoad("hasPet", ref value);
		data.SaveLoad("petReady", ref m_petReady);
		if (data.isLoading && value && (Object)(object)FamilyManager.Instance != (Object)null)
		{
			m_pet = FamilyManager.Instance.GetPet();
		}
		data.SaveLoad("water", ref m_water);
		data.SaveLoad("waterContamination", ref m_waterContamination);
		int value2 = ((!((Object)(object)m_vehicle == (Object)null)) ? m_vehicle.objectId : (-1));
		data.SaveLoad("vehicleId", ref value2);
		data.SaveLoad("petrol", ref m_petrol);
		if (data.isLoading && value2 > -1 && (Object)(object)ObjectManager.Instance != (Object)null)
		{
			m_vehicle = ObjectManager.Instance.GetObjectWithId(value2) as Obj_CamperVan;
		}
		int value3 = ((!((Object)(object)m_horse == (Object)null)) ? m_horse.objectId : (-1));
		data.SaveLoad("horseId", ref value3);
		if (data.isLoading && value3 > -1 && (Object)(object)ObjectManager.Instance != (Object)null)
		{
			m_horse = ObjectManager.Instance.GetObjectWithId(value3) as Obj_Horse;
		}
		data.SaveLoad("searchExp", ref m_searchExperienceGained);
		try
		{
			data.SaveLoadList("visitedLocations", m_visitedThisTrip, delegate(int i)
			{
				data.SaveLoad("x", ref m_visitedThisTrip[i].x);
				data.SaveLoad("y", ref m_visitedThisTrip[i].y);
			}, delegate
			{
				ExpeditionMap.GridRef gridRef2 = new ExpeditionMap.GridRef();
				data.SaveLoad("x", ref gridRef2.x);
				data.SaveLoad("y", ref gridRef2.y);
				m_visitedThisTrip.Add(gridRef2);
			});
		}
		catch
		{
		}
		try
		{
			data.SaveLoadList("searchedList", m_searchedThisTrip, delegate(int i)
			{
				string value5 = m_searchedThisTrip[i];
				data.SaveLoad("regionName", ref value5);
			}, delegate
			{
				string value5 = string.Empty;
				data.SaveLoad("regionName", ref value5);
				if (!string.IsNullOrEmpty(value5))
				{
					m_searchedThisTrip.Add(value5);
				}
			});
		}
		catch (SaveData.MissingGroupException)
		{
		}
		data.SaveLoad("recalled", ref m_isRecalled);
		data.SaveLoad("location", ref m_location);
		data.SaveLoad("lastWaypoint", ref m_lastWaypoint);
		data.SaveLoad("currWaypoint", ref m_currWaypoint);
		data.SaveLoad("waypointDist", ref m_waypointDistance);
		data.SaveLoad("waypointProg", ref m_waypointProgress);
		data.SaveLoad("speedModifier", ref m_speedModifier);
		data.SaveLoad("distanceTravelled", ref m_distanceTraveled);
		data.SaveLoad("distanceTravelledUntilOG", ref m_distanceUntilOGEncounter);
		data.SaveLoad("currentLeg", ref m_currentLeg);
		data.SaveLoadList("Route", m_route, delegate(int i)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			Vector2 value5 = m_route[i];
			data.SaveLoad("waypoint", ref value5);
		}, delegate
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			Vector2 value5 = Vector2.zero;
			data.SaveLoad("waypoint", ref value5);
			m_route.Add(value5);
		});
		if (data.isLoading)
		{
			m_currentRegion = ExpeditionMap.Instance.GetRegionInWorld(m_location);
		}
		data.SaveLoadList("CarriedItems", m_carriedItems, delegate(int i)
		{
			int value5 = (int)m_carriedItems[i].m_type;
			data.SaveLoad("itemType", ref value5);
			data.SaveLoad("itemCount", ref m_carriedItems[i].m_count);
		}, delegate
		{
			ItemGrid.ItemSlot itemSlot = new ItemGrid.ItemSlot();
			int value5 = -1;
			data.SaveLoad("itemType", ref value5);
			data.SaveLoad("itemCount", ref itemSlot.m_count);
			itemSlot.m_type = (ItemManager.ItemType)value5;
			m_carriedItems.Add(itemSlot);
		});
		data.SaveLoad("combatParticipation", ref m_participatedInCombat);
		List<ePartyState> loadedStates = new List<ePartyState>();
		List<StateDef> stack = new List<StateDef>();
		stack.AddRange(m_stateStack.ToArray());
		data.SaveLoadList("stateStack", stack, delegate(int i)
		{
			int value5 = (int)stack[i].state;
			data.SaveLoad("state", ref value5);
		}, delegate
		{
			int value5 = -1;
			data.SaveLoad("state", ref value5);
			if (value5 > -1)
			{
				loadedStates.Add((ePartyState)value5);
			}
		});
		data.SaveLoad("encounteredStorm", ref m_encounteredStorm);
		data.SaveLoad("encounteredNpcs", ref m_encounteredNpcsThisTrip);
		if (data.isLoading)
		{
			UpdateSightRangeValue();
			UpdatePerceptionValue();
		}
		if (data.isLoading)
		{
			loadedStates.Reverse();
			for (int num = 0; num < loadedStates.Count; num++)
			{
				switch (loadedStates[num])
				{
				case ePartyState.ReportingLocation:
				case ePartyState.ReportingLocationWaitUser:
					Begin_ReportingLocation();
					break;
				case ePartyState.SearchingLocation:
					Begin_SearchingLocation();
					break;
				case ePartyState.LeavingShelter:
				case ePartyState.VehicleLeaving:
				case ePartyState.HorseLeaving:
					PushState(ePartyState.LeavingShelter);
					break;
				case ePartyState.EnteringShelter:
					Begin_EnteringShelter();
					break;
				case ePartyState.VehicleReturning:
					Begin_VehicleReturning();
					break;
				case ePartyState.HorseReturning:
					Begin_HorseReturning();
					break;
				case ePartyState.EncounteredItemsStart:
				case ePartyState.EncounteredItems:
				case ePartyState.EncounteredItemsWaitUser:
				case ePartyState.EncounteredItemsRequestTransferPanel:
				case ePartyState.EncounteredItemsWaitItemTransfer:
					PushState(ePartyState.EncounteredItemsStart);
					break;
				case ePartyState.EncounteredNPCsStart:
				case ePartyState.EncounteredNPCs:
				case ePartyState.EncounteredNPCsWaitUser:
				case ePartyState.EncounteredNPCsRequestNewEncounter:
				case ePartyState.EncounteredNPCsWaitFinished:
				case ePartyState.EncounteredNPCsAutoResolve:
					PushState(ePartyState.EncounteredNPCsStart);
					break;
				case ePartyState.OpenGroundNpcEncounterStart:
				case ePartyState.OpenGroundNpcEncounter:
				case ePartyState.OpenGroundNpcEncounterWaitUser:
				case ePartyState.OpenGroundNpcEncounterRequestNewEncounter:
				case ePartyState.OpenGroundNpcEncounterWaitFinished:
				case ePartyState.OpenGroundNpcEncounterAutoResolve:
					PushState(ePartyState.OpenGroundNpcEncounterStart);
					break;
				case ePartyState.EncounteredQuestNPCs:
				case ePartyState.EncounteredQuestNPCsWaitUser:
					PushState(ePartyState.EncounteredQuestNPCs);
					break;
				case ePartyState.QuestEncounterStart:
				case ePartyState.QuestEncounterWaitFinished:
					PushState(ePartyState.QuestEncounterStart);
					break;
				case ePartyState.ReportingDiversionsStart:
				case ePartyState.ReportingDiversions:
				case ePartyState.ReportingDiversionsWaitUser:
					PushState(ePartyState.ReportingDiversionsStart);
					break;
				case ePartyState.ReturnedShowExperienceGained:
				case ePartyState.ReturnedRequestTransferPanel:
				case ePartyState.ReturnedWaitItemTransfer:
				case ePartyState.EnteringShelterNextUpdate:
					PushState(ePartyState.EnteringShelterNextUpdate);
					break;
				default:
					PushState(loadedStates[num]);
					break;
				}
			}
			if (loadedStates.Count == 0)
			{
				bool flag = false;
				if ((Object)(object)ExpeditionMap.Instance != (Object)null)
				{
					ExpeditionMap.GridRef gridRef = ExpeditionMap.Instance.WorldPosToGridRef(Vector2.zero);
					if (Mathf.Abs(currentRegion.gridReference.x - gridRef.x) <= 2 && Mathf.Abs(currentRegion.gridReference.y - gridRef.y) <= 2)
					{
						flag = true;
					}
				}
				bool value4 = false;
				data.SaveLoad("returning", ref value4);
				if (flag || value4)
				{
					if ((Object)(object)m_vehicle != (Object)null)
					{
						Begin_VehicleReturning();
					}
					else if ((Object)(object)m_horse != (Object)null)
					{
						Begin_HorseReturning();
					}
					else
					{
						Begin_EnteringShelter();
					}
				}
			}
		}
		data.GroupEnd();
		return true;
	}
}
