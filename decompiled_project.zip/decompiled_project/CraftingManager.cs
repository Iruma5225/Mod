using System;
using System.Collections.Generic;
using UnityEngine;

public class CraftingManager : BaseManagerNoUpdate, ISaveable
{
	public enum CraftLocation
	{
		Workbench,
		Lab,
		AmmoPress
	}

	[Serializable]
	public class Recipe
	{
		[Serializable]
		public class Ingredient
		{
			public ItemManager.ItemType Item = ItemManager.ItemType.Undefined;

			public int Quantity = 1;
		}

		public string ID = string.Empty;

		public CraftLocation location;

		[Range(1f, 5f)]
		public int level = 1;

		public bool unique;

		public bool locked;

		public ItemManager.ItemType Result = ItemManager.ItemType.Undefined;

		public Ingredient[] Input = new Ingredient[0];

		public Recipe(ItemManager.ItemType result, Ingredient[] input)
		{
			Result = result;
			Input = input;
		}
	}

	[SerializeField]
	private List<Recipe> m_RecipesInspector = new List<Recipe>();

	private Dictionary<ItemManager.ItemType, List<Recipe>> m_CraftingRecipes = new Dictionary<ItemManager.ItemType, List<Recipe>>();

	private Dictionary<int, List<Recipe>> m_RecipesByLevel = new Dictionary<int, List<Recipe>>();

	private List<string> m_UnlockedRecipes = new List<string>();

	private List<string> m_CraftedRecipes = new List<string>();

	private static float[] CraftTimesToTools = new float[11]
	{
		1f, 1f, 0.9f, 0.8f, 0.7f, 0.6f, 0.5f, 0.4f, 0.3f, 0.2f,
		0.1f
	};

	public static readonly Recipe FreeLadderRecipe = new Recipe(ItemManager.ItemType.Shelter_Ladder, new Recipe.Ingredient[0]);

	private static CraftingManager m_theInstance = null;

	public static CraftingManager Instance => m_theInstance;

	private void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
			return;
		}
		Debug.Log((object)"Duplicate CraftingManager created!");
		Object.Destroy((Object)(object)this);
	}

	public override void StartManager()
	{
		LoadRecipesFromInspector(m_RecipesInspector, m_CraftingRecipes);
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
	}

	private void LoadRecipesFromInspector(List<Recipe> list, Dictionary<ItemManager.ItemType, List<Recipe>> dictionary)
	{
		if (list.Count > 0)
		{
			for (int i = 0; i < list.Count; i++)
			{
				AddRecipe(list[i]);
			}
		}
	}

	public bool AddRecipe(Recipe newRecipe)
	{
		if (!IsRecipeValid(newRecipe))
		{
			return false;
		}
		if (newRecipe.level < 0)
		{
			return false;
		}
		if (m_CraftingRecipes.ContainsKey(newRecipe.Result))
		{
			m_CraftingRecipes[newRecipe.Result].Add(newRecipe);
		}
		else
		{
			List<Recipe> list = new List<Recipe>();
			list.Add(newRecipe);
			List<Recipe> value = list;
			m_CraftingRecipes.Add(newRecipe.Result, value);
		}
		if (m_RecipesByLevel.TryGetValue(newRecipe.level, out var value2))
		{
			value2.Add(newRecipe);
		}
		else
		{
			List<Recipe> list = new List<Recipe>();
			list.Add(newRecipe);
			List<Recipe> value3 = list;
			m_RecipesByLevel.Add(newRecipe.level, value3);
		}
		return true;
	}

	public bool RemoveRecipe(string id)
	{
		foreach (KeyValuePair<ItemManager.ItemType, List<Recipe>> craftingRecipe in m_CraftingRecipes)
		{
			for (int i = 0; i < craftingRecipe.Value.Count; i++)
			{
				if (string.Compare(id, craftingRecipe.Value[i].ID) == 0)
				{
					craftingRecipe.Value.RemoveAt(i);
					if (craftingRecipe.Value.Count <= 0)
					{
						m_CraftingRecipes.Remove(craftingRecipe.Key);
					}
					return true;
				}
			}
		}
		return false;
	}

	public List<Recipe> GetAllRecipes()
	{
		List<Recipe> list = new List<Recipe>();
		foreach (List<Recipe> value in m_CraftingRecipes.Values)
		{
			list.AddRange(value);
		}
		return RemoveUnavailableRecipes(list);
	}

	public List<Recipe> GetAllRecipes(CraftLocation location)
	{
		return FilterRecipesByLocation(GetAllRecipes(), location);
	}

	public List<Recipe> GetRecipesByLevel(int level)
	{
		if (!m_RecipesByLevel.TryGetValue(level, out var value))
		{
			return null;
		}
		return RemoveUnavailableRecipes(value);
	}

	public List<Recipe> GetRecipesByLevel(int level, CraftLocation location)
	{
		return FilterRecipesByLocation(GetRecipesByLevel(level), location);
	}

	private List<Recipe> RemoveUnavailableRecipes(List<Recipe> recipes)
	{
		List<Recipe> list = new List<Recipe>();
		ItemDefinition itemDefinition = null;
		for (int i = 0; i < recipes.Count; i++)
		{
			itemDefinition = ItemManager.Instance.GetItemDefinition(recipes[i].Result);
			if (!((Object)(object)itemDefinition == (Object)null) && (!recipes[i].locked || m_UnlockedRecipes.Contains(recipes[i].ID)) && (!recipes[i].unique || !m_CraftedRecipes.Contains(recipes[i].ID)))
			{
				list.Add(recipes[i]);
			}
		}
		return list;
	}

	private List<Recipe> FilterRecipesByLocation(List<Recipe> recipes, CraftLocation location)
	{
		List<Recipe> list = new List<Recipe>();
		for (int i = 0; i < recipes.Count; i++)
		{
			if (recipes[i].location == location)
			{
				list.Add(recipes[i]);
			}
		}
		return list;
	}

	public List<Recipe> GetRecipesForItem(ItemManager.ItemType item)
	{
		List<Recipe> value = null;
		m_CraftingRecipes.TryGetValue(item, out value);
		if (value == null)
		{
			return null;
		}
		return new List<Recipe>(value);
	}

	public Recipe GetRecipeByID(string id)
	{
		foreach (KeyValuePair<ItemManager.ItemType, List<Recipe>> craftingRecipe in m_CraftingRecipes)
		{
			for (int i = 0; i < craftingRecipe.Value.Count; i++)
			{
				if (string.Compare(id, craftingRecipe.Value[i].ID) == 0)
				{
					return craftingRecipe.Value[i];
				}
			}
		}
		return null;
	}

	public bool UnlockRecipe(string id)
	{
		Recipe recipeByID = GetRecipeByID(id);
		if (recipeByID == null)
		{
			return false;
		}
		if (!recipeByID.locked)
		{
			return false;
		}
		if (m_UnlockedRecipes.Contains(id))
		{
			return false;
		}
		m_UnlockedRecipes.Add(id);
		return true;
	}

	public bool LockRecipe(string id)
	{
		Recipe recipeByID = GetRecipeByID(id);
		if (recipeByID == null)
		{
			return false;
		}
		if (!m_UnlockedRecipes.Contains(id))
		{
			return false;
		}
		m_UnlockedRecipes.Remove(id);
		return true;
	}

	public bool SetRecipeAsCrafted(Recipe recipe)
	{
		if (recipe == null || string.IsNullOrEmpty(recipe.ID))
		{
			return false;
		}
		string iD = recipe.ID;
		if (m_CraftedRecipes.Contains(iD))
		{
			return false;
		}
		m_CraftedRecipes.Add(iD);
		return true;
	}

	public bool UnsetRecipeAsCrafted(Recipe recipe)
	{
		if (recipe == null || string.IsNullOrEmpty(recipe.ID))
		{
			return false;
		}
		string iD = recipe.ID;
		if (!m_CraftedRecipes.Contains(iD))
		{
			return false;
		}
		m_CraftedRecipes.Remove(iD);
		return true;
	}

	public bool HasBeenCrafted(Recipe recipe)
	{
		if (m_CraftedRecipes != null && m_CraftedRecipes.Count > 0)
		{
			return m_CraftedRecipes.FindIndex((string x) => string.Compare(x, recipe.ID) == 0) >= 0;
		}
		return false;
	}

	public static bool CanCraftRecipe(Recipe recipe)
	{
		if ((Object)(object)InventoryManager.Instance == (Object)null || recipe == null)
		{
			return false;
		}
		for (int i = 0; i < recipe.Input.Length; i++)
		{
			if (InventoryManager.Instance.GetNumItemsOfType(recipe.Input[i].Item) < recipe.Input[i].Quantity)
			{
				return false;
			}
		}
		return true;
	}

	private static bool IsRecipeValid(Recipe recipe)
	{
		if (recipe.Result == ItemManager.ItemType.Undefined)
		{
			return false;
		}
		if (!IsSpecial(recipe.Result))
		{
			if (!CheckIsValidItem(recipe.Result) && !CheckIsValidObject(recipe.Result))
			{
				return false;
			}
			if (recipe.Input.Length <= 0)
			{
				return false;
			}
		}
		Recipe.Ingredient[] input = recipe.Input;
		foreach (Recipe.Ingredient ingredient in input)
		{
			if (ingredient.Item == ItemManager.ItemType.Undefined)
			{
				return false;
			}
			if (!ItemManager.Instance.HasBeenDefined(ingredient.Item))
			{
				return false;
			}
		}
		return true;
	}

	private static bool CheckIsValidItem(ItemManager.ItemType craft)
	{
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(craft);
		if ((Object)(object)itemDefinition != (Object)null)
		{
			return true;
		}
		return false;
	}

	private static bool CheckIsValidObject(ItemManager.ItemType craft)
	{
		if ((Object)(object)ObjectManager.Instance == (Object)null)
		{
			return false;
		}
		if (ObjectManager.Instance.HasPrefab(ConvertResultToObject(craft)))
		{
			return true;
		}
		return false;
	}

	public static bool IsItem(ItemManager.ItemType craft)
	{
		if (ConvertResultToObject(craft) == ObjectManager.ObjectType.Undefined && !IsSpecial(craft))
		{
			return true;
		}
		return false;
	}

	public static bool IsObject(ItemManager.ItemType craft)
	{
		if (ConvertResultToObject(craft) != ObjectManager.ObjectType.Undefined && !IsSpecial(craft))
		{
			return true;
		}
		return false;
	}

	public static bool IsSpecial(ItemManager.ItemType craft)
	{
		switch (craft)
		{
		case ItemManager.ItemType.Upgrade:
			return true;
		case ItemManager.ItemType.Shelter_Room:
		case ItemManager.ItemType.Shelter_Ladder:
		case ItemManager.ItemType.Shelter_Light:
			return true;
		default:
		{
			ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(craft);
			if ((Object)(object)itemDefinition != (Object)null && itemDefinition.Category == ItemManager.ItemCategory.ShelterPaint)
			{
				return true;
			}
			if (craft == ItemManager.ItemType.Object_Sculpture)
			{
				return true;
			}
			return false;
		}
		}
	}

	public static ObjectManager.ObjectType ConvertResultToObject(ItemManager.ItemType craft)
	{
		if ((Object)(object)ItemManager.Instance == (Object)null)
		{
			return ObjectManager.ObjectType.Undefined;
		}
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(craft);
		if ((Object)(object)itemDefinition == (Object)null)
		{
			return ObjectManager.ObjectType.Undefined;
		}
		ObjectManager.ObjectType objectType = itemDefinition.ObjectType;
		if (objectType <= ObjectManager.ObjectType.Undefined && objectType >= ObjectManager.ObjectType.Max)
		{
			return ObjectManager.ObjectType.Undefined;
		}
		return objectType;
	}

	public static bool IsCraftableObject(Obj_Base obj)
	{
		ItemManager.ItemType item = ItemManager.Instance.FindItemForObject(obj.GetObjectType(), obj.objectLevel);
		List<Recipe> recipesForItem = Instance.GetRecipesForItem(item);
		if (recipesForItem != null && recipesForItem.Count > 0)
		{
			return true;
		}
		return false;
	}

	public static bool StartCraft(Recipe recipe, FamilyMember member, Obj_Base craftingTable)
	{
		if ((Object)(object)InventoryManager.Instance == (Object)null || (Object)(object)ItemManager.Instance == (Object)null || (Object)(object)member == (Object)null || recipe == null || (Object)(object)craftingTable == (Object)null)
		{
			return false;
		}
		if (!IsRecipeValid(recipe))
		{
			return false;
		}
		if ((Object)(object)((Component)craftingTable).GetComponent<Int_Craft>() == (Object)null)
		{
			return false;
		}
		if (recipe.unique && (Object)(object)Instance != (Object)null && Instance.HasBeenCrafted(recipe))
		{
			return false;
		}
		if (!RemoveItemsFromInventory(recipe))
		{
			return false;
		}
		Job_Craft job_Craft = new Job_Craft(member, recipe, craftingTable);
		if (!member.AddPlayerJob(job_Craft))
		{
			job_Craft.Cancel(forced: true);
			return true;
		}
		if (recipe.unique && (Object)(object)Instance != (Object)null)
		{
			Instance.SetRecipeAsCrafted(recipe);
		}
		return true;
	}

	public static bool CancelCraft(Recipe recipe)
	{
		if ((Object)(object)InventoryManager.Instance == (Object)null || (Object)(object)ItemManager.Instance == (Object)null || recipe == null)
		{
			return false;
		}
		if (recipe.unique && (Object)(object)Instance != (Object)null && Instance.HasBeenCrafted(recipe))
		{
			Instance.UnsetRecipeAsCrafted(recipe);
		}
		if (!AddItemsToInventory(recipe))
		{
			return false;
		}
		return true;
	}

	public static bool FinishCraft(Recipe recipe, FamilyMember member, Obj_Base craftingTable)
	{
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)InventoryManager.Instance == (Object)null || (Object)(object)ItemManager.Instance == (Object)null || (Object)(object)member == (Object)null || recipe == null)
		{
			return false;
		}
		if (IsItem(recipe.Result))
		{
			ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(recipe.Result);
			if (!((Object)(object)itemDefinition != (Object)null))
			{
				return false;
			}
			InventoryManager.Instance.AddNewItems(recipe.Result, itemDefinition.CraftStackSize);
		}
		else if (IsObject(recipe.Result))
		{
			if (craftingTable.GetObjectType() != ObjectManager.ObjectType.CraftingGhost)
			{
				return false;
			}
			Vector2 position = default(Vector2);
			((Vector2)(ref position))._002Ector(((Component)craftingTable).transform.position.x, ((Component)craftingTable).transform.position.y);
			ObjectManager.Instance.RemoveObject(craftingTable);
			ItemDefinition itemDefinition2 = ItemManager.Instance.GetItemDefinition(recipe.Result);
			if ((Object)(object)itemDefinition2 != (Object)null)
			{
				Obj_Base obj_Base = ObjectManager.Instance.SpawnObject(itemDefinition2.ObjectType, itemDefinition2.ObjectLevel, position);
				if ((Object)(object)obj_Base != (Object)null)
				{
					obj_Base.SetRecipeId(recipe.ID);
				}
			}
		}
		else if (recipe.Result == ItemManager.ItemType.Shelter_Ladder)
		{
			FinishCraft_Ladder(recipe, member, craftingTable);
		}
		else if (recipe.Result == ItemManager.ItemType.Shelter_Light)
		{
			FinishCraft_Light(recipe, member, craftingTable);
		}
		else if (ItemManager.Instance.GetItemCategory(recipe.Result) == ItemManager.ItemCategory.ShelterPaint)
		{
			FinishCraft_Paint(recipe, member, craftingTable);
		}
		else if (recipe.Result == ItemManager.ItemType.Upgrade)
		{
			FinishCraft_Upgrade(recipe, member, craftingTable);
		}
		else
		{
			if (recipe.Result != ItemManager.ItemType.Object_Sculpture)
			{
				return false;
			}
			FinishCraft_Sculpture(recipe, member, craftingTable);
		}
		if (recipe.Result != ItemManager.ItemType.Upgrade)
		{
			if ((Object)(object)AchievementManager.instance != (Object)null)
			{
				AchievementManager.instance.OnCraftFinished(recipe.Result);
			}
			if ((Object)(object)TutorialManager.Instance != (Object)null)
			{
				TutorialManager.Instance.SetPopupSeen(TutorialManager.PopupType.CraftReminder);
			}
			if (IsObject(recipe.Result) || recipe.Result == ItemManager.ItemType.Object_Sculpture)
			{
				UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.Rearrange);
			}
		}
		return true;
	}

	public static bool HasTheseIngredients(Recipe recipe)
	{
		for (int i = 0; i < recipe.Input.Length; i++)
		{
			if (InventoryManager.Instance.GetNumItemsOfType(recipe.Input[i].Item) < recipe.Input[i].Quantity)
			{
				return false;
			}
		}
		return true;
	}

	private static bool RemoveItemsFromInventory(Recipe recipe)
	{
		if ((Object)(object)InventoryManager.Instance == (Object)null)
		{
			return false;
		}
		for (int i = 0; i < recipe.Input.Length; i++)
		{
			if (!InventoryManager.Instance.RemoveItemsOfType(recipe.Input[i].Item, recipe.Input[i].Quantity))
			{
				return false;
			}
		}
		return true;
	}

	private static bool AddItemsToInventory(Recipe recipe)
	{
		if ((Object)(object)InventoryManager.Instance == (Object)null)
		{
			return false;
		}
		bool result = true;
		for (int i = 0; i < recipe.Input.Length; i++)
		{
			if (!InventoryManager.Instance.AddNewItems(recipe.Input[i].Item, recipe.Input[i].Quantity))
			{
				result = false;
			}
		}
		return result;
	}

	public static float CalculateCraftTime(float craftTime)
	{
		if ((Object)(object)InventoryManager.Instance != (Object)null)
		{
			return CraftTimesToTools[InventoryManager.Instance.ToolCount] * craftTime;
		}
		return craftTime;
	}

	public static bool StartCraft_Room(Recipe recipe, FamilyMember member, Obj_Base room_ghost, Obj_Base ladder_ghost = null)
	{
		if (!RemoveItemsFromInventory(recipe))
		{
			return false;
		}
		Job_CraftRoom job_CraftRoom = new Job_CraftRoom(member, recipe, room_ghost);
		if (!member.AddPlayerJob(job_CraftRoom))
		{
			job_CraftRoom.Cancel(forced: true);
		}
		if ((Object)(object)ladder_ghost != (Object)null)
		{
			job_CraftRoom.AddLadder(FreeLadderRecipe, ladder_ghost);
		}
		return false;
	}

	public static bool FinishCraft_Room(Recipe recipe, FamilyMember member, Obj_Base room_ghost)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		if (room_ghost.GetObjectType() != ObjectManager.ObjectType.RoomGhost)
		{
			return false;
		}
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(((Component)room_ghost).transform.position.x, ((Component)room_ghost).transform.position.y);
		ObjectManager.Instance.RemoveObject(room_ghost);
		if (!ShelterRoomGrid.Instance.WorldCoordsToCellCoords(Vector2.op_Implicit(val), out var cell_x, out var cell_y))
		{
			return false;
		}
		if (ShelterRoomGrid.Instance.IsOnSurface(cell_x, cell_y) || cell_y - 1 < 0)
		{
			return false;
		}
		if (ShelterRoomGrid.Instance.IsOnSurface(cell_x, cell_y - 1))
		{
			ShelterRoomGrid.Instance.SetCellType(cell_x, cell_y, ShelterRoomGrid.CellType.RoomTop);
		}
		else
		{
			ShelterRoomGrid.Instance.SetCellType(cell_x, cell_y, ShelterRoomGrid.CellType.Room);
		}
		return true;
	}

	public static bool FinishCraft_Ladder(Recipe recipe, FamilyMember member, Obj_Base ladder_ghost)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		if (ladder_ghost.GetObjectType() != ObjectManager.ObjectType.LadderGhost)
		{
			return false;
		}
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(((Component)ladder_ghost).transform.position.x, ((Component)ladder_ghost).transform.position.y);
		ObjectManager.Instance.RemoveObject(ladder_ghost);
		if (!ShelterRoomGrid.Instance.WorldCoordsToCellCoords(Vector2.op_Implicit(val), out var cell_x, out var cell_y))
		{
			return false;
		}
		float num = (float)cell_x * ShelterRoomGrid.Instance.grid_cell_width;
		float num2 = num + ShelterRoomGrid.Instance.grid_cell_width;
		float num3 = (val.x - num) / (num2 - num);
		if (num3 < 0f || num3 > 1f)
		{
			return false;
		}
		if ((Object)(object)ShelterRoomGrid.Instance.AddLadder(cell_x, cell_y, num3) == (Object)null)
		{
			return false;
		}
		return true;
	}

	public static bool StartCraft_Paint(Recipe recipe, FamilyMember member, Obj_Base base_ghost)
	{
		if (!RemoveItemsFromInventory(recipe))
		{
			return false;
		}
		Job_Craft job_Craft = new Job_Craft(member, recipe, base_ghost);
		if (!member.AddPlayerJob(job_Craft))
		{
			job_Craft.Cancel(forced: true);
		}
		return false;
	}

	public static bool FinishCraft_Paint(Recipe recipe, FamilyMember member, Obj_Base base_ghost)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		if (base_ghost.GetObjectType() != ObjectManager.ObjectType.RoomPaintGhost)
		{
			return false;
		}
		Obj_RoomPaintGhost obj_RoomPaintGhost = (Obj_RoomPaintGhost)base_ghost;
		if ((Object)(object)base_ghost == (Object)null)
		{
			return false;
		}
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(((Component)obj_RoomPaintGhost).transform.position.x, ((Component)obj_RoomPaintGhost).transform.position.y);
		Color paintColor = obj_RoomPaintGhost.PaintColor;
		ObjectManager.Instance.RemoveObject(obj_RoomPaintGhost);
		if (!ShelterRoomGrid.Instance.WorldCoordsToCellCoords(Vector2.op_Implicit(val), out var cell_x, out var cell_y))
		{
			return false;
		}
		ShelterRoomGrid.Instance.ClearGraffiti(cell_x, cell_y);
		ShelterRoomGrid.Instance.PaintRoom(cell_x, cell_y, paintColor);
		return true;
	}

	public static bool StartCraft_Light(Recipe recipe, FamilyMember member, Obj_Base base_ghost)
	{
		if (!RemoveItemsFromInventory(recipe))
		{
			return false;
		}
		Job_Craft job_Craft = new Job_Craft(member, recipe, base_ghost);
		if (!member.AddPlayerJob(job_Craft))
		{
			job_Craft.Cancel(forced: true);
		}
		return false;
	}

	public static bool FinishCraft_Light(Recipe recipe, FamilyMember member, Obj_Base base_ghost)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		if (base_ghost.GetObjectType() != ObjectManager.ObjectType.RoomLightGhost)
		{
			return false;
		}
		Obj_RoomLightGhost obj_RoomLightGhost = (Obj_RoomLightGhost)base_ghost;
		if ((Object)(object)obj_RoomLightGhost == (Object)null)
		{
			return false;
		}
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(((Component)obj_RoomLightGhost).transform.position.x, ((Component)obj_RoomLightGhost).transform.position.y);
		ObjectManager.Instance.RemoveObject(obj_RoomLightGhost);
		if (!ShelterRoomGrid.Instance.WorldCoordsToCellCoords(Vector2.op_Implicit(val), out var cell_x, out var cell_y))
		{
			return false;
		}
		ShelterRoomGrid.Instance.AddLight(cell_x, cell_y);
		return true;
	}

	public static bool FinishCraft_Upgrade(Recipe recipe, FamilyMember member, Obj_Base base_obj)
	{
		UpgradeObject component = ((Component)base_obj).GetComponent<UpgradeObject>();
		if ((Object)(object)component == (Object)null)
		{
			return false;
		}
		if (!component.GetLevelFromID(recipe.ID, out var path, out var level))
		{
			return false;
		}
		component.Upgrade(path, level);
		base_obj.SetIsBeingUpgraded(set: false);
		base_obj.SetUpgradeCharacter(null);
		if ((Object)(object)AchievementManager.instance != (Object)null)
		{
			AchievementManager.instance.OnObjectUpgraded(base_obj);
		}
		return true;
	}

	public static bool FinishCraft_Sculpture(Recipe recipe, FamilyMember member, Obj_Base base_ghost)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		if (base_ghost.GetObjectType() != ObjectManager.ObjectType.CraftingGhost)
		{
			return false;
		}
		Vector2 position = default(Vector2);
		((Vector2)(ref position))._002Ector(((Component)base_ghost).transform.position.x, ((Component)base_ghost).transform.position.y);
		Obj_CraftingGhost obj_CraftingGhost = base_ghost as Obj_CraftingGhost;
		ObjectManager.ObjectType objectType = ObjectManager.ObjectType.Undefined;
		int level = 0;
		if ((Object)(object)obj_CraftingGhost != (Object)null)
		{
			objectType = obj_CraftingGhost.imitatedType;
			level = obj_CraftingGhost.imitatedLevel;
		}
		ObjectManager.Instance.RemoveObject(base_ghost);
		Obj_Base obj_Base = null;
		if (objectType != ObjectManager.ObjectType.Undefined)
		{
			obj_Base = ObjectManager.Instance.SpawnObject(objectType, level, position);
		}
		if ((Object)(object)obj_Base != (Object)null)
		{
			obj_Base.SetRecipeId(recipe.ID);
		}
		return true;
	}

	public bool IsRelocationEnabled()
	{
		return true;
	}

	public bool IsReadyForLoad()
	{
		return true;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("CraftingManager");
		data.SaveLoadList("unlocked_recipes", m_UnlockedRecipes, delegate(int i)
		{
			string value = m_UnlockedRecipes[i];
			data.SaveLoad("id", ref value);
		}, delegate
		{
			string value = string.Empty;
			data.SaveLoad("id", ref value);
			if (!string.IsNullOrEmpty(value))
			{
				m_UnlockedRecipes.Add(value);
			}
		});
		try
		{
			data.SaveLoadList("crafted_recipes", m_CraftedRecipes, delegate(int i)
			{
				string value = m_CraftedRecipes[i];
				data.SaveLoad("id", ref value);
			}, delegate
			{
				string value = string.Empty;
				data.SaveLoad("id", ref value);
				if (!string.IsNullOrEmpty(value))
				{
					m_CraftedRecipes.Add(value);
				}
			});
		}
		catch (SaveData.MissingGroupException)
		{
		}
		data.GroupEnd();
		return true;
	}

	private void OnValidate()
	{
		if (((Behaviour)this).isActiveAndEnabled)
		{
			RefreshRecipeIDs();
		}
	}

	[ContextMenu("Refresh Recipe IDs")]
	public void RefreshRecipeIDs()
	{
		if (m_RecipesInspector == null)
		{
			return;
		}
		Recipe recipe = null;
		for (int i = 0; i < m_RecipesInspector.Count; i++)
		{
			recipe = m_RecipesInspector[i];
			if (m_CraftingRecipes.ContainsKey(recipe.Result))
			{
				m_CraftingRecipes[recipe.Result].Add(recipe);
			}
			else
			{
				List<Recipe> list = new List<Recipe>();
				list.Add(recipe);
				List<Recipe> value = list;
				m_CraftingRecipes.Add(recipe.Result, value);
			}
			recipe.ID = recipe.Result.ToString() + "_" + m_CraftingRecipes[recipe.Result].Count;
		}
		m_CraftingRecipes.Clear();
	}
}
