using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

public class ItemGrid : UIGrid
{
	public class ItemSlot
	{
		public ItemManager.ItemType m_type = ItemManager.ItemType.Undefined;

		public int m_count;

		public int m_stackSize;

		public int m_slotIndex = -1;
	}

	public delegate void ItemGridSelectionEvent(ItemGrid grid, ItemManager.ItemType type, int slotIndex);

	public delegate void ItemGridDeselectionEvent(ItemGrid grid);

	public delegate void GridFullEvent(ItemGrid grid);

	public delegate void ItemGridClickEvent(ItemGrid grid, ItemManager.ItemType type, int slotIndex, bool rightClick);

	public GameObject m_itemButtonPrefab;

	public int m_visibleSlots;

	public int m_maxSlots;

	public bool m_stackedItems;

	public bool m_alwaysSortByType;

	public bool m_ignoreWaterRationStackSize;

	public bool m_alwaysSortByCategory;

	public bool m_lockAllButtons;

	public float m_scrollFactor = 2f;

	private float m_ScrollAccumulator;

	private bool m_initialized;

	private List<ItemSlot> m_items = new List<ItemSlot>();

	private List<ItemButtonBase> m_buttons = new List<ItemButtonBase>();

	private ItemGridSelectionEvent onItemGridSelection;

	private ItemGridDeselectionEvent onItemGridDeselection;

	public GridFullEvent onGridFull;

	private ItemGridClickEvent onItemGridClick;

	private int m_topVisibleRow;

	public bool m_navigationScrolling;

	private GameObject m_hiddenScrollUpObject;

	private GameObject m_hiddenScrollDownObject;

	public UIButton m_visibleScrollUpButton;

	public UIButton m_visibleScrollDownButton;

	private GameObject m_selectedButton;

	private ItemButtonBase m_selectedButtonBase;

	public List<ItemButtonBase> GetButtons => m_buttons;

	protected override void Start()
	{
		base.Start();
		((Behaviour)this).enabled = true;
	}

	public ReadOnlyCollection<ItemSlot> GetItems()
	{
		return m_items.AsReadOnly();
	}

	public void Initialize(ItemGridSelectionEvent selectionDelegate, ItemGridDeselectionEvent deselectionDelegate, ItemGridClickEvent clickEvent)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		m_topVisibleRow = 0;
		if (!m_initialized)
		{
			onItemGridSelection = selectionDelegate;
			onItemGridDeselection = deselectionDelegate;
			onItemGridClick = clickEvent;
			if ((Object)(object)m_itemButtonPrefab != (Object)null)
			{
				for (int i = 0; i < m_visibleSlots; i++)
				{
					GameObject val = Object.Instantiate<GameObject>(m_itemButtonPrefab, Vector3.zero, Quaternion.identity);
					if ((Object)(object)val != (Object)null)
					{
						val.transform.parent = ((Component)this).transform;
						val.transform.localScale = Vector3.one;
						((Object)val).name = "item_" + i.ToString("D2");
						AddChild(val.transform);
						ItemButtonBase component = val.GetComponent<ItemButtonBase>();
						if ((Object)(object)component != (Object)null)
						{
							component.SetSlotIndex(i);
							component.SetItem(ItemManager.ItemType.Undefined, 0, 0);
							component.onSelected = OnItemSelected;
							component.onClicked = OnItemClicked;
							component.onScrolled = OnItemScrolled;
							m_buttons.Add(component);
						}
					}
				}
			}
			InitializeScrollButtons();
			m_initialized = true;
		}
		ClearItems();
		UpdateScrollButtons();
		base.repositionNow = true;
	}

	private void InitializeScrollButtons()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Expected O, but got Unknown
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Expected O, but got Unknown
		if (!m_navigationScrolling)
		{
			return;
		}
		GameObject val = new GameObject(((Object)this).name + "_scrollup", new Type[3]
		{
			typeof(UIKeyNavigation),
			typeof(UIButton),
			typeof(ItemGridScrollWidget)
		});
		if ((Object)(object)val != (Object)null)
		{
			val.transform.parent = ((Component)this).transform;
			UIButton component = val.GetComponent<UIButton>();
			if ((Object)(object)component != (Object)null)
			{
				component.tweenTarget = ((Component)component).gameObject;
				((Behaviour)component).enabled = false;
			}
			ItemGridScrollWidget component2 = val.GetComponent<ItemGridScrollWidget>();
			if ((Object)(object)component2 != (Object)null)
			{
				component2.onSelection = OnNavigationScrollUp;
			}
			m_hiddenScrollUpObject = val;
		}
		val = new GameObject(((Object)this).name + "_scrolldown", new Type[3]
		{
			typeof(UIKeyNavigation),
			typeof(UIButton),
			typeof(ItemGridScrollWidget)
		});
		if ((Object)(object)val != (Object)null)
		{
			val.transform.parent = ((Component)this).transform;
			UIButton component3 = val.GetComponent<UIButton>();
			if ((Object)(object)component3 != (Object)null)
			{
				component3.tweenTarget = ((Component)component3).gameObject;
				((Behaviour)component3).enabled = false;
			}
			ItemGridScrollWidget component4 = val.GetComponent<ItemGridScrollWidget>();
			if ((Object)(object)component4 != (Object)null)
			{
				component4.onSelection = OnNavigationScrollDown;
			}
			m_hiddenScrollDownObject = val;
		}
	}

	private void UpdateScrollButtons()
	{
		bool flag = false;
		bool flag2 = false;
		if (m_topVisibleRow > 0)
		{
			flag = true;
		}
		int num = m_visibleSlots / maxPerLine;
		int num2 = m_maxSlots / maxPerLine;
		int num3 = m_items.Count / maxPerLine;
		if (m_items.Count % maxPerLine > 0)
		{
			num3++;
		}
		if (m_maxSlots % maxPerLine > 0)
		{
			num2++;
		}
		if (m_topVisibleRow + num < num2 && m_topVisibleRow + num < num3 && m_items.Count > maxPerLine * num)
		{
			flag2 = true;
		}
		if (m_navigationScrolling)
		{
			for (int i = 0; i < Mathf.Min(m_buttons.Count, maxPerLine); i++)
			{
				UIKeyNavigation component = ((Component)m_buttons[i]).GetComponent<UIKeyNavigation>();
				if ((Object)(object)component != (Object)null)
				{
					component.onUp = ((!flag) ? null : m_hiddenScrollUpObject);
				}
			}
			for (int j = Mathf.Max(0, m_buttons.Count - maxPerLine); j < m_buttons.Count; j++)
			{
				UIKeyNavigation component2 = ((Component)m_buttons[j]).GetComponent<UIKeyNavigation>();
				if ((Object)(object)component2 != (Object)null)
				{
					component2.onDown = ((!flag2) ? null : m_hiddenScrollDownObject);
				}
			}
		}
		if ((Object)(object)m_visibleScrollUpButton != (Object)null)
		{
			((Behaviour)m_visibleScrollUpButton).enabled = flag;
			m_visibleScrollUpButton.SetState((!flag) ? UIButtonColor.State.Disabled : UIButtonColor.State.Normal, immediate: true);
		}
		if ((Object)(object)m_visibleScrollDownButton != (Object)null)
		{
			((Behaviour)m_visibleScrollDownButton).enabled = flag2;
			m_visibleScrollDownButton.SetState((!flag2) ? UIButtonColor.State.Disabled : UIButtonColor.State.Normal, immediate: true);
		}
	}

	private void OnNavigationScrollUp()
	{
		ScrollUp();
		if ((Object)(object)m_selectedButton != (Object)null)
		{
			UICamera.selectedObject = m_selectedButton;
		}
	}

	private void OnNavigationScrollDown()
	{
		ScrollDown();
		if ((Object)(object)m_selectedButton != (Object)null)
		{
			UICamera.selectedObject = m_selectedButton;
		}
	}

	public void ScrollUp()
	{
		if (m_topVisibleRow > 0)
		{
			m_topVisibleRow--;
			UpdateItems();
		}
	}

	public void ScrollDown()
	{
		int num = m_visibleSlots / maxPerLine;
		int num2 = m_maxSlots / maxPerLine;
		int num3 = m_items.Count / maxPerLine;
		if (m_items.Count % maxPerLine > 0)
		{
			num3++;
		}
		if (m_maxSlots % maxPerLine > 0)
		{
			num2++;
		}
		if (m_topVisibleRow + num < num2 && m_topVisibleRow + num < num3 && m_items.Count > maxPerLine * num)
		{
			m_topVisibleRow++;
			UpdateItems();
		}
	}

	public void SelectFirstButton()
	{
	}

	public void ClearItems()
	{
		m_topVisibleRow = 0;
		m_items.Clear();
		UpdateItems();
	}

	protected override void Update()
	{
		base.Update();
	}

	public bool CanAddItems(ItemManager.ItemType type, int count)
	{
		int slotsRequired = 0;
		if (CalcExtraSlotsRequiredForAdd(type, count, out slotsRequired))
		{
			return m_items.Count + slotsRequired <= m_maxSlots;
		}
		return false;
	}

	public bool CalcExtraSlotsRequiredForAdd(ItemManager.ItemType type, int count, out int slotsRequired)
	{
		slotsRequired = 0;
		if ((Object)(object)ItemManager.Instance == (Object)null || type == ItemManager.ItemType.Undefined || count == 0)
		{
			return false;
		}
		int num = 0;
		for (int i = 0; i < m_items.Count; i++)
		{
			if (m_items[i].m_type == type)
			{
				num += m_items[i].m_count;
			}
		}
		int count2 = num + count;
		int stacks = 0;
		int stacks2 = 0;
		if (!ItemManager.Instance.SplitIntoStacks(type, num, out stacks))
		{
			return false;
		}
		if (!ItemManager.Instance.SplitIntoStacks(type, count2, out stacks2))
		{
			return false;
		}
		if (!m_stackedItems)
		{
			slotsRequired = ((num <= 0) ? 1 : 0);
			return true;
		}
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(type);
		if ((Object)(object)itemDefinition != (Object)null && m_ignoreWaterRationStackSize && (itemDefinition.Category == ItemManager.ItemCategory.Food || itemDefinition.Category == ItemManager.ItemCategory.Water || itemDefinition.Category == ItemManager.ItemCategory.Meat || itemDefinition.Category == ItemManager.ItemCategory.Entertainment))
		{
			slotsRequired = ((num <= 0) ? 1 : 0);
			return true;
		}
		slotsRequired = Mathf.Max(0, stacks2 - stacks);
		return true;
	}

	public bool CalcExtraSlotsRequiredForAdd(List<ItemSlot> items, out int slotsRequired)
	{
		slotsRequired = 0;
		if (items == null)
		{
			return false;
		}
		Dictionary<ItemManager.ItemType, int> dictionary = new Dictionary<ItemManager.ItemType, int>();
		Dictionary<ItemManager.ItemType, int> dictionary2 = new Dictionary<ItemManager.ItemType, int>();
		for (int i = 0; i < items.Count; i++)
		{
			ItemManager.ItemType type = items[i].m_type;
			if (dictionary2.ContainsKey(type))
			{
				dictionary2[type] += items[i].m_count;
			}
			else
			{
				dictionary2[type] = items[i].m_count;
			}
		}
		List<ItemManager.ItemType> list = new List<ItemManager.ItemType>(dictionary2.Keys);
		for (int j = 0; j < list.Count; j++)
		{
			ItemManager.ItemType itemType = list[j];
			for (int k = 0; k < m_items.Count; k++)
			{
				if (itemType == m_items[k].m_type)
				{
					dictionary2[itemType] += m_items[k].m_count;
					if (dictionary.ContainsKey(itemType))
					{
						dictionary[itemType] += m_items[k].m_count;
					}
					else
					{
						dictionary[itemType] = m_items[k].m_count;
					}
				}
			}
		}
		int num = 0;
		foreach (KeyValuePair<ItemManager.ItemType, int> item in dictionary)
		{
			int stacks = 0;
			if (!m_stackedItems)
			{
				num++;
			}
			else if (ItemManager.Instance.SplitIntoStacks(item.Key, item.Value, out stacks))
			{
				num += stacks;
			}
		}
		int num2 = 0;
		foreach (KeyValuePair<ItemManager.ItemType, int> item2 in dictionary2)
		{
			int stacks2 = 0;
			if (!m_stackedItems)
			{
				num2++;
			}
			else if (ItemManager.Instance.SplitIntoStacks(item2.Key, item2.Value, out stacks2))
			{
				num2 += stacks2;
			}
		}
		slotsRequired = Mathf.Max(0, num2 - num);
		return true;
	}

	public int GetFreeSlots()
	{
		return m_maxSlots - m_items.Count;
	}

	public int GetUsedSlots()
	{
		return m_items.Count;
	}

	public int GetNumItemsInSlot(int index)
	{
		if (index >= 0 && index < m_items.Count)
		{
			return m_items[index].m_count;
		}
		return 0;
	}

	public bool AddItem(ItemManager.ItemType type, int count)
	{
		if (count <= 0 || type == ItemManager.ItemType.Undefined)
		{
			return false;
		}
		bool flag = false;
		flag = ((!m_stackedItems) ? AddItem_Unstacked(type, count) : AddItem_Stacked(type, count));
		if (m_alwaysSortByType)
		{
			SortItemsIgnoringCount();
		}
		UpdateItems();
		return flag;
	}

	private bool AddItem_Stacked(ItemManager.ItemType type, int count)
	{
		int num = 0;
		if ((Object)(object)ItemManager.Instance != (Object)null)
		{
			ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(type);
			if ((Object)(object)itemDefinition != (Object)null)
			{
				num = itemDefinition.StackSize;
				if (m_ignoreWaterRationStackSize && (itemDefinition.Category == ItemManager.ItemCategory.Food || itemDefinition.Category == ItemManager.ItemCategory.Water || itemDefinition.Category == ItemManager.ItemCategory.Meat || itemDefinition.Category == ItemManager.ItemCategory.Entertainment))
				{
					num = 0;
				}
				if ((num != 0 || itemDefinition.Category == ItemManager.ItemCategory.Food || itemDefinition.Category == ItemManager.ItemCategory.Water || itemDefinition.Category == ItemManager.ItemCategory.Meat) && itemDefinition.Category != ItemManager.ItemCategory.Entertainment)
				{
				}
			}
		}
		int num2 = -1;
		for (int i = 0; i < m_items.Count; i++)
		{
			if (m_items[i].m_type == type)
			{
				num2 = i;
				break;
			}
		}
		if (num2 == -1)
		{
			if (m_items.Count >= m_maxSlots)
			{
				return false;
			}
			ItemSlot itemSlot = new ItemSlot();
			itemSlot.m_type = type;
			itemSlot.m_count = 0;
			itemSlot.m_stackSize = num;
			m_items.Add(itemSlot);
			num2 = m_items.Count - 1;
		}
		int num3 = count;
		while (num3 > 0)
		{
			ItemSlot itemSlot2 = m_items[num2];
			if (itemSlot2.m_stackSize <= 0)
			{
				itemSlot2.m_count += num3;
				num3 = 0;
			}
			else
			{
				int num4 = Mathf.Min(num3, itemSlot2.m_stackSize - itemSlot2.m_count);
				itemSlot2.m_count += num4;
				num3 -= num4;
			}
			if (num3 <= 0 || itemSlot2.m_count != itemSlot2.m_stackSize)
			{
				continue;
			}
			if (num2 >= m_items.Count - 1 || m_items[num2 + 1].m_type != type)
			{
				if (m_items.Count >= m_maxSlots)
				{
					return false;
				}
				int num5 = m_items.Count;
				if (num2 < m_items.Count - 1)
				{
					num5 = num2 + 1;
				}
				ItemSlot itemSlot3 = new ItemSlot();
				itemSlot3.m_type = type;
				itemSlot3.m_stackSize = num;
				itemSlot3.m_count = 0;
				m_items.Insert(num5, itemSlot3);
				num2 = num5;
			}
			else
			{
				num2++;
			}
		}
		return true;
	}

	private bool AddItem_Unstacked(ItemManager.ItemType type, int count)
	{
		int num = -1;
		for (int i = 0; i < m_items.Count; i++)
		{
			if (m_items[i].m_type == type)
			{
				num = i;
				break;
			}
		}
		if (num == -1)
		{
			if (m_items.Count >= m_maxSlots)
			{
				return false;
			}
			ItemSlot itemSlot = new ItemSlot();
			itemSlot.m_type = type;
			itemSlot.m_count = count;
			itemSlot.m_stackSize = 0;
			m_items.Add(itemSlot);
		}
		else
		{
			m_items[num].m_count += count;
		}
		return true;
	}

	public int RemoveItems(ItemManager.ItemType type, int count)
	{
		int num = count;
		int num2 = m_items.Count - 1;
		while (num2 >= 0 && num > 0)
		{
			if (m_items[num2].m_type == type)
			{
				int num3 = Mathf.Min(m_items[num2].m_count, num);
				m_items[num2].m_count -= num3;
				num -= num3;
				if (m_items[num2].m_count == 0)
				{
					m_items.RemoveAt(num2);
				}
			}
			num2--;
		}
		if (m_alwaysSortByType)
		{
			SortItemsIgnoringCount();
		}
		else
		{
			UpdateItems();
		}
		return count - num;
	}

	public int RemoveItemsAt(int slotIndex, int count)
	{
		if (slotIndex < 0 || slotIndex >= m_items.Count || count <= 0)
		{
			return 0;
		}
		ItemSlot itemSlot = m_items[slotIndex];
		int num = Mathf.Min(itemSlot.m_count, count);
		itemSlot.m_count -= num;
		if (itemSlot.m_count == 0)
		{
			m_items.RemoveAt(slotIndex);
		}
		if (m_alwaysSortByType)
		{
			SortItemsIgnoringCount();
		}
		else
		{
			UpdateItems();
		}
		return num;
	}

	public bool TransferItems(ItemGrid other, ItemManager.ItemType type, int count)
	{
		if ((Object)(object)other == (Object)null || type == ItemManager.ItemType.Undefined || count <= 0)
		{
			return false;
		}
		if (!other.CanAddItems(type, count))
		{
			if (onGridFull != null)
			{
				onGridFull(this);
			}
			return false;
		}
		int num = RemoveItems(type, count);
		if (num > 0 && !other.AddItem(type, num))
		{
			AddItem(type, num);
			return false;
		}
		return true;
	}

	public bool TransferItems(ItemGrid other, int slotIndex, int count)
	{
		if ((Object)(object)other == (Object)null || slotIndex < 0 || slotIndex >= m_items.Count || count <= 0)
		{
			return false;
		}
		ItemManager.ItemType type = m_items[slotIndex].m_type;
		if (type == ItemManager.ItemType.Undefined)
		{
			return false;
		}
		if (!other.CanAddItems(type, count))
		{
			if (onGridFull != null)
			{
				onGridFull(this);
			}
			return false;
		}
		int num = RemoveItemsAt(slotIndex, count);
		if (num > 0 && !other.AddItem(type, num))
		{
			AddItem(type, num);
			return false;
		}
		return true;
	}

	public void SortItems()
	{
		for (int i = 0; i < m_items.Count; i++)
		{
			m_items[i].m_slotIndex = i;
		}
		m_items.Sort(CompareSlots_TypeCount);
		UpdateItems();
	}

	public void SortItemsIgnoringCount()
	{
		for (int i = 0; i < m_items.Count; i++)
		{
			m_items[i].m_slotIndex = i;
		}
		if (m_alwaysSortByCategory)
		{
			m_items.Sort(CompareSlots_Category);
		}
		else
		{
			m_items.Sort(CompareSlots_Type);
		}
		UpdateItems();
	}

	public void UpdateItems()
	{
		int num = 0;
		int num2 = m_visibleSlots / maxPerLine;
		if (m_items.Count > maxPerLine * num2)
		{
			num = m_topVisibleRow * maxPerLine;
		}
		if (num <= 0 || num >= m_items.Count)
		{
		}
		for (int i = 0; i < m_buttons.Count; i++)
		{
			if ((Object)(object)m_buttons[i] != (Object)null)
			{
				m_buttons[i].SetLocked(locked: false);
			}
		}
		int num3 = 0;
		for (int j = num; j < m_items.Count; j++)
		{
			ItemSlot itemSlot = m_items[j];
			if (num3 >= m_buttons.Count)
			{
				break;
			}
			m_buttons[num3].SetItem(itemSlot.m_type, itemSlot.m_count, itemSlot.m_stackSize);
			m_buttons[num3].SetSlotIndex(j);
			num3++;
		}
		for (int k = num3; k < m_buttons.Count; k++)
		{
			m_buttons[k].SetItem(ItemManager.ItemType.Undefined, 0, 0);
			m_buttons[k].SetSlotIndex(k + num);
		}
		if (m_lockAllButtons)
		{
			for (int l = 0; l < m_buttons.Count; l++)
			{
				m_buttons[l].SetLocked(locked: true);
			}
		}
		else
		{
			for (int m = num3; m < m_buttons.Count; m++)
			{
				if (m + num >= m_maxSlots)
				{
					m_buttons[m].SetLocked(locked: true);
				}
			}
		}
		UpdateScrollButtons();
	}

	public bool IsGridSlotLocked(int slotIndex)
	{
		int num = 0;
		int num2 = m_visibleSlots / maxPerLine;
		if (m_items.Count > maxPerLine * num2)
		{
			num = m_topVisibleRow * maxPerLine;
		}
		int num3 = Mathf.Max(0, slotIndex - num);
		if (num3 < m_buttons.Count && (Object)(object)m_buttons[num3] != (Object)null)
		{
			return m_buttons[num3].IsLocked;
		}
		return false;
	}

	private void OnItemSelected(ItemButtonBase itemButton, bool selected)
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Expected O, but got Unknown
		if ((Object)(object)m_selectedButtonBase != (Object)null && m_selectedButtonBase.m_type != ItemManager.ItemType.Undefined && (Object)(object)m_selectedButtonBase != (Object)null && (Object)(object)m_selectedButtonBase != (Object)(object)itemButton)
		{
			m_selectedButtonBase.colourTween.style = UITweener.Style.Once;
			m_selectedButtonBase.colourTween.from = itemButton.defaultColour.defaultColor;
			m_selectedButtonBase.colourTween.to = itemButton.defaultColour.defaultColor;
			m_selectedButtonBase.colourTween.duration = 0.01f;
			((Behaviour)m_selectedButtonBase.colourTween).enabled = true;
		}
		if (selected && itemButton.m_type != ItemManager.ItemType.Undefined)
		{
			m_selectedButton = ((Component)itemButton).gameObject;
			m_selectedButtonBase = m_selectedButton.GetComponent<ItemButtonBase>();
			if ((Object)(object)m_selectedButton == (Object)(object)((Component)itemButton).gameObject && (Object)(object)m_selectedButtonBase != (Object)null)
			{
				m_selectedButtonBase.colourTween.style = UITweener.Style.Loop;
				m_selectedButtonBase.colourTween.from = Color.white;
				m_selectedButtonBase.colourTween.to = Color.white;
				m_selectedButtonBase.colourTween.duration = 1f;
				m_selectedButtonBase.colourTween.animationCurve = new AnimationCurve((Keyframe[])(object)new Keyframe[3]
				{
					new Keyframe(0f, 0f),
					new Keyframe(0.5f, 1f),
					new Keyframe(1f, 0f)
				});
				((Behaviour)m_selectedButtonBase.colourTween).enabled = true;
			}
		}
		else if (!selected && (Object)(object)m_selectedButtonBase != (Object)null && itemButton.m_type != ItemManager.ItemType.Undefined)
		{
			m_selectedButtonBase.colourTween.style = UITweener.Style.Once;
			m_selectedButtonBase.colourTween.from = itemButton.defaultColour.defaultColor;
			m_selectedButtonBase.colourTween.to = itemButton.defaultColour.defaultColor;
			m_selectedButtonBase.colourTween.duration = 0.01f;
			((Behaviour)m_selectedButtonBase.colourTween).enabled = true;
		}
		if (selected && onItemGridSelection != null)
		{
			onItemGridSelection(this, itemButton.m_type, itemButton.slotIndex);
		}
		if (!selected && onItemGridDeselection != null)
		{
			onItemGridDeselection(this);
		}
	}

	private void OnItemClicked(ItemButtonBase itemButton, bool rightClick)
	{
		if (onItemGridClick != null)
		{
			onItemGridClick(this, itemButton.m_type, itemButton.slotIndex, rightClick);
		}
	}

	private void OnItemScrolled(ItemButtonBase itemButton, float delta)
	{
		Scroll(delta);
	}

	private static int CompareSlots_Type(ItemSlot left, ItemSlot right)
	{
		int num = (int)left.m_type;
		int num2 = (int)right.m_type;
		switch (left.m_type)
		{
		case ItemManager.ItemType.Water:
			num = -400;
			break;
		case ItemManager.ItemType.Ration:
			num = -300;
			break;
		case ItemManager.ItemType.Meat:
			num = -200;
			break;
		case ItemManager.ItemType.DesperateMeat:
			num = -100;
			break;
		}
		switch (right.m_type)
		{
		case ItemManager.ItemType.Water:
			num2 = -400;
			break;
		case ItemManager.ItemType.Ration:
			num2 = -300;
			break;
		case ItemManager.ItemType.Meat:
			num2 = -200;
			break;
		case ItemManager.ItemType.DesperateMeat:
			num2 = -100;
			break;
		}
		if (num == num2)
		{
			return left.m_slotIndex - right.m_slotIndex;
		}
		return num - num2;
	}

	private static int CompareSlots_Category(ItemSlot left, ItemSlot right)
	{
		int num = (int)left.m_type;
		int num2 = (int)right.m_type;
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(left.m_type);
		ItemDefinition itemDefinition2 = ItemManager.Instance.GetItemDefinition(right.m_type);
		switch (itemDefinition.Category)
		{
		case ItemManager.ItemCategory.Weapon:
			num -= 5000;
			break;
		case ItemManager.ItemCategory.Equipment:
			num -= 4000;
			break;
		case ItemManager.ItemCategory.Armour:
			num -= 3000;
			break;
		case ItemManager.ItemCategory.LoadCarrying:
			num -= 2000;
			break;
		case ItemManager.ItemCategory.Ammo:
			num -= 1000;
			break;
		}
		switch (itemDefinition2.Category)
		{
		case ItemManager.ItemCategory.Weapon:
			num2 -= 5000;
			break;
		case ItemManager.ItemCategory.Equipment:
			num2 -= 4000;
			break;
		case ItemManager.ItemCategory.Armour:
			num2 -= 3000;
			break;
		case ItemManager.ItemCategory.LoadCarrying:
			num2 -= 2000;
			break;
		case ItemManager.ItemCategory.Ammo:
			num2 -= 1000;
			break;
		}
		if (num == num2)
		{
			return left.m_slotIndex - right.m_slotIndex;
		}
		return num - num2;
	}

	private static int CompareSlots_TypeCount(ItemSlot left, ItemSlot right)
	{
		int num = (int)left.m_type;
		int num2 = (int)right.m_type;
		switch (left.m_type)
		{
		case ItemManager.ItemType.Water:
			num = -400;
			break;
		case ItemManager.ItemType.Ration:
			num = -300;
			break;
		case ItemManager.ItemType.Meat:
			num = -200;
			break;
		case ItemManager.ItemType.DesperateMeat:
			num = -100;
			break;
		}
		switch (right.m_type)
		{
		case ItemManager.ItemType.Water:
			num2 = -400;
			break;
		case ItemManager.ItemType.Ration:
			num2 = -300;
			break;
		case ItemManager.ItemType.Meat:
			num2 = -200;
			break;
		case ItemManager.ItemType.DesperateMeat:
			num2 = -100;
			break;
		}
		if (num == num2)
		{
			if (left.m_count == right.m_count)
			{
				return left.m_slotIndex - right.m_slotIndex;
			}
			return right.m_count - left.m_count;
		}
		return num - num2;
	}

	public int GetNumItems(ItemManager.ItemType type)
	{
		int num = 0;
		for (int i = 0; i < m_items.Count; i++)
		{
			if (m_items[i].m_type == type)
			{
				num += m_items[i].m_count;
			}
		}
		return num;
	}

	public Vector3 GetPositionOfSlot(int slot)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		int num = slot - m_topVisibleRow * maxPerLine;
		if (num < 0 || num >= m_buttons.Count)
		{
			return Vector3.zero;
		}
		Vector3 position = ((Component)m_buttons[num]).transform.position;
		return position + new Vector3(cellWidth * ((Component)this).transform.lossyScale.x, 0f - cellHeight * ((Component)this).transform.lossyScale.y) / 2f;
	}

	public void Scroll(float delta)
	{
		if (!((Component)this).gameObject.activeInHierarchy || Mathf.Approximately(m_scrollFactor, Mathf.Epsilon))
		{
			return;
		}
		if (Mathf.Sign(m_ScrollAccumulator) != Mathf.Sign(delta))
		{
			m_ScrollAccumulator = 0f;
		}
		m_ScrollAccumulator += delta * m_scrollFactor;
		float num = Mathf.Abs(m_ScrollAccumulator);
		if (!(num >= 1f))
		{
			return;
		}
		float num2 = Mathf.Sign(m_ScrollAccumulator);
		int num3 = Mathf.FloorToInt(num);
		m_ScrollAccumulator -= (float)num3 * num2;
		if (num2 > 0f)
		{
			for (int i = 0; i < num3; i++)
			{
				ScrollUp();
			}
		}
		else
		{
			for (int j = 0; j < num3; j++)
			{
				ScrollDown();
			}
		}
		if ((Object)(object)m_selectedButton != (Object)null && (Object)(object)UICamera.hoveredObject == (Object)(object)m_selectedButton)
		{
			ItemButtonBase component = m_selectedButton.GetComponent<ItemButtonBase>();
			OnItemSelected(component, selected: false);
			OnItemSelected(component, selected: true);
		}
	}

	public void OnScroll(float delta)
	{
		Scroll(delta);
	}
}
