using System.Collections.Generic;
using UnityEngine;

public class TutorialStage_ClimbDownHatch : BaseTutorial
{
	public Transform m_initialPoint;

	public Transform m_walkWaypoints;

	private FamilyMember m_traveller;

	public override TutorialManager.TutorialStage GetTutorialStage()
	{
		return TutorialManager.TutorialStage.ClimbDownHatch;
	}

	public override void OnEnterStage(bool showPanel)
	{
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		base.OnEnterStage(showPanel);
		List<FamilyMember> list = new List<FamilyMember>();
		if ((Object)(object)FamilyManager.Instance != (Object)null)
		{
			list = FamilyManager.Instance.GetAllFamilyMembers();
		}
		if (list != null && list.Count == 4)
		{
			m_traveller = list[3];
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading)
			{
				for (int i = 0; i < list.Count; i++)
				{
					list[i].TriggerAnim("Idle");
					list[i].ClearPath();
					list[i].job_queue.ForceClear();
					list[i].ai_queue.ForceClear();
				}
				((Component)m_traveller).gameObject.transform.position = m_initialPoint.position;
				m_traveller.AddAIJob(new Job_GoToLocation(m_traveller, m_walkWaypoints.position, cancellableInTransit: false));
				Vector3 position = default(Vector3);
				((Vector3)(ref position))._002Ector(2.864f, -7.68f, 0f);
				((Component)list[0]).transform.position = position;
				((Vector3)(ref position))._002Ector(0.54f, -7.68f, 0f);
				((Component)list[1]).transform.position = position;
				((Vector3)(ref position))._002Ector(1.259f, -7.68f, 0f);
				((Component)list[2]).transform.position = position;
			}
		}
		Camera main = Camera.main;
		if ((Object)(object)main != (Object)null)
		{
			BasicCamera component = ((Component)main).GetComponent<BasicCamera>();
			if ((Object)(object)component != (Object)null)
			{
				component.SetPendingDisable(disable: true);
				component.SetCursor(CursorBase.CursorType.None);
				component.SetPendingZoom(zoomOut: false);
			}
		}
	}

	public override bool IsStageComplete()
	{
		if ((Object)(object)m_traveller == (Object)null || !m_traveller.ai_queue.is_empty)
		{
			return false;
		}
		return true;
	}

	public override void OnExitStage()
	{
		base.OnExitStage();
		if ((Object)(object)Camera.main != (Object)null)
		{
			BasicCamera component = ((Component)Camera.main).GetComponent<BasicCamera>();
			if ((Object)(object)component != (Object)null)
			{
				component.SetPendingDisable(disable: false);
				((Behaviour)component).enabled = true;
				component.SetCursor(CursorBase.CursorType.Standard);
			}
		}
	}
}
