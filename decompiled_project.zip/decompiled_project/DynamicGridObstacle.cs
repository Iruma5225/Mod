using System;
using System.Collections;
using Pathfinding;
using UnityEngine;

[RequireComponent(typeof(Collider))]
public class DynamicGridObstacle : MonoBehaviour
{
	private Collider col;

	public float updateError = 1f;

	public float checkTime = 0.2f;

	private Bounds prevBounds;

	private bool isWaitingForUpdate;

	private void Start()
	{
		col = ((Component)this).GetComponent<Collider>();
		if ((Object)(object)col == (Object)null)
		{
			throw new Exception("A collider must be attached to the GameObject for DynamicGridObstacle to work");
		}
		((MonoBehaviour)this).StartCoroutine(UpdateGraphs());
	}

	private IEnumerator UpdateGraphs()
	{
		if ((Object)(object)col == (Object)null || (Object)(object)AstarPath.active == (Object)null)
		{
			Debug.LogWarning((object)"No collider is attached to the GameObject. Canceling check");
			yield break;
		}
		while (Object.op_Implicit((Object)(object)col))
		{
			while (isWaitingForUpdate)
			{
				yield return (object)new WaitForSeconds(checkTime);
			}
			Bounds newBounds = col.bounds;
			Bounds merged = newBounds;
			((Bounds)(ref merged)).Encapsulate(prevBounds);
			Vector3 minDiff = ((Bounds)(ref merged)).min - ((Bounds)(ref newBounds)).min;
			Vector3 maxDiff = ((Bounds)(ref merged)).max - ((Bounds)(ref newBounds)).max;
			if (Mathf.Abs(minDiff.x) > updateError || Mathf.Abs(minDiff.y) > updateError || Mathf.Abs(minDiff.z) > updateError || Mathf.Abs(maxDiff.x) > updateError || Mathf.Abs(maxDiff.y) > updateError || Mathf.Abs(maxDiff.z) > updateError)
			{
				isWaitingForUpdate = true;
				DoUpdateGraphs();
			}
			yield return (object)new WaitForSeconds(checkTime);
		}
		OnDestroy();
	}

	public void OnDestroy()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)AstarPath.active != (Object)null)
		{
			GraphUpdateObject ob = new GraphUpdateObject(prevBounds);
			AstarPath.active.UpdateGraphs(ob);
		}
	}

	public void DoUpdateGraphs()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)col == (Object)null))
		{
			isWaitingForUpdate = false;
			Bounds bounds = col.bounds;
			Bounds val = bounds;
			((Bounds)(ref val)).Encapsulate(prevBounds);
			if (BoundsVolume(val) < BoundsVolume(bounds) + BoundsVolume(prevBounds))
			{
				AstarPath.active.UpdateGraphs(val);
			}
			else
			{
				AstarPath.active.UpdateGraphs(prevBounds);
				AstarPath.active.UpdateGraphs(bounds);
			}
			prevBounds = bounds;
		}
	}

	private static float BoundsVolume(Bounds b)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		return Math.Abs(((Bounds)(ref b)).size.x * ((Bounds)(ref b)).size.y * ((Bounds)(ref b)).size.z);
	}
}
