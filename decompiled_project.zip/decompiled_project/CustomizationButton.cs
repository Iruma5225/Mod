using UnityEngine;

public class CustomizationButton : MonoBehaviour
{
	[SerializeField]
	private EventDelegate m_onLeft;

	[SerializeField]
	private EventDelegate m_onRight;

	[SerializeField]
	private UITweener m_leftArrowTween;

	[SerializeField]
	private UITweener m_rightArrowTween;

	private float m_repeatDelay = 0.5f;

	private float m_deadzone = 0.7f;

	private float m_nextRepeatTime;

	private float m_prevHoriz;

	private UIButton leftButton;

	private UIButton rightButton;

	public void OnSelect(bool selected)
	{
		m_prevHoriz = 0f;
		m_nextRepeatTime = 0f;
	}

	public void Update()
	{
		if (!((Object)(object)UICamera.selectedObject != (Object)(object)((Component)this).gameObject))
		{
		}
	}

	public void OnLeftPressed()
	{
		if (m_onLeft != null && m_onLeft.isValid)
		{
			m_onLeft.Execute();
		}
		if ((Object)(object)m_leftArrowTween != (Object)null)
		{
			m_leftArrowTween.ResetToBeginning();
			m_leftArrowTween.PlayForward();
		}
	}

	public void OnRightPressed()
	{
		if (m_onRight != null && m_onRight.isValid)
		{
			m_onRight.Execute();
		}
		if ((Object)(object)m_rightArrowTween != (Object)null)
		{
			m_rightArrowTween.ResetToBeginning();
			m_rightArrowTween.PlayForward();
		}
	}

	private void Awake()
	{
		if ((Object)(object)m_leftArrowTween != (Object)null)
		{
			leftButton = ((Component)m_leftArrowTween).GetComponent<UIButton>();
		}
		if ((Object)(object)m_rightArrowTween != (Object)null)
		{
			rightButton = ((Component)m_rightArrowTween).GetComponent<UIButton>();
		}
	}
}
