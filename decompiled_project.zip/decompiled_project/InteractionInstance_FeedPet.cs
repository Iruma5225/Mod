using UnityEngine;

public class InteractionInstance_FeedPet : InteractionInstance_Base
{
	private Int_FeedPet interaction;

	private Obj_Pet pet;

	private int m_desperateMeatTaken;

	private int m_meatTaken;

	private int m_rationsTaken;

	protected override bool OnInteractionStarted()
	{
		pet = obj_base as Obj_Pet;
		if ((Object)(object)pet == (Object)null || pet.hasFood)
		{
			return false;
		}
		interaction = base_interaction as Int_FeedPet;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		if ((Object)(object)FoodManager.Instance == (Object)null || FoodManager.Instance.Rations + FoodManager.Instance.TotalMeat < interaction.RationsUsed)
		{
			return false;
		}
		int num = interaction.RationsUsed;
		if (FoodManager.Instance.DesperateMeat > 0)
		{
			num -= FoodManager.Instance.TakeDesperateMeat(num);
			m_desperateMeatTaken = interaction.RationsUsed - num;
		}
		if (FoodManager.Instance.Meat > 0 && num > 0)
		{
			num -= FoodManager.Instance.TakeMeat(num);
			m_meatTaken = interaction.RationsUsed - num;
		}
		if (num > 0)
		{
			num -= FoodManager.Instance.TakeRations(num);
			m_rationsTaken = interaction.RationsUsed - num;
		}
		if (interaction.crouch)
		{
			member.SetAnimBool("Crouch", truth: true);
		}
		member.TriggerAnim("Rummage");
		if ((Object)(object)pet != (Object)null)
		{
			pet.PlayFeedSound();
		}
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		member.SetAnimBool("Crouch", truth: false);
		if (!base.cancelled)
		{
			if ((Object)(object)pet != (Object)null)
			{
				pet.OnFed();
			}
		}
		else if ((Object)(object)FoodManager.Instance != (Object)null)
		{
			if (m_desperateMeatTaken > 0)
			{
				FoodManager.Instance.AddDesperateMeat(m_desperateMeatTaken);
			}
			if (m_meatTaken > 0)
			{
				FoodManager.Instance.AddMeat(m_meatTaken);
			}
			if (m_rationsTaken > 0)
			{
				FoodManager.Instance.AddRations(m_rationsTaken);
			}
		}
		return true;
	}
}
