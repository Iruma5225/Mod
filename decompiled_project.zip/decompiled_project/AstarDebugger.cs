using System;
using System.Text;
using Pathfinding;
using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Pathfinding/Debugger")]
public class AstarDebugger : MonoBehaviour
{
	private struct GraphPoint
	{
		public float fps;

		public float memory;

		public bool collectEvent;
	}

	private struct PathTypeDebug
	{
		private string name;

		private Func<int> getSize;

		private Func<int> getTotalCreated;

		public PathTypeDebug(string name, Func<int> getSize, Func<int> getTotalCreated)
		{
			this.name = name;
			this.getSize = getSize;
			this.getTotalCreated = getTotalCreated;
		}

		public void Print(StringBuilder text)
		{
			int num = getTotalCreated();
			if (num > 0)
			{
				text.Append("\n").Append(("  " + name).PadRight(25)).Append(getSize())
					.Append("/")
					.Append(num);
			}
		}
	}

	public int yOffset = 5;

	public bool show = true;

	public bool showInEditor;

	public bool showFPS;

	public bool showPathProfile;

	public bool showMemProfile;

	public bool showGraph;

	public int graphBufferSize = 200;

	public Font font;

	public int fontSize = 12;

	private StringBuilder text = new StringBuilder();

	private string cachedText;

	private float lastUpdate = -999f;

	private GraphPoint[] graph;

	private float delayedDeltaTime = 1f;

	private float lastCollect;

	private float lastCollectNum;

	private float delta;

	private float lastDeltaTime;

	private int allocRate;

	private int lastAllocMemory;

	private float lastAllocSet = -9999f;

	private int allocMem;

	private int collectAlloc;

	private int peakAlloc;

	private int fpsDropCounterSize = 200;

	private float[] fpsDrops;

	private Rect boxRect;

	private GUIStyle style;

	private Camera cam;

	private float graphWidth = 100f;

	private float graphHeight = 100f;

	private float graphOffset = 50f;

	private int maxVecPool;

	private int maxNodePool;

	private PathTypeDebug[] debugTypes = new PathTypeDebug[1]
	{
		new PathTypeDebug("ABPath", PathPool<ABPath>.GetSize, PathPool<ABPath>.GetTotalCreated)
	};

	public void Start()
	{
		((MonoBehaviour)this).useGUILayout = false;
		fpsDrops = new float[fpsDropCounterSize];
		cam = ((Component)this).GetComponent<Camera>();
		if ((Object)(object)cam == (Object)null)
		{
			cam = Camera.main;
		}
		graph = new GraphPoint[graphBufferSize];
		for (int i = 0; i < fpsDrops.Length; i++)
		{
			fpsDrops[i] = 1f / Time.deltaTime;
		}
	}

	public void Update()
	{
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0310: Unknown result type (might be due to invalid IL or missing references)
		//IL_0366: Unknown result type (might be due to invalid IL or missing references)
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c9: Unknown result type (might be due to invalid IL or missing references)
		if (!show || (!Application.isPlaying && !showInEditor))
		{
			return;
		}
		int num = GC.CollectionCount(0);
		if (lastCollectNum != (float)num)
		{
			lastCollectNum = num;
			delta = Time.realtimeSinceStartup - lastCollect;
			lastCollect = Time.realtimeSinceStartup;
			lastDeltaTime = Time.deltaTime;
			collectAlloc = allocMem;
		}
		allocMem = (int)GC.GetTotalMemory(forceFullCollection: false);
		bool flag = allocMem < peakAlloc;
		peakAlloc = (flag ? peakAlloc : allocMem);
		if (Time.realtimeSinceStartup - lastAllocSet > 0.3f || !Application.isPlaying)
		{
			int num2 = allocMem - lastAllocMemory;
			lastAllocMemory = allocMem;
			lastAllocSet = Time.realtimeSinceStartup;
			delayedDeltaTime = Time.deltaTime;
			if (num2 >= 0)
			{
				allocRate = num2;
			}
		}
		if (Application.isPlaying)
		{
			fpsDrops[Time.frameCount % fpsDrops.Length] = ((Time.deltaTime == 0f) ? float.PositiveInfinity : (1f / Time.deltaTime));
			int num3 = Time.frameCount % graph.Length;
			graph[num3].fps = ((!(Time.deltaTime < Mathf.Epsilon)) ? (1f / Time.deltaTime) : 0f);
			graph[num3].collectEvent = flag;
			graph[num3].memory = allocMem;
		}
		if (!Application.isPlaying || !((Object)(object)cam != (Object)null) || !showGraph)
		{
			return;
		}
		graphWidth = (float)cam.pixelWidth * 0.8f;
		float num4 = float.PositiveInfinity;
		float num5 = 0f;
		float num6 = float.PositiveInfinity;
		float num7 = 0f;
		for (int i = 0; i < graph.Length; i++)
		{
			num4 = Mathf.Min(graph[i].memory, num4);
			num5 = Mathf.Max(graph[i].memory, num5);
			num6 = Mathf.Min(graph[i].fps, num6);
			num7 = Mathf.Max(graph[i].fps, num7);
		}
		int num8 = Time.frameCount % graph.Length;
		Matrix4x4 m = Matrix4x4.TRS(new Vector3(((float)cam.pixelWidth - graphWidth) / 2f, graphOffset, 1f), Quaternion.identity, new Vector3(graphWidth, graphHeight, 1f));
		for (int j = 0; j < graph.Length - 1; j++)
		{
			if (j != num8)
			{
				DrawGraphLine(j, m, (float)j / (float)graph.Length, (float)(j + 1) / (float)graph.Length, AstarMath.MapTo(num4, num5, graph[j].memory), AstarMath.MapTo(num4, num5, graph[j + 1].memory), Color.blue);
				DrawGraphLine(j, m, (float)j / (float)graph.Length, (float)(j + 1) / (float)graph.Length, AstarMath.MapTo(num6, num7, graph[j].fps), AstarMath.MapTo(num6, num7, graph[j + 1].fps), Color.green);
			}
		}
	}

	public void DrawGraphLine(int index, Matrix4x4 m, float x1, float x2, float y1, float y2, Color col)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		Debug.DrawLine(cam.ScreenToWorldPoint(((Matrix4x4)(ref m)).MultiplyPoint3x4(new Vector3(x1, y1))), cam.ScreenToWorldPoint(((Matrix4x4)(ref m)).MultiplyPoint3x4(new Vector3(x2, y2))), col);
	}

	public void Cross(Vector3 p)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		Matrix4x4 cameraToWorldMatrix = cam.cameraToWorldMatrix;
		p = ((Matrix4x4)(ref cameraToWorldMatrix)).MultiplyPoint(p);
		Debug.DrawLine(p - Vector3.up * 0.2f, p + Vector3.up * 0.2f, Color.red);
		Debug.DrawLine(p - Vector3.right * 0.2f, p + Vector3.right * 0.2f, Color.red);
	}

	public void OnGUI()
	{
	}
}
