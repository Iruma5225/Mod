using UnityEngine;

public class InteractionInstance_Hide : InteractionInstance_Base
{
	private Obj_HidingSpot m_hidingSpot;

	protected override bool OnInteractionStarted()
	{
		m_hidingSpot = ((Component)this).GetComponent<Obj_HidingSpot>();
		if ((Object)(object)m_hidingSpot == (Object)null)
		{
			return false;
		}
		if (m_hidingSpot.maxHidden <= 0)
		{
			return false;
		}
		if ((Object)(object)BreachMan.instance == (Object)null || !BreachMan.instance.inProgress)
		{
			return false;
		}
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled)
		{
			m_hidingSpot.AddHidden(member);
		}
		return true;
	}
}
