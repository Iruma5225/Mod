using UnityEngine;

public class Int_WaterPlant : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_WaterPlant";
	}

	public override string GetInteractionType()
	{
		return "water_plant";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		Obj_Planter obj_Planter = obj as Obj_Planter;
		if (base.IsPlayerSelectable() && (Object)(object)WaterManager.Instance != (Object)null && WaterManager.Instance.StoredWater > 0f && obj_Planter.seedPlanted && !obj_Planter.ReadyToHarvest())
		{
			return true;
		}
		return false;
	}
}
