public class NpcDialogueTrade : NpcDialogueBase
{
	public NpcDialogueTrade(NpcDialoguePanel panel)
		: base(panel)
	{
		SetState(TradeStage_Initial);
	}

	private DialogueResult TradeStage_Initial()
	{
		string text = "npc.dialogue";
		switch (dialoguePanel.currentNpc.traderType)
		{
		case NpcVisitor.TraderType.Normal:
			text += ".trader.normal";
			break;
		case NpcVisitor.TraderType.ExtraCheap:
			text += ".trader.cheap";
			break;
		case NpcVisitor.TraderType.ExtraExpensive:
			text += ".trader.expensive";
			break;
		}
		dialoguePanel.PushNpcText(text, autoContinue: true);
		SetState(TradeStage_WaitForUI);
		return DialogueResult.Continue;
	}

	private DialogueResult TradeStage_WaitForUI()
	{
		if (!dialoguePanel.IsTextDone())
		{
			return DialogueResult.Continue;
		}
		return DialogueResult.Trade;
	}
}
