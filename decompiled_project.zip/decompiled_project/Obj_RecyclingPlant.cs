using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

public class Obj_RecyclingPlant : Obj_Integrity
{
	private List<ItemStack> m_output = new List<ItemStack>();

	[SerializeField]
	private float m_recycleTimePerItem = 20f;

	private float totalRecycleTime;

	private int totalItemsBeingRecycled;

	private bool m_outputReady;

	private bool m_inUse;

	[SerializeField]
	private List<SpriteRenderer> lights = new List<SpriteRenderer>();

	[SerializeField]
	private SpriteRenderer disabledLights;

	private float lightTimer;

	private int lightSpriteCount;

	[SerializeField]
	private bool m_randomLights = true;

	[SerializeField]
	private int integrityLostPerItem = 1;

	[SerializeField]
	[Range(0f, 100f)]
	private int m_percentageOfBaseItemsOutput = 100;

	public ReadOnlyCollection<ItemStack> output => m_output.AsReadOnly();

	public float recycleTimePerItem => m_recycleTimePerItem;

	public bool outputReady => m_outputReady;

	public bool inUse => m_inUse;

	public int percentageOfBaseItemsOutput => m_percentageOfBaseItemsOutput;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.RecyclingPlant;
	}

	public override void Awake()
	{
		base.Awake();
		SetLights();
	}

	public void SetInUse(bool state)
	{
		m_inUse = state;
	}

	public void StartRecycle(List<ItemStack> recycList, float time, int count)
	{
		m_output.Clear();
		m_output.AddRange(recycList);
		totalRecycleTime = time;
		totalItemsBeingRecycled = count;
		if ((Object)(object)power_component != (Object)null)
		{
			power_component.RequiredPower = 2;
			if ((Object)(object)PowerManager.Instance != (Object)null)
			{
				PowerManager.Instance.UpdatePowerFlow();
			}
		}
		SetInUse(state: true);
	}

	private void EndRecycle()
	{
		m_outputReady = true;
		Degrade(totalItemsBeingRecycled * integrityLostPerItem);
		SetInUse(state: false);
		if ((Object)(object)power_component != (Object)null)
		{
			power_component.RequiredPower = 0;
			if ((Object)(object)PowerManager.Instance != (Object)null)
			{
				PowerManager.Instance.UpdatePowerFlow();
			}
		}
	}

	public override void Update()
	{
		base.Update();
		if (!HasEnoughPower())
		{
			SetLights();
		}
		else
		{
			if (!m_inUse)
			{
				return;
			}
			totalRecycleTime -= Time.deltaTime;
			if (totalRecycleTime <= 0f)
			{
				EndRecycle();
				totalRecycleTime = 0f;
			}
			lightTimer -= Time.deltaTime;
			if (!(lightTimer <= 0f))
			{
				return;
			}
			if (m_randomLights)
			{
				SetLights(Random.Range(0, lights.Count));
			}
			else
			{
				if (lightSpriteCount >= lights.Count)
				{
					lightSpriteCount = 0;
				}
				SetLights(lightSpriteCount);
				lightSpriteCount++;
			}
			lightTimer = Random.Range(0.05f, 0.5f);
		}
	}

	private void SetLights(int index = -1)
	{
		for (int i = 0; i < lights.Count; i++)
		{
			((Renderer)lights[i]).enabled = index == i;
		}
		if ((Object)(object)disabledLights != (Object)null)
		{
			((Renderer)disabledLights).enabled = index < 0;
		}
	}

	public void CollectOutput()
	{
		m_output.Clear();
		m_outputReady = false;
		totalItemsBeingRecycled = 0;
	}

	public override List<string> GetTooltipExtraInfo()
	{
		List<string> tooltipExtraInfo = base.GetTooltipExtraInfo();
		tooltipExtraInfo.Add(Localization.Get("ui.text.inuse"));
		if (m_inUse)
		{
			tooltipExtraInfo.Add(Localization.Get("text.ui.yes"));
		}
		else
		{
			tooltipExtraInfo.Add(Localization.Get("text.ui.no"));
		}
		tooltipExtraInfo.Add(Localization.Get("ui.tooltip.recycletime"));
		int num = Mathf.FloorToInt(totalRecycleTime / 60f);
		int num2 = Mathf.FloorToInt(totalRecycleTime - (float)(num * 60));
		if (num < 10)
		{
			if (num2 < 10)
			{
				tooltipExtraInfo.Add("0" + num + ":0" + num2);
			}
			else
			{
				tooltipExtraInfo.Add("0" + num + ":" + num2);
			}
		}
		else if (num2 < 10)
		{
			tooltipExtraInfo.Add(num + ":0" + num2);
		}
		else
		{
			tooltipExtraInfo.Add(num + ":" + num2);
		}
		return tooltipExtraInfo;
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		data.SaveLoad("totalRecycleTime", ref totalRecycleTime);
		data.SaveLoad("totalItemsBeingRecycled", ref totalItemsBeingRecycled);
		data.SaveLoad("outputReady", ref m_outputReady);
		data.SaveLoad("inUse", ref m_inUse);
		data.SaveLoad("lightTimer", ref lightTimer);
		data.SaveLoadList("output", m_output, delegate(int i)
		{
			int value = (int)m_output[i].m_type;
			data.SaveLoad("type", ref value);
			data.SaveLoad("count", ref m_output[i].m_count);
		}, delegate
		{
			ItemStack itemStack = new ItemStack();
			int value = -1;
			data.SaveLoad("type", ref value);
			data.SaveLoad("count", ref itemStack.m_count);
			if (value > -1)
			{
				itemStack.m_type = (ItemManager.ItemType)value;
				m_output.Add(itemStack);
			}
		});
		if (data.isLoading && m_inUse)
		{
			List<ItemStack> list = new List<ItemStack>();
			for (int num = 0; num < m_output.Count; num++)
			{
				list.Add(new ItemStack(m_output[num]));
			}
			StartRecycle(list, totalRecycleTime, totalItemsBeingRecycled);
		}
	}
}
