public class Int_BurnCorpse : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_BurnCorpse";
	}

	public override string GetInteractionType()
	{
		return "burn_corpse";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}
}
