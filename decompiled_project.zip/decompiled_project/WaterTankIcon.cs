using UnityEngine;

public class WaterTankIcon : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
