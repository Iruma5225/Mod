using UnityEngine;

[RequireComponent(typeof(MeshRenderer))]
[RequireComponent(typeof(MeshFilter))]
public class VideoPlayer : MonoBehaviour
{
	public delegate void VideoCallback(bool wasStopped);

	public event VideoCallback playbackFinished;

	private void Start()
	{
	}

	private void Update()
	{
	}

	public bool LoadVideo(string filename)
	{
		return false;
	}

	public bool IsVideoLoaded()
	{
		return false;
	}

	public bool Play()
	{
		return false;
	}

	public bool IsPlaying()
	{
		return false;
	}

	public bool Stop()
	{
		return false;
	}

	private void OnVideoFinished(bool wasStopped)
	{
		if (this.playbackFinished != null)
		{
			this.playbackFinished(wasStopped);
		}
	}
}
