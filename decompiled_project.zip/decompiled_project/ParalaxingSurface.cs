using UnityEngine;

public class ParalaxingSurface : MonoBehaviour
{
	private BasicCamera m_camera;

	private Vector3 m_initialPos = Vector3.zero;

	[SerializeField]
	private bool m_movingObject;

	[Range(0f, 100f)]
	[SerializeField]
	private float m_camMovementPercent = 100f;

	public void Start()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		m_camMovementPercent = Mathf.Clamp(m_camMovementPercent, 0f, 100f);
		m_initialPos = ((Component)this).transform.position;
		if ((Object)(object)Camera.main != (Object)null)
		{
			m_camera = ((Component)Camera.main).GetComponent<BasicCamera>();
		}
	}

	public void LateUpdate()
	{
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)m_camera == (Object)null)
		{
			return;
		}
		if (m_movingObject)
		{
			if (!m_camera.isZoomed)
			{
				((Component)this).transform.Translate(new Vector3(m_camera.xTranslationThisFrame * m_camMovementPercent * 0.01f, 0f, 0f));
			}
		}
		else if (m_camera.isZoomed)
		{
			((Component)this).transform.position = m_initialPos;
		}
		else
		{
			Vector3 position = ((Component)this).transform.position;
			position.x = m_initialPos.x + m_camMovementPercent * 0.01f * m_camera.xTranslationFromInitial;
			((Component)this).transform.position = position;
		}
	}
}
