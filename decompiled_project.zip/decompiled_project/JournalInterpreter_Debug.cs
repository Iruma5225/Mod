using System.Collections.Generic;
using System.Text;

public class JournalInterpreter_Debug : JournalInterpreter_Base
{
	public override JournalManager.JournalEntryType GetEntryType()
	{
		return JournalManager.JournalEntryType.Debug;
	}

	public override string CreateJournalEntry(JournalEvents events, JournalStatus status)
	{
		StringBuilder stringBuilder = new StringBuilder();
		List<JournalEvents.EventRecord> eventsOfType = events.GetEventsOfType(JournalEvents.Event.TestEvent);
		if (eventsOfType != null)
		{
			stringBuilder.AppendFormat("There have been {0} test events.", eventsOfType.Count);
		}
		return stringBuilder.ToString();
	}
}
