using UnityEngine;

public class MapHelpPanel : BasePanel
{
	public override void OnShow()
	{
		base.OnShow();
	}

	public static MapHelpPanel CreateMapHelpPanel()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		Object mapHelpBox = UIPanelManager.Instance().MapHelpBox;
		if (mapHelpBox != (Object)null)
		{
			Object obj = Object.Instantiate(mapHelpBox);
			MapHelpPanel component = ((GameObject)((obj is GameObject) ? obj : null)).GetComponent<MapHelpPanel>();
			if ((Object)(object)component != (Object)null)
			{
				if (UIRoot.list.Count > 0)
				{
					((Component)component).transform.parent = ((Component)UIRoot.list[0]).transform;
				}
				((Component)component).transform.localScale = Vector3.one;
				((Component)component).transform.localPosition = new Vector3(105f, 62f, -10f);
				component.PushMapHelp();
				return component;
			}
			return null;
		}
		return null;
	}

	public void PushMapHelp()
	{
		UIPanelManager.Instance().PushPanel(this);
	}

	public void RemoveHelpBox()
	{
		UIPanelManager.Instance().PopPanel(this);
	}

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool DestroyOnClose()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool Popup()
	{
		return true;
	}

	public override bool AlwaysOnTopOfStack()
	{
		return true;
	}
}
