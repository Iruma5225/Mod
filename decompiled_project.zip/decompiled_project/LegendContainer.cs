using UnityEngine;

public class LegendContainer : MonoBehaviour
{
	public enum ButtonEnum
	{
		AButton,
		XButton,
		YButton,
		BButton
	}

	[SerializeField]
	private UI_PlatformButton a_button;

	[SerializeField]
	private UI_PlatformButton x_button;

	[SerializeField]
	private UI_PlatformButton y_button;

	[SerializeField]
	private UI_PlatformButton b_button;

	[SerializeField]
	private UITablePivot table;

	private bool m_RepositionNextUpdate;

	private void Awake()
	{
	}

	private void OnDestroy()
	{
	}

	private void OnEnable()
	{
		m_RepositionNextUpdate = true;
	}

	private void LateUpdate()
	{
		if (m_RepositionNextUpdate)
		{
			m_RepositionNextUpdate = false;
			if ((Object)(object)table != (Object)null)
			{
				table.Reposition();
			}
		}
	}

	private UI_PlatformButton GetButton(ButtonEnum button)
	{
		UI_PlatformButton result = null;
		switch (button)
		{
		case ButtonEnum.AButton:
			result = a_button;
			break;
		case ButtonEnum.XButton:
			result = x_button;
			break;
		case ButtonEnum.YButton:
			result = y_button;
			break;
		case ButtonEnum.BButton:
			result = b_button;
			break;
		}
		return result;
	}

	public void SetButtonText(ButtonEnum button, string text)
	{
		UI_PlatformButton button2 = GetButton(button);
		if ((Object)(object)button2 != (Object)null)
		{
			button2.SetText(text);
			Reposition();
		}
	}

	public void ShowButton(ButtonEnum button, bool show)
	{
		UI_PlatformButton button2 = GetButton(button);
		if ((Object)(object)button2 != (Object)null)
		{
			((Component)button2).gameObject.SetActive(show);
			Reposition();
		}
	}

	public void SetButtonEnabled(ButtonEnum button, bool enabled)
	{
		UI_PlatformButton button2 = GetButton(button);
		if ((Object)(object)button2 != (Object)null)
		{
			button2.SetEnabled(enabled);
		}
	}

	public void Reposition()
	{
		m_RepositionNextUpdate = true;
	}
}
