using System;
using UnityEngine;

[Serializable]
public class RandomStatGenerator
{
	[Range(0f, 20f)]
	public int StrengthMin;

	[Range(0f, 20f)]
	public int StrengthMax;

	[Range(0f, 20f)]
	public int DexterityMin;

	[Range(0f, 20f)]
	public int DexterityMax;

	[Range(0f, 20f)]
	public int IntelligenceMin;

	[Range(0f, 20f)]
	public int IntelligenceMax;

	[Range(0f, 20f)]
	public int CharismaMin;

	[Range(0f, 20f)]
	public int CharismaMax;

	[Range(0f, 20f)]
	public int PerceptionMin;

	[Range(0f, 20f)]
	public int PerceptionMax;

	public int GetRandomStrength()
	{
		return Random.Range(StrengthMin, Mathf.Max(StrengthMax + 1, StrengthMin + 1));
	}

	public int GetRandomDexterity()
	{
		return Random.Range(DexterityMin, Mathf.Max(DexterityMax + 1, DexterityMin + 1));
	}

	public int GetRandomIntelligence()
	{
		return Random.Range(IntelligenceMin, Mathf.Max(IntelligenceMax + 1, IntelligenceMin + 1));
	}

	public int GetRandomCharisma()
	{
		return Random.Range(CharismaMin, Mathf.Max(CharismaMax + 1, CharismaMin + 1));
	}

	public int GetRandomPerception()
	{
		return Random.Range(PerceptionMin, Mathf.Max(PerceptionMax + 1, PerceptionMin + 1));
	}
}
