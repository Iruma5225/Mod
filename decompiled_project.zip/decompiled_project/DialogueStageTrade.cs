using UnityEngine;

public class DialogueStageTrade : BaseDialogueStage
{
	private string m_textId = string.Empty;

	private string m_npcPersonality = string.Empty;

	private EncounterManager.EncounterTradeType m_tradeType;

	private EncounterManager.EncounterType m_altEncounter;

	private QuestInstance m_quest;

	public DialogueStageTrade(QuestInstance quest)
	{
		m_quest = quest;
		m_npcPersonality = EncounterManager.Instance.GetLeadNpc().Personality.ToString();
		if ((Object)(object)FactionMan.instance != (Object)null && (Object)(object)EncounterManager.Instance != (Object)null && EncounterManager.Instance.encounterFactionId > -1)
		{
			string factionDialogueId = FactionMan.instance.GetFactionDialogueId(EncounterManager.Instance.encounterFactionId);
			if (!string.IsNullOrEmpty(factionDialogueId))
			{
				m_npcPersonality = factionDialogueId;
			}
		}
		if (EncounterDialoguePanel.Instance.PlayerControlled || quest != null)
		{
			SetState(State_Player_Begin);
		}
		else
		{
			SetState(State_Npc_Begin);
		}
	}

	private DialogueResult State_Player_Begin()
	{
		int charisma = EncounterDialoguePanel.Instance.LeadPlayerCharacter.Charisma;
		int charisma2 = EncounterManager.Instance.GetLeadNpc().Charisma;
		EncounterLogic.StatCheckResult statCheckResult = EncounterLogic.StatCheck(charisma, charisma2);
		Debug.Log((object)("Trade check result was " + statCheckResult));
		if (statCheckResult == EncounterLogic.StatCheckResult.FailedSlightly)
		{
			statCheckResult = EncounterLogic.StatCheckResult.Failed;
		}
		if (m_quest != null)
		{
			statCheckResult = EncounterLogic.StatCheckResult.GoodSuccess;
			m_tradeType = EncounterManager.EncounterTradeType.Normal;
		}
		else if (statCheckResult == EncounterLogic.StatCheckResult.GoodSuccess)
		{
			m_tradeType = EncounterManager.EncounterTradeType.Good;
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Trade.Good";
		}
		else if (statCheckResult == EncounterLogic.StatCheckResult.ModerateSuccess)
		{
			m_tradeType = EncounterManager.EncounterTradeType.Normal;
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Trade.Normal";
		}
		else if (statCheckResult == EncounterLogic.StatCheckResult.PoorSuccess)
		{
			m_tradeType = EncounterManager.EncounterTradeType.Poor;
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Trade.Poor";
		}
		else if (statCheckResult <= EncounterLogic.StatCheckResult.Failed)
		{
			m_tradeType = EncounterManager.EncounterTradeType.None;
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Trade.Failed";
		}
		if (m_quest != null)
		{
			SetState(State_Player_WaitNpcResponseText);
		}
		else if (statCheckResult == EncounterLogic.StatCheckResult.FailedSlightly)
		{
			SetState(State_Player_ShowNpcResponseNotInterested);
		}
		else
		{
			SetState(State_Player_ShowNpcResponse);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_ShowNpcResponse()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText(m_textId))
		{
			SetState(State_Player_WaitNpcResponseText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitNpcResponseText()
	{
		if (!EncounterDialoguePanel.Instance.IsTextDone())
		{
			return DialogueResult.Continue;
		}
		DialogueResult result = DialogueResult.EndEncounter;
		switch (m_tradeType)
		{
		case EncounterManager.EncounterTradeType.Good:
			result = DialogueResult.DoGoodTrade;
			SetState(State_Player_StartTrade);
			break;
		case EncounterManager.EncounterTradeType.Normal:
			result = DialogueResult.DoNormalTrade;
			SetState(State_Player_StartTrade);
			break;
		case EncounterManager.EncounterTradeType.Poor:
			result = DialogueResult.DoPoorTrade;
			SetState(State_Player_StartTrade);
			break;
		case EncounterManager.EncounterTradeType.None:
			result = DialogueResult.TradeOver;
			break;
		}
		return result;
	}

	private DialogueResult State_Player_StartTrade()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText(null))
		{
			SetState(State_Player_WaitForTradeComplete);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitForTradeComplete()
	{
		if (!EncounterManager.Instance.isTradeOngoing)
		{
			SetState(State_Player_ShowNpcTradeComplete);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_ShowNpcTradeComplete()
	{
		m_textId = "Encounter.Npc." + m_npcPersonality + ".Trade.Complete";
		switch (m_tradeType)
		{
		case EncounterManager.EncounterTradeType.Good:
			m_textId += ".Good";
			break;
		case EncounterManager.EncounterTradeType.Normal:
			m_textId += ".Normal";
			break;
		case EncounterManager.EncounterTradeType.Poor:
			m_textId += ".Poor";
			break;
		}
		m_textId += ((!EncounterManager.Instance.wasTradeSuccessful) ? ".Failure" : ".Success");
		if (EncounterDialoguePanel.Instance.PushNpcText(m_textId))
		{
			SetState(State_Player_WaitNpcTradeCompleteText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitNpcTradeCompleteText()
	{
		if (!EncounterDialoguePanel.Instance.IsTextDone())
		{
			return DialogueResult.Continue;
		}
		return DialogueResult.TradeOver;
	}

	private DialogueResult State_Player_ShowNpcResponseNotInterested()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText("Encounter.Npc." + m_npcPersonality + ".Trade.NotInterested"))
		{
			SetState(State_Player_WaitNpcNotInterestedText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitNpcNotInterestedText()
	{
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			switch (EncounterGenerator.Instance.GetRandomEncounterType(EncounterManager.Instance.GetLeadNpc()))
			{
			case EncounterManager.EncounterType.Recruit:
				m_altEncounter = EncounterManager.EncounterType.Recruit;
				m_textId = "Encounter.Npc." + m_npcPersonality + ".Trade.TryRecruit";
				break;
			case EncounterManager.EncounterType.Intimidate:
				m_altEncounter = EncounterManager.EncounterType.Intimidate;
				m_textId = "Encounter.Npc." + m_npcPersonality + ".Trade.TryIntimidate";
				break;
			default:
				m_altEncounter = EncounterManager.EncounterType.WalkAway;
				m_textId = "Encounter.Npc." + m_npcPersonality + ".WalkAway";
				break;
			}
			SetState(State_Player_ShowNpcAlternateEncounterText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_ShowNpcAlternateEncounterText()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText(m_textId))
		{
			SetState(State_Player_WaitNpcAlternateEncounterText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitNpcAlternateEncounterText()
	{
		DialogueResult result = DialogueResult.Continue;
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			switch (m_altEncounter)
			{
			case EncounterManager.EncounterType.Recruit:
				result = DialogueResult.NpcSwitchToRecruit;
				break;
			case EncounterManager.EncounterType.Intimidate:
				result = DialogueResult.NpcSwitchToIntimidate;
				break;
			case EncounterManager.EncounterType.WalkAway:
				result = DialogueResult.EndEncounter;
				break;
			}
		}
		return result;
	}

	private DialogueResult State_Npc_Begin()
	{
		int charisma = EncounterManager.Instance.GetLeadNpc().Charisma;
		int charisma2 = EncounterDialoguePanel.Instance.LeadPlayerCharacter.Charisma;
		EncounterLogic.StatCheckResult statCheckResult = EncounterLogic.StatCheck(charisma, charisma2);
		Debug.Log((object)("Trade check result was " + statCheckResult));
		if (statCheckResult == EncounterLogic.StatCheckResult.GoodSuccess)
		{
			m_tradeType = EncounterManager.EncounterTradeType.Poor;
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Trade.Poor";
		}
		else if (statCheckResult >= EncounterLogic.StatCheckResult.PoorSuccess)
		{
			m_tradeType = EncounterManager.EncounterTradeType.Normal;
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Trade.Normal";
		}
		else
		{
			m_tradeType = EncounterManager.EncounterTradeType.Good;
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Trade.Good";
		}
		SetState(State_Npc_WaitNpcResponseText);
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_ShowNpcResponse()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText(m_textId))
		{
			SetState(State_Npc_WaitNpcResponseText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_WaitNpcResponseText()
	{
		if (!EncounterDialoguePanel.Instance.IsTextDone())
		{
			return DialogueResult.Continue;
		}
		DialogueResult result = DialogueResult.EndEncounter;
		switch (m_tradeType)
		{
		case EncounterManager.EncounterTradeType.Good:
			result = DialogueResult.DoGoodTrade;
			SetState(State_Player_StartTrade);
			break;
		case EncounterManager.EncounterTradeType.Normal:
			result = DialogueResult.DoNormalTrade;
			SetState(State_Player_StartTrade);
			break;
		case EncounterManager.EncounterTradeType.Poor:
			result = DialogueResult.DoPoorTrade;
			SetState(State_Player_StartTrade);
			break;
		case EncounterManager.EncounterTradeType.None:
			result = DialogueResult.TradeOver;
			break;
		}
		return result;
	}
}
