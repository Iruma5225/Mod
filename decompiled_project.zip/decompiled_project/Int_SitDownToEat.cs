using UnityEngine;

public class Int_SitDownToEat : Int_Base
{
	[SerializeField]
	private float m_HungerReductionModifier = 1.1f;

	[SerializeField]
	private int m_IntegrityPerSit = 10;

	public float HungerReductionModifier => m_HungerReductionModifier;

	public int IntegrityPerSit => m_IntegrityPerSit;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_SitDownToEat";
	}

	public override string GetInteractionType()
	{
		return "sit_down_to_eat";
	}

	public override bool IsPlayerSelectable()
	{
		return false;
	}
}
