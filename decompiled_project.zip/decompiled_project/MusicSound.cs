using UnityEngine;

public class MusicSound : MonoBehaviour
{
	private enum SoundState
	{
		None,
		Disabled,
		DelayingCurrent,
		CrossFading,
		Playing
	}

	private AudioSource m_CurrentAudio;

	private AudioSource m_NextAudio;

	private SoundState m_SoundState;

	private AudioClip m_CurrentSound;

	private AudioClip m_PendingSound;

	[SerializeField]
	private float m_SoundVolume = 1f;

	[SerializeField]
	private bool m_looping = true;

	[SerializeField]
	private float m_FadeOutTime = 1f;

	[SerializeField]
	private float m_FadeInTime = 2f;

	[SerializeField]
	private bool m_fadeInFromNothing;

	private float m_FadeOutStep;

	private float m_FadeInStep;

	private bool m_FadeOutDone;

	private bool m_FadeInDone;

	private bool m_FadeOutNow;

	private bool m_finished;

	public AudioClip currentSound => m_CurrentSound;

	public bool isFinished => m_finished;

	public virtual void Awake()
	{
		AudioSource[] components = ((Component)this).GetComponents<AudioSource>();
		if (components != null)
		{
			if ((Object)(object)components[0] != (Object)null)
			{
				m_CurrentAudio = components[0];
				m_CurrentAudio.ignoreListenerVolume = true;
				m_CurrentAudio.playOnAwake = false;
				m_CurrentAudio.loop = m_looping;
				m_CurrentAudio.priority = 0;
				m_CurrentAudio.volume = m_SoundVolume;
			}
			if ((Object)(object)components[1] != (Object)null)
			{
				m_NextAudio = components[1];
				m_NextAudio.ignoreListenerVolume = true;
				m_NextAudio.playOnAwake = false;
				m_NextAudio.loop = m_looping;
				m_NextAudio.priority = 0;
				m_NextAudio.volume = 0f;
			}
		}
		for (int i = 0; i < components.Length; i++)
		{
			components[i].ignoreListenerPause = true;
		}
	}

	public virtual void Update()
	{
		switch (m_SoundState)
		{
		case SoundState.Disabled:
			break;
		case SoundState.None:
			if ((Object)(object)m_PendingSound != (Object)null)
			{
				if (m_FadeOutTime > 0f)
				{
					m_FadeOutStep = m_CurrentAudio.volume / m_FadeOutTime;
				}
				if (m_FadeInTime > 0f)
				{
					m_FadeInStep = m_SoundVolume / m_FadeInTime;
				}
				m_SoundState = SoundState.CrossFading;
			}
			break;
		case SoundState.Playing:
			if (m_FadeOutNow)
			{
				m_FadeOutNow = false;
				if (m_FadeOutTime > 0f)
				{
					m_FadeOutStep = m_CurrentAudio.volume / m_FadeOutTime;
				}
				m_PendingSound = null;
				m_SoundState = SoundState.CrossFading;
			}
			if ((Object)(object)m_PendingSound != (Object)null)
			{
				if (m_FadeOutTime > 0f)
				{
					m_FadeOutStep = m_CurrentAudio.volume / m_FadeOutTime;
				}
				if (m_FadeInTime > 0f)
				{
					m_FadeInStep = m_SoundVolume / m_FadeInTime;
				}
				m_SoundState = SoundState.CrossFading;
			}
			else if (!m_CurrentAudio.isPlaying)
			{
				m_finished = true;
			}
			break;
		case SoundState.CrossFading:
			if (!m_NextAudio.isPlaying && (Object)(object)m_PendingSound != (Object)null)
			{
				m_NextAudio.clip = m_PendingSound;
				m_NextAudio.Play();
			}
			if (!m_FadeOutDone)
			{
				if (m_CurrentAudio.isPlaying)
				{
					if (m_FadeOutTime > 0f)
					{
						AudioSource currentAudio = m_CurrentAudio;
						currentAudio.volume -= m_FadeOutStep * RealTime.deltaTime;
					}
					else
					{
						m_CurrentAudio.volume = 0f;
					}
					if (m_CurrentAudio.volume <= 0f)
					{
						m_CurrentAudio.Stop();
						m_FadeOutDone = true;
					}
				}
				else
				{
					m_FadeOutDone = true;
				}
			}
			if ((Object)(object)m_CurrentAudio.clip == (Object)null)
			{
				m_NextAudio.volume = m_SoundVolume;
				if (!m_fadeInFromNothing)
				{
					m_FadeInDone = true;
				}
				m_FadeOutDone = true;
			}
			if (m_NextAudio.isPlaying && !m_FadeInDone)
			{
				if (m_FadeInTime > 0f)
				{
					AudioSource nextAudio = m_NextAudio;
					nextAudio.volume += m_FadeInStep * RealTime.deltaTime;
				}
				else
				{
					m_NextAudio.volume = m_SoundVolume;
				}
				if (m_NextAudio.volume >= m_SoundVolume)
				{
					m_FadeInDone = true;
				}
			}
			else
			{
				m_FadeInDone = true;
			}
			if (m_FadeInDone && m_FadeOutDone)
			{
				m_CurrentSound = m_PendingSound;
				m_PendingSound = null;
				AudioSource currentAudio2 = m_CurrentAudio;
				m_CurrentAudio = m_NextAudio;
				m_NextAudio = currentAudio2;
				m_NextAudio.clip = null;
				m_NextAudio.volume = 0f;
				m_FadeOutDone = false;
				m_FadeInDone = false;
				m_SoundState = SoundState.Playing;
			}
			break;
		case SoundState.DelayingCurrent:
			break;
		}
	}

	public void SetPendingSound(AudioClip clip)
	{
		if ((Object)(object)clip == (Object)null)
		{
			m_FadeOutNow = true;
		}
		m_PendingSound = clip;
		m_finished = false;
	}
}
