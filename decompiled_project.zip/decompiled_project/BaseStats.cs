using System;
using UnityEngine;

[Serializable]
public class BaseStats
{
	public enum StatType
	{
		Strength,
		Dexterity,
		Intelligence,
		Charisma,
		Perception,
		Max
	}

	public delegate void OnStatExperienceGained(StatType statType, int xpAmount);

	public delegate void OnStatLevelGained(StatType statType);

	public delegate void OnReachMaxLevel(StatType statType);

	private BaseStat[] stats = new BaseStat[5];

	[SerializeField]
	private BaseStat strength = new BaseStat(StatType.Strength);

	[SerializeField]
	private BaseStat dexterity = new BaseStat(StatType.Dexterity);

	[SerializeField]
	private BaseStat intelligence = new BaseStat(StatType.Intelligence);

	[SerializeField]
	private BaseStat charisma = new BaseStat(StatType.Charisma);

	[SerializeField]
	private BaseStat perception = new BaseStat(StatType.Perception);

	public BaseStat Strength => strength;

	public BaseStat Dexterity => dexterity;

	public BaseStat Intelligence => intelligence;

	public BaseStat Charisma => charisma;

	public BaseStat Perception => perception;

	public event OnStatExperienceGained onExperienceGained;

	public event OnStatLevelGained onLevelGained;

	public event OnReachMaxLevel onReachMaxLevel;

	public void Initialize()
	{
		stats[0] = strength;
		stats[1] = dexterity;
		stats[2] = intelligence;
		stats[3] = charisma;
		stats[4] = perception;
		strength.onExperienceGain = OnExperienceGained;
		dexterity.onExperienceGain = OnExperienceGained;
		intelligence.onExperienceGain = OnExperienceGained;
		charisma.onExperienceGain = OnExperienceGained;
		perception.onExperienceGain = OnExperienceGained;
		strength.onLevelGain = OnLevelGained;
		dexterity.onLevelGain = OnLevelGained;
		intelligence.onLevelGain = OnLevelGained;
		charisma.onLevelGain = OnLevelGained;
		perception.onLevelGain = OnLevelGained;
		strength.onReachMaxLevel = OnReachedMaxLevel;
		dexterity.onReachMaxLevel = OnReachedMaxLevel;
		intelligence.onReachMaxLevel = OnReachedMaxLevel;
		charisma.onReachMaxLevel = OnReachedMaxLevel;
		perception.onReachMaxLevel = OnReachedMaxLevel;
	}

	private void OnExperienceGained(StatType statType, int xpAmount)
	{
		if (this.onExperienceGained != null)
		{
			this.onExperienceGained(statType, xpAmount);
		}
	}

	private void OnLevelGained(StatType statType)
	{
		if (this.onLevelGained != null)
		{
			this.onLevelGained(statType);
		}
	}

	private void OnReachedMaxLevel(StatType statType)
	{
		if (this.onReachMaxLevel != null)
		{
			this.onReachMaxLevel(statType);
		}
	}

	public BaseStat GetStatByEnum(StatType statType)
	{
		if (statType == StatType.Max)
		{
			return null;
		}
		return stats[(int)statType];
	}

	public void CopyOther(BaseStats other)
	{
		for (int i = 0; i < 5; i++)
		{
			stats[i].CopyStat(other.stats[i]);
		}
	}

	public void SaveLoadBaseStats(SaveData data)
	{
		data.GroupStart("BaseStats");
		strength.SaveLoadBaseStat(data);
		dexterity.SaveLoadBaseStat(data);
		intelligence.SaveLoadBaseStat(data);
		charisma.SaveLoadBaseStat(data);
		perception.SaveLoadBaseStat(data);
		data.GroupEnd();
	}
}
