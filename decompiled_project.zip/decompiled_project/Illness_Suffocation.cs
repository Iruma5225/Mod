using System;
using UnityEngine;

[Serializable]
public class Illness_Suffocation : Illness_Base
{
	private int m_healthDamageAmount;

	private float m_healthDamageInterval;

	private float m_healthDamageTime;

	public override void Initialize(FamilyMember member)
	{
		base.Initialize(member);
		m_healthDamageInterval = GameTime.GameSecondsToRealSeconds(720f);
		m_healthDamageAmount = 1;
		m_healthDamageTime = 0f;
	}

	public override void UpdateIllness()
	{
		if ((Object)(object)EnvironmentManager.Instance != (Object)null)
		{
			if (!m_member.isOutside && EnvironmentManager.Instance.OxygenLevel == 0f)
			{
				SetActive(active: true);
			}
			else
			{
				SetActive(active: false);
			}
		}
		else if (m_member.isOutside)
		{
			SetActive(active: false);
		}
		if (base.isActive && Time.time >= m_healthDamageTime)
		{
			m_healthDamageTime = Time.time + m_healthDamageInterval;
			m_member.Damage(m_healthDamageAmount, BaseCharacter.DamageType.Suffocation, string.Empty);
		}
	}

	protected override void OnContractIllness()
	{
		m_healthDamageTime = Time.time + m_healthDamageInterval;
		m_member.SetWalkSpeedMultiplier(0.5f);
	}

	protected override void OnCureIllness()
	{
		m_member.SetWalkSpeedMultiplier(1f);
	}

	public override void SaveLoadIllness(SaveData data)
	{
		data.GroupStart("Suffocating");
		base.SaveLoadIllness(data);
		data.SaveLoadAbsoluteTime("damageTime", ref m_healthDamageTime);
		data.GroupEnd();
	}
}
