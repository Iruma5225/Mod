using System;
using System.IO;
using System.Text;
using Pathfinding.Ionic.Zip;
using Pathfinding.Util;
using UnityEngine;

namespace Pathfinding.Serialization;

public class AstarSerializer
{
	private AstarData data;

	private ZipFile zip;

	private MemoryStream str;

	private GraphMeta meta;

	private SerializeSettings settings;

	private NavGraph[] graphs;

	private int graphIndexOffset;

	private const string binaryExt = ".binary";

	private const string jsonExt = ".binary";

	private uint checksum = uint.MaxValue;

	private static StringBuilder _stringBuilder = new StringBuilder();

	public AstarSerializer(AstarData data)
	{
		this.data = data;
		settings = SerializeSettings.Settings;
	}

	public AstarSerializer(AstarData data, SerializeSettings settings)
	{
		this.data = data;
		this.settings = settings;
	}

	private static StringBuilder GetStringBuilder()
	{
		_stringBuilder.Length = 0;
		return _stringBuilder;
	}

	public void SetGraphIndexOffset(int offset)
	{
		graphIndexOffset = offset;
	}

	private void AddChecksum(byte[] bytes)
	{
		checksum = Checksum.GetChecksum(bytes, checksum);
	}

	public uint GetChecksum()
	{
		return checksum;
	}

	public void OpenSerialize()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		zip = new ZipFile();
		zip.AlternateEncoding = Encoding.UTF8;
		zip.AlternateEncodingUsage = (ZipOption)2;
		meta = new GraphMeta();
	}

	public byte[] CloseSerialize()
	{
		byte[] array = SerializeMeta();
		AddChecksum(array);
		zip.AddEntry("meta.binary", array);
		DateTime dateTime = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
		foreach (ZipEntry entry in zip.Entries)
		{
			entry.AccessedTime = dateTime;
			entry.CreationTime = dateTime;
			entry.LastModified = dateTime;
			entry.ModifiedTime = dateTime;
		}
		MemoryStream memoryStream = new MemoryStream();
		zip.Save((Stream)memoryStream);
		array = memoryStream.ToArray();
		memoryStream.Dispose();
		zip.Dispose();
		zip = null;
		return array;
	}

	public void SerializeGraphs(NavGraph[] _graphs)
	{
		if (graphs != null)
		{
			throw new InvalidOperationException("Cannot serialize graphs multiple times.");
		}
		graphs = _graphs;
		if (zip == null)
		{
			throw new NullReferenceException("You must not call CloseSerialize before a call to this function");
		}
		if (graphs == null)
		{
			graphs = new NavGraph[0];
		}
		for (int i = 0; i < graphs.Length; i++)
		{
			if (graphs[i] != null)
			{
				byte[] array = Serialize(graphs[i]);
				AddChecksum(array);
				zip.AddEntry("graph" + i + ".binary", array);
			}
		}
	}

	private byte[] SerializeMeta()
	{
		meta.version = AstarPath.Version;
		meta.graphs = data.graphs.Length;
		meta.guids = new string[data.graphs.Length];
		meta.typeNames = new string[data.graphs.Length];
		meta.nodeCounts = new int[data.graphs.Length];
		for (int i = 0; i < data.graphs.Length; i++)
		{
			if (data.graphs[i] != null)
			{
				meta.guids[i] = data.graphs[i].guid.ToString();
				meta.typeNames[i] = data.graphs[i].GetType().FullName;
			}
		}
		MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("A*");
		binaryWriter.Write(meta.version.Major);
		binaryWriter.Write(meta.version.Minor);
		binaryWriter.Write(meta.version.Build);
		binaryWriter.Write(meta.version.Revision);
		binaryWriter.Write(meta.graphs);
		binaryWriter.Write(meta.guids.Length);
		for (int j = 0; j < meta.guids.Length; j++)
		{
			binaryWriter.Write(meta.guids[j] ?? string.Empty);
		}
		binaryWriter.Write(meta.typeNames.Length);
		for (int k = 0; k < meta.typeNames.Length; k++)
		{
			binaryWriter.Write(meta.typeNames[k] ?? string.Empty);
		}
		binaryWriter.Write(meta.nodeCounts.Length);
		for (int l = 0; l < meta.nodeCounts.Length; l++)
		{
			binaryWriter.Write(meta.nodeCounts[l]);
		}
		return memoryStream.ToArray();
	}

	public byte[] Serialize(NavGraph graph)
	{
		MemoryStream memoryStream = new MemoryStream();
		BinaryWriter writer = new BinaryWriter(memoryStream);
		GraphSerializationContext ctx = new GraphSerializationContext(writer);
		graph.SerializeSettings(ctx);
		return memoryStream.ToArray();
	}

	public void SerializeNodes()
	{
		if (settings.nodes)
		{
			if (graphs == null)
			{
				throw new InvalidOperationException("Cannot serialize nodes with no serialized graphs (call SerializeGraphs first)");
			}
			for (int i = 0; i < graphs.Length; i++)
			{
				byte[] array = SerializeNodes(i);
				AddChecksum(array);
				zip.AddEntry("graph" + i + "_nodes.binary", array);
			}
			for (int j = 0; j < graphs.Length; j++)
			{
				byte[] array2 = SerializeNodeConnections(j);
				AddChecksum(array2);
				zip.AddEntry("graph" + j + "_conns.binary", array2);
			}
		}
	}

	private byte[] SerializeNodes(int index)
	{
		return new byte[0];
	}

	public void SerializeExtraInfo()
	{
		if (!settings.nodes)
		{
			return;
		}
		int totCount = 0;
		for (int i = 0; i < graphs.Length; i++)
		{
			if (graphs[i] == null)
			{
				continue;
			}
			graphs[i].GetNodes(delegate(GraphNode node)
			{
				totCount = Math.Max(node.NodeIndex, totCount);
				if (node.NodeIndex == -1)
				{
					Debug.LogError((object)"Graph contains destroyed nodes. This is a bug.");
				}
				return true;
			});
		}
		MemoryStream memoryStream = new MemoryStream();
		BinaryWriter wr = new BinaryWriter(memoryStream);
		wr.Write(totCount);
		int c = 0;
		for (int num = 0; num < graphs.Length; num++)
		{
			if (graphs[num] != null)
			{
				graphs[num].GetNodes(delegate(GraphNode node)
				{
					c = Math.Max(node.NodeIndex, c);
					wr.Write(node.NodeIndex);
					return true;
				});
			}
		}
		if (c != totCount)
		{
			throw new Exception("Some graphs are not consistent in their GetNodes calls, sequential calls give different results.");
		}
		byte[] array = memoryStream.ToArray();
		wr.Close();
		AddChecksum(array);
		zip.AddEntry("graph_references.binary", array);
		for (int num2 = 0; num2 < graphs.Length; num2++)
		{
			if (graphs[num2] != null)
			{
				MemoryStream memoryStream2 = new MemoryStream();
				BinaryWriter binaryWriter = new BinaryWriter(memoryStream2);
				GraphSerializationContext ctx = new GraphSerializationContext(binaryWriter);
				graphs[num2].SerializeExtraInfo(ctx);
				byte[] array2 = memoryStream2.ToArray();
				binaryWriter.Close();
				AddChecksum(array2);
				zip.AddEntry("graph" + num2 + "_extra.binary", array2);
				memoryStream2 = new MemoryStream();
				binaryWriter = new BinaryWriter(memoryStream2);
				ctx = new GraphSerializationContext(binaryWriter);
				graphs[num2].GetNodes(delegate(GraphNode node)
				{
					node.SerializeReferences(ctx);
					return true;
				});
				binaryWriter.Close();
				array2 = memoryStream2.ToArray();
				AddChecksum(array2);
				zip.AddEntry("graph" + num2 + "_references.binary", array2);
			}
		}
	}

	private byte[] SerializeNodeConnections(int index)
	{
		return new byte[0];
	}

	public void SerializeEditorSettings(GraphEditorBase[] editors)
	{
		if (editors != null && settings.editorSettings)
		{
		}
	}

	public bool OpenDeserialize(byte[] bytes)
	{
		str = new MemoryStream();
		str.Write(bytes, 0, bytes.Length);
		str.Position = 0L;
		try
		{
			zip = ZipFile.Read((Stream)str);
		}
		catch (Exception ex)
		{
			Debug.LogWarning((object)("Caught exception when loading from zip\n" + ex));
			str.Dispose();
			return false;
		}
		meta = DeserializeMeta(zip["meta.binary"]);
		if (FullyDefinedVersion(meta.version) > FullyDefinedVersion(AstarPath.Version))
		{
			Debug.LogWarning((object)string.Concat("Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ", AstarPath.Version, " Data version: ", meta.version, "\nThis is usually fine as the stored data is usually backwards and forwards compatible.\nHowever node data (not settings) can get corrupted between versions, so it is recommended to recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n"));
		}
		else if (FullyDefinedVersion(meta.version) < FullyDefinedVersion(AstarPath.Version))
		{
			Debug.LogWarning((object)string.Concat("Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ", AstarPath.Version, " Data version: ", meta.version, "\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommended to recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n"));
		}
		return true;
	}

	private static Version FullyDefinedVersion(Version v)
	{
		return new Version(Mathf.Max(v.Major, 0), Mathf.Max(v.Minor, 0), Mathf.Max(v.Build, 0), Mathf.Max(v.Revision, 0));
	}

	public void CloseDeserialize()
	{
		str.Dispose();
		zip.Dispose();
		zip = null;
		str = null;
	}

	public NavGraph[] DeserializeGraphs()
	{
		graphs = new NavGraph[meta.graphs];
		int num = 0;
		for (int i = 0; i < meta.graphs; i++)
		{
			Type graphType = meta.GetGraphType(i);
			if (!object.Equals(graphType, null))
			{
				num++;
				ZipEntry val = zip["graph" + i + ".binary"];
				if (val == null)
				{
					throw new FileNotFoundException("Could not find data for graph " + i + " in zip. Entry 'graph+" + i + ".binary' does not exist");
				}
				NavGraph navGraph = data.CreateGraph(graphType);
				navGraph.graphIndex = (uint)(i + graphIndexOffset);
				MemoryStream memoryStream = new MemoryStream();
				val.Extract((Stream)memoryStream);
				memoryStream.Position = 0L;
				BinaryReader reader = new BinaryReader(memoryStream);
				GraphSerializationContext ctx = new GraphSerializationContext(reader, null, i + graphIndexOffset);
				navGraph.DeserializeSettings(ctx);
				graphs[i] = navGraph;
				if (graphs[i].guid.ToString() != meta.guids[i])
				{
					throw new Exception(string.Concat("Guid in graph file not equal to guid defined in meta file. Have you edited the data manually?\n", graphs[i].guid, " != ", meta.guids[i]));
				}
			}
		}
		NavGraph[] array = new NavGraph[num];
		num = 0;
		for (int j = 0; j < graphs.Length; j++)
		{
			if (graphs[j] != null)
			{
				array[num] = graphs[j];
				num++;
			}
		}
		graphs = array;
		return graphs;
	}

	public void DeserializeExtraInfo()
	{
		bool flag = false;
		for (int i = 0; i < graphs.Length; i++)
		{
			ZipEntry val = zip["graph" + i + "_extra.binary"];
			if (val != null)
			{
				flag = true;
				MemoryStream memoryStream = new MemoryStream();
				val.Extract((Stream)memoryStream);
				memoryStream.Seek(0L, SeekOrigin.Begin);
				BinaryReader reader = new BinaryReader(memoryStream);
				GraphSerializationContext ctx = new GraphSerializationContext(reader, null, i + graphIndexOffset);
				graphs[i].DeserializeExtraInfo(ctx);
			}
		}
		if (!flag)
		{
			return;
		}
		int totCount = 0;
		for (int j = 0; j < graphs.Length; j++)
		{
			if (graphs[j] == null)
			{
				continue;
			}
			graphs[j].GetNodes(delegate(GraphNode node)
			{
				totCount = Math.Max(node.NodeIndex, totCount);
				if (node.NodeIndex == -1)
				{
					Debug.LogError((object)"Graph contains destroyed nodes. This is a bug.");
				}
				return true;
			});
		}
		ZipEntry val2 = zip["graph_references.binary"];
		if (val2 == null)
		{
			throw new Exception("Node references not found in the data. Was this loaded from an older version of the A* Pathfinding Project?");
		}
		MemoryStream memoryStream2 = new MemoryStream();
		val2.Extract((Stream)memoryStream2);
		memoryStream2.Seek(0L, SeekOrigin.Begin);
		BinaryReader reader2 = new BinaryReader(memoryStream2);
		int num = reader2.ReadInt32();
		GraphNode[] int2Node = new GraphNode[num + 1];
		try
		{
			for (int num2 = 0; num2 < graphs.Length; num2++)
			{
				if (graphs[num2] != null)
				{
					graphs[num2].GetNodes(delegate(GraphNode node)
					{
						int2Node[reader2.ReadInt32()] = node;
						return true;
					});
				}
			}
		}
		catch (Exception innerException)
		{
			throw new Exception("Some graph(s) has thrown an exception during GetNodes, or some graph(s) have deserialized more or fewer nodes than were serialized", innerException);
		}
		reader2.Close();
		for (int num3 = 0; num3 < graphs.Length; num3++)
		{
			if (graphs[num3] != null)
			{
				val2 = zip["graph" + num3 + "_references.binary"];
				if (val2 == null)
				{
					throw new Exception("Node references for graph " + num3 + " not found in the data. Was this loaded from an older version of the A* Pathfinding Project?");
				}
				memoryStream2 = new MemoryStream();
				val2.Extract((Stream)memoryStream2);
				memoryStream2.Seek(0L, SeekOrigin.Begin);
				reader2 = new BinaryReader(memoryStream2);
				GraphSerializationContext ctx2 = new GraphSerializationContext(reader2, int2Node, num3 + graphIndexOffset);
				graphs[num3].GetNodes(delegate(GraphNode node)
				{
					node.DeserializeReferences(ctx2);
					return true;
				});
			}
		}
	}

	public void PostDeserialization()
	{
		for (int i = 0; i < graphs.Length; i++)
		{
			if (graphs[i] != null)
			{
				graphs[i].PostDeserialization();
			}
		}
	}

	public void DeserializeEditorSettings(GraphEditorBase[] graphEditors)
	{
	}

	private string GetString(ZipEntry entry)
	{
		MemoryStream memoryStream = new MemoryStream();
		entry.Extract((Stream)memoryStream);
		memoryStream.Position = 0L;
		StreamReader streamReader = new StreamReader(memoryStream);
		string result = streamReader.ReadToEnd();
		memoryStream.Position = 0L;
		streamReader.Dispose();
		return result;
	}

	private GraphMeta DeserializeMeta(ZipEntry entry)
	{
		if (entry == null)
		{
			throw new Exception("No metadata found in serialized data.");
		}
		GraphMeta graphMeta = new GraphMeta();
		MemoryStream memoryStream = new MemoryStream();
		entry.Extract((Stream)memoryStream);
		memoryStream.Position = 0L;
		BinaryReader binaryReader = new BinaryReader(memoryStream);
		if (binaryReader.ReadString() != "A*")
		{
			throw new Exception("Invalid magic number in saved data");
		}
		int num = binaryReader.ReadInt32();
		int num2 = binaryReader.ReadInt32();
		int num3 = binaryReader.ReadInt32();
		int num4 = binaryReader.ReadInt32();
		if (num < 0)
		{
			graphMeta.version = new Version(0, 0);
		}
		else if (num2 < 0)
		{
			graphMeta.version = new Version(num, 0);
		}
		else if (num3 < 0)
		{
			graphMeta.version = new Version(num, num2);
		}
		else if (num4 < 0)
		{
			graphMeta.version = new Version(num, num2, num3);
		}
		else
		{
			graphMeta.version = new Version(num, num2, num3, num4);
		}
		graphMeta.graphs = binaryReader.ReadInt32();
		graphMeta.guids = new string[binaryReader.ReadInt32()];
		for (int i = 0; i < graphMeta.guids.Length; i++)
		{
			graphMeta.guids[i] = binaryReader.ReadString();
		}
		graphMeta.typeNames = new string[binaryReader.ReadInt32()];
		for (int j = 0; j < graphMeta.typeNames.Length; j++)
		{
			graphMeta.typeNames[j] = binaryReader.ReadString();
		}
		graphMeta.nodeCounts = new int[binaryReader.ReadInt32()];
		for (int k = 0; k < graphMeta.nodeCounts.Length; k++)
		{
			graphMeta.nodeCounts[k] = binaryReader.ReadInt32();
		}
		return graphMeta;
	}

	public static void SaveToFile(string path, byte[] data)
	{
		using FileStream fileStream = new FileStream(path, FileMode.Create);
		fileStream.Write(data, 0, data.Length);
	}

	public static byte[] LoadFromFile(string path)
	{
		using FileStream fileStream = new FileStream(path, FileMode.Open);
		byte[] array = new byte[(int)fileStream.Length];
		fileStream.Read(array, 0, (int)fileStream.Length);
		return array;
	}
}
