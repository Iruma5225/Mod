using System;
using System.IO;
using UnityEngine;

namespace Pathfinding.Serialization;

public class GraphSerializationContext
{
	private readonly GraphNode[] id2NodeMapping;

	public readonly BinaryReader reader;

	public readonly BinaryWriter writer;

	public readonly int graphIndex;

	public GraphSerializationContext(BinaryReader reader, GraphNode[] id2NodeMapping, int graphIndex)
	{
		this.reader = reader;
		this.id2NodeMapping = id2NodeMapping;
		this.graphIndex = graphIndex;
	}

	public GraphSerializationContext(BinaryWriter writer)
	{
		this.writer = writer;
	}

	public int GetNodeIdentifier(GraphNode node)
	{
		return node?.NodeIndex ?? (-1);
	}

	public GraphNode GetNodeFromIdentifier(int id)
	{
		if (id2NodeMapping == null)
		{
			throw new Exception("Calling GetNodeFromIdentifier when serializing");
		}
		if (id == -1)
		{
			return null;
		}
		GraphNode graphNode = id2NodeMapping[id];
		if (graphNode == null)
		{
			throw new Exception("Invalid id");
		}
		return graphNode;
	}

	public void SerializeVector3(Vector3 v)
	{
		writer.Write(v.x);
		writer.Write(v.y);
		writer.Write(v.z);
	}

	public Vector3 DeserializeVector3()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		return new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
	}

	public int DeserializeInt(int defaultValue)
	{
		if (reader.BaseStream.Position <= reader.BaseStream.Length - 4)
		{
			return reader.ReadInt32();
		}
		return defaultValue;
	}

	public float DeserializeFloat(float defaultValue)
	{
		if (reader.BaseStream.Position <= reader.BaseStream.Length - 4)
		{
			return reader.ReadSingle();
		}
		return defaultValue;
	}

	public void SerializeUnityObject(Object ob)
	{
		if (ob == (Object)null)
		{
			writer.Write(int.MaxValue);
			return;
		}
		int instanceID = ob.GetInstanceID();
		string name = ob.name;
		string assemblyQualifiedName = ((object)ob).GetType().AssemblyQualifiedName;
		string value = string.Empty;
		Component val = (Component)(object)((ob is Component) ? ob : null);
		GameObject val2 = (GameObject)(object)((ob is GameObject) ? ob : null);
		if ((Object)(object)val != (Object)null || (Object)(object)val2 != (Object)null)
		{
			if ((Object)(object)val != (Object)null && (Object)(object)val2 == (Object)null)
			{
				val2 = val.gameObject;
			}
			UnityReferenceHelper unityReferenceHelper = val2.GetComponent<UnityReferenceHelper>();
			if ((Object)(object)unityReferenceHelper == (Object)null)
			{
				Debug.Log((object)("Adding UnityReferenceHelper to Unity Reference '" + ob.name + "'"));
				unityReferenceHelper = val2.AddComponent<UnityReferenceHelper>();
			}
			unityReferenceHelper.Reset();
			value = unityReferenceHelper.GetGUID();
		}
		writer.Write(instanceID);
		writer.Write(name);
		writer.Write(assemblyQualifiedName);
		writer.Write(value);
	}

	public Object DeserializeUnityObject()
	{
		int num = reader.ReadInt32();
		if (num == int.MaxValue)
		{
			return null;
		}
		string text = reader.ReadString();
		string text2 = reader.ReadString();
		string text3 = reader.ReadString();
		Type type = Type.GetType(text2);
		if ((object)type == null)
		{
			Debug.LogError((object)("Could not find type '" + text2 + "'. Cannot deserialize Unity reference"));
			return null;
		}
		if (!string.IsNullOrEmpty(text3))
		{
			UnityReferenceHelper[] array = Object.FindObjectsOfType(typeof(UnityReferenceHelper)) as UnityReferenceHelper[];
			for (int i = 0; i < array.Length; i++)
			{
				if (array[i].GetGUID() == text3)
				{
					if ((object)type == typeof(GameObject))
					{
						return (Object)(object)((Component)array[i]).gameObject;
					}
					return (Object)(object)((Component)array[i]).GetComponent(type);
				}
			}
		}
		Object[] array2 = Resources.LoadAll(text, type);
		for (int j = 0; j < array2.Length; j++)
		{
			if (array2[j].name == text || array2.Length == 1)
			{
				return array2[j];
			}
		}
		return null;
	}
}
