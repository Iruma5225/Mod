public abstract class PlatformLeaderboards_Base
{
	public delegate void LeaderboardCallback(bool success, LeaderboardData results, bool closeMenu);

	public event LeaderboardCallback onReadComplete;

	public abstract bool ReadLeaderboard(LeaderboardConfig boardConfig, LeaderboardFilter filter, int startRow, int numRowsToRead);

	public abstract void ShowPlayerInfo(RowData row);

	public abstract int GetMaxRowsToRead();

	public virtual void Update()
	{
	}

	public virtual void Reset()
	{
	}

	protected void TriggerReadComplete(bool success, LeaderboardData results, bool closeMenu = false)
	{
		if (this.onReadComplete != null)
		{
			this.onReadComplete(success, results, closeMenu);
		}
	}
}
