using UnityEngine;

public class Int_DrinkCoffee : Int_Base
{
	public AudioClip m_DrinkSFX;

	[SerializeField]
	private float m_ThirstReduction = 25f;

	[SerializeField]
	private float m_TirednessReduction = 10f;

	public float ThirstReduction => m_ThirstReduction;

	public float TirednessReduction => m_TirednessReduction;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_DrinkCoffee";
	}

	public override string GetInteractionType()
	{
		return "drink_coffee";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public void DrinkSoundEffect()
	{
		if ((Object)(object)m_DrinkSFX != (Object)null)
		{
			((Component)this).GetComponent<AudioSource>().PlayOneShot(m_DrinkSFX);
		}
	}

	public override bool IsPlayerSelectable()
	{
		if (base.IsPlayerSelectable())
		{
			Obj_CoffeeMachine obj_CoffeeMachine = obj as Obj_CoffeeMachine;
			if ((Object)(object)obj_CoffeeMachine != (Object)null && obj_CoffeeMachine.HasEnoughPower() && obj_CoffeeMachine.IsEnabled() && !obj_CoffeeMachine.brewing && obj_CoffeeMachine.cupsOfCoffee > 0)
			{
				return true;
			}
		}
		return false;
	}
}
