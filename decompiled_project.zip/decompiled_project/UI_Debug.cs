using UnityEngine;

public class UI_Debug : MonoBehaviour
{
	[SerializeField]
	private KeyCode debugKey = (KeyCode)96;

	private bool uiActive;

	private void Awake()
	{
		for (int i = 0; i < ((Component)this).transform.childCount; i++)
		{
			((Component)((Component)this).transform.GetChild(i)).gameObject.SetActive(uiActive);
		}
	}

	private void Update()
	{
	}
}
