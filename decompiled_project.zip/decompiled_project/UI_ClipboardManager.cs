using UnityEngine;

public class UI_ClipboardManager : MonoBehaviour
{
	public GameObject[] CategoryScreens;

	private GameObject CategoryScreenSelected;

	private int CategoryScreensIndex;

	public GameObject[] FamilyPageScreens;

	private GameObject FamilyPageScreenSelected;

	private int FamilyPageScreensIndex;

	public GameObject[] ShelterPageScreens;

	private GameObject ShelterPageScreenSelected;

	private int ShelterPageScreensIndex;

	public GameObject[] ResourcePageScreens;

	private GameObject ResourcePageScreenSelected;

	private int ResourcePageScreensIndex;

	private bool booleanVar;

	public GameObject BGFamily;

	public GameObject BGShelter;

	public GameObject BGResources;

	private void Start()
	{
		if (CategoryScreens.Length >= 1)
		{
			CategoryScreenSelected = CategoryScreens[CategoryScreensIndex];
		}
		if (FamilyPageScreens.Length >= 1)
		{
			FamilyPageScreenSelected = FamilyPageScreens[FamilyPageScreensIndex];
		}
		if (ShelterPageScreens.Length >= 1)
		{
			ShelterPageScreenSelected = ShelterPageScreens[ShelterPageScreensIndex];
		}
		if (ResourcePageScreens.Length >= 1)
		{
			ResourcePageScreenSelected = ResourcePageScreens[ResourcePageScreensIndex];
		}
	}

	private void Update()
	{
		if (Input.GetKeyDown("c"))
		{
			booleanVar = !booleanVar;
			if (!booleanVar)
			{
				((Behaviour)((Component)this).gameObject.GetComponent<UIPanel>()).enabled = false;
			}
			else
			{
				((Behaviour)((Component)this).gameObject.GetComponent<UIPanel>()).enabled = true;
			}
		}
	}

	public void CategoryLeft()
	{
		if (CategoryScreens.Length >= 1)
		{
			CategoryScreensIndex++;
			if (CategoryScreensIndex >= CategoryScreens.Length)
			{
				CategoryScreensIndex = 0;
			}
			CategoryScreenSelected.SetActive(false);
			CategoryScreenSelected = CategoryScreens[CategoryScreensIndex];
			CategoryScreenSelected.SetActive(true);
		}
	}

	public void CategoryRight()
	{
		if (CategoryScreens.Length >= 1)
		{
			CategoryScreensIndex--;
			if (CategoryScreensIndex <= -1)
			{
				CategoryScreensIndex = CategoryScreens.Length - 1;
			}
			CategoryScreenSelected.SetActive(false);
			CategoryScreenSelected = CategoryScreens[CategoryScreensIndex];
			CategoryScreenSelected.SetActive(true);
		}
	}

	public void PageLeft()
	{
		if (BGFamily.activeSelf && FamilyPageScreens.Length >= 1)
		{
			FamilyPageScreensIndex++;
			if (FamilyPageScreensIndex >= FamilyPageScreens.Length)
			{
				FamilyPageScreensIndex = 0;
			}
			FamilyPageScreenSelected.SetActive(false);
			FamilyPageScreenSelected = FamilyPageScreens[FamilyPageScreensIndex];
			FamilyPageScreenSelected.SetActive(true);
		}
		if (BGShelter.activeSelf && ShelterPageScreens.Length >= 1)
		{
			ShelterPageScreensIndex++;
			if (ShelterPageScreensIndex >= ShelterPageScreens.Length)
			{
				ShelterPageScreensIndex = 0;
			}
			ShelterPageScreenSelected.SetActive(false);
			ShelterPageScreenSelected = ShelterPageScreens[ShelterPageScreensIndex];
			ShelterPageScreenSelected.SetActive(true);
		}
		if (BGResources.activeSelf && ResourcePageScreens.Length >= 1)
		{
			ResourcePageScreensIndex++;
			if (ResourcePageScreensIndex >= ResourcePageScreens.Length)
			{
				ResourcePageScreensIndex = 0;
			}
			ResourcePageScreenSelected.SetActive(false);
			ResourcePageScreenSelected = ResourcePageScreens[ResourcePageScreensIndex];
			ResourcePageScreenSelected.SetActive(true);
		}
	}

	public void PageRight()
	{
		if (BGFamily.activeSelf && FamilyPageScreens.Length >= 1)
		{
			FamilyPageScreensIndex--;
			if (FamilyPageScreensIndex <= -1)
			{
				FamilyPageScreensIndex = FamilyPageScreens.Length - 1;
			}
			FamilyPageScreenSelected.SetActive(false);
			FamilyPageScreenSelected = FamilyPageScreens[FamilyPageScreensIndex];
			FamilyPageScreenSelected.SetActive(true);
		}
		if (BGShelter.activeSelf && ShelterPageScreens.Length >= 1)
		{
			ShelterPageScreensIndex--;
			if (ShelterPageScreensIndex <= -1)
			{
				ShelterPageScreensIndex = ShelterPageScreens.Length - 1;
			}
			ShelterPageScreenSelected.SetActive(false);
			ShelterPageScreenSelected = ShelterPageScreens[ShelterPageScreensIndex];
			ShelterPageScreenSelected.SetActive(true);
		}
		if (BGResources.activeSelf && ResourcePageScreens.Length >= 1)
		{
			ResourcePageScreensIndex--;
			if (ResourcePageScreensIndex <= -1)
			{
				ResourcePageScreensIndex = ResourcePageScreens.Length - 1;
			}
			ResourcePageScreenSelected.SetActive(false);
			ResourcePageScreenSelected = ResourcePageScreens[ResourcePageScreensIndex];
			ResourcePageScreenSelected.SetActive(true);
		}
	}
}
