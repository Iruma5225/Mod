using System.Collections.Generic;
using UnityEngine;

public class CombatAIBear : CombatAIBase
{
	public CombatAIBear(EncounterCharacter character)
		: base(character)
	{
	}

	public override EncounterCombatPanel.CombatActionInfo GetNextAction(List<EncounterCharacter> enemies, List<EncounterCharacter> friends)
	{
		EncounterCombatPanel.CombatActionInfo combatActionInfo = new EncounterCombatPanel.CombatActionInfo();
		List<EncounterCharacter> list = new List<EncounterCharacter>(enemies);
		list.RemoveAll((EncounterCharacter x) => !x.canStillFight || x.hasEscaped);
		combatActionInfo.target = list[Random.Range(0, list.Count)];
		combatActionInfo.action = EncounterCombatPanel.CombatActionEnum.Melee;
		return combatActionInfo;
	}

	public override void OnActionExecuted(EncounterCombatPanel.CombatActionEnum action, EncounterCharacter target)
	{
		base.OnActionExecuted(action, target);
	}
}
