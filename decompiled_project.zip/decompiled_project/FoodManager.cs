using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

public class FoodManager : BaseManagerNoUpdate, ISaveable
{
	private List<Obj_Pantry> m_Pantrys = new List<Obj_Pantry>();

	private List<Obj_Freezer> m_Freezers = new List<Obj_Freezer>();

	[SerializeField]
	private int m_MaxRations;

	[SerializeField]
	private int m_Rations;

	[SerializeField]
	private int m_MaxMeat;

	[SerializeField]
	private int m_Meat;

	[SerializeField]
	private int m_DesperateMeat;

	private static FoodManager m_theInstance;

	public ReadOnlyCollection<Obj_Pantry> Pantrys => m_Pantrys.AsReadOnly();

	public ReadOnlyCollection<Obj_Freezer> Freezers => m_Freezers.AsReadOnly();

	public int MaxRations => m_MaxRations;

	public int Rations => m_Rations;

	public int MaxMeat => m_MaxMeat;

	public int Meat => m_Meat;

	public int DesperateMeat => m_DesperateMeat;

	public int TotalMeat => m_Meat + m_DesperateMeat;

	public int TotalFood => Rations + TotalMeat;

	public static FoodManager Instance => m_theInstance;

	private void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
		}
		else
		{
			Debug.Log((object)"Duplicate FoodManager created!");
		}
	}

	public override void StartManager()
	{
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
	}

	public bool AddRations(int amount)
	{
		m_Rations += amount;
		if (m_Rations > m_MaxRations)
		{
			m_Rations = m_MaxRations;
		}
		if (m_Rations >= m_MaxRations && (Object)(object)ActivityLog.Instance != (Object)null)
		{
			ActivityLog.Instance.Add(ActivityLog.Activity.PantryFull);
		}
		UpdatePantrys();
		return true;
	}

	public int TakeRations(int amount)
	{
		int rations = m_Rations;
		m_Rations = Mathf.Max(m_Rations - amount, 0);
		UpdatePantrys();
		return rations - m_Rations;
	}

	public int TakeMeat(int amount)
	{
		int num = 0;
		for (int i = 0; i < m_Freezers.Count; i++)
		{
			Obj_Freezer obj_Freezer = m_Freezers[i];
			if ((Object)(object)obj_Freezer != (Object)null && obj_Freezer.Meat > 0)
			{
				num += obj_Freezer.RemoveMeat(amount - num);
				if (num == amount)
				{
					break;
				}
			}
		}
		return num;
	}

	public int AddMeat(int amount)
	{
		int num = amount;
		for (int i = 0; i < m_Freezers.Count; i++)
		{
			Obj_Freezer obj_Freezer = m_Freezers[i];
			if ((Object)(object)obj_Freezer != (Object)null && obj_Freezer.TotalSpaceAvailable() > 0)
			{
				num -= obj_Freezer.AddMeat(num);
				if (num <= 0)
				{
					break;
				}
			}
		}
		return amount - num;
	}

	public int TakeDesperateMeat(int amount)
	{
		int num = 0;
		for (int i = 0; i < m_Freezers.Count; i++)
		{
			Obj_Freezer obj_Freezer = m_Freezers[i];
			if ((Object)(object)obj_Freezer != (Object)null && obj_Freezer.DesperateMeat > 0)
			{
				num += obj_Freezer.RemoveDesperateMeat(amount - num);
				if (num == amount)
				{
					break;
				}
			}
		}
		return num;
	}

	public int AddDesperateMeat(int amount)
	{
		int num = amount;
		for (int i = 0; i < m_Freezers.Count; i++)
		{
			Obj_Freezer obj_Freezer = m_Freezers[i];
			if ((Object)(object)obj_Freezer != (Object)null && obj_Freezer.TotalSpaceAvailable() > 0)
			{
				num -= obj_Freezer.AddDesperateMeat(num);
				if (num <= 0)
				{
					break;
				}
			}
		}
		return amount - num;
	}

	public void RegisterStorage(Obj_Pantry pantry)
	{
		if (!m_Pantrys.Contains(pantry))
		{
			m_Pantrys.Add(pantry);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_MaxRations += pantry.Capacity;
			}
			UpdatePantrys();
		}
	}

	public void UnRegisterStorage(Obj_Pantry pantry)
	{
		if (m_Pantrys.Contains(pantry))
		{
			m_Pantrys.Remove(pantry);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_MaxRations -= pantry.Capacity;
				m_Rations = Mathf.Min(m_Rations, m_MaxRations);
			}
			UpdatePantrys();
		}
	}

	public void RegisterStorage(Obj_Freezer freezer)
	{
		if (!m_Freezers.Contains(freezer))
		{
			m_Freezers.Add(freezer);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_MaxMeat += freezer.TotalMeatCapacity;
			}
		}
	}

	public void UnRegisterStorage(Obj_Freezer freezer)
	{
		if (m_Freezers.Contains(freezer))
		{
			m_Freezers.Remove(freezer);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_MaxMeat -= freezer.TotalMeatCapacity;
			}
			UpdateMeatTotals();
		}
	}

	private void UpdatePantrys()
	{
		for (int i = 0; i < m_Pantrys.Count; i++)
		{
			m_Pantrys[i].OnFoodUpdated();
		}
	}

	public void UpdateMeatTotals()
	{
		List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Freezer);
		int num = 0;
		int num2 = 0;
		for (int i = 0; i < objectsOfType.Count; i++)
		{
			Obj_Freezer obj_Freezer = objectsOfType[i] as Obj_Freezer;
			if ((Object)(object)obj_Freezer != (Object)null)
			{
				num += obj_Freezer.Meat;
				num2 += obj_Freezer.DesperateMeat;
			}
		}
		m_Meat = num;
		m_DesperateMeat = num2;
	}

	public int TotalMeatAvailable()
	{
		List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Freezer);
		int num = 0;
		for (int i = 0; i < objectsOfType.Count; i++)
		{
			Obj_Freezer obj_Freezer = objectsOfType[i] as Obj_Freezer;
			if ((Object)(object)obj_Freezer != (Object)null)
			{
				num += obj_Freezer.Meat;
				num += obj_Freezer.DesperateMeat;
			}
		}
		return num;
	}

	public bool IsRelocationEnabled()
	{
		return false;
	}

	public bool IsReadyForLoad()
	{
		return true;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("FoodManager");
		data.SaveLoad("rations", ref m_Rations);
		data.SaveLoad("maxRations", ref m_MaxRations);
		data.SaveLoad("maxMeat", ref m_MaxMeat);
		data.SaveLoad("meat", ref m_Meat);
		data.SaveLoad("desperateMeat", ref m_DesperateMeat);
		data.GroupEnd();
		return true;
	}
}
