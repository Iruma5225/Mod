using System.Collections.Generic;
using UnityEngine;

public class DialogueStageOpening : BaseDialogueStage
{
	private EncounterManager.EncounterType m_choice;

	private string m_textId = string.Empty;

	private string m_npcPersonality = string.Empty;

	public DialogueStageOpening()
	{
		SetState(State_WaitFade);
	}

	private DialogueResult State_WaitFade()
	{
		if (!FadeManager.Instance.IsFading())
		{
			m_npcPersonality = EncounterManager.Instance.GetLeadNpc().Personality.ToString();
			if ((Object)(object)FactionMan.instance != (Object)null && (Object)(object)EncounterManager.Instance != (Object)null && EncounterManager.Instance.encounterFactionId > -1)
			{
				string factionDialogueId = FactionMan.instance.GetFactionDialogueId(EncounterManager.Instance.encounterFactionId);
				if (!string.IsNullOrEmpty(factionDialogueId))
				{
					m_npcPersonality = factionDialogueId;
				}
			}
			int numberOfRandomKeys = Localization.GetNumberOfRandomKeys("Encounter.Player." + m_npcPersonality + ".Opening");
			EncounterDialoguePanel.Instance.SetConversationID(Random.Range(1, numberOfRandomKeys + 1));
			if (EncounterDialoguePanel.Instance.PlayerControlled)
			{
				SetState(State_Player_Begin);
			}
			else
			{
				SetState(State_Npc_Begin);
			}
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_Begin()
	{
		if (EncounterDialoguePanel.Instance.PushPlayerText("Encounter.Player." + m_npcPersonality + ".Opening"))
		{
			SetState(State_Player_WaitOpeningText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitOpeningText()
	{
		if (!EncounterDialoguePanel.Instance.IsTextDone())
		{
			return DialogueResult.Continue;
		}
		List<EncounterCharacter> list = new List<EncounterCharacter>(EncounterManager.Instance.GetPlayerCharacters());
		list.RemoveAll((EncounterCharacter x) => !x.isPlayerControlled);
		if (list.Count > 1)
		{
			EncounterDialoguePanel.Instance.PushPlayerOptions(new List<string> { "Text.UI.Confirm" });
			EncounterDialoguePanel.Instance.ShowSelectCharacterPrompt(show: true);
			SetState(State_Player_WaitChooseChar);
		}
		else
		{
			SetState(State_Player_Choose);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitChooseChar()
	{
		if (m_onTabLeft == null)
		{
			m_onTabLeft = delegate
			{
				EncounterDialoguePanel.Instance.SelectPreviousPlayerCharacter();
			};
		}
		if (m_onTabRight == null)
		{
			m_onTabRight = delegate
			{
				EncounterDialoguePanel.Instance.SelectNextPlayerCharacter();
			};
		}
		if (m_onCharSelected == null)
		{
			m_onCharSelected = delegate(EncounterCharacter character, bool selected)
			{
				if ((Object)(object)character != (Object)null && character.isPlayerControlled)
				{
					character.SetHighlight(selected);
				}
			};
		}
		if (m_onCharClicked == null)
		{
			m_onCharClicked = delegate(EncounterCharacter character, bool right_click)
			{
				if (!right_click)
				{
					EncounterDialoguePanel.Instance.SelectPlayerCharacter(character);
				}
			};
		}
		string chosenOption = EncounterDialoguePanel.Instance.GetChosenOption();
		if (string.IsNullOrEmpty(chosenOption))
		{
			return DialogueResult.Continue;
		}
		if (chosenOption != null && chosenOption == "Text.UI.Confirm")
		{
			SetState(State_Player_Choose);
		}
		EncounterDialoguePanel.Instance.ShowSelectCharacterPrompt(show: false);
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_Choose()
	{
		EncounterDialoguePanel.Instance.PushPlayerOptions(new List<string> { "Text.UI.Trade", "Text.UI.Recruit", "Text.UI.Intimidate", "Text.UI.Flee" });
		SetState(State_Player_WaitChoice);
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitChoice()
	{
		string chosenOption = EncounterDialoguePanel.Instance.GetChosenOption();
		if (string.IsNullOrEmpty(chosenOption))
		{
			return DialogueResult.Continue;
		}
		m_choice = EncounterManager.EncounterType.Invalid;
		switch (chosenOption)
		{
		case "Text.UI.Trade":
			m_choice = EncounterManager.EncounterType.Trade;
			m_textId = "Encounter.Player." + m_npcPersonality + ".Opening.AnnounceTrade";
			break;
		case "Text.UI.Recruit":
			m_choice = EncounterManager.EncounterType.Recruit;
			m_textId = "Encounter.Player." + m_npcPersonality + ".Opening.AnnounceRecruit";
			break;
		case "Text.UI.Intimidate":
			m_choice = EncounterManager.EncounterType.Intimidate;
			m_textId = "Encounter.Player." + m_npcPersonality + ".Opening.AnnounceIntimidate";
			break;
		case "Text.UI.Flee":
			m_choice = EncounterManager.EncounterType.Escape;
			m_textId = "Encounter.Player." + m_npcPersonality + ".Opening.AnnounceEscape";
			break;
		}
		SetState(State_Player_AnnounceChoice);
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_AnnounceChoice()
	{
		if (EncounterDialoguePanel.Instance.PushPlayerText(m_textId))
		{
			SetState(State_Player_WaitAnnounceText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitAnnounceText()
	{
		DialogueResult result = DialogueResult.Continue;
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			EncounterDialoguePanel.Instance.PushPlayerText(null);
			switch (m_choice)
			{
			case EncounterManager.EncounterType.Trade:
				result = DialogueResult.StageTrade;
				break;
			case EncounterManager.EncounterType.Recruit:
				result = DialogueResult.StageRecruit;
				break;
			case EncounterManager.EncounterType.Intimidate:
				result = DialogueResult.StageIntimidate;
				break;
			case EncounterManager.EncounterType.Escape:
				EncounterDialoguePanel.Instance.PushPlayerText(null);
				EncounterDialoguePanel.Instance.Escape(EncounterManager.Instance.GetPlayerCharacters(), EncounterManager.Instance.GetNPCs());
				m_timer = 4f;
				SetState(State_Player_Escaping);
				break;
			}
			Debug.Log((object)("Opening stage result : " + result));
		}
		return result;
	}

	private DialogueResult State_Player_Escaping()
	{
		DialogueResult result = DialogueResult.Continue;
		if (m_timer <= Mathf.Epsilon)
		{
			bool flag = EncounterDialoguePanel.Instance.DidEscapeSucceed(EncounterManager.Instance.GetPlayerCharacters(), EncounterManager.Instance.GetNPCs());
			result = ((!flag) ? DialogueResult.DoCombat : DialogueResult.EndEncounter);
			EncounterDialoguePanel.Instance.EscapeOver(EncounterManager.Instance.GetPlayerCharacters(), EncounterManager.Instance.GetNPCs(), flag);
		}
		return result;
	}

	private DialogueResult State_Npc_Begin()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText("Encounter.Npc." + m_npcPersonality + ".Opening"))
		{
			SetState(State_Npc_WaitOpeningText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_WaitOpeningText()
	{
		if (!EncounterDialoguePanel.Instance.IsTextDone())
		{
			return DialogueResult.Continue;
		}
		List<EncounterCharacter> list = new List<EncounterCharacter>(EncounterManager.Instance.GetPlayerCharacters());
		list.RemoveAll((EncounterCharacter x) => !x.isPlayerControlled);
		if (list.Count > 1)
		{
			EncounterDialoguePanel.Instance.PushPlayerOptions(new List<string> { "Text.UI.Confirm" });
			EncounterDialoguePanel.Instance.ShowSelectCharacterPrompt(show: true);
			SetState(State_Npc_WaitPlayerSelection);
		}
		else
		{
			SetState(State_Npc_PlayerOpeningResponse);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_WaitPlayerSelection()
	{
		if (m_onTabLeft == null)
		{
			m_onTabLeft = delegate
			{
				EncounterDialoguePanel.Instance.SelectPreviousPlayerCharacter();
			};
		}
		if (m_onTabRight == null)
		{
			m_onTabRight = delegate
			{
				EncounterDialoguePanel.Instance.SelectNextPlayerCharacter();
			};
		}
		if (m_onCharSelected == null)
		{
			m_onCharSelected = delegate(EncounterCharacter character, bool selected)
			{
				if ((Object)(object)character != (Object)null && character.isPlayerControlled)
				{
					character.SetHighlight(selected);
				}
			};
		}
		if (m_onCharClicked == null)
		{
			m_onCharClicked = delegate(EncounterCharacter character, bool right_click)
			{
				if (!right_click)
				{
					EncounterDialoguePanel.Instance.SelectPlayerCharacter(character);
				}
			};
		}
		string chosenOption = EncounterDialoguePanel.Instance.GetChosenOption();
		if (string.IsNullOrEmpty(chosenOption))
		{
			return DialogueResult.Continue;
		}
		if (chosenOption != null && chosenOption == "Text.UI.Confirm")
		{
			SetState(State_Npc_PlayerOpeningResponse);
		}
		EncounterDialoguePanel.Instance.ShowSelectCharacterPrompt(show: false);
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_PlayerOpeningResponse()
	{
		if (EncounterDialoguePanel.Instance.PushPlayerText("Encounter.Player." + m_npcPersonality + ".Opening.Response"))
		{
			SetState(State_Npc_WaitPlayerOpeningResponse);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_WaitPlayerOpeningResponse()
	{
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			SetState(State_Npc_ChooseEncounter);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_ChooseEncounter()
	{
		m_choice = EncounterGenerator.Instance.GetRandomEncounterType(EncounterManager.Instance.GetLeadNpc());
		switch (m_choice)
		{
		case EncounterManager.EncounterType.Trade:
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Opening.Trade";
			break;
		case EncounterManager.EncounterType.Intimidate:
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Opening.Intimidate";
			break;
		case EncounterManager.EncounterType.Recruit:
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Opening.Recruit";
			break;
		}
		SetState(State_Npc_AnnounceChoice);
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_AnnounceChoice()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText(m_textId))
		{
			SetState(State_Npc_WaitAnnounceText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_WaitAnnounceText()
	{
		DialogueResult result = DialogueResult.Continue;
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			switch (m_choice)
			{
			case EncounterManager.EncounterType.Trade:
				result = DialogueResult.StageTrade;
				break;
			case EncounterManager.EncounterType.Recruit:
				result = DialogueResult.StageRecruit;
				break;
			case EncounterManager.EncounterType.Intimidate:
				result = DialogueResult.StageIntimidate;
				break;
			}
			Debug.Log((object)("Opening stage result : " + result));
		}
		return result;
	}
}
