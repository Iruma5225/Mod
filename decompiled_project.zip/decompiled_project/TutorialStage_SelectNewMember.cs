using System.Collections.Generic;
using UnityEngine;

public class TutorialStage_SelectNewMember : BaseTutorial
{
	[SerializeField]
	private PlatformLocalize objectiveScript;

	private int m_initialMemberId = -1;

	private FamilyMember m_targetMember;

	public override TutorialManager.TutorialStage GetTutorialStage()
	{
		return TutorialManager.TutorialStage.SelectNewMember;
	}

	public override void OnEnterStage(bool showPanel)
	{
		base.OnEnterStage(showPanel);
		if ((Object)(object)TutorialManager.Instance != (Object)null)
		{
			m_initialMemberId = TutorialManager.Instance.initialFamilyMemberId;
		}
		if ((Object)(object)InteractionManager.Instance != (Object)null && (Object)(object)FamilyManager.Instance != (Object)null)
		{
			List<FamilyMember> allFamilyMembers = FamilyManager.Instance.GetAllFamilyMembers();
			for (int i = 0; i < allFamilyMembers.Count; i++)
			{
				if ((Object)(object)allFamilyMembers[i] != (Object)null && allFamilyMembers[i].GetId() != m_initialMemberId && allFamilyMembers[i].isAdult)
				{
					m_targetMember = allFamilyMembers[i];
					break;
				}
			}
			InteractionManager.Instance.SetAllowFamilySelection(allowSelection: true);
		}
		if ((Object)(object)objectiveScript != (Object)null && (Object)(object)m_targetMember != (Object)null)
		{
			objectiveScript.SetReplacement("%S%", m_targetMember.firstName);
		}
		if ((Object)(object)m_targetMember != (Object)null && (Object)(object)ObjectiveArrowMan.Instance != (Object)null)
		{
			ObjectiveArrowMan.Instance.AddObjective(m_targetMember.objectiveTarget);
		}
	}

	public override bool IsStageComplete()
	{
		if ((Object)(object)InteractionManager.Instance != (Object)null)
		{
			FamilyMember selectedFamilyMember = InteractionManager.Instance.GetSelectedFamilyMember();
			if ((Object)(object)selectedFamilyMember != (Object)null && (Object)(object)selectedFamilyMember == (Object)(object)m_targetMember)
			{
				return true;
			}
		}
		return false;
	}

	public override void OnExitStage()
	{
		base.OnExitStage();
		if ((Object)(object)m_targetMember != (Object)null && (Object)(object)ObjectiveArrowMan.Instance != (Object)null)
		{
			ObjectiveArrowMan.Instance.RemoveObjective(m_targetMember.objectiveTarget);
		}
		if ((Object)(object)InteractionManager.Instance != (Object)null)
		{
			InteractionManager.Instance.SetAllowFamilySelection(allowSelection: false);
		}
	}
}
