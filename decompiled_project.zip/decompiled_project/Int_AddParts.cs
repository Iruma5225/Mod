using UnityEngine;

public class Int_AddParts : Int_Base
{
	private Obj_CamperVan obj_vehicle;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_AddParts";
	}

	public override string GetInteractionType()
	{
		return "add_parts";
	}

	public override int GetInteractionPriority()
	{
		return 2;
	}

	public override void Awake()
	{
		base.Awake();
		if ((Object)(object)obj != (Object)null)
		{
			obj_vehicle = obj as Obj_CamperVan;
		}
	}

	public override bool IsPlayerSelectable()
	{
		if (base.IsPlayerSelectable() && (Object)(object)obj_vehicle != (Object)null && obj_vehicle.PlayerHasParts())
		{
			return true;
		}
		return false;
	}
}
