using System.Collections.Generic;
using UnityEngine;

public class QuestLibrary : MonoBehaviour
{
	[SerializeField]
	private List<QuestDef> m_quests = new List<QuestDef>();

	[SerializeField]
	private List<ScenarioDef> m_scenarios = new List<ScenarioDef>();

	private Dictionary<string, QuestDefBase> m_definitions = new Dictionary<string, QuestDefBase>();

	private static QuestLibrary m_instance;

	public static QuestLibrary instance => m_instance;

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
			return;
		}
		m_definitions.Clear();
		List<QuestDefBase> list = new List<QuestDefBase>();
		for (int i = 0; i < m_quests.Count; i++)
		{
			list.Add(m_quests[i]);
		}
		for (int j = 0; j < m_scenarios.Count; j++)
		{
			list.Add(m_scenarios[j]);
		}
		for (int k = 0; k < list.Count; k++)
		{
			if (!string.IsNullOrEmpty(list[k].id) && !m_definitions.ContainsKey(list[k].id))
			{
				m_definitions.Add(list[k].id, list[k]);
			}
		}
	}

	public void Update()
	{
	}

	public QuestDefBase FindDefinition(string id)
	{
		if (m_definitions.ContainsKey(id))
		{
			return m_definitions[id];
		}
		return null;
	}

	public QuestDef FindQuestDefinition(string id)
	{
		QuestDefBase questDefBase = FindDefinition(id);
		if (questDefBase != null)
		{
			return questDefBase as QuestDef;
		}
		return null;
	}

	public ScenarioDef FindScenarioDefinition(string id)
	{
		QuestDefBase questDefBase = FindDefinition(id);
		if (questDefBase != null)
		{
			return questDefBase as ScenarioDef;
		}
		return null;
	}

	public bool IsAvailable(QuestDefBase def, bool ignoreWeight, bool discoverByRadio)
	{
		if (def == null)
		{
			return false;
		}
		if ((Object)(object)QuestManager.instance != (Object)null && !QuestManager.instance.IsAvailable(def.id))
		{
			return false;
		}
		if (!ignoreWeight && def.selectionProperties.weight <= 0f)
		{
			return false;
		}
		if ((Object)(object)QuestManager.instance != (Object)null && QuestManager.instance.IsQuestOnTimeout(def.id))
		{
			return false;
		}
		if (GameTime.Day <= 0 || GameTime.Day < def.selectionProperties.startDate)
		{
			return false;
		}
		if (def.IsQuest() && discoverByRadio != def.selectionProperties.discoverByRadio)
		{
			return false;
		}
		if ((Object)(object)QuestManager.instance != (Object)null)
		{
			int maxSimultaneousInstances = def.selectionProperties.maxSimultaneousInstances;
			if (maxSimultaneousInstances > 0 && QuestManager.instance.CountInstances(def.id) >= maxSimultaneousInstances)
			{
				return false;
			}
		}
		bool result = true;
		for (int i = 0; i < def.selectionProperties.prerequisiteMilestones.Count; i++)
		{
			if (!QuestManager.instance.CheckGlobalMilestone(def.selectionProperties.prerequisiteMilestones[i]))
			{
				result = false;
				break;
			}
		}
		return result;
	}

	private List<QuestDef> GetAvailableQuests(bool discoverByRadio)
	{
		List<QuestDef> list = new List<QuestDef>();
		List<string> list2 = new List<string>();
		list2.AddRange(m_definitions.Keys);
		for (int i = 0; i < list2.Count; i++)
		{
			if (m_definitions[list2[i]] is QuestDef questDef && questDef.IsQuest() && !questDef.IsSubquest() && !questDef.IsFloating() && IsAvailable(questDef, ignoreWeight: false, discoverByRadio))
			{
				list.Add(questDef);
			}
		}
		return list;
	}

	private List<ScenarioDef> GetAvailableScenarios()
	{
		List<ScenarioDef> list = new List<ScenarioDef>();
		List<string> list2 = new List<string>();
		list2.AddRange(m_definitions.Keys);
		for (int i = 0; i < list2.Count; i++)
		{
			if (m_definitions[list2[i]] is ScenarioDef scenarioDef && scenarioDef.IsScenario() && IsAvailable(scenarioDef, ignoreWeight: false, discoverByRadio: false))
			{
				list.Add(scenarioDef);
			}
		}
		return list;
	}

	public QuestDef GetRandomAvailableQuest(bool discoverByRadio)
	{
		if ((Object)(object)QuestManager.instance == (Object)null)
		{
			return null;
		}
		List<QuestDef> availableQuests = GetAvailableQuests(discoverByRadio);
		if (availableQuests == null || availableQuests.Count == 0)
		{
			return null;
		}
		float num = 0f;
		for (int i = 0; i < availableQuests.Count; i++)
		{
			num += availableQuests[i].selectionProperties.weight;
		}
		float num2 = Random.value * num;
		float num3 = 0f;
		for (int j = 0; j < availableQuests.Count; j++)
		{
			if (num2 >= num3 && num2 < num3 + availableQuests[j].selectionProperties.weight)
			{
				return availableQuests[j];
			}
			num3 += availableQuests[j].selectionProperties.weight;
		}
		return null;
	}

	public ScenarioDef GetRandomAvailableScenario()
	{
		if ((Object)(object)QuestManager.instance == (Object)null)
		{
			return null;
		}
		List<ScenarioDef> availableScenarios = GetAvailableScenarios();
		if (availableScenarios == null || availableScenarios.Count == 0)
		{
			return null;
		}
		float num = 0f;
		for (int i = 0; i < availableScenarios.Count; i++)
		{
			num += availableScenarios[i].selectionProperties.weight;
		}
		float num2 = Random.value * num;
		float num3 = 0f;
		for (int j = 0; j < availableScenarios.Count; j++)
		{
			if (num2 >= num3 && num2 < num3 + availableScenarios[j].selectionProperties.weight)
			{
				return availableScenarios[j];
			}
			num3 += availableScenarios[j].selectionProperties.weight;
		}
		return null;
	}
}
