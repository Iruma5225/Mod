using System;
using UnityEngine;

public abstract class Obj_GhostBase : Obj_Base
{
	public enum PlacementState
	{
		Placing,
		Placed
	}

	private PlacementState m_State;

	private bool m_Placable;

	private bool m_placed;

	protected Action<Obj_Base> m_PlacedCallback;

	protected Action m_CancelledCallback;

	[SerializeField]
	[Header("Ghost Settings")]
	private bool m_Pausable;

	protected string m_CraftRecipeID = string.Empty;

	protected SpriteRenderer m_SpriteRenderer;

	[SerializeField]
	protected Color m_UnplacableColor = Color.red;

	[SerializeField]
	protected Color m_PlacableColor = Color.green;

	[SerializeField]
	protected Color m_PlacedColor = Color.white;

	[SerializeField]
	protected string m_PlacedSpriteLayer = "Objects";

	[SerializeField]
	protected int m_PlacedSpriteOrder = 20;

	[SerializeField]
	protected AudioClip m_PlacedSound;

	[SerializeField]
	protected AudioClip m_UnplacableSound;

	[SerializeField]
	protected AudioClip m_CancelledSound;

	[SerializeField]
	protected SpriteRenderer m_ConstructionIcon;

	[SerializeField]
	protected SpriteRenderer m_placementIcon;

	protected float m_CraftedPercentage;

	protected bool m_ConstructionPaused;

	public PlacementState State => m_State;

	public bool isPlaced => m_placed;

	public float CraftedPercentage => m_CraftedPercentage;

	public abstract CursorBase.CursorType GetCursorType();

	public virtual bool GetCameraZoom()
	{
		return false;
	}

	public override void Awake()
	{
		base.Awake();
		m_SpriteRenderer = ((Component)this).GetComponentInChildren<SpriteRenderer>();
		ShowConstructionIcon(show: false);
		SetPlacable(placable: false);
	}

	public void SetUpGhost(Action<Obj_Base> placedCallback, Action cancelledCallback)
	{
		if (!((Object)(object)m_SpriteRenderer == (Object)null))
		{
			m_PlacedCallback = placedCallback;
			if (m_PlacedCallback == null)
			{
			}
			m_CancelledCallback = cancelledCallback;
			if (m_PlacedCallback != null)
			{
			}
		}
	}

	public virtual void SetConstructionPercentage(float percentage)
	{
		m_CraftedPercentage = Mathf.Clamp01(percentage);
		if (constructionSprites != null && constructionSprites.Length > 0)
		{
			int num = Mathf.FloorToInt(m_CraftedPercentage * (float)constructionSprites.Length);
			num = Mathf.Clamp(num, 0, constructionSprites.Length - 1);
			if ((Object)(object)m_SpriteRenderer.sprite != (Object)(object)constructionSprites[num])
			{
				m_SpriteRenderer.sprite = constructionSprites[num];
			}
		}
	}

	private void ShowConstructionIcon(bool show)
	{
		if ((Object)(object)m_ConstructionIcon != (Object)null)
		{
			((Component)m_ConstructionIcon).gameObject.SetActive(show);
			((Component)m_placementIcon).gameObject.SetActive(!show);
		}
	}

	public bool IsPlacable()
	{
		return m_Placable;
	}

	protected void SetPlacable(bool placable)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		m_Placable = placable;
		if ((Object)(object)m_SpriteRenderer != (Object)null)
		{
			m_SpriteRenderer.color = ((!placable) ? m_UnplacableColor : m_PlacableColor);
			m_placementIcon.color = m_SpriteRenderer.color;
		}
	}

	public bool HasBeenPlaced()
	{
		return m_State == PlacementState.Placed;
	}

	public bool OnTryPlacement()
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		if (!IsPlacable())
		{
			AudioManager.Instance.PlayUI(m_UnplacableSound);
			return false;
		}
		if (constructionSprites != null && constructionSprites.Length > 0)
		{
			m_SpriteRenderer.sprite = constructionSprites[0];
		}
		m_SpriteRenderer.color = m_PlacedColor;
		((Renderer)m_SpriteRenderer).sortingLayerName = m_PlacedSpriteLayer;
		((Renderer)m_SpriteRenderer).sortingOrder = m_PlacedSpriteOrder;
		m_CraftedPercentage = 0f;
		m_State = PlacementState.Placed;
		base.selectable = false;
		return true;
	}

	public virtual void OnPlacementFinished()
	{
		if (m_PlacedCallback != null)
		{
			m_PlacedCallback(this);
		}
		AudioManager.Instance.PlayUI(m_PlacedSound);
		m_placed = true;
		ShowConstructionIcon(show: true);
	}

	public void OnCancelPlacement()
	{
		if (m_CancelledCallback != null)
		{
			m_CancelledCallback();
		}
		AudioManager.Instance.PlayUI(m_CancelledSound);
	}

	public void SetCraftRecipeID(string recipe)
	{
		m_CraftRecipeID = recipe;
	}

	public bool IsPaused()
	{
		return m_ConstructionPaused;
	}

	public virtual bool IsPausable()
	{
		return m_Pausable;
	}

	public virtual void PauseConstruction()
	{
		if (!IsPaused() && IsPausable())
		{
			m_ConstructionPaused = true;
			base.selectable = true;
		}
	}

	public virtual bool ResumeConstruction(FamilyMember member)
	{
		if (!IsPaused() || !IsPausable() || (Object)(object)member == (Object)null || string.IsNullOrEmpty(m_CraftRecipeID))
		{
			return false;
		}
		CraftingManager.Recipe recipeByID = CraftingManager.Instance.GetRecipeByID(m_CraftRecipeID);
		Job_Craft job_Craft = new Job_Craft(member, recipeByID, this);
		if (!member.AddPlayerJob(job_Craft))
		{
			job_Craft.Cancel(forced: true);
			return false;
		}
		m_ConstructionPaused = false;
		base.selectable = false;
		return true;
	}

	public virtual bool CancelConstruction()
	{
		if (!string.IsNullOrEmpty(m_CraftRecipeID))
		{
			CraftingManager.Recipe recipeByID = CraftingManager.Instance.GetRecipeByID(m_CraftRecipeID);
			if (recipeByID != null)
			{
				CraftingManager.CancelCraft(recipeByID);
			}
		}
		ObjectManager.Instance.RemoveObject(this);
		return true;
	}

	public virtual bool IsValidRoom(ShelterRoomGrid.GridCell cell)
	{
		if (cell == null)
		{
			return false;
		}
		if (cell.type == ShelterRoomGrid.CellType.Room || cell.type == ShelterRoomGrid.CellType.RoomTop || cell.type == ShelterRoomGrid.CellType.Surface)
		{
			return true;
		}
		return false;
	}

	public override bool SaveLoad(SaveData data)
	{
		if (data.isLoading || (data.isSaving && m_placed))
		{
			data.GroupStart((!base.initialObject) ? "spawned_objects" : "initial_objects");
			data.GroupStart("object_" + base.objectId);
			SaveLoadGhost(data);
			data.GroupEnd();
			data.GroupEnd();
		}
		return true;
	}

	protected virtual void SaveLoadGhost(SaveData data)
	{
		int value = (int)m_State;
		data.SaveLoad("state", ref value);
		if (data.isLoading)
		{
			m_State = (PlacementState)value;
		}
		data.SaveLoad("placed", ref m_placed);
		data.SaveLoad("sortingLayerName", ref m_PlacedSpriteLayer);
		data.SaveLoad("sortingLayerOrder", ref m_PlacedSpriteOrder);
		data.SaveLoad("paused", ref m_ConstructionPaused);
		data.SaveLoad("recipeID", ref m_CraftRecipeID);
		data.SaveLoad("construction", ref m_CraftedPercentage);
		if (data.isLoading)
		{
			SetConstructionPercentage(m_CraftedPercentage);
			if (m_placed)
			{
				SetPlacable(placable: true);
			}
			ShowConstructionIcon(m_placed);
		}
	}
}
