using UnityEngine;

public class UI_AutoIcon : MonoBehaviour
{
	private UI_Character character;

	private UISprite sprite;

	private void Awake()
	{
		character = ((Component)((Component)this).transform.parent.parent).GetComponent<UI_Character>();
		sprite = ((Component)this).GetComponent<UISprite>();
	}

	private void Update()
	{
		if ((Object)(object)character.familyMember != (Object)null)
		{
			if (character.familyMember.automation && !((Behaviour)sprite).enabled)
			{
				((Behaviour)sprite).enabled = true;
			}
			if (!character.familyMember.automation && ((Behaviour)sprite).enabled)
			{
				((Behaviour)sprite).enabled = false;
			}
		}
	}
}
