using UnityEngine;

public class ItemButtonBase_Storage : ItemButtonBase
{
	[SerializeField]
	private UIAtlas m_spriteAtlas;

	[SerializeField]
	private string m_lockedSpriteName = string.Empty;

	public override void SetLocked(bool locked)
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		base.SetLocked(locked);
		if ((Object)(object)m_sprite != (Object)null && locked)
		{
			m_sprite.atlas = m_spriteAtlas;
			m_sprite.spriteName = m_lockedSpriteName;
			m_sprite.color = defaultColour.defaultColor;
		}
	}

	public override void Update()
	{
		base.Update();
	}
}
