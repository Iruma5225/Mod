using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

public class WaterManager : BaseManager, ISaveable
{
	private List<Obj_WaterFilter> m_Filters = new List<Obj_WaterFilter>();

	private List<Obj_WaterTank> m_Tanks = new List<Obj_WaterTank>();

	[SerializeField]
	private float m_MaxStoredWater;

	[SerializeField]
	private float m_StoredWater;

	private float m_Contamination;

	private float m_RainWaterPerSec;

	private float m_BlackRainWaterPerSec;

	[SerializeField]
	private float m_ContFilteredPerSec_Upgrade0 = 0.1f;

	[SerializeField]
	private float m_ContFilteredPerSec_Upgrade1 = 0.11f;

	[SerializeField]
	private float m_ContFilteredPerSec_Upgrade2 = 0.12f;

	[SerializeField]
	private float m_ContFilteredPerSec_Upgrade3 = 0.13f;

	[SerializeField]
	private float m_ContFilteredPerSec_Upgrade4 = 0.15f;

	[Range(1f, 10f)]
	[SerializeField]
	private float[] m_RainWaterPerSecPerLevel = new float[5] { 0.5f, 0.55f, 0.6f, 0.65f, 0.75f };

	[SerializeField]
	private float m_RainContaminationPerSec;

	[Range(1f, 10f)]
	[SerializeField]
	private float[] m_BlackRainWaterPerSecPerLevel = new float[5] { 0.25f, 0.275f, 0.3f, 0.325f, 0.375f };

	[SerializeField]
	private float m_BlackRainContaminationPerSec;

	private float m_UpdateInterval = 1f;

	private float m_UpdateTime;

	private static WaterManager m_theInstance;

	public ReadOnlyCollection<Obj_WaterFilter> Filters => m_Filters.AsReadOnly();

	public ReadOnlyCollection<Obj_WaterTank> Tanks => m_Tanks.AsReadOnly();

	public float MaxStoredWater => m_MaxStoredWater;

	public float StoredWater => m_StoredWater;

	public float Contamination => m_Contamination;

	public static WaterManager Instance => m_theInstance;

	private void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
		}
		else
		{
			Debug.Log((object)"Duplicate WaterManager created!");
		}
	}

	public override void StartManager()
	{
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
	}

	public override void UpdateManager()
	{
		if (Time.time >= m_UpdateTime)
		{
			UpdateWater();
			m_UpdateTime = Time.time + m_UpdateInterval;
		}
	}

	public void UpdateWater()
	{
		int num = 0;
		for (int i = 0; i < m_Filters.Count; i++)
		{
			if (m_Filters[i].IsEnabled() && m_Filters[i].HasEnoughPower() && m_Filters[i].IsNotBroken())
			{
				num = m_Filters[i].GetUpgradeLevel(UpgradeObject.PathEnum.Efficiency);
			}
		}
		m_RainWaterPerSec = m_RainWaterPerSecPerLevel[num];
		m_BlackRainWaterPerSec = m_BlackRainWaterPerSecPerLevel[num];
		if ((Object)(object)WeatherManager.Instance != (Object)null)
		{
			if (WeatherManager.Instance.currentState == WeatherManager.WeatherState.Rain)
			{
				AddWater(m_RainWaterPerSec * m_UpdateInterval);
				AddContamination(m_RainContaminationPerSec * m_UpdateInterval);
			}
			else if (WeatherManager.Instance.currentState == WeatherManager.WeatherState.BlackRain)
			{
				AddWater(m_BlackRainWaterPerSec * m_UpdateInterval);
				AddContamination(m_BlackRainContaminationPerSec * m_UpdateInterval);
			}
		}
		bool flag = false;
		int num2 = 0;
		for (int j = 0; j < m_Filters.Count; j++)
		{
			if (m_Filters[j].IsEnabled() && m_Filters[j].HasEnoughPower() && m_Filters[j].IsNotBroken())
			{
				flag = true;
				int upgradeLevel = m_Filters[j].GetUpgradeLevel(UpgradeObject.PathEnum.Decontamination);
				num = m_Filters[j].GetUpgradeLevel(UpgradeObject.PathEnum.Efficiency);
				if (upgradeLevel > num2)
				{
					num2 = upgradeLevel;
				}
			}
		}
		if (flag && num2 >= 0)
		{
			float num3 = m_ContFilteredPerSec_Upgrade0;
			if (num2 == 1)
			{
				num3 = m_ContFilteredPerSec_Upgrade1;
			}
			else if (num2 == 2)
			{
				num3 = m_ContFilteredPerSec_Upgrade2;
			}
			else if (num2 == 3)
			{
				num3 = m_ContFilteredPerSec_Upgrade3;
			}
			else if (num2 >= 4)
			{
				num3 = m_ContFilteredPerSec_Upgrade4;
			}
			float contamination = m_Contamination;
			m_Contamination = Mathf.Max(m_Contamination - num3 * m_UpdateInterval, 0f);
			if (m_Contamination != contamination)
			{
				UpdateTanks();
			}
		}
	}

	public float AddWater(float amount)
	{
		float num = Mathf.Min(amount, m_MaxStoredWater - m_StoredWater);
		if (num > 0f)
		{
			m_StoredWater += num;
			if (m_StoredWater >= m_MaxStoredWater && (Object)(object)ActivityLog.Instance != (Object)null)
			{
				ActivityLog.Instance.Add(ActivityLog.Activity.WaterTankFull);
			}
			UpdateTanks();
			if (LoadingManager.IsLoadingFinished())
			{
				for (int i = 0; i < m_Tanks.Count; i++)
				{
					m_Tanks[i].activatePosWaterIcon();
				}
			}
		}
		return num;
	}

	public void AddContamination(float contamination)
	{
		if (contamination > 0f)
		{
			float contamination2 = m_Contamination;
			m_Contamination = Mathf.Min(m_Contamination + contamination, 100f);
			if (contamination2 != m_Contamination)
			{
				UpdateTanks();
			}
		}
	}

	public bool UseWater(float amount)
	{
		if (m_StoredWater - amount < 0f)
		{
			return false;
		}
		m_StoredWater -= amount;
		UpdateTanks();
		if (LoadingManager.IsLoadingFinished())
		{
			for (int i = 0; i < m_Tanks.Count; i++)
			{
				m_Tanks[i].activateNegWaterIcon();
			}
		}
		return true;
	}

	public void RegisterFilter(Obj_WaterFilter filter)
	{
		if (!m_Filters.Contains(filter))
		{
			m_Filters.Add(filter);
		}
	}

	public void UnRegisterFilter(Obj_WaterFilter filter)
	{
		if (m_Filters.Contains(filter))
		{
			m_Filters.Remove(filter);
		}
	}

	public void RegisterStorage(Obj_WaterTank tank)
	{
		if (!m_Tanks.Contains(tank))
		{
			m_Tanks.Add(tank);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_MaxStoredWater += tank.Capacity;
			}
			UpdateTanks();
		}
	}

	public void UnRegisterStorage(Obj_WaterTank tank)
	{
		if (m_Tanks.Contains(tank))
		{
			m_Tanks.Remove(tank);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_MaxStoredWater -= tank.Capacity;
				m_StoredWater = Mathf.Min(m_StoredWater, m_MaxStoredWater);
			}
			UpdateTanks();
		}
	}

	private void UpdateTanks()
	{
		for (int i = 0; i < m_Tanks.Count; i++)
		{
			m_Tanks[i].OnWaterUpdated();
		}
	}

	public bool IsRelocationEnabled()
	{
		return false;
	}

	public bool IsReadyForLoad()
	{
		return true;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("WaterManager");
		data.SaveLoad("storedWater", ref m_StoredWater);
		data.SaveLoad("maxStoredWater", ref m_MaxStoredWater);
		data.SaveLoad("contamination", ref m_Contamination);
		data.SaveLoadAbsoluteTime("updateTime", ref m_UpdateTime);
		data.GroupEnd();
		return true;
	}
}
