using GooglePlayGames;
using GooglePlayGames.BasicApi;
using UnityEngine;

public class PlatformLeaderboards_GPS : PlatformLeaderboards_Base
{
	private LeaderboardScoreData m_resultsData;

	private bool m_busy;

	private int m_startRow;

	private int m_endRow;

	private int m_totalRows;

	private LeaderboardFilter m_filter;

	public override int GetMaxRowsToRead()
	{
		return 10;
	}

	public override bool ReadLeaderboard(LeaderboardConfig boardConfig, LeaderboardFilter filter, int startRow, int numRowsToRead)
	{
		bool result = false;
		if (Social.localUser.authenticated)
		{
			m_totalRows = 0;
			m_startRow = startRow;
			m_endRow = m_startRow + numRowsToRead - 1;
			m_filter = filter;
			string gPSId = boardConfig.GPSId;
			if (boardConfig.type == LeaderboardType.Monthly_DaysSurvived || boardConfig.type == LeaderboardType.Monthly_DaysSurvived_Hard || boardConfig.type == LeaderboardType.Monthly_DaysSurvived_Hardcore)
			{
				if (m_filter == LeaderboardFilter.Overall)
				{
					PlayGamesPlatform.Instance.LoadScores(gPSId, LeaderboardStart.TopScores, GetMaxRowsToRead(), LeaderboardCollection.Public, LeaderboardTimeSpan.Weekly, delegate(LeaderboardScoreData m_resultsData)
					{
						result = m_resultsData.Valid;
						if (m_resultsData.Valid)
						{
						}
					});
				}
				else if (m_filter == LeaderboardFilter.Friends)
				{
					PlayGamesPlatform.Instance.LoadScores(gPSId, LeaderboardStart.PlayerCentered, GetMaxRowsToRead(), LeaderboardCollection.Social, LeaderboardTimeSpan.Weekly, delegate(LeaderboardScoreData m_resultsData)
					{
						result = m_resultsData.Valid;
						if (m_resultsData.Valid)
						{
						}
					});
				}
				else if (m_filter == LeaderboardFilter.MyScore)
				{
					PlayGamesPlatform.Instance.LoadScores(gPSId, LeaderboardStart.PlayerCentered, GetMaxRowsToRead(), LeaderboardCollection.Public, LeaderboardTimeSpan.Weekly, delegate(LeaderboardScoreData m_resultsData)
					{
						result = m_resultsData.Valid;
						if (m_resultsData.Valid)
						{
						}
					});
				}
			}
			else if (m_filter == LeaderboardFilter.Overall)
			{
				PlayGamesPlatform.Instance.LoadScores(gPSId, LeaderboardStart.TopScores, GetMaxRowsToRead(), LeaderboardCollection.Public, LeaderboardTimeSpan.AllTime, delegate(LeaderboardScoreData m_resultsData)
				{
					result = m_resultsData.Valid;
					if (m_resultsData.Valid)
					{
					}
				});
			}
			else if (m_filter == LeaderboardFilter.Friends)
			{
				PlayGamesPlatform.Instance.LoadScores(gPSId, LeaderboardStart.PlayerCentered, GetMaxRowsToRead(), LeaderboardCollection.Social, LeaderboardTimeSpan.AllTime, delegate(LeaderboardScoreData m_resultsData)
				{
					result = m_resultsData.Valid;
					if (m_resultsData.Valid)
					{
					}
				});
			}
			else if (m_filter == LeaderboardFilter.MyScore)
			{
				PlayGamesPlatform.Instance.LoadScores(gPSId, LeaderboardStart.PlayerCentered, GetMaxRowsToRead(), LeaderboardCollection.Public, LeaderboardTimeSpan.AllTime, delegate(LeaderboardScoreData m_resultsData)
				{
					result = m_resultsData.Valid;
					if (m_resultsData.Valid)
					{
					}
				});
			}
			return result;
		}
		return result;
	}

	public override void ShowPlayerInfo(RowData row)
	{
		if (row != null && Social.localUser.authenticated)
		{
			Social.ShowLeaderboardUI();
		}
	}
}
