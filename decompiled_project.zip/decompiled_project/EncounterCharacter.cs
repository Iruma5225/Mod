using System;
using System.Collections.Generic;
using UnityEngine;

public class EncounterCharacter : MonoBehaviour
{
	public enum CombatState
	{
		Idle,
		SkipTurn,
		Moving,
		DrawWeapon,
		Melee,
		MeleeReaction,
		SkipTurnDueToCowardice,
		Item,
		PickupWeapon,
		Throwing,
		Shooting,
		DefendStart,
		Cowering,
		Dying,
		Finished
	}

	public enum TeamEnum
	{
		Player,
		NPC
	}

	public enum PersonalityType
	{
		Generic,
		Aggressive,
		Haggler,
		Passive
	}

	public enum SpeciesEnum
	{
		Human,
		Mutant,
		Bear,
		Wolf,
		Dog
	}

	public enum MoveType
	{
		Run,
		Walk,
		Backwards
	}

	[Serializable]
	public class MoveSpeeds
	{
		public float run = 2.4f;

		public float walk = 1.6f;

		public float backwards = 0.8f;
	}

	[Serializable]
	public class SpeciesMoveSpeeds
	{
		public SpeciesEnum species;

		public MoveSpeeds speeds = new MoveSpeeds();
	}

	private CombatState current_state = CombatState.Finished;

	[SerializeField]
	private int health = 100;

	[SerializeField]
	private int m_maxHealth = 100;

	[SerializeField]
	private bool bleeding;

	[SerializeField]
	private bool subdued;

	[SerializeField]
	private bool dazed;

	[SerializeField]
	private bool defending;

	[SerializeField]
	private bool escaping;

	[SerializeField]
	private bool escaped;

	[SerializeField]
	private bool chasing;

	[SerializeField]
	private TeamEnum m_team = TeamEnum.NPC;

	[SerializeField]
	private PersonalityType personality;

	[SerializeField]
	private SpeciesEnum species;

	[SerializeField]
	private BaseStats stats = new BaseStats();

	private const float TraumaFromKilling = 10f;

	private int health_lost;

	private int trauma_sustained;

	private Dictionary<BaseStats.StatType, int> changed_stats = new Dictionary<BaseStats.StatType, int>();

	private List<Traits.Weakness> traits_gained = new List<Traits.Weakness>();

	private ItemDefinition_Combat.DamageTypeEnum last_damage_type;

	private ItemManager.ItemType last_damaged_by = ItemManager.ItemType.Undefined;

	private EncounterCharacter last_damage_from;

	private ItemManager.ItemType defaultWeapon = ItemManager.ItemType.Weapon_Fists;

	private ItemManager.ItemType weapon = ItemManager.ItemType.Undefined;

	private ItemDefinition_Combat weapon_def;

	private List<ItemStack> equipped_items = new List<ItemStack>
	{
		new ItemStack(),
		new ItemStack()
	};

	private List<ItemStack> backpack_items = new List<ItemStack>();

	[SerializeField]
	private float adrenalinTimer;

	private int modStr;

	private int modDex;

	private EncounterCharacter target_character;

	private PartyMember party_member;

	private CompanionAnimal m_pet;

	private NpcVisitor m_visitor;

	private CombatAIBase combat_ai;

	private bool wants_to_escape;

	[SerializeField]
	private string firstName = string.Empty;

	[SerializeField]
	private string lastName = string.Empty;

	[SerializeField]
	private EncounterCharacterCollider m_collider;

	[SerializeField]
	private Transform ui_position;

	[SerializeField]
	private Transform menu_position;

	[SerializeField]
	private MoveSpeeds default_move_speeds = new MoveSpeeds();

	[SerializeField]
	private List<SpeciesMoveSpeeds> species_move_speeds = new List<SpeciesMoveSpeeds>();

	private MoveSpeeds move_speeds;

	private Vector3 home_position = Vector3.zero;

	private bool prefer_run;

	private Vector3 start_move_position = Vector3.zero;

	private Vector3 target_move_position = Vector3.zero;

	private float move_start_time;

	private float move_finished_time;

	private float move_percentage;

	private CombatState move_finished_state;

	private EncounterLogic.AttackResult melee_attack_result;

	private const float melee_attack_delay = 0f;

	private float melee_attack_time;

	private float melee_connect_time;

	private const int courageous_guaranteed_hits = 2;

	private int m_guaranteedHits;

	[SerializeField]
	private Transform melee_point;

	private bool multiple_attacks;

	private bool counterable_attack;

	private bool special_attack;

	private int attack_count;

	[SerializeField]
	private int max_attack_count = 3;

	private Action onAttackHit;

	private Action<EncounterLogic.AttackResult> onAttackMiss;

	private Action onAttackOver;

	private float melee_reaction_time;

	private float melee_reaction_impact_time;

	private float next_state_time;

	private Action melee_reaction_callback;

	private bool has_reacted;

	private bool has_impacted;

	[SerializeField]
	private float m_drawDelay = 2f;

	private float m_drawWaitTime;

	[SerializeField]
	private float m_cowardiceDelay = 4f;

	private float m_cowardiceWaitTime;

	private Action onItemUsed;

	private string combat_item_anim = string.Empty;

	[SerializeField]
	private float m_useItemDelay;

	private float m_useItemWaitTime;

	[SerializeField]
	private Transform thrown_item_spawn_point;

	[SerializeField]
	private GameObject thrown_combat_item_prefab;

	private ItemManager.ItemType combat_item = ItemManager.ItemType.Undefined;

	private ItemDefinition_Combat combat_item_def;

	private ThrownCombatItem thrown_item;

	[SerializeField]
	private float m_itemSpawnDelay;

	private float m_itemSpawnTime;

	[SerializeField]
	private float m_turnEndDelay;

	private float m_turnEndTime;

	private bool item_spawned;

	private bool item_landed;

	private ItemManager.ItemType dropped_weapon = ItemManager.ItemType.Undefined;

	private bool dropped_weapon_onscreen;

	[SerializeField]
	private DroppedCombatItem dropped_weapon_object;

	[SerializeField]
	private float m_pickupItemDelay;

	[SerializeField]
	private float m_pickupItemEndDelay;

	private float m_pickupItemWaitTime;

	private const int dazeDuration = 3;

	private int dazeTimer;

	private List<EncounterCharacter> shooting_targets;

	private const float shooting_delay_initial = 0.625f;

	private float shooting_time;

	private int ammo_used;

	private List<EncounterCharacter> cowering_targets;

	[SerializeField]
	private float m_deathDelay;

	private float m_deathWaitTime;

	[SerializeField]
	private Transform escape_point;

	[SerializeField]
	private Transform chase_point;

	[SerializeField]
	private AudioClip deathSound;

	[SerializeField]
	private ParticleSystem bloodParticle;

	[SerializeField]
	private ParticleSystem childBloodParticle;

	private bool facing_forwards = true;

	private Sprite m_AvatarSprite;

	private CharacterMesh m_mesh;

	private string m_meshId = string.Empty;

	private Animator m_CharacterAnimator;

	private string current_anim = "Idle";

	private bool m_layersSetUp;

	private ItemDefinition_Combat.AnimInfo current_weapon_anim;

	public ItemManager.ItemType weapon_inspector = ItemManager.ItemType.Undefined;

	public ItemManager.ItemType armour_inspector = ItemManager.ItemType.Undefined;

	public List<ItemStack> equipped_item_inspector;

	public List<ItemStack> backpack_inspector = new List<ItemStack>();

	public bool isIdle => current_state == CombatState.Idle;

	public bool isAttacking => current_state != CombatState.Idle && current_state != CombatState.Finished && current_state != CombatState.Cowering;

	public bool isCowering => current_state == CombatState.Cowering;

	public bool isTurnFinished => current_state == CombatState.Finished;

	public int Health
	{
		get
		{
			return health;
		}
		set
		{
			if (health > 0 && value <= 0)
			{
				OnDeath();
			}
			int num = Mathf.Clamp(value, 0, m_maxHealth);
			health_lost += health - num;
			health = num;
			if (num < health && isPlayerControlled)
			{
				UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.LostHealth);
			}
		}
	}

	public int maxHealth => m_maxHealth;

	public bool isDead => health <= 0;

	public bool isBleeding => bleeding;

	public bool isSubdued => subdued;

	public bool isDazed => dazed;

	public bool isDefending => defending;

	public bool isEscaping => escaping;

	public bool hasEscaped => escaped;

	public bool isChasing => chasing;

	public bool canStillFight => !isDead && !isSubdued;

	public TeamEnum team => m_team;

	public bool isPlayerCharacter => m_team == TeamEnum.Player;

	public bool isNPC => m_team == TeamEnum.NPC;

	public bool isPlayerControlled => isPlayerCharacter && species == SpeciesEnum.Human;

	public PersonalityType Personality => personality;

	public SpeciesEnum Species => species;

	public BaseStats Stats
	{
		get
		{
			return stats;
		}
		set
		{
			stats = value;
		}
	}

	public int Strength => stats.Strength.Level;

	public int Dexterity => stats.Dexterity.Level;

	public int Intelligence => stats.Intelligence.Level;

	public int Charisma => stats.Charisma.Level;

	public int Perception => stats.Perception.Level;

	public int StrengthModifier => stats.Strength.GetModifier();

	public int DexterityModifier => stats.Dexterity.GetModifier();

	public int IntelligenceModifier => stats.Intelligence.GetModifier();

	public int CharismaModifier => stats.Charisma.GetModifier();

	public int PerceptionModifier => stats.Perception.GetModifier();

	public int HealthLost => health_lost;

	public int TraumaSustained => trauma_sustained;

	public List<Traits.Weakness> TraitsTurnedToStrengths => traits_gained;

	public ItemDefinition_Combat.DamageTypeEnum lastDamageType => last_damage_type;

	public ItemManager.ItemType lastDamagedBy => last_damaged_by;

	public EncounterCharacter lastDamageFrom => last_damage_from;

	public bool hasWeapon => weapon != ItemManager.ItemType.Undefined && weapon != defaultWeapon;

	public bool hasRangedWeapon
	{
		get
		{
			if ((Object)(object)weapon_def != (Object)null && weapon_def.WeaponType == ItemDefinition_Combat.WeaponTypeEnum.Ranged)
			{
				return true;
			}
			return false;
		}
	}

	public bool hasAmmo
	{
		get
		{
			if ((Object)(object)weapon_def != (Object)null)
			{
				return ammo_used < weapon_def.ClipSize && (HasBackpackItem(weapon_def.AmmoType) || hasAmmoEquipped);
			}
			return false;
		}
	}

	public bool hasBackpackItems
	{
		get
		{
			if ((Object)(object)partyMember != (Object)null)
			{
				return ExplorationManager.Instance.GetPartyItems(partyMember.partyId).Count > 0;
			}
			return backpack_items.Count > 0;
		}
	}

	public bool hasCorrectAmmo
	{
		get
		{
			for (int i = 0; i < equipped_items.Count; i++)
			{
				if (equipped_items[i].m_type == weapon_def.AmmoType)
				{
					return true;
				}
			}
			return false;
		}
	}

	public bool hasAmmoEquipped
	{
		get
		{
			if (InventoryManager.Instance.GetNumItemsOfType(weapon_def.AmmoType) > 0)
			{
				return true;
			}
			return false;
		}
	}

	public EncounterCharacter lastTargetedCharacter => target_character;

	public PartyMember partyMember => party_member;

	public CompanionAnimal pet => m_pet;

	public NpcVisitor visitor => m_visitor;

	public CombatAIBase ai => combat_ai;

	public bool aiTargetable => (Object)(object)m_pet == (Object)null;

	public bool wantsToEscape
	{
		get
		{
			return wants_to_escape;
		}
		set
		{
			wants_to_escape = value;
		}
	}

	public string Name => firstName + " " + lastName;

	public string Name_Short => firstName;

	public string Surname => lastName;

	public Vector3 uiPosition => (!((Object)(object)ui_position != (Object)null)) ? Vector3.zero : ui_position.position;

	public Vector3 menuPosition => (!((Object)(object)menu_position != (Object)null)) ? Vector3.zero : menu_position.position;

	public Vector3 meleeAttackPoint => (!((Object)(object)melee_point != (Object)null)) ? Vector3.zero : melee_point.position;

	public bool hasDroppedWeapon => dropped_weapon != ItemManager.ItemType.Undefined;

	public bool hasAvailableDroppedWeapon => hasDroppedWeapon && dropped_weapon_onscreen;

	public CharacterMesh mesh => m_mesh;

	public string meshId => m_meshId;

	public void SetName(string _firstName, string _surname)
	{
		firstName = _firstName;
		lastName = string.Empty;
	}

	public bool IsFacingForwards()
	{
		return facing_forwards;
	}

	public void Initialise()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		home_position = ((Component)this).transform.position;
		if ((Object)(object)m_collider != (Object)null)
		{
			m_collider.Initialise();
			EncounterCharacterCollider collider = m_collider;
			collider.onSelected = (EncounterCharacterCollider.EncounterColliderEvent)Delegate.Combine(collider.onSelected, new EncounterCharacterCollider.EncounterColliderEvent(OnColliderSelected));
			EncounterCharacterCollider collider2 = m_collider;
			collider2.onClicked = (EncounterCharacterCollider.EncounterColliderClickEvent)Delegate.Combine(collider2.onClicked, new EncounterCharacterCollider.EncounterColliderClickEvent(OnColliderClicked));
		}
		PauseManager.OnPause -= OnGamePaused;
		PauseManager.OnPause += OnGamePaused;
		PauseManager.OnResume -= OnGameResumed;
		PauseManager.OnResume += OnGameResumed;
	}

	public void Setup(PartyMember member)
	{
		if ((Object)(object)member == (Object)null || (Object)(object)member.person == (Object)null)
		{
			return;
		}
		party_member = member;
		SetName(member.person.firstName, member.person.lastName);
		SetSpecies(SpeciesEnum.Human);
		SetWeapon(member.GetEquippedWeapon());
		SetEquippedItem(0, member.GetEquippedItem1());
		SetEquippedItem(1, member.GetEquippedItem2());
		SetAppearance(member.person);
		SetAvatarSprite(member.person.avatarSprite);
		List<ItemManager.ItemType> list = new List<ItemManager.ItemType>();
		list.Add(member.GetEquippedItem1());
		list.Add(member.GetEquippedItem2());
		string text = string.Empty;
		for (int i = 0; i < list.Count; i++)
		{
			switch (list[i])
			{
			case ItemManager.ItemType.BulletProofVest_poor:
				text = "armor1";
				break;
			case ItemManager.ItemType.BulletProofVest_good:
				text = "armor2";
				break;
			case ItemManager.ItemType.BulletProofVest_great:
				text = "armor3";
				break;
			}
		}
		for (int j = 0; j < list.Count; j++)
		{
			switch (list[j])
			{
			case ItemManager.ItemType.GasMask:
				mesh.SetTexture(CharacterMesh.TextureType.Head, "gasmask");
				break;
			case ItemManager.ItemType.AdvancedGasMask:
				mesh.SetTexture(CharacterMesh.TextureType.Head, "AdvancedGasMask");
				break;
			}
		}
		if (!string.IsNullOrEmpty(text) && (Object)(object)mesh != (Object)null)
		{
			mesh.SetOverlayTexture(text);
		}
		SetStats(member.person.BaseStats);
		health = member.person.health;
	}

	public void SetSpecies(SpeciesEnum newSpecies)
	{
		species = newSpecies;
		defaultWeapon = GetDefaultWeaponForSpecies(species);
		move_speeds = GetDefaultMoveSpeedsForSpecies(species);
		SetWeapon(defaultWeapon);
	}

	public void SetPersonality(PersonalityType personalityType)
	{
		personality = personalityType;
	}

	public void SetStats(BaseStats other)
	{
		stats.Initialize();
		stats.CopyOther(other);
	}

	public void SetStats(int str, int strMax, int dex, int dexMax, int intel, int intelMax, int per, int perMax, int cha, int chaMax)
	{
		stats.Initialize();
		stats.Strength.SetInitialLevel(str, strMax);
		stats.Dexterity.SetInitialLevel(dex, dexMax);
		stats.Intelligence.SetInitialLevel(intel, intelMax);
		stats.Charisma.SetInitialLevel(per, perMax);
		stats.Perception.SetInitialLevel(cha, chaMax);
	}

	private MoveSpeeds GetDefaultMoveSpeedsForSpecies(SpeciesEnum species)
	{
		SpeciesMoveSpeeds speciesMoveSpeeds = species_move_speeds.Find((SpeciesMoveSpeeds x) => x.species == species);
		if (speciesMoveSpeeds != null)
		{
			return speciesMoveSpeeds.speeds;
		}
		return default_move_speeds;
	}

	private static ItemManager.ItemType GetDefaultWeaponForSpecies(SpeciesEnum species)
	{
		ItemManager.ItemType itemType = ItemManager.ItemType.Weapon_Fists;
		return species switch
		{
			SpeciesEnum.Bear => ItemManager.ItemType.Weapon_BearArms, 
			SpeciesEnum.Wolf => ItemManager.ItemType.Weapon_WolfPaws, 
			SpeciesEnum.Dog => ItemManager.ItemType.Weapon_DogPaws, 
			_ => ItemManager.ItemType.Weapon_Fists, 
		};
	}

	public bool SetWeapon(ItemManager.ItemType type)
	{
		weapon = type;
		weapon_def = ItemManager.Instance.GetCombatDefinition(weapon);
		if ((Object)(object)weapon_def == (Object)null)
		{
			weapon = defaultWeapon;
			weapon_def = ItemManager.Instance.GetCombatDefinition(weapon);
		}
		m_layersSetUp = false;
		return true;
	}

	public bool SetEquippedItem(int index, ItemManager.ItemType type, int quantity = 1)
	{
		if (index < 0 || index >= equipped_items.Count)
		{
			return false;
		}
		equipped_items[index].m_type = type;
		equipped_items[index].m_count = Mathf.Max(quantity, 1);
		return true;
	}

	public void SetUpQuestNpc(QuestManager.QuestCharacterInfo info)
	{
		SetSpecies(SpeciesEnum.Human);
		if (info != null)
		{
			SetPersonality(info.m_personality);
			if (info.m_weapon >= ItemManager.ItemType.Weapon_Fists && info.m_weapon <= ItemManager.ItemType.Weapon_Rifle)
			{
				SetWeapon(info.m_weapon);
			}
			else
			{
				SetWeapon(ItemManager.ItemType.Weapon_Fists);
			}
			if ((Object)(object)ItemManager.Instance != (Object)null)
			{
				if (info.m_equippedItem1 != ItemManager.ItemType.Undefined)
				{
					ItemManager.ItemCategory itemCategory = ItemManager.Instance.GetItemCategory(info.m_equippedItem1);
					if (itemCategory == ItemManager.ItemCategory.Armour || itemCategory == ItemManager.ItemCategory.Equipment)
					{
						SetEquippedItem(0, info.m_equippedItem1);
					}
				}
				if (info.m_equippedItem2 != ItemManager.ItemType.Undefined)
				{
					ItemManager.ItemCategory itemCategory2 = ItemManager.Instance.GetItemCategory(info.m_equippedItem2);
					if (itemCategory2 == ItemManager.ItemCategory.Armour || itemCategory2 == ItemManager.ItemCategory.Equipment)
					{
						SetEquippedItem(1, info.m_equippedItem2);
					}
				}
			}
			SetStats(info.m_strength, 20, info.m_dexterity, 20, info.m_intelligence, 20, info.m_perception, 20, info.m_charisma, 20);
			backpack_items.Clear();
			for (int i = 0; i < info.m_carriedItems.Count; i++)
			{
				backpack_items.Add(new ItemStack(info.m_carriedItems[i]));
			}
			SetName(info.m_preset.m_firstName, info.m_preset.m_lastName);
			SetAppearance(info.m_preset);
			List<ItemManager.ItemType> list = new List<ItemManager.ItemType>();
			list.Add(info.m_equippedItem1);
			list.Add(info.m_equippedItem2);
			string text = string.Empty;
			for (int j = 0; j < list.Count; j++)
			{
				switch (list[j])
				{
				case ItemManager.ItemType.BulletProofVest_poor:
					text = "armor1";
					break;
				case ItemManager.ItemType.BulletProofVest_good:
					text = "armor2";
					break;
				case ItemManager.ItemType.BulletProofVest_great:
					text = "armor3";
					break;
				}
			}
			if (!string.IsNullOrEmpty(text) && (Object)(object)mesh != (Object)null)
			{
				mesh.SetOverlayTexture(text);
			}
		}
		else
		{
			bool flag = Random.Range(0, 2) == 0;
			firstName = NameGenerator.GetFirstName((!flag) ? NameGenerator.Gender.Female : NameGenerator.Gender.Male);
			lastName = NameGenerator.GetSurname();
			SetAppearance((!flag) ? "woman" : "man");
		}
	}

	public void SetupFromNPCVisitor(NpcVisitor npc)
	{
		SetSpecies(SpeciesEnum.Human);
		if (!((Object)(object)npc != (Object)null))
		{
			return;
		}
		m_visitor = npc;
		SetPersonality(npc.personality);
		SetStats(npc.BaseStats);
		SetName(npc.firstName, npc.lastName);
		SetAppearance(npc);
		SetWeapon(npc.GetWeapon());
		List<ItemManager.ItemType> list = new List<ItemManager.ItemType>();
		list.Add(npc.GetArmor());
		string text = string.Empty;
		for (int i = 0; i < list.Count; i++)
		{
			switch (list[i])
			{
			case ItemManager.ItemType.BulletProofVest_poor:
				text = "armor1";
				break;
			case ItemManager.ItemType.BulletProofVest_good:
				text = "armor2";
				break;
			case ItemManager.ItemType.BulletProofVest_great:
				text = "armor3";
				break;
			}
		}
		if (!string.IsNullOrEmpty(text) && (Object)(object)mesh != (Object)null)
		{
			mesh.SetOverlayTexture(text);
		}
		SetEquippedItem(0, npc.GetArmor());
		health = npc.health;
	}

	public void Setup(CompanionAnimal animal)
	{
		if (!((Object)(object)animal == (Object)null))
		{
			m_pet = animal;
			SetName(animal.petName, string.Empty);
			SetSpecies(animal.species);
			SetAppearance(animal);
			SetWeapon(GetDefaultWeaponForSpecies(species));
			SetStats(animal.stats);
			health = Mathf.CeilToInt(animal.health);
			m_maxHealth = Mathf.CeilToInt(animal.maxHealth);
		}
	}

	private bool CreateCharacterMesh(string meshId)
	{
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)CharacterMeshOptions.instance == (Object)null)
		{
			return false;
		}
		CharacterMeshOptions.CharacterMeshType characterMeshType = CharacterMeshOptions.instance.FindCharacterMesh(meshId);
		if (characterMeshType == null)
		{
			return false;
		}
		if ((Object)(object)characterMeshType.m_anims == (Object)null)
		{
			return false;
		}
		if ((Object)(object)m_mesh != (Object)null)
		{
			Object.Destroy((Object)(object)((Component)m_mesh).gameObject);
		}
		GameObject val = Object.Instantiate<GameObject>(characterMeshType.m_meshAsset, Vector3.zero, Quaternion.identity);
		if ((Object)(object)val != (Object)null)
		{
			((Object)val.gameObject).name = "mesh";
			val.transform.parent = ((Component)this).transform;
			val.transform.localPosition = Vector2.op_Implicit(characterMeshType.m_meshOffset);
			val.transform.localScale = Vector3.one;
			val.transform.rotation = Quaternion.Euler(new Vector3(0f, 180f, 0f));
			m_meshId = meshId;
			m_layersSetUp = false;
			m_CharacterAnimator = val.GetComponent<Animator>();
			if ((Object)(object)m_CharacterAnimator != (Object)null)
			{
				m_CharacterAnimator.runtimeAnimatorController = characterMeshType.m_anims;
				m_CharacterAnimator.updateMode = (AnimatorUpdateMode)2;
				m_CharacterAnimator.speed = 0.5f;
			}
			m_mesh = val.AddComponent<CharacterMesh>();
			if ((Object)(object)m_mesh != (Object)null)
			{
				m_mesh.SetMeshType(characterMeshType, "UICharacterMesh");
				m_mesh.RefreshColors();
				m_mesh.RefreshTextures();
				if ((Object)(object)m_collider != (Object)null && characterMeshType != null)
				{
					((Component)m_collider).transform.localScale = ((Component)m_mesh).transform.localScale;
					m_collider.SetSizeAndOffset(characterMeshType.m_collisionBoxDimensions, characterMeshType.m_collisionBoxOffset);
				}
				return true;
			}
		}
		return false;
	}

	public bool SetAppearance(string meshId)
	{
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		CreateCharacterMesh(meshId);
		if ((Object)(object)m_mesh == (Object)null)
		{
			return false;
		}
		if ((Object)(object)NpcVisitManager.Instance != (Object)null)
		{
			m_mesh.SetColor(CharacterMesh.ColorCustomization.SkinColor, NpcVisitManager.Instance.GetRandomNpcColor(CharacterMesh.ColorCustomization.SkinColor));
			m_mesh.SetColor(CharacterMesh.ColorCustomization.HairColor, NpcVisitManager.Instance.GetRandomNpcColor(CharacterMesh.ColorCustomization.HairColor));
			m_mesh.SetColor(CharacterMesh.ColorCustomization.ShirtColor, NpcVisitManager.Instance.GetRandomNpcColor(CharacterMesh.ColorCustomization.ShirtColor));
			m_mesh.SetColor(CharacterMesh.ColorCustomization.PantsColor, NpcVisitManager.Instance.GetRandomNpcColor(CharacterMesh.ColorCustomization.PantsColor));
		}
		else
		{
			m_mesh.SetColor(CharacterMesh.ColorCustomization.SkinColor, new Color(1f, 0.8f, 0.8f));
			m_mesh.SetColor(CharacterMesh.ColorCustomization.HairColor, new Color(0.6f, 0.3f, 0.1f));
			m_mesh.SetColor(CharacterMesh.ColorCustomization.ShirtColor, new Color(Random.value * 0.7f, Random.value * 0.7f, Random.value * 0.7f, 1f));
			m_mesh.SetColor(CharacterMesh.ColorCustomization.PantsColor, new Color(Random.value * 0.7f, Random.value * 0.7f, Random.value * 0.7f, 1f));
		}
		m_mesh.RandomizeTextures();
		SetupAppearanceUI();
		return true;
	}

	public bool SetAppearance(FamilyMember person)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)person != (Object)null)
		{
			CreateCharacterMesh(person.meshId);
			if ((Object)(object)m_mesh == (Object)null)
			{
				return false;
			}
			m_mesh.SetColor(CharacterMesh.ColorCustomization.HairColor, person.hairColor);
			m_mesh.SetColor(CharacterMesh.ColorCustomization.SkinColor, person.skinColor);
			m_mesh.SetColor(CharacterMesh.ColorCustomization.ShirtColor, person.shirtColor);
			m_mesh.SetColor(CharacterMesh.ColorCustomization.PantsColor, person.pantsColor);
			m_mesh.SetTexture(CharacterMesh.TextureType.Head, person.headTexture);
			m_mesh.SetTexture(CharacterMesh.TextureType.Torso, person.torsoTexture);
			m_mesh.SetTexture(CharacterMesh.TextureType.Legs, person.legTexture);
			m_mesh.SetOverlayTexture(person.torsoOverlay);
		}
		SetupAppearanceUI();
		return true;
	}

	public bool SetAppearance(NpcVisitor person)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)person != (Object)null)
		{
			CreateCharacterMesh(person.meshId);
			if ((Object)(object)m_mesh == (Object)null)
			{
				return false;
			}
			m_mesh.SetColor(CharacterMesh.ColorCustomization.HairColor, person.hairColor);
			m_mesh.SetColor(CharacterMesh.ColorCustomization.SkinColor, person.skinColor);
			m_mesh.SetColor(CharacterMesh.ColorCustomization.ShirtColor, person.shirtColor);
			m_mesh.SetColor(CharacterMesh.ColorCustomization.PantsColor, person.pantsColor);
			m_mesh.SetTexture(CharacterMesh.TextureType.Head, person.headTexture);
			m_mesh.SetTexture(CharacterMesh.TextureType.Torso, person.torsoTexture);
			m_mesh.SetTexture(CharacterMesh.TextureType.Legs, person.legTexture);
			m_mesh.SetOverlayTexture(person.torsoOverlay);
		}
		SetupAppearanceUI();
		return true;
	}

	public bool SetAppearance(CharacterMeshOptions.CharacterPreset preset)
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		if (preset != null)
		{
			CreateCharacterMesh(preset.m_meshId);
			if ((Object)(object)m_mesh == (Object)null)
			{
				return false;
			}
			m_mesh.SetColor(CharacterMesh.ColorCustomization.HairColor, preset.m_hairColor);
			m_mesh.SetColor(CharacterMesh.ColorCustomization.SkinColor, preset.m_skinColor);
			m_mesh.SetColor(CharacterMesh.ColorCustomization.ShirtColor, preset.m_shirtColor);
			m_mesh.SetColor(CharacterMesh.ColorCustomization.PantsColor, preset.m_pantsColor);
			m_mesh.SetTexture(CharacterMesh.TextureType.Head, preset.m_headTexture);
			m_mesh.SetTexture(CharacterMesh.TextureType.Torso, preset.m_torsoTexture);
			m_mesh.SetTexture(CharacterMesh.TextureType.Legs, preset.m_legTexture);
			m_mesh.SetOverlayTexture(preset.m_torsoOverlay);
		}
		SetupAppearanceUI();
		return true;
	}

	public bool SetAppearance(CompanionAnimal animal)
	{
		if ((Object)(object)animal != (Object)null)
		{
			CreateCharacterMesh(animal.meshId);
			if ((Object)(object)m_mesh == (Object)null)
			{
				return false;
			}
		}
		SetupAppearanceUI();
		return true;
	}

	private void SetupAppearanceUI()
	{
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)CharacterMeshOptions.instance != (Object)null))
		{
			return;
		}
		CharacterMeshOptions.CharacterMeshType characterMeshType = CharacterMeshOptions.instance.FindCharacterMesh(m_mesh.meshId);
		if (characterMeshType == null)
		{
			return;
		}
		for (int i = 0; i < characterMeshType.m_headTextures.Count; i++)
		{
			if (characterMeshType.m_headTextures[i].m_id == m_mesh.headTexture)
			{
				SetAvatarSprite(characterMeshType.m_headTextures[i].m_avatar);
				break;
			}
		}
		if (m_mesh.torsoTexture == "Shirtless")
		{
			m_mesh.SetColor(CharacterMesh.ColorCustomization.ShirtColor, m_mesh.skinColor);
		}
		if ((Object)(object)ui_position != (Object)null)
		{
			ui_position.localPosition = Vector2.op_Implicit(characterMeshType.m_uiOffset);
		}
	}

	public void SetAvatarSprite(Sprite sprite)
	{
		m_AvatarSprite = sprite;
	}

	public void ColorizeAvatarSprite(UI2DSprite sprite)
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)sprite == (Object)null) && !((Object)(object)m_AvatarSprite == (Object)null))
		{
			sprite.sprite2D = null;
			sprite.sprite2D = m_AvatarSprite;
			if ((Object)(object)m_mesh != (Object)null)
			{
				sprite.material.SetColor("_HairColour", m_mesh.hairColor);
				sprite.material.SetColor("_SkinColour", m_mesh.skinColor);
				sprite.material.SetColor("_ShirtColour", m_mesh.shirtColor);
				sprite.material.SetColor("_PantsColour", m_mesh.pantsColor);
			}
		}
	}

	public void SetFacingForwards(bool forwards)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		if (forwards != facing_forwards)
		{
			facing_forwards = forwards;
			if ((Object)(object)m_mesh != (Object)null)
			{
				((Component)m_mesh).transform.localScale = Vector3.Scale(((Component)m_mesh).transform.localScale, new Vector3(-1f, 1f, 1f));
			}
		}
	}

	public void SetCharacterDepth(int order)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)m_mesh != (Object)null)
		{
			Vector3 localPosition = ((Component)m_mesh).transform.localPosition;
			localPosition.z = -order;
			((Component)m_mesh).transform.localPosition = localPosition;
		}
		if ((Object)(object)m_collider != (Object)null)
		{
			m_collider.SetDepth(order);
		}
	}

	public void SetHighlight(bool highlight)
	{
		if ((Object)(object)m_mesh != (Object)null)
		{
			m_mesh.SetHighlight((!highlight) ? 0f : 1f);
		}
	}

	private void OnGamePaused()
	{
		if ((Object)(object)m_CharacterAnimator != (Object)null)
		{
			m_CharacterAnimator.updateMode = (AnimatorUpdateMode)0;
		}
	}

	private void OnGameResumed(float timePaused)
	{
		if ((Object)(object)m_CharacterAnimator != (Object)null)
		{
			m_CharacterAnimator.updateMode = (AnimatorUpdateMode)2;
		}
	}

	private void TriggerAnim(string animTrigger)
	{
		if (((!isDead && !isSubdued) || string.Compare(animTrigger, "Death", ignoreCase: true) == 0 || string.Compare(animTrigger, "Death2", ignoreCase: true) == 0 || string.Compare(animTrigger, "Knockout", ignoreCase: true) == 0) && (Object)(object)m_CharacterAnimator != (Object)null && ((Behaviour)m_CharacterAnimator).isActiveAndEnabled)
		{
			if (!string.IsNullOrEmpty(current_anim))
			{
				m_CharacterAnimator.ResetTrigger(current_anim);
			}
			m_CharacterAnimator.SetTrigger(animTrigger);
			current_anim = animTrigger;
		}
	}

	private void TriggerAnim_Idle()
	{
		if (isDazed)
		{
			TriggerAnim("Dazed");
			return;
		}
		if (isDefending)
		{
			TriggerAnim("Defend");
			return;
		}
		current_weapon_anim = GetWeaponAnim(ItemDefinition_Combat.WeaponAnimEnum.Idle);
		if (current_weapon_anim != null)
		{
			TriggerAnim(current_weapon_anim.TriggerName);
		}
	}

	public void SetAnimBool(string parameter, bool truth)
	{
		if (!((Object)(object)m_CharacterAnimator == (Object)null) && !string.IsNullOrEmpty(parameter))
		{
			m_CharacterAnimator.SetBool(parameter, truth);
		}
	}

	private void RandomiseCurrentAnimation()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)m_CharacterAnimator != (Object)null)
		{
			AnimatorStateInfo currentAnimatorStateInfo = m_CharacterAnimator.GetCurrentAnimatorStateInfo(weapon_def.AnimationLayer);
			if (((AnimatorStateInfo)(ref currentAnimatorStateInfo)).shortNameHash != 0)
			{
				m_CharacterAnimator.CrossFade(((AnimatorStateInfo)(ref currentAnimatorStateInfo)).shortNameHash, 0f, weapon_def.AnimationLayer, Random.value);
			}
		}
	}

	private ItemDefinition_Combat.AnimInfo GetItemAnim(ItemManager.ItemType item, ItemDefinition_Combat.WeaponAnimEnum type)
	{
		if (item == ItemManager.ItemType.Undefined)
		{
			return null;
		}
		ItemDefinition_Combat combatDefinition = ItemManager.Instance.GetCombatDefinition(item);
		if ((Object)(object)combatDefinition != (Object)null)
		{
			ItemDefinition_Combat.AnimInfo animInfo = combatDefinition.GetAnimInfo(type);
			if (animInfo != null)
			{
				return animInfo;
			}
		}
		return null;
	}

	private ItemDefinition_Combat.AnimInfo GetWeaponAnim(ItemDefinition_Combat.WeaponAnimEnum type)
	{
		ItemDefinition_Combat.AnimInfo itemAnim = GetItemAnim(weapon, type);
		if (itemAnim != null)
		{
			return itemAnim;
		}
		itemAnim = GetItemAnim(defaultWeapon, type);
		if (itemAnim != null)
		{
			return itemAnim;
		}
		return null;
	}

	private float GetMoveSpeed(MoveType type)
	{
		float result = 0f;
		if (move_speeds != null)
		{
			result = type switch
			{
				MoveType.Run => move_speeds.run, 
				MoveType.Walk => move_speeds.walk, 
				MoveType.Backwards => move_speeds.backwards, 
				_ => 0f, 
			};
		}
		return result;
	}

	private void PlaySFX(AudioClip clip)
	{
		if ((Object)(object)AudioManager.Instance != (Object)null && (Object)(object)clip != (Object)null)
		{
			AudioManager.Instance.PlaySFX(clip, AudioManager.MixerEnum.Encounter);
		}
	}

	private void PlayBloodParticle()
	{
		if ((Object)(object)party_member != (Object)null && (Object)(object)party_member.person != (Object)null && party_member.person.isChild)
		{
			if ((Object)(object)childBloodParticle != (Object)null)
			{
				((Component)childBloodParticle).gameObject.SetActive(true);
				childBloodParticle.time = 0f;
				childBloodParticle.Play();
			}
		}
		else if ((Object)(object)bloodParticle != (Object)null)
		{
			((Component)bloodParticle).gameObject.SetActive(true);
			bloodParticle.time = 0f;
			bloodParticle.Play();
		}
	}

	public void Reset()
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		health = maxHealth;
		dazed = false;
		subdued = false;
		bleeding = false;
		defending = false;
		escaping = false;
		escaped = false;
		chasing = false;
		((Component)this).transform.position = home_position;
		SetFacingForwards(forwards: true);
		current_weapon_anim = null;
		target_character = null;
		combat_ai = null;
		party_member = null;
		firstName = string.Empty;
		lastName = string.Empty;
		m_pet = null;
		SetSpecies(SpeciesEnum.Human);
		SetPersonality(PersonalityType.Generic);
		SetStats(0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
		move_speeds = GetDefaultMoveSpeedsForSpecies(species);
		health_lost = 0;
		trauma_sustained = 0;
		changed_stats.Clear();
		traits_gained.Clear();
		last_damage_type = ItemDefinition_Combat.DamageTypeEnum.Undefined;
		last_damaged_by = ItemManager.ItemType.Undefined;
		last_damage_from = null;
		dazeTimer = 0;
		defaultWeapon = GetDefaultWeaponForSpecies(species);
		weapon = defaultWeapon;
		weapon_def = ItemManager.Instance.GetCombatDefinition(defaultWeapon);
		dropped_weapon = ItemManager.ItemType.Undefined;
		dropped_weapon_onscreen = false;
		if ((Object)(object)dropped_weapon_object != (Object)null)
		{
			dropped_weapon_object.ShowWeapon(ItemManager.ItemType.Undefined);
		}
		ammo_used = 0;
		for (int i = 0; i < equipped_items.Count; i++)
		{
			equipped_items[i].m_type = ItemManager.ItemType.Undefined;
			equipped_items[i].m_count = 0;
		}
		SetState(CombatState.Finished);
		if ((Object)(object)m_mesh != (Object)null)
		{
			Object.Destroy((Object)(object)((Component)m_mesh).gameObject);
		}
		m_CharacterAnimator = null;
	}

	public void ModifyStat(BaseStats.StatType stat, int change_value)
	{
		if (!changed_stats.TryGetValue(stat, out var value))
		{
			changed_stats.Add(stat, change_value);
		}
		else
		{
			changed_stats[stat] = value + change_value;
		}
	}

	public int GetStatChange(BaseStats.StatType stat)
	{
		if (changed_stats.TryGetValue(stat, out var value))
		{
			return value;
		}
		return 0;
	}

	public void GainTrait(Traits.Weakness weakness)
	{
		if (!traits_gained.Contains(weakness))
		{
			traits_gained.Add(weakness);
		}
	}

	private ItemManager.ItemType FindBestArmour()
	{
		ItemManager.ItemType result = ItemManager.ItemType.Undefined;
		int num = -1;
		ItemDefinition itemDefinition = null;
		ItemDefinition_Combat itemDefinition_Combat = null;
		for (int i = 0; i < equipped_items.Count; i++)
		{
			itemDefinition = ItemManager.Instance.GetItemDefinition(equipped_items[i].m_type);
			if ((Object)(object)itemDefinition == (Object)null || itemDefinition.Category != ItemManager.ItemCategory.Armour)
			{
				continue;
			}
			if (num < 0)
			{
				result = equipped_items[i].m_type;
				continue;
			}
			int num2 = 0;
			for (int j = 0; j < 10; j++)
			{
				itemDefinition_Combat = ItemManager.Instance.GetCombatDefinition(itemDefinition_Combat.NextArmourType);
				if ((Object)(object)itemDefinition_Combat == (Object)null)
				{
					break;
				}
				num2++;
			}
			if (num2 > num)
			{
				result = equipped_items[i].m_type;
			}
		}
		return result;
	}

	public void TakeDamage(int dmg, ItemDefinition_Combat.DamageTypeEnum dmgType = ItemDefinition_Combat.DamageTypeEnum.Undefined, ItemManager.ItemType dmgSource = ItemManager.ItemType.Undefined, EncounterCharacter attacker = null)
	{
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		if (dmg <= 0 || isDead || isSubdued)
		{
			return;
		}
		if (dmgType == ItemDefinition_Combat.DamageTypeEnum.Undefined)
		{
		}
		last_damage_type = dmgType;
		last_damaged_by = dmgSource;
		if ((Object)(object)attacker != (Object)null)
		{
			last_damage_from = attacker;
		}
		if (combat_ai != null)
		{
			combat_ai.OnTakeDamage(dmg, dmgType, dmgSource, attacker);
		}
		if (dmgType == ItemDefinition_Combat.DamageTypeEnum.Concussion)
		{
			GetDazed();
			return;
		}
		ItemManager.ItemType item = FindBestArmour();
		ItemDefinition_Combat combatDefinition = ItemManager.Instance.GetCombatDefinition(item);
		if (dmgType == ItemDefinition_Combat.DamageTypeEnum.Piercing && (Object)(object)combatDefinition != (Object)null)
		{
			RemoveEquippedItem(item);
			if (combatDefinition.NextArmourType != ItemManager.ItemType.Undefined)
			{
				AddEquippedItem(combatDefinition.NextArmourType);
			}
			else if ((Object)(object)partyMember != (Object)null && (Object)(object)partyMember.person != (Object)null)
			{
				partyMember.person.SetOverlayTexture("none");
			}
			return;
		}
		float num = 1f;
		if ((dmgType == ItemDefinition_Combat.DamageTypeEnum.Blunt || dmgType == ItemDefinition_Combat.DamageTypeEnum.Slashing || dmgType == ItemDefinition_Combat.DamageTypeEnum.Explosive) && (Object)(object)combatDefinition != (Object)null)
		{
			num = 1f - combatDefinition.MeleeResistance;
		}
		int num2 = Mathf.FloorToInt((float)dmg * num);
		Health -= Mathf.FloorToInt((float)num2);
		FloatingTextPool.ShowFloatingText(num2.ToString(), uiPosition);
		if (Health > 0 && !isBleeding && EncounterLogic.BleedRoll(dmgType))
		{
			bleeding = true;
			FloatingTextPool.ShowFloatingText(Localization.Get("UI.combat.bleeding"), uiPosition);
		}
	}

	private void OnDeath()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		if (Vector3.Distance(((Component)this).transform.position, home_position) > Mathf.Epsilon)
		{
			MoveToPoint(home_position, run: true, CombatState.Dying);
		}
		else
		{
			SetState(CombatState.Dying);
		}
	}

	private void OnEnemyKilled(EncounterCharacter enemy, bool wasRanged = false)
	{
		float num = 10f;
		if (enemy.Species != species)
		{
			num /= 2f;
		}
		if (EncounterManager.Instance.isPlayerControlled)
		{
			num *= 2f;
		}
		if ((Object)(object)party_member != (Object)null && (Object)(object)party_member.person != (Object)null)
		{
			if (party_member.person.humansKilledInCombat >= 10)
			{
				num *= 0.5f;
			}
			if (enemy.Species == SpeciesEnum.Human)
			{
				party_member.person.OnHumanKilledInCombat();
			}
		}
		trauma_sustained += Mathf.CeilToInt(num);
		if (wasRanged)
		{
			ModifyStat(BaseStats.StatType.Dexterity, EncounterManager.Instance.rangedKillExperience);
		}
		else
		{
			ModifyStat(BaseStats.StatType.Strength, EncounterManager.Instance.meleeKillExperience);
			ModifyStat(BaseStats.StatType.Dexterity, EncounterManager.Instance.meleeKillExperience);
		}
		if (combat_ai != null)
		{
			combat_ai.OnEnemyKilled(enemy, wasRanged);
		}
		if ((Object)(object)AchievementManager.instance != (Object)null)
		{
			AchievementManager.instance.OnEnemyKilled(enemy);
		}
	}

	private void OnEnemySubdued(EncounterCharacter enemy)
	{
		ModifyStat(BaseStats.StatType.Strength, EncounterManager.Instance.meleeKillExperience);
		ModifyStat(BaseStats.StatType.Dexterity, EncounterManager.Instance.meleeKillExperience);
		if (combat_ai != null)
		{
			combat_ai.OnEnemySubdued(enemy);
		}
		if ((Object)(object)AchievementManager.instance != (Object)null)
		{
			AchievementManager.instance.OnEnemySubdued(enemy);
		}
	}

	public void OnPanelShown()
	{
	}

	public void OnPanelClosed()
	{
	}

	public void OnCombatStarted()
	{
		if (!isPlayerControlled)
		{
			if (species == SpeciesEnum.Human || species == SpeciesEnum.Mutant)
			{
				switch (personality)
				{
				case PersonalityType.Generic:
					combat_ai = new CombatAIGeneric(this);
					break;
				case PersonalityType.Aggressive:
					combat_ai = new CombatAIAggressive(this);
					break;
				case PersonalityType.Haggler:
					combat_ai = new CombatAIHaggler(this);
					break;
				case PersonalityType.Passive:
					combat_ai = new CombatAIPassive(this);
					break;
				}
			}
			else
			{
				switch (species)
				{
				case SpeciesEnum.Bear:
					combat_ai = new CombatAIBear(this);
					break;
				case SpeciesEnum.Wolf:
					combat_ai = new CombatAIWolf(this);
					break;
				case SpeciesEnum.Dog:
					combat_ai = new CombatAIDog(this);
					break;
				}
			}
		}
		SetState(CombatState.Finished);
	}

	public void OnCombatEnded()
	{
		combat_ai = null;
	}

	public void UpdateCharacter()
	{
		if ((Object)(object)m_CharacterAnimator != (Object)null && m_CharacterAnimator.layerCount > 0 && !m_layersSetUp && (Object)(object)weapon_def != (Object)null)
		{
			for (int i = 1; i < m_CharacterAnimator.layerCount; i++)
			{
				m_CharacterAnimator.SetLayerWeight(i, 0f);
			}
			if (weapon_def.AnimationLayer > 0)
			{
				m_CharacterAnimator.SetLayerWeight(weapon_def.AnimationLayer, 1f);
			}
			m_layersSetUp = true;
		}
		UpdateState();
	}

	public void OnTurnStarted()
	{
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		if (isDazed && dazeTimer > 0)
		{
			dazeTimer--;
			if (dazeTimer <= 0)
			{
				RecoverFromDaze();
			}
		}
		if (isDefending)
		{
			defending = false;
		}
		SetState(CombatState.Idle);
		if (isBleeding)
		{
			ItemDefinition_Combat.AnimInfo weaponAnim = GetWeaponAnim(ItemDefinition_Combat.WeaponAnimEnum.Recoil);
			if (weaponAnim != null)
			{
				TriggerAnim(weaponAnim.TriggerName);
			}
			PlayBloodParticle();
			TakeDamage(EncounterManager.Instance.bleedHealthPerRound);
			FloatingTextPool.ShowFloatingText(Localization.Get("UI.combat.bleeding"), uiPosition);
			if (Health <= 0 && (Object)(object)last_damage_from != (Object)null)
			{
				last_damage_from.OnEnemyKilled(this);
			}
		}
		if (combat_ai != null)
		{
			combat_ai.OnTurnStarted();
		}
	}

	public void OnTurnEnded()
	{
		UpdateCharacter();
		if (combat_ai != null)
		{
			combat_ai.OnTurnEnded();
		}
	}

	private void SetState(CombatState new_state)
	{
		switch (current_state)
		{
		case CombatState.Idle:
			ExitState_Idle();
			break;
		case CombatState.Moving:
			ExitState_Moving();
			break;
		case CombatState.SkipTurn:
			ExitState_SkipTurn();
			break;
		case CombatState.DrawWeapon:
			ExitState_DrawWeapon();
			break;
		case CombatState.Melee:
			ExitState_Melee();
			break;
		case CombatState.MeleeReaction:
			ExitState_MeleeReaction();
			break;
		case CombatState.SkipTurnDueToCowardice:
			ExitState_SkipTurnDueToCowardice();
			break;
		case CombatState.Throwing:
			ExitState_Throwing();
			break;
		case CombatState.Shooting:
			ExitState_Shooting();
			break;
		case CombatState.Item:
			ExitState_Item();
			break;
		case CombatState.PickupWeapon:
			ExitState_PickupWeapon();
			break;
		case CombatState.DefendStart:
			ExitState_DefendStart();
			break;
		case CombatState.Cowering:
			ExitState_Cowering();
			break;
		case CombatState.Dying:
			ExitState_Dying();
			break;
		case CombatState.Finished:
			ExitState_Idle();
			break;
		}
		current_state = new_state;
		switch (current_state)
		{
		case CombatState.Idle:
			EnterState_Idle();
			break;
		case CombatState.Moving:
			EnterState_Moving();
			break;
		case CombatState.SkipTurn:
			EnterState_SkipTurn();
			break;
		case CombatState.DrawWeapon:
			EnterState_DrawWeapon();
			break;
		case CombatState.Melee:
			EnterState_Melee();
			break;
		case CombatState.MeleeReaction:
			EnterState_MeleeReaction();
			break;
		case CombatState.SkipTurnDueToCowardice:
			EnterState_SkipTurnDueToCowardice();
			break;
		case CombatState.Throwing:
			EnterState_Throwing();
			break;
		case CombatState.Shooting:
			EnterState_Shooting();
			break;
		case CombatState.Item:
			EnterState_Item();
			break;
		case CombatState.PickupWeapon:
			EnterState_PickupWeapon();
			break;
		case CombatState.DefendStart:
			EnterState_DefendStart();
			break;
		case CombatState.Cowering:
			EnterState_Cowering();
			break;
		case CombatState.Dying:
			EnterState_Dying();
			break;
		case CombatState.Finished:
			EnterState_Idle();
			break;
		}
	}

	private void UpdateState()
	{
		switch (current_state)
		{
		case CombatState.Idle:
			UpdateState_Idle();
			break;
		case CombatState.Moving:
			UpdateState_Moving();
			break;
		case CombatState.SkipTurn:
			UpdateState_SkipTurn();
			break;
		case CombatState.DrawWeapon:
			UpdateState_DrawWeapon();
			break;
		case CombatState.Melee:
			UpdateState_Melee();
			break;
		case CombatState.MeleeReaction:
			UpdateState_MeleeReaction();
			break;
		case CombatState.SkipTurnDueToCowardice:
			UpdateState_SkipTurnDueToCowardice();
			break;
		case CombatState.Throwing:
			UpdateState_Throwing();
			break;
		case CombatState.Shooting:
			UpdateState_Shooting();
			break;
		case CombatState.Item:
			UpdateState_Item();
			break;
		case CombatState.PickupWeapon:
			UpdateState_PickupWeapon();
			break;
		case CombatState.DefendStart:
			UpdateState_DefendStart();
			break;
		case CombatState.Cowering:
			UpdateState_Cowering();
			break;
		case CombatState.Dying:
			UpdateState_Dying();
			break;
		case CombatState.Finished:
			UpdateState_Idle();
			break;
		}
	}

	private void EnterState_Idle()
	{
		TriggerAnim_Idle();
	}

	private void UpdateState_Idle()
	{
	}

	private void ExitState_Idle()
	{
	}

	public void Idle()
	{
		SetState(CombatState.Idle);
	}

	private void EnterState_SkipTurn()
	{
		m_turnEndTime = PausableTime.time + m_turnEndDelay;
	}

	private void UpdateState_SkipTurn()
	{
		if (PausableTime.time >= m_turnEndTime)
		{
			SetState(CombatState.Finished);
		}
	}

	private void ExitState_SkipTurn()
	{
	}

	public void SkipTurn()
	{
		SetState(CombatState.SkipTurn);
	}

	private void EnterState_Moving()
	{
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		if ((target_move_position.x - start_move_position.x < 0f && isPlayerCharacter && IsFacingForwards()) || (target_move_position.x - start_move_position.x > 0f && isNPC && IsFacingForwards()))
		{
			move_finished_time = PausableTime.time + Vector3.Distance(target_move_position, start_move_position) / GetMoveSpeed(MoveType.Backwards);
			TriggerAnim("WalkBackwards");
		}
		else if (prefer_run || species == SpeciesEnum.Wolf || species == SpeciesEnum.Bear)
		{
			move_finished_time = PausableTime.time + Vector3.Distance(target_move_position, start_move_position) / GetMoveSpeed(MoveType.Run);
			TriggerAnim("Run");
		}
		else
		{
			move_finished_time = PausableTime.time + Vector3.Distance(target_move_position, start_move_position) / GetMoveSpeed(MoveType.Walk);
			TriggerAnim("Walk");
		}
		move_start_time = PausableTime.time;
	}

	private void UpdateState_Moving()
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		move_percentage = Mathf.Clamp01((PausableTime.time - move_start_time) / (move_finished_time - move_start_time));
		if (move_percentage >= 1f)
		{
			((Component)this).transform.position = target_move_position;
			SetState(move_finished_state);
		}
		else
		{
			((Component)this).transform.position = Vector3.Lerp(start_move_position, target_move_position, move_percentage);
		}
	}

	private void ExitState_Moving()
	{
	}

	private void MoveToPoint(Vector3 point, bool run, CombatState next_state = CombatState.Idle)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		if (current_state != CombatState.Moving)
		{
			start_move_position = ((Component)this).transform.position;
			target_move_position = point;
			prefer_run = run;
			move_finished_state = next_state;
			SetState(CombatState.Moving);
		}
	}

	private void EnterState_DrawWeapon()
	{
		TriggerAnim("Draw");
		m_drawWaitTime = PausableTime.time + m_drawDelay;
	}

	private void UpdateState_DrawWeapon()
	{
		if (PausableTime.time >= m_drawWaitTime)
		{
			SetState(CombatState.Finished);
		}
	}

	private void ExitState_DrawWeapon()
	{
	}

	public void DrawWeapon()
	{
		SetState(CombatState.DrawWeapon);
	}

	private void EnterState_SkipTurnDueToCowardice()
	{
		TriggerAnim("Cower");
		m_cowardiceWaitTime = PausableTime.time + m_cowardiceDelay;
	}

	private void UpdateState_SkipTurnDueToCowardice()
	{
		if (PausableTime.time >= m_cowardiceWaitTime)
		{
			SetState(CombatState.Finished);
		}
	}

	private void ExitState_SkipTurnDueToCowardice()
	{
	}

	private void EnterState_Melee()
	{
		attack_count = 0;
		m_guaranteedHits = 0;
		if ((Object)(object)party_member != (Object)null && (Object)(object)party_member.person != (Object)null && party_member.person.traits.HasStrength(Traits.Strength.Courageous))
		{
			m_guaranteedHits = 2;
		}
	}

	private void UpdateState_Melee()
	{
		if (PausableTime.time >= melee_attack_time)
		{
			if (target_character.isDead || melee_attack_result != EncounterLogic.AttackResult.Hit || (attack_count > 0 && !multiple_attacks) || attack_count >= max_attack_count)
			{
				if (target_character.isDead)
				{
					OnEnemyKilled(target_character);
				}
				if (target_character.isSubdued)
				{
					OnEnemySubdued(target_character);
				}
				if (onAttackOver != null)
				{
					onAttackOver();
				}
				return;
			}
			current_weapon_anim = GetWeaponAnim(ItemDefinition_Combat.WeaponAnimEnum.Melee);
			if (current_weapon_anim == null)
			{
				return;
			}
			attack_count++;
			TriggerAnim(current_weapon_anim.TriggerName);
			PlaySFX(current_weapon_anim.GetAttackSound());
			if (special_attack)
			{
				melee_attack_result = EncounterLogic.AttackRoll_Special(this, target_character, weapon);
			}
			else
			{
				melee_attack_result = EncounterLogic.AttackRoll_Melee(this, target_character, weapon);
			}
			if (melee_attack_result != EncounterLogic.AttackResult.Hit && m_guaranteedHits > 0)
			{
				melee_attack_result = EncounterLogic.AttackResult.Hit;
				m_guaranteedHits--;
			}
			if (melee_attack_result == EncounterLogic.AttackResult.Counter && !counterable_attack)
			{
				melee_attack_result = EncounterLogic.AttackResult.Block;
			}
			if (melee_attack_result == EncounterLogic.AttackResult.Hit)
			{
				target_character.Recoil(current_weapon_anim.ImpactTime);
			}
			else if (melee_attack_result == EncounterLogic.AttackResult.Counter)
			{
				target_character.CounterAttack(this);
			}
			else if (melee_attack_result == EncounterLogic.AttackResult.Block)
			{
				target_character.Block(current_weapon_anim.ImpactTime);
			}
			else if (melee_attack_result == EncounterLogic.AttackResult.Miss)
			{
				target_character.Dodge(current_weapon_anim.ImpactTime);
			}
			melee_attack_time = PausableTime.time + current_weapon_anim.Length;
			melee_connect_time = PausableTime.time + current_weapon_anim.ImpactTime;
		}
		if (!(PausableTime.time >= melee_connect_time))
		{
			return;
		}
		if (melee_attack_result == EncounterLogic.AttackResult.Hit)
		{
			if (onAttackHit != null)
			{
				onAttackHit();
			}
			PlaySFX(current_weapon_anim.GetImpactSound());
			if ((target_character.isDead || target_character.isSubdued) && (Object)(object)partyMember != (Object)null && (Object)(object)partyMember.person != (Object)null && partyMember.person.traits.HasWeakness(Traits.Weakness.Cowardice))
			{
				GainTrait(Traits.Weakness.Cowardice);
			}
		}
		else if (onAttackMiss != null)
		{
			onAttackMiss(melee_attack_result);
		}
		melee_connect_time = melee_attack_time + current_weapon_anim.ImpactTime;
	}

	private void ExitState_Melee()
	{
		melee_attack_result = EncounterLogic.AttackResult.Hit;
	}

	public void MeleeAttack(EncounterCharacter target)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		target_character = target;
		if (target_character.meleeAttackPoint == Vector3.zero)
		{
		}
		if ((Object)(object)party_member != (Object)null && (Object)(object)party_member.person != (Object)null && party_member.person.traits.HasWeakness(Traits.Weakness.Cowardice) && Random.value < 0.25f)
		{
			SetState(CombatState.SkipTurnDueToCowardice);
			return;
		}
		multiple_attacks = true;
		counterable_attack = true;
		special_attack = false;
		onAttackHit = delegate
		{
			if ((Object)(object)weapon_def != (Object)null)
			{
				int dmg = EncounterLogic.DamageRoll(this, target_character, weapon);
				target_character.TakeDamage(dmg, weapon_def.DamageType, weapon, this);
			}
			target_character.PlayBloodParticle();
		};
		onAttackMiss = delegate(EncounterLogic.AttackResult result)
		{
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat." + result), target_character.uiPosition);
		};
		onAttackOver = delegate
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			MoveToPoint(home_position, run: true, CombatState.Finished);
		};
		MoveToPoint(target_character.meleeAttackPoint, run: true, CombatState.Melee);
	}

	public void CounterAttack(EncounterCharacter target)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		target_character = target;
		if (target_character.meleeAttackPoint == Vector3.zero)
		{
		}
		FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Counter"), uiPosition);
		multiple_attacks = false;
		counterable_attack = false;
		special_attack = false;
		onAttackHit = delegate
		{
			if ((Object)(object)weapon_def != (Object)null)
			{
				int num = EncounterLogic.DamageRoll(this, target_character, weapon);
				num = Mathf.CeilToInt((float)num / 2f);
				target_character.TakeDamage(num, weapon_def.DamageType, weapon, this);
			}
			target_character.PlayBloodParticle();
		};
		onAttackMiss = delegate(EncounterLogic.AttackResult result)
		{
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat." + result), target_character.uiPosition);
		};
		onAttackOver = delegate
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			target_character.MoveToPoint(target_character.home_position, run: true, CombatState.Finished);
			SetState(CombatState.Finished);
		};
		SetState(CombatState.Melee);
	}

	public void Subdue(EncounterCharacter target)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		target_character = target;
		if (target_character.meleeAttackPoint == Vector3.zero)
		{
		}
		if ((Object)(object)party_member != (Object)null && (Object)(object)party_member.person != (Object)null && party_member.person.traits.HasWeakness(Traits.Weakness.Cowardice) && Random.value < 0.25f)
		{
			SetState(CombatState.SkipTurnDueToCowardice);
			return;
		}
		multiple_attacks = false;
		counterable_attack = false;
		special_attack = true;
		onAttackHit = delegate
		{
			switch (EncounterLogic.SubdueRoll(this, target_character, weapon))
			{
			case EncounterLogic.SubdueResult.Subdue:
				target_character.GetSubdued();
				if ((Object)(object)partyMember != (Object)null && (Object)(object)partyMember.person != (Object)null && partyMember.person.traits.HasWeakness(Traits.Weakness.Cowardice))
				{
					GainTrait(Traits.Weakness.Cowardice);
				}
				ModifyStat(BaseStats.StatType.Strength, EncounterManager.Instance.meleeKillExperience);
				ModifyStat(BaseStats.StatType.Dexterity, EncounterManager.Instance.meleeKillExperience);
				break;
			case EncounterLogic.SubdueResult.Daze:
				target_character.GetDazed();
				break;
			default:
				target_character.ResistSubdue();
				break;
			}
			target_character.PlayBloodParticle();
		};
		onAttackMiss = delegate(EncounterLogic.AttackResult result)
		{
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat." + result), target_character.uiPosition);
		};
		onAttackOver = delegate
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			MoveToPoint(home_position, run: true, CombatState.Finished);
		};
		MoveToPoint(target_character.meleeAttackPoint, run: true, CombatState.Melee);
	}

	public void Steal(EncounterCharacter target)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		target_character = target;
		if (target_character.meleeAttackPoint == Vector3.zero)
		{
		}
		ItemManager.ItemType oldWeapon = weapon;
		SetWeapon(defaultWeapon);
		multiple_attacks = false;
		counterable_attack = false;
		special_attack = true;
		onAttackHit = delegate
		{
			//IL_010b: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0133: Unknown result type (might be due to invalid IL or missing references)
			//IL_0166: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
			if ((Object)(object)weapon_def != (Object)null)
			{
				int num = EncounterLogic.DamageRoll(this, target_character, weapon);
				num = Mathf.CeilToInt((float)num / 2f);
				target_character.TakeDamage(num, weapon_def.DamageType, weapon, this);
			}
			target_character.PlayBloodParticle();
			if (target_character.Species != SpeciesEnum.Human && target_character.Species != SpeciesEnum.Mutant)
			{
				FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Steal.Miss"), target_character.uiPosition);
			}
			else
			{
				ItemManager.ItemType randomBackpackItem = target_character.GetRandomBackpackItem();
				switch (randomBackpackItem)
				{
				case ItemManager.ItemType.AdvancedGasMask:
				case ItemManager.ItemType.MilitaryRucksack:
					FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Steal.Miss"), target_character.uiPosition);
					break;
				case ItemManager.ItemType.Undefined:
					FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Steal.NoItems"), target_character.uiPosition);
					break;
				default:
					if (!AddToBackpack(randomBackpackItem, 1))
					{
						FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Steal.NoRoom"), target_character.uiPosition);
					}
					else
					{
						target_character.RemoveBackpackItems(randomBackpackItem, 1);
						ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(randomBackpackItem);
						if ((Object)(object)itemDefinition != (Object)null)
						{
							FloatingTextPool.ShowFloatingText(Localization.Get(itemDefinition.NameLocalizationKey), target_character.uiPosition);
						}
					}
					break;
				}
			}
		};
		onAttackMiss = delegate
		{
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Steal.Miss"), target_character.uiPosition);
		};
		onAttackOver = delegate
		{
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			SetWeapon(oldWeapon);
			MoveToPoint(home_position, run: true, CombatState.Finished);
		};
		MoveToPoint(target_character.meleeAttackPoint, run: true, CombatState.Melee);
	}

	public void Disarm(EncounterCharacter target)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		target_character = target;
		if (target_character.meleeAttackPoint == Vector3.zero)
		{
		}
		ItemManager.ItemType oldWeapon = weapon;
		SetWeapon(defaultWeapon);
		multiple_attacks = false;
		counterable_attack = false;
		special_attack = true;
		onAttackHit = delegate
		{
			//IL_010a: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
			if ((Object)(object)weapon_def != (Object)null)
			{
				int num = EncounterLogic.DamageRoll(this, target_character, weapon);
				num = Mathf.CeilToInt((float)num / 2f);
				target_character.TakeDamage(num, weapon_def.DamageType, weapon, this);
			}
			target_character.PlayBloodParticle();
			if (target_character.Species != SpeciesEnum.Human && target_character.Species != SpeciesEnum.Mutant)
			{
				FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Disarm.Miss"), target_character.uiPosition);
			}
			else if (target_character.weapon == defaultWeapon)
			{
				FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Disarm.Miss"), target_character.uiPosition);
			}
			else
			{
				target_character.DropWeapon();
			}
		};
		onAttackMiss = delegate
		{
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Disarm.Miss"), target_character.uiPosition);
		};
		onAttackOver = delegate
		{
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			SetWeapon(oldWeapon);
			MoveToPoint(home_position, run: true, CombatState.Finished);
		};
		MoveToPoint(target_character.meleeAttackPoint, run: true, CombatState.Melee);
	}

	private void EnterState_MeleeReaction()
	{
		has_reacted = false;
		has_impacted = false;
	}

	private void UpdateState_MeleeReaction()
	{
		if (PausableTime.time >= next_state_time)
		{
			SetState(CombatState.Finished);
			if (melee_reaction_callback != null)
			{
				melee_reaction_callback();
			}
		}
		else if (!has_impacted)
		{
			if (PausableTime.time >= melee_reaction_impact_time)
			{
				PlaySFX(current_weapon_anim.GetImpactSound());
				has_impacted = true;
			}
			if (!has_reacted && PausableTime.time >= melee_reaction_time)
			{
				TriggerAnim(current_weapon_anim.TriggerName);
				has_reacted = true;
			}
		}
	}

	private void ExitState_MeleeReaction()
	{
	}

	private void PlayMeleeReaction(ItemDefinition_Combat.WeaponAnimEnum anim, float impact_time, Action reaction_callback = null)
	{
		current_weapon_anim = GetWeaponAnim(anim);
		if (current_weapon_anim != null)
		{
			melee_reaction_time = PausableTime.time + Mathf.Max(impact_time - current_weapon_anim.ImpactTime, 0f);
			melee_reaction_impact_time = melee_reaction_time + current_weapon_anim.ImpactTime;
			next_state_time = melee_reaction_time + current_weapon_anim.Length;
			melee_reaction_callback = reaction_callback;
			SetState(CombatState.MeleeReaction);
		}
	}

	public void Recoil(float impact_time)
	{
		PlayMeleeReaction(ItemDefinition_Combat.WeaponAnimEnum.Recoil, impact_time);
	}

	public void Dodge(float impact_time)
	{
		PlayMeleeReaction(ItemDefinition_Combat.WeaponAnimEnum.Dodge, impact_time);
	}

	public void Block(float impact_time)
	{
		PlayMeleeReaction(ItemDefinition_Combat.WeaponAnimEnum.Block, impact_time);
	}

	private void EnterState_DefendStart()
	{
		m_turnEndTime = PausableTime.time;
	}

	private void UpdateState_DefendStart()
	{
		if (!(PausableTime.time < m_turnEndTime))
		{
			defending = true;
			SetState(CombatState.Finished);
		}
	}

	private void ExitState_DefendStart()
	{
	}

	public void Defend()
	{
		SetState(CombatState.DefendStart);
	}

	public void GetDazed()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		dazed = true;
		dazeTimer = 3;
		if (isIdle || isTurnFinished)
		{
			TriggerAnim_Idle();
		}
		FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Dazed"), uiPosition);
	}

	public void RecoverFromDaze()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		dazed = false;
		dazeTimer = 0;
		if (isIdle || isTurnFinished)
		{
			TriggerAnim_Idle();
		}
		FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.RecoverDazed"), uiPosition);
	}

	public void GetSubdued()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		subdued = true;
		TriggerAnim("Knockout");
		FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Subdued"), uiPosition);
	}

	public void ResistSubdue()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Resisted"), uiPosition);
	}

	private void EnterState_PickupWeapon()
	{
		TriggerAnim("Pickup");
		m_pickupItemWaitTime = PausableTime.time + m_pickupItemDelay;
	}

	private void UpdateState_PickupWeapon()
	{
		if (dropped_weapon != ItemManager.ItemType.Undefined && PausableTime.time >= m_pickupItemWaitTime)
		{
			if ((Object)(object)dropped_weapon_object != (Object)null)
			{
				dropped_weapon_object.PickupWeapon();
			}
			SetWeapon(dropped_weapon);
			dropped_weapon = ItemManager.ItemType.Undefined;
			dropped_weapon_onscreen = false;
			TriggerAnim("Idle");
			m_pickupItemWaitTime = PausableTime.time + m_pickupItemEndDelay;
		}
		if (dropped_weapon == ItemManager.ItemType.Undefined && PausableTime.time >= m_pickupItemWaitTime)
		{
			DrawWeapon();
		}
	}

	private void ExitState_PickupWeapon()
	{
	}

	public void PickupWeapon()
	{
		if (!hasWeapon && dropped_weapon != ItemManager.ItemType.Undefined)
		{
			SetState(CombatState.PickupWeapon);
		}
	}

	public void DropWeapon()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		if (hasWeapon)
		{
			if ((Object)(object)dropped_weapon_object != (Object)null)
			{
				dropped_weapon_object.ShowWeapon(weapon);
			}
			dropped_weapon = weapon;
			dropped_weapon_onscreen = true;
			FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Disarmed"), uiPosition);
			SetWeapon(defaultWeapon);
			DrawWeapon();
		}
	}

	private void EnterState_Throwing()
	{
		if (combat_item == ItemManager.ItemType.Undefined || (Object)(object)combat_item_def == (Object)null)
		{
			SetState(CombatState.Finished);
			return;
		}
		thrown_item = null;
		item_spawned = false;
		item_landed = false;
		m_itemSpawnTime = PausableTime.time;
		m_turnEndTime = 0f;
		RemoveBackpackItems(combat_item, 1);
		ItemDefinition_Combat.AnimInfo itemAnim = GetItemAnim(combat_item, ItemDefinition_Combat.WeaponAnimEnum.Throw);
		if (itemAnim != null)
		{
			m_itemSpawnTime = PausableTime.time + Mathf.Min(itemAnim.Length, itemAnim.ImpactTime);
			TriggerAnim(itemAnim.TriggerName);
			PlaySFX(itemAnim.GetAttackSound());
		}
	}

	private void UpdateState_Throwing()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		if (!item_spawned && PausableTime.time >= m_itemSpawnTime)
		{
			if ((Object)(object)thrown_combat_item_prefab != (Object)null)
			{
				GameObject val = Object.Instantiate<GameObject>(thrown_combat_item_prefab, thrown_item_spawn_point.position, thrown_item_spawn_point.rotation);
				if ((Object)(object)val != (Object)null)
				{
					thrown_item = val.GetComponent<ThrownCombatItem>();
					if ((Object)(object)thrown_item != (Object)null)
					{
						bool dud = Random.value > combat_item_def.ExplodeChance;
						((Component)thrown_item).transform.parent = ((Component)this).transform.parent;
						((Component)thrown_item).transform.localScale = Vector3.one;
						if (!thrown_item.Initialise(((Component)target_character).transform.position, combat_item, dud))
						{
							Object.Destroy((Object)(object)thrown_item);
							thrown_item = null;
						}
					}
				}
			}
			if ((Object)(object)thrown_item == (Object)null)
			{
				SetState(CombatState.Finished);
				return;
			}
			item_spawned = true;
		}
		if (!item_landed && (Object)(object)thrown_item != (Object)null && thrown_item.HasLanded())
		{
			if (thrown_item.isDud)
			{
				FloatingTextPool.ShowFloatingText(Localization.Get("UI.combat.grenade.dud"), ((Component)thrown_item).transform.position);
			}
			else
			{
				List<EncounterCharacter> list = ((!target_character.isPlayerCharacter) ? EncounterManager.Instance.GetNPCs() : EncounterManager.Instance.GetPlayerCharacters());
				for (int i = 0; i < list.Count; i++)
				{
					list[i].TakeDamage(Random.Range(combat_item_def.BaseDamageMin, combat_item_def.BaseDamageMax + 1), combat_item_def.DamageType, combat_item, this);
					list[i].Recoil(0f);
					if (list[i].isDead)
					{
						OnEnemyKilled(list[i], wasRanged: true);
					}
				}
			}
			item_landed = true;
			m_turnEndTime = PausableTime.time + m_turnEndDelay;
		}
		else if (item_spawned && item_landed && PausableTime.time >= m_turnEndTime)
		{
			SetState(CombatState.Finished);
		}
	}

	private void ExitState_Throwing()
	{
	}

	private void EnterState_Item()
	{
		RemoveBackpackItems(combat_item, 1);
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(combat_item);
		if ((Object)(object)itemDefinition != (Object)null)
		{
			PlaySFX(itemDefinition.UseSound);
		}
		TriggerAnim(combat_item_anim);
		m_useItemWaitTime = PausableTime.time + m_useItemDelay;
	}

	private void UpdateState_Item()
	{
		if (!(PausableTime.time < m_useItemWaitTime))
		{
			if (onItemUsed != null)
			{
				onItemUsed();
			}
			SetState(CombatState.Finished);
		}
	}

	private void ExitState_Item()
	{
	}

	public void UseBackpackItem(ItemManager.ItemType item, EncounterCharacter target)
	{
		if (!HasBackpackItem(item))
		{
			SetState(CombatState.Finished);
			return;
		}
		target_character = target;
		combat_item = item;
		combat_item_def = ItemManager.Instance.GetCombatDefinition(item);
		if ((Object)(object)combat_item_def != (Object)null && combat_item_def.WeaponType == ItemDefinition_Combat.WeaponTypeEnum.Thrown)
		{
			SetState(CombatState.Throwing);
		}
		else if (item == ItemManager.ItemType.FirstAid || item == ItemManager.ItemType.Bandages)
		{
			combat_item_anim = "Bandage";
			onItemUsed = delegate
			{
				if (item == ItemManager.ItemType.FirstAid)
				{
					Health += 50;
				}
				bleeding = false;
			};
			SetState(CombatState.Item);
		}
		else
		{
			if (item != ItemManager.ItemType.Adrenalin)
			{
				return;
			}
			combat_item_anim = "Bandage";
			onItemUsed = delegate
			{
				if (item == ItemManager.ItemType.Adrenalin)
				{
					modStr = stats.Strength.LevelModifier;
					modDex = stats.Dexterity.LevelModifier;
					stats.Strength.SetLevelModifier(3 + modStr);
					stats.Dexterity.SetLevelModifier(3 + modDex);
				}
			};
			SetState(CombatState.Item);
		}
	}

	private void EnterState_Shooting()
	{
		if ((Object)(object)weapon_def == (Object)null || weapon_def.WeaponType != ItemDefinition_Combat.WeaponTypeEnum.Ranged)
		{
			SetState(CombatState.Finished);
			return;
		}
		current_weapon_anim = GetWeaponAnim(ItemDefinition_Combat.WeaponAnimEnum.Fire);
		if (current_weapon_anim == null)
		{
			SetState(CombatState.Finished);
			return;
		}
		attack_count = 0;
		shooting_time = PausableTime.time;
	}

	private void UpdateState_Shooting()
	{
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		if (PausableTime.time < shooting_time)
		{
			return;
		}
		shooting_targets.RemoveAll((EncounterCharacter x) => x.isDead || x.isSubdued || x.hasEscaped);
		if (ammo_used >= weapon_def.ClipSize || ((Object)(object)BreachMan.instance != (Object)null && !BreachMan.instance.inProgress && !HasBackpackItem(weapon_def.AmmoType)) || ((Object)(object)BreachMan.instance != (Object)null && BreachMan.instance.inProgress && !hasAmmoEquipped) || (attack_count > 0 && !multiple_attacks) || shooting_targets.Count <= 0)
		{
			SetState(CombatState.Finished);
			return;
		}
		target_character = shooting_targets[Random.Range(0, shooting_targets.Count)];
		TriggerAnim(current_weapon_anim.TriggerName);
		ammo_used++;
		attack_count++;
		PlaySFX(current_weapon_anim.GetAttackSound());
		if ((Object)(object)BreachMan.instance != (Object)null && !BreachMan.instance.inProgress)
		{
			RemoveBackpackItems(weapon_def.AmmoType, 1);
		}
		else if ((Object)(object)BreachMan.instance != (Object)null && BreachMan.instance.inProgress)
		{
			InventoryManager.Instance.RemoveItemsOfType(weapon_def.AmmoType, 1);
		}
		if (EncounterLogic.AttackRoll_Ranged(this, target_character, weapon, multiple_attacks) == EncounterLogic.AttackResult.Hit)
		{
			PlaySFX(current_weapon_anim.GetImpactSound());
			int dmg = Random.Range(weapon_def.RangedDamageMin, weapon_def.RangedDamageMax + 1);
			target_character.TakeDamage(dmg, weapon_def.DamageTypeRanged, weapon, this);
			if (target_character.isDead)
			{
				OnEnemyKilled(target_character, wasRanged: true);
			}
		}
		else
		{
			FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Miss"), target_character.uiPosition);
		}
		shooting_time = PausableTime.time + weapon_def.RefireTime;
	}

	private void ExitState_Shooting()
	{
	}

	public void ShootSingle(EncounterCharacter target)
	{
		shooting_targets = new List<EncounterCharacter> { target };
		target_character = null;
		multiple_attacks = false;
		SetState(CombatState.Shooting);
	}

	public void ShootMultiple(List<EncounterCharacter> targets)
	{
		shooting_targets = new List<EncounterCharacter>(targets);
		target_character = null;
		multiple_attacks = true;
		SetState(CombatState.Shooting);
	}

	private void EnterState_Cowering()
	{
		TriggerAnim("Cower");
	}

	private void UpdateState_Cowering()
	{
		if (cowering_targets != null)
		{
			for (int i = 0; i < cowering_targets.Count; i++)
			{
				if (!cowering_targets[i].isTurnFinished && !cowering_targets[i].isCowering)
				{
					return;
				}
			}
		}
		SetState(CombatState.Finished);
	}

	private void ExitState_Cowering()
	{
		cowering_targets = null;
	}

	public void Cower(List<EncounterCharacter> shooters)
	{
		cowering_targets = new List<EncounterCharacter>(shooters);
		for (int i = 0; i < cowering_targets.Count; i++)
		{
			if (!cowering_targets[i].isTurnFinished && !cowering_targets[i].isCowering)
			{
				SetState(CombatState.Cowering);
				return;
			}
		}
		SetState(CombatState.Finished);
	}

	private void EnterState_Dying()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (lastDamageType == ItemDefinition_Combat.DamageTypeEnum.Undefined)
		{
			TriggerAnim("Death");
		}
		else
		{
			TriggerAnim("Knockout");
		}
		FloatingTextPool.ShowFloatingText(Localization.Get("Text.Combat.Dead"), uiPosition);
		AudioManager.Instance.PlayUI(deathSound);
		m_deathWaitTime = PausableTime.time + m_deathDelay;
	}

	private void UpdateState_Dying()
	{
		if (!(PausableTime.time < m_deathWaitTime))
		{
			SetState(CombatState.Finished);
		}
	}

	private void ExitState_Dying()
	{
	}

	public void StartEscape()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		escaping = true;
		wantsToEscape = false;
		SetFacingForwards(forwards: false);
		MoveToPoint(escape_point.position, run: true, CombatState.Finished);
	}

	public void EscapeFailed()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		escaping = false;
		SetFacingForwards(forwards: true);
		((Component)this).transform.position = home_position;
		if (hasDroppedWeapon)
		{
			dropped_weapon_onscreen = false;
			if ((Object)(object)dropped_weapon_object != (Object)null)
			{
				dropped_weapon_object.ShowWeapon(ItemManager.ItemType.Undefined);
			}
		}
		SetState(CombatState.Finished);
	}

	public void EscapeSuccess()
	{
		escaping = false;
		escaped = true;
		MoveOffscreen();
		SetState(CombatState.Finished);
	}

	public void Chase()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		chasing = true;
		MoveToPoint(chase_point.position, run: true, CombatState.Finished);
	}

	public void ChaseFailed()
	{
		chasing = false;
		MoveOffscreen();
		SetState(CombatState.Finished);
	}

	public void ChaseSuccess()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		chasing = false;
		SetState(CombatState.Finished);
		MoveOffscreen();
		MoveToPoint(home_position, run: true, CombatState.Finished);
		if (hasDroppedWeapon)
		{
			dropped_weapon_onscreen = false;
			if ((Object)(object)dropped_weapon_object != (Object)null)
			{
				dropped_weapon_object.ShowWeapon(ItemManager.ItemType.Undefined);
			}
		}
	}

	public void MoveOffscreen()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.position = escape_point.position;
	}

	public void WalkInFromOffscreen()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		MoveToPoint(home_position, run: false, CombatState.Finished);
	}

	public bool HasEquippedItem(ItemManager.ItemType item)
	{
		for (int i = 0; i < equipped_items.Count; i++)
		{
			if (equipped_items[i].m_type == item && equipped_items[i].m_count > 0)
			{
				return true;
			}
		}
		return false;
	}

	public void AddEquippedItem(ItemManager.ItemType item)
	{
		if (item == ItemManager.ItemType.Undefined)
		{
			return;
		}
		int num = -1;
		for (int i = 0; i < equipped_items.Count; i++)
		{
			if (equipped_items[i].m_type == item)
			{
				equipped_items[i].m_count++;
				return;
			}
			if (equipped_items[i].m_type == ItemManager.ItemType.Undefined && num < 0)
			{
				num = i;
			}
		}
		if (num >= 0)
		{
			equipped_items[num].m_type = item;
			equipped_items[num].m_count = 1;
		}
	}

	public void RemoveEquippedItem(ItemManager.ItemType item)
	{
		if (item == ItemManager.ItemType.Undefined)
		{
			return;
		}
		for (int i = 0; i < equipped_items.Count; i++)
		{
			if (equipped_items[i].m_type == item)
			{
				equipped_items[i].m_count--;
				if (equipped_items[i].m_count <= 0)
				{
					equipped_items.RemoveAt(i);
				}
			}
		}
	}

	public List<ItemStack> GetEquippedItems()
	{
		if ((Object)(object)partyMember != (Object)null)
		{
			return partyMember.GetEquippedItems();
		}
		List<ItemStack> list = new List<ItemStack>();
		if (hasWeapon)
		{
			list.Add(new ItemStack(weapon, 1));
		}
		else if (dropped_weapon != ItemManager.ItemType.Undefined)
		{
			list.Add(new ItemStack(dropped_weapon, 1));
		}
		for (int i = 0; i < equipped_items.Count; i++)
		{
			if (equipped_items[i].m_type != ItemManager.ItemType.Undefined && equipped_items[i].m_count > 0)
			{
				list.Add(equipped_items[i]);
			}
		}
		return list;
	}

	public void EmptyBackpack()
	{
		backpack_items.Clear();
	}

	public bool AddToBackpack(ItemManager.ItemType item, int quantity)
	{
		if ((Object)(object)partyMember != (Object)null)
		{
			return ExplorationManager.Instance.AddToPartyItems(partyMember.partyId, item, quantity);
		}
		for (int i = 0; i < backpack_items.Count; i++)
		{
			if (backpack_items[i].m_type == item)
			{
				backpack_items[i].m_count += Mathf.Max(quantity, 0);
				return true;
			}
		}
		backpack_items.Add(new ItemStack(item, Mathf.Max(quantity, 0)));
		return true;
	}

	public bool HasBackpackItem(ItemManager.ItemType item)
	{
		if ((Object)(object)partyMember != (Object)null)
		{
			return ExplorationManager.Instance.PartyHasItem(partyMember.partyId, item);
		}
		for (int i = 0; i < backpack_items.Count; i++)
		{
			if (backpack_items[i].m_type == item && backpack_items[i].m_count > 0)
			{
				return true;
			}
		}
		return false;
	}

	public void RemoveBackpackItems(ItemManager.ItemType item, int quantity)
	{
		quantity = Mathf.Max(quantity, 0);
		if (item == ItemManager.ItemType.Undefined)
		{
			return;
		}
		if ((Object)(object)partyMember != (Object)null)
		{
			ExplorationManager.Instance.RemoveFromPartyItems(partyMember.partyId, item, quantity);
			return;
		}
		for (int i = 0; i < backpack_items.Count; i++)
		{
			if (backpack_items[i].m_type == item)
			{
				backpack_items[i].m_count -= quantity;
				if (backpack_items[i].m_count <= 0)
				{
					backpack_items.RemoveAt(i);
				}
			}
		}
	}

	public List<ItemStack> GetBackpackItems()
	{
		if ((Object)(object)partyMember != (Object)null)
		{
			return ExplorationManager.Instance.GetPartyItems(partyMember.partyId);
		}
		return new List<ItemStack>(backpack_items);
	}

	public List<ItemStack> GetUsableItems()
	{
		List<ItemStack> list = new List<ItemStack>();
		List<ItemStack> backpackItems = GetBackpackItems();
		for (int i = 0; i < backpackItems.Count; i++)
		{
			ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(backpackItems[i].m_type);
			if ((Object)(object)itemDefinition != (Object)null && itemDefinition.CanUseInCombat)
			{
				list.Add(backpackItems[i]);
			}
		}
		return list;
	}

	public ItemManager.ItemType GetRandomBackpackItem()
	{
		List<ItemStack> backpackItems = GetBackpackItems();
		if (backpackItems != null && backpackItems.Count > 0)
		{
			return backpackItems[Random.Range(0, backpackItems.Count)].m_type;
		}
		return ItemManager.ItemType.Undefined;
	}

	public List<ItemStack> GetAllItems()
	{
		List<ItemStack> backpackItems = GetBackpackItems();
		backpackItems.AddRange(GetEquippedItems());
		return backpackItems;
	}

	private void OnColliderSelected(EncounterCharacterCollider collider, bool selected)
	{
		if ((Object)(object)EncounterManager.Instance != (Object)null)
		{
			EncounterManager.Instance.OnCharacterSelected(this, selected);
		}
	}

	private void OnColliderClicked(EncounterCharacterCollider collider, bool wasRightClick)
	{
		if ((Object)(object)EncounterManager.Instance != (Object)null)
		{
			EncounterManager.Instance.OnCharacterClicked(this, wasRightClick);
		}
	}

	public void SetupFromInspector()
	{
		SetSpecies(species);
		string empty = string.Empty;
		empty = species switch
		{
			SpeciesEnum.Bear => "bear", 
			SpeciesEnum.Wolf => "wolf", 
			SpeciesEnum.Dog => "dog", 
			_ => (!((double)Random.value < 0.5)) ? "woman" : "man", 
		};
		if (!string.IsNullOrEmpty(empty))
		{
			SetAppearance(empty);
			SetPersonality(personality);
			SetWeapon(weapon_inspector);
			equipped_items.AddRange(equipped_item_inspector);
			backpack_items.AddRange(backpack_inspector);
		}
	}
}
