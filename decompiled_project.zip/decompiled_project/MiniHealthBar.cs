using UnityEngine;

public class MiniHealthBar : MonoBehaviour
{
	private EncounterCharacter character;

	private UIProgressBar progress;

	private Transform root_transform;

	private const float autoShowDuration = 1.5f;

	private float autoHideTime;

	private float prev_value;

	private bool visible;

	public void Awake()
	{
		progress = ((Component)this).GetComponent<UIProgressBar>();
		root_transform = ((Component)this).transform.parent;
	}

	public void Initialise(EncounterCharacter enc_char)
	{
		character = enc_char;
		if ((Object)(object)root_transform != (Object)null && (Object)(object)character != (Object)null)
		{
			((Object)root_transform).name = ((Object)character).name;
		}
		progress.value = (float)character.Health / (float)character.maxHealth;
		prev_value = progress.value;
		((Component)this).gameObject.SetActive(true);
	}

	public void SetInactive()
	{
		character = null;
		progress.value = 0f;
		prev_value = progress.value;
		((Component)this).gameObject.SetActive(false);
	}

	public void SetVisible(bool vis)
	{
		if (!((Object)(object)character == (Object)null) && !((Object)(object)progress == (Object)null))
		{
			visible = vis;
			if ((!(progress.value <= 0f) && !character.isDead && !character.isSubdued) || !vis)
			{
				((Behaviour)progress.backgroundWidget).enabled = visible;
				((Behaviour)progress.foregroundWidget).enabled = visible;
			}
		}
	}

	private void Update()
	{
		if ((Object)(object)character == (Object)null || (Object)(object)progress == (Object)null)
		{
			return;
		}
		progress.value = (float)character.Health / (float)character.maxHealth;
		if (autoHideTime > 0f && RealTime.time >= autoHideTime && !visible)
		{
			((Behaviour)progress.backgroundWidget).enabled = false;
			((Behaviour)progress.foregroundWidget).enabled = false;
			autoHideTime = 0f;
		}
		if (progress.value != prev_value)
		{
			prev_value = progress.value;
			if (progress.value <= 0f)
			{
				((Behaviour)progress.backgroundWidget).enabled = false;
				((Behaviour)progress.foregroundWidget).enabled = false;
			}
			else
			{
				autoHideTime = RealTime.time + 1.5f;
				((Behaviour)progress.backgroundWidget).enabled = true;
				((Behaviour)progress.foregroundWidget).enabled = true;
			}
		}
	}

	private void LateUpdate()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)root_transform != (Object)null)
		{
			root_transform.position = character.uiPosition;
		}
	}
}
