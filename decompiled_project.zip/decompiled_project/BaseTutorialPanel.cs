using UnityEngine;

public class BaseTutorialPanel : BasePanel
{
	[SerializeField]
	private float m_showDuration = 8f;

	private float m_showUntilTime;

	[SerializeField]
	private bool m_pauseGame;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return m_pauseGame;
	}

	public override bool PausesGameTime()
	{
		return m_pauseGame;
	}

	public override bool Passive()
	{
		return true;
	}

	public override void OnShow()
	{
		base.OnShow();
		m_showUntilTime = RealTime.time + m_showDuration;
		GetUIPanel().depth -= 3000;
	}

	public override void Update()
	{
		if (RealTime.time >= m_showUntilTime && (Object)(object)UIPanelManager.instance != (Object)null)
		{
			UIPanelManager.instance.PopPanel(this);
		}
	}
}
