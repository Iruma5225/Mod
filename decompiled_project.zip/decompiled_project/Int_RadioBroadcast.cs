using System.Collections.Generic;
using UnityEngine;

public class Int_RadioBroadcast : Int_Base
{
	private Obj_Radio radio;

	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "radio_broadcast";
	}

	public override int GetInteractionPriority()
	{
		return 3;
	}

	public override bool HasSubMenu()
	{
		return true;
	}

	public override void Awake()
	{
		base.Awake();
		radio = obj as Obj_Radio;
	}

	public override bool IsPlayerSelectable()
	{
		if (base.IsPlayerSelectable() && (Object)(object)radio != (Object)null && !radio.broadcasting && !radio.scanning)
		{
			return true;
		}
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		ShowBroadcastSubMenu(member);
		return true;
	}

	private void ShowBroadcastSubMenu(FamilyMember member)
	{
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		list.Add("broadcastTrader");
		list2.Add(Localization.Get("object.interaction.radio_broadcast_trader"));
		list.Add("broadcastJoiner");
		list2.Add(Localization.Get("object.interaction.radio_broadcast_joiner"));
		ContextMenuPanel interactionMenu = InteractionManager.Instance.GetInteractionMenu();
		if ((Object)(object)interactionMenu != (Object)null)
		{
			interactionMenu.PushNewLayer(string.Empty, list, list2, delegate(string selected)
			{
				OnBroadcastSelected(selected, member);
			});
		}
	}

	private void OnBroadcastSelected(string option, FamilyMember member)
	{
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		string jobtype = string.Empty;
		if (!string.IsNullOrEmpty(option) && string.Compare(option, "broadcastTrader") == 0)
		{
			jobtype = "radio_broadcast_trader";
		}
		if (!string.IsNullOrEmpty(option) && string.Compare(option, "broadcastJoiner") == 0)
		{
			jobtype = "radio_broadcast_joiner";
		}
		if (!((Object)(object)member != (Object)null) || !member.isDead)
		{
			Job job = new Job(jobtype, ((Component)obj).transform.position, member, obj);
			if (!member.AddPlayerJob(job))
			{
				job.Cancel(forced: true);
			}
			if ((Object)(object)MeshSortMan.instance != (Object)null)
			{
				MeshSortMan.instance.ForceToFront(member);
			}
		}
	}
}
