using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadingLevel : MonoBehaviour
{
	private float m_loadTime;

	public void Awake()
	{
		m_loadTime = Time.realtimeSinceStartup + 0.5f;
	}

	public void Update()
	{
		if (m_loadTime > 0f && Time.realtimeSinceStartup >= m_loadTime)
		{
			m_loadTime = 0f;
			string text = LoadingScreen.nextLevel;
			if (string.IsNullOrEmpty(text))
			{
				text = "MenuScene";
			}
			else if ((Object)(object)SaveManager.instance != (Object)null)
			{
				SaveManager.instance.ContinueTransition();
			}
			AsyncOperation sceneLoadAsyncOp = SceneManager.LoadSceneAsync(text);
			SaveManager.instance.SceneLoadAsyncOp = sceneLoadAsyncOp;
			LoadingScreen.ClearNextLevel();
		}
	}
}
