using System.Collections.Generic;
using UnityEngine;

public class LoadingManager : MonoBehaviour
{
	public enum LoadingState
	{
		Invalid,
		Started,
		Finished
	}

	private static LoadingState mc_LoadingState = LoadingState.Invalid;

	private static List<BaseManagerNoUpdate> mc_ManagersWaitingToStart = new List<BaseManagerNoUpdate>();

	private void Awake()
	{
		mc_LoadingState = LoadingState.Started;
		if ((Object)(object)LoadingScreen.Instance != (Object)null && ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading))
		{
			LoadingScreen.Instance.HideLoadingScreen();
		}
	}

	private void OnDestroy()
	{
		mc_LoadingState = LoadingState.Invalid;
		mc_ManagersWaitingToStart.Clear();
	}

	private void Update()
	{
		if (mc_LoadingState == LoadingState.Started)
		{
			StartManagers();
			SetLoadingFinished();
		}
	}

	public static bool IsLoadingFinished()
	{
		return mc_LoadingState == LoadingState.Finished;
	}

	public static void SetLoadingFinished()
	{
		if (mc_ManagersWaitingToStart.Count <= 0)
		{
			mc_LoadingState = LoadingState.Finished;
		}
	}

	public static void AddManager(BaseManagerNoUpdate obj)
	{
		if (mc_LoadingState != LoadingState.Finished && !((Object)(object)obj == (Object)null))
		{
			mc_ManagersWaitingToStart.Add(obj);
		}
	}

	public static void StartManagers()
	{
		if (mc_LoadingState == LoadingState.Finished)
		{
			return;
		}
		for (int i = 0; i < mc_ManagersWaitingToStart.Count; i++)
		{
			BaseManagerNoUpdate baseManagerNoUpdate = mc_ManagersWaitingToStart[i];
			try
			{
				baseManagerNoUpdate.StartManager();
			}
			catch
			{
			}
		}
		mc_ManagersWaitingToStart.Clear();
	}

	public static void StartRegisterSaveables()
	{
		if (mc_LoadingState != LoadingState.Finished)
		{
		}
	}
}
