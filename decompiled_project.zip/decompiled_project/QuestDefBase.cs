using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

[Serializable]
public abstract class QuestDefBase
{
	[Serializable]
	public class QuestCharacter
	{
		public enum StatSetting
		{
			Explicit,
			Random_Low,
			Random_Medium,
			Random_High
		}

		[Serializable]
		private class StatValues
		{
			public int m_strength;

			public int m_dexterity;

			public int m_charisma;

			public int m_perception;

			public int m_intelligence;
		}

		[SerializeField]
		private string m_characterId = string.Empty;

		[SerializeField]
		private string m_presetId = string.Empty;

		[SerializeField]
		private ItemManager.ItemType m_weapon = ItemManager.ItemType.Weapon_Fists;

		[SerializeField]
		private ItemManager.ItemType m_equippedItem1 = ItemManager.ItemType.Undefined;

		[SerializeField]
		private ItemManager.ItemType m_equippedItem2 = ItemManager.ItemType.Undefined;

		[SerializeField]
		private EncounterCharacter.PersonalityType m_personality;

		[SerializeField]
		private int m_numRandomItems;

		[SerializeField]
		private List<ItemStack> m_carriedItems = new List<ItemStack>();

		[SerializeField]
		private StatSetting m_statSetting = StatSetting.Random_Low;

		[SerializeField]
		private StatValues m_stats = new StatValues();

		public string characterId => m_characterId;

		public string presetId => m_presetId;

		public ItemManager.ItemType weapon => m_weapon;

		public ItemManager.ItemType equippedItem1 => m_equippedItem1;

		public ItemManager.ItemType equippedItem2 => m_equippedItem2;

		public EncounterCharacter.PersonalityType personality => m_personality;

		public int numRandomItems => m_numRandomItems;

		public ReadOnlyCollection<ItemStack> carriedItems
		{
			get
			{
				List<ItemStack> list = new List<ItemStack>();
				for (int i = 0; i < m_carriedItems.Count; i++)
				{
					list.Add(new ItemStack(m_carriedItems[i]));
				}
				return list.AsReadOnly();
			}
		}

		public StatSetting statSetting => m_statSetting;

		public int strength => m_stats.m_strength;

		public int dexterity => m_stats.m_dexterity;

		public int charisma => m_stats.m_charisma;

		public int perception => m_stats.m_perception;

		public int intelligence => m_stats.m_intelligence;
	}

	[Serializable]
	public class QuestSelection
	{
		[SerializeField]
		private float m_weight = 1f;

		[SerializeField]
		private int m_startDate;

		[SerializeField]
		private int m_timeoutDays;

		[SerializeField]
		private int m_maxSimultaneousInstances = 1;

		[SerializeField]
		private bool m_onceOnly;

		[SerializeField]
		private bool m_discoverByRadio;

		[SerializeField]
		private List<string> m_prerequisiteMilestones = new List<string>();

		public float weight => m_weight;

		public int startDate => m_startDate;

		public int timeoutDays => m_timeoutDays;

		public int maxSimultaneousInstances => m_maxSimultaneousInstances;

		public bool onceOnly => m_onceOnly;

		public bool discoverByRadio => m_discoverByRadio;

		public ReadOnlyCollection<string> prerequisiteMilestones => m_prerequisiteMilestones.AsReadOnly();
	}

	[SerializeField]
	private string m_id = string.Empty;

	[SerializeField]
	private string m_nameKey = string.Empty;

	[SerializeField]
	private string m_descriptionKey = string.Empty;

	[SerializeField]
	private List<string> m_subquests = new List<string>();

	[SerializeField]
	private List<QuestCharacter> m_characterSetup = new List<QuestCharacter>();

	[SerializeField]
	private QuestSelection m_selectionProperties = new QuestSelection();

	[SerializeField]
	private int m_daysUntilExpire;

	[SerializeField]
	private bool m_cancelWhenUnansweredTwice = true;

	[SerializeField]
	private bool m_countsTowardsHelpingHand = true;

	public string visitedIcon = string.Empty;

	public string id => m_id;

	public string nameKey => m_nameKey;

	public string descriptionKey => m_descriptionKey;

	public ReadOnlyCollection<string> subquests => m_subquests.AsReadOnly();

	public ReadOnlyCollection<QuestCharacter> characterSetup => m_characterSetup.AsReadOnly();

	public QuestSelection selectionProperties => m_selectionProperties;

	public int daysUntilExpire => m_daysUntilExpire;

	public bool cancelWhenUnansweredTwice => m_cancelWhenUnansweredTwice;

	public bool countsTowardsHelpingHand => m_countsTowardsHelpingHand;

	public abstract bool IsQuest();

	public abstract bool IsScenario();
}
