using System.Collections.Generic;
using UnityEngine;

public class Obj_HazmatSuit : Obj_Base
{
	public class HazmatSuit
	{
		private const float hazmat_degrade_rate = 25f;

		private int suit_integrity = 100;

		private float suitAccumulator;

		public int SuitIntegrity
		{
			get
			{
				return suit_integrity;
			}
			set
			{
				suit_integrity = Mathf.Clamp(value, 0, 100);
			}
		}

		public void Update(float rad_percentage)
		{
		}

		public void SaveLoadHazmatSuit(SaveData data)
		{
			data.GroupStart("HazmatSuit");
			data.SaveLoad("integrity", ref suit_integrity);
			data.SaveLoad("accumulator", ref suitAccumulator);
			data.GroupEnd();
		}
	}

	[SerializeField]
	private int suits = 2;

	[SerializeField]
	private List<Sprite> sprites = new List<Sprite>();

	private List<HazmatSuit> hazmat_suits;

	[SerializeField]
	private AudioClip m_take_sound;

	[SerializeField]
	private AudioClip m_return_sound;

	private AudioSource m_audio;

	private SpriteRenderer spriteRenderer;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.HazmatSuits;
	}

	public override void Awake()
	{
		base.Awake();
		spriteRenderer = ((Component)this).GetComponentInChildren<SpriteRenderer>();
		m_audio = ((Component)this).GetComponent<AudioSource>();
		hazmat_suits = new List<HazmatSuit>();
		for (int i = 0; i < suits; i++)
		{
			hazmat_suits.Add(new HazmatSuit());
		}
		UpdateSprite();
	}

	public bool HasSuits()
	{
		return hazmat_suits.Count > 0;
	}

	public bool IsFullOfSuits()
	{
		return hazmat_suits.Count >= suits;
	}

	public bool AreSuitsDamaged()
	{
		for (int i = 0; i < hazmat_suits.Count; i++)
		{
			if (hazmat_suits[i].SuitIntegrity < 100)
			{
				return true;
			}
		}
		return false;
	}

	public int GetLowestSuitIntegrity()
	{
		int num = 1;
		for (int i = 0; i < hazmat_suits.Count; i++)
		{
			if (hazmat_suits[i].SuitIntegrity < num)
			{
				num = hazmat_suits[i].SuitIntegrity;
			}
		}
		return num;
	}

	public HazmatSuit TakeSuit()
	{
		if (!HasSuits())
		{
			return null;
		}
		HazmatSuit result = hazmat_suits[0];
		hazmat_suits.RemoveAt(0);
		UpdateSprite();
		return result;
	}

	public bool ReturnSuit(HazmatSuit suit)
	{
		if (IsFullOfSuits())
		{
			return false;
		}
		hazmat_suits.Add(suit);
		UpdateSprite();
		return true;
	}

	public void RepairSuits(int amount)
	{
		if (!HasSuits())
		{
			return;
		}
		for (int i = 0; i < hazmat_suits.Count; i++)
		{
			if (hazmat_suits[i].SuitIntegrity < 100)
			{
				hazmat_suits[i].SuitIntegrity += amount;
			}
		}
	}

	public void UpdateSprite()
	{
		if ((Object)(object)spriteRenderer != (Object)null && sprites.Count >= 1)
		{
			int num = Mathf.CeilToInt((float)hazmat_suits.Count / (float)suits * (float)(sprites.Count - 1));
			if (num >= 0 && num < sprites.Count && (Object)(object)sprites[num] != (Object)null)
			{
				spriteRenderer.sprite = sprites[num];
			}
		}
	}

	public void PlayTakeSound()
	{
		if ((Object)(object)m_audio != (Object)null && (Object)(object)m_take_sound != (Object)null)
		{
			m_audio.PlayOneShot(m_take_sound);
		}
	}

	public void PlayReturnSound()
	{
		if ((Object)(object)m_audio != (Object)null && (Object)(object)m_return_sound != (Object)null)
		{
			m_audio.PlayOneShot(m_return_sound);
		}
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		data.SaveLoadList("suits", hazmat_suits, delegate(int i)
		{
			hazmat_suits[i].SaveLoadHazmatSuit(data);
		}, delegate
		{
			HazmatSuit hazmatSuit = new HazmatSuit();
			if (hazmatSuit != null)
			{
				hazmatSuit.SaveLoadHazmatSuit(data);
				hazmat_suits.Add(hazmatSuit);
			}
		});
		if (data.isLoading)
		{
			UpdateSprite();
		}
	}
}
