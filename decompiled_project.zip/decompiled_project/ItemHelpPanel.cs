using UnityEngine;

public class ItemHelpPanel : BasePanel
{
	[SerializeField]
	protected UILabel m_itemHelpNameMobile;

	[SerializeField]
	protected UILabel m_itemHelpQuantityMobile;

	[SerializeField]
	protected UILabel m_itemHelpDescriptionMobile;

	[SerializeField]
	protected UISprite m_itemHelpSpriteMobile;

	public override void OnShow()
	{
		base.OnShow();
	}

	public static ItemHelpPanel CreateItemHelpPanel(UISprite sprite, string name, string quantity, string description)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		Object itemHelpBox = UIPanelManager.Instance().ItemHelpBox;
		if (itemHelpBox != (Object)null)
		{
			Object obj = Object.Instantiate(itemHelpBox);
			ItemHelpPanel component = ((GameObject)((obj is GameObject) ? obj : null)).GetComponent<ItemHelpPanel>();
			if ((Object)(object)component != (Object)null)
			{
				if (UIRoot.list.Count > 0)
				{
					((Component)component).transform.parent = ((Component)UIRoot.list[0]).transform;
				}
				((Component)component).transform.localScale = Vector3.one;
				((Component)component).transform.localPosition = Vector3.zero;
				component.SetupHelpBox(sprite, name, quantity, description);
				if ((Object)(object)AudioManager.Instance != (Object)null && (Object)(object)AudioManager.Instance.ShowItemHelpSFX != (Object)null)
				{
					AudioManager.Instance.PlayUI(AudioManager.Instance.ShowItemHelpSFX);
				}
				return component;
			}
			return null;
		}
		return null;
	}

	public void SetupHelpBox(UISprite sprite, string name, string quantity, string description)
	{
		if ((Object)(object)sprite != (Object)null)
		{
			m_itemHelpSpriteMobile.atlas = sprite.atlas;
			m_itemHelpSpriteMobile.spriteName = sprite.spriteName;
		}
		else
		{
			m_itemHelpSpriteMobile.atlas = null;
			m_itemHelpSpriteMobile.spriteName = null;
		}
		m_itemHelpNameMobile.text = name;
		m_itemHelpQuantityMobile.text = quantity;
		m_itemHelpDescriptionMobile.text = description;
		UIPanelManager.Instance().PushPanel(this);
	}

	public void RemoveHelpBox()
	{
		if ((Object)(object)AudioManager.Instance != (Object)null && (Object)(object)AudioManager.Instance.CloseItemHelpSFX != (Object)null)
		{
			AudioManager.Instance.PlayUI(AudioManager.Instance.CloseItemHelpSFX);
		}
		UIPanelManager.Instance().PopPanel(this);
	}

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool DestroyOnClose()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool Popup()
	{
		return true;
	}

	public override bool AlwaysOnTopOfStack()
	{
		return true;
	}
}
