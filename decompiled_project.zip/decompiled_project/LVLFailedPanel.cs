using UnityEngine;

public class LVLFailedPanel : MonoBehaviour
{
	public void OnClose()
	{
		Application.Quit();
	}
}
