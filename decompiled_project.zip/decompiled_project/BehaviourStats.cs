using System;
using UnityEngine;

[Serializable]
public class BehaviourStats
{
	public BehaviourStat fatigue = new BehaviourStat(BehaviourStat.BehaviourStatType.Fatigue);

	public BehaviourStat dirtiness = new BehaviourStat(BehaviourStat.BehaviourStatType.Dirtiness);

	public BehaviourStat hunger = new BehaviourStat(BehaviourStat.BehaviourStatType.Hunger);

	public BehaviourStat thirst = new BehaviourStat(BehaviourStat.BehaviourStatType.Thirst);

	public BehaviourStat toilet = new BehaviourStat(BehaviourStat.BehaviourStatType.Toilet);

	public BehaviourStat stress = new BehaviourStat(BehaviourStat.BehaviourStatType.Stress);

	private FamilyMember m_member;

	private BehaviourStat[] stats = new BehaviourStat[6];

	public TraumaStat trauma = new TraumaStat();

	public LoyaltyStat loyalty = new LoyaltyStat();

	public float Stress => stress.Value;

	public void Initialize(FamilyMember member)
	{
		stats[5] = stress;
		stats[0] = fatigue;
		stats[1] = dirtiness;
		stats[2] = hunger;
		stats[3] = thirst;
		stats[4] = toilet;
		for (int i = 0; i < stats.Length; i++)
		{
			stats[i].Initialise();
		}
		m_member = member;
		trauma.Initialise(member);
		loyalty.Initialise(member);
	}

	public BehaviourStat GetStat(BehaviourStat.BehaviourStatType type)
	{
		if (type == BehaviourStat.BehaviourStatType.Max || type == BehaviourStat.BehaviourStatType.Stress)
		{
			return null;
		}
		return stats[(int)type];
	}

	public void UpdateStats()
	{
		float num = 0f;
		for (int i = 0; i < stats.Length; i++)
		{
			if (i != 5)
			{
				float stat_change = 0f;
				stats[i].Update(out stat_change);
				if ((Object)(object)m_member != (Object)null && ((m_member.traits.HasStrength(Traits.Strength.Optimistic) && stat_change < 0f) || (m_member.traits.HasWeakness(Traits.Weakness.Pessimistic) && stat_change > 0f)))
				{
					stat_change *= 1.1f;
				}
				num += stat_change;
			}
		}
		stress.Modify(num);
		float stat_change2 = 0f;
		stress.Update(out stat_change2);
		trauma.Modify(stat_change2);
		loyalty.Update();
	}

	public void SaveLoadBehaviourStats(SaveData data)
	{
		data.GroupStart("BehaviourStats");
		hunger.SaveLoadBehaviourStat(data, "hunger");
		thirst.SaveLoadBehaviourStat(data, "thirst");
		fatigue.SaveLoadBehaviourStat(data, "fatigue");
		dirtiness.SaveLoadBehaviourStat(data, "dirtiness");
		toilet.SaveLoadBehaviourStat(data, "toilet");
		stress.SaveLoadBehaviourStat(data, "stress");
		trauma.SaveLoadTraumaStat(data, "trauma");
		try
		{
			loyalty.SaveLoadLoyaltyStat(data, "loyalty");
		}
		catch (SaveData.MissingGroupException)
		{
			loyalty.Set(loyalty.MaxValue);
		}
		data.GroupEnd();
	}
}
