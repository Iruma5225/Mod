using System.Collections.Generic;
using AnimationOrTween;
using UnityEngine;

public class SlotSelectionPanel : BasePanel
{
	public enum SlotState
	{
		Pending,
		Empty,
		Corrupt,
		Loaded
	}

	private class SlotInfo
	{
		public SlotState m_state;

		public string m_familyName = string.Empty;

		public string m_dateSaved = string.Empty;

		public int m_daysSurvived;

		public int m_rainDiff = 1;

		public int m_resourceDiff = 1;

		public int m_breachDiff = 1;

		public int m_factionDiff = 1;

		public int m_moodDiff = 1;

		public int m_mapSize;

		public bool m_fog;

		public int m_diffSetting = 1;
	}

	[SerializeField]
	private TweenAlpha m_tween;

	[SerializeField]
	private Animator m_hatchAnimator;

	[SerializeField]
	private AudioClip new_game_sound;

	[SerializeField]
	private AudioClip load_game_sound;

	[SerializeField]
	private BasePanel m_customizationPanel;

	[SerializeField]
	private GameObject m_loadingGraphic;

	[SerializeField]
	private List<UILabel> m_slotButtonLabels = new List<UILabel>();

	[SerializeField]
	private List<UILabel> m_slotDescLabels = new List<UILabel>();

	private List<SlotInfo> m_slotInfo = new List<SlotInfo>();

	public int m_selectedSlot = -1;

	private int m_chosenSlot = -1;

	private bool m_goingBack;

	private bool m_inputEnabled;

	private bool m_infoNeedsRefresh;

	private int m_slotBeingLoaded = -1;

	private bool m_loadingSave;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return false;
	}

	public void Start()
	{
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.onSlotDataLoadFinished += OnSaveLoaded;
		}
	}

	public void OnDestroy()
	{
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.onSlotDataLoadFinished -= OnSaveLoaded;
		}
	}

	private void RefreshSaveSlotInfo()
	{
		m_slotInfo.Clear();
		for (int i = 0; i < 3; i++)
		{
			SlotInfo slotInfo = new SlotInfo();
			if ((Object)(object)SaveManager.instance != (Object)null)
			{
				bool exists = false;
				bool corrupted = false;
				SaveManager.instance.DoesSaveExist(i + 1, out exists, out corrupted);
				if (!exists)
				{
					slotInfo.m_state = SlotState.Empty;
				}
				else if (corrupted)
				{
					slotInfo.m_state = SlotState.Corrupt;
				}
			}
			m_slotInfo.Add(slotInfo);
			if (m_slotBeingLoaded == -1 && slotInfo.m_state == SlotState.Pending)
			{
				m_slotBeingLoaded = i;
				if (!SaveManager.instance.platformSave.PlatformLoad((SaveManager.SaveType)(1 + m_slotBeingLoaded)))
				{
					m_slotBeingLoaded = -1;
					slotInfo.m_state = SlotState.Corrupt;
				}
			}
		}
	}

	private void RefreshSlotLabels()
	{
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < m_slotInfo.Count; i++)
		{
			SlotInfo slotInfo = m_slotInfo[i];
			if (i < m_slotButtonLabels.Count && (Object)(object)m_slotButtonLabels[i] != (Object)null)
			{
				string text = Localization.Get("Text.UI.Slot") + " " + (i + 1);
				switch (slotInfo.m_state)
				{
				case SlotState.Pending:
				case SlotState.Empty:
					text = text + ": " + Localization.Get("Text.UI.Empty");
					break;
				case SlotState.Loaded:
					text = text + ":\n" + slotInfo.m_dateSaved;
					break;
				}
				m_slotButtonLabels[i].text = text;
			}
			if (i >= m_slotDescLabels.Count || !((Object)(object)m_slotDescLabels[i] != (Object)null))
			{
				continue;
			}
			m_slotDescLabels[i].color = Color.white;
			string text2 = string.Empty;
			if (slotInfo.m_state == SlotState.Loaded)
			{
				string text3 = Localization.Get("Text.UI.TheFamily");
				if (text3.Length > 0 && text3.Contains("$1"))
				{
					text3 = text3.Replace("$1", slotInfo.m_familyName);
				}
				string empty = string.Empty;
				if (slotInfo.m_daysSurvived <= 1)
				{
					empty = Localization.Get("Text.UI.SurvivedOneDay");
				}
				else
				{
					empty = Localization.Get("Text.UI.SurvivedXDays");
					if (empty.Length > 0 && empty.Contains("$1"))
					{
						empty = empty.Replace("$1", slotInfo.m_daysSurvived.ToString());
					}
				}
				string text4 = Localization.Get("ui.difficulty.difficulty");
				text4 += ": ";
				switch (slotInfo.m_diffSetting)
				{
				case 0:
					text4 += Localization.Get("ui.difficulty.difficultyeasy");
					break;
				case 1:
					text4 += Localization.Get("ui.difficulty.difficultynormal");
					break;
				case 2:
					text4 += Localization.Get("ui.difficulty.difficultyhard");
					break;
				case 3:
					text4 += Localization.Get("ui.difficulty.difficultyhardcore");
					break;
				case 4:
					text4 += Localization.Get("ui.difficulty.difficultycustom");
					break;
				}
				string text5 = text2;
				text2 = text5 + text3 + ", " + empty + "\n" + text4;
			}
			else if (slotInfo.m_state == SlotState.Corrupt)
			{
				text2 += Localization.Get("text.ui.problemreadingsave");
				m_slotDescLabels[i].color = Color.red;
			}
			m_slotDescLabels[i].text = text2;
		}
	}

	public override void OnExtra1()
	{
		PromptDeleteCurrentSlot();
	}

	public void PromptDeleteCurrentSlot()
	{
		if ((!((Object)(object)SaveManager.instance != (Object)null) || !SaveManager.instance.isDeleting) && m_selectedSlot > -1 && m_selectedSlot < m_slotInfo.Count && (m_slotInfo[m_selectedSlot].m_state == SlotState.Loaded || m_slotInfo[m_selectedSlot].m_state == SlotState.Corrupt))
		{
			MessageBox.Show(MessageBoxButtons.YesNo_Buttons, "Text.UI.DeleteSave", OnDeleteMessageBox);
		}
	}

	private void OnDeleteMessageBox(int response)
	{
		if (response == 1 && (Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.DeleteSlot(m_selectedSlot + 1);
			m_infoNeedsRefresh = true;
		}
	}

	public override void OnShow()
	{
		base.OnShow();
		m_goingBack = false;
		m_inputEnabled = false;
		m_chosenSlot = -1;
		RefreshSaveSlotInfo();
		if (m_slotBeingLoaded == -1)
		{
			RefreshSlotLabels();
			if ((Object)(object)m_tween != (Object)null)
			{
				m_tween.PlayForward();
			}
			else
			{
				m_inputEnabled = true;
			}
		}
		if ((Object)(object)m_loadingGraphic != (Object)null)
		{
			m_loadingGraphic.SetActive(false);
		}
	}

	public override void OnResume()
	{
		base.OnResume();
		if ((Object)(object)m_tween != (Object)null)
		{
			m_tween.PlayForward();
		}
		else
		{
			m_inputEnabled = true;
		}
	}

	public override void OnCancel()
	{
		if (m_inputEnabled && (!((Object)(object)SaveManager.instance != (Object)null) || (!SaveManager.instance.isLoading && !SaveManager.instance.isDeleting)))
		{
			base.OnCancel();
			m_goingBack = true;
			m_inputEnabled = false;
			if ((Object)(object)m_tween != (Object)null)
			{
				m_tween.PlayReverse();
				m_tween.ResetToBeginning();
			}
			else if ((Object)(object)UIPanelManager.instance != (Object)null)
			{
				UIPanelManager.instance.PopPanel(this);
			}
		}
	}

	public override void Update()
	{
		if (Input.GetKeyDown((KeyCode)27) && !MessageBox.isOpen)
		{
			OnCancel();
			m_customizationPanel.OnCancel();
		}
		if (m_infoNeedsRefresh && ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isDeleting))
		{
			m_infoNeedsRefresh = false;
			RefreshSaveSlotInfo();
			if (m_slotBeingLoaded == -1)
			{
				RefreshSlotLabels();
			}
		}
		else if ((Object)(object)SaveManager.instance != (Object)null && SaveManager.instance.isDeleting)
		{
			return;
		}
		if (m_slotBeingLoaded <= -1 || SaveManager.instance.platformSave == null || SaveManager.instance.platformSave.IsBusy())
		{
			return;
		}
		if (m_slotBeingLoaded < m_slotInfo.Count)
		{
			byte[] data = null;
			bool flag = false;
			if (SaveManager.instance.platformSave.PlatformGetLoadedData(out data) && data != null && data.Length > 0)
			{
				SaveData saveData = new SaveData(data);
				if (saveData != null && saveData.isLoading && data.Length > 0)
				{
					m_slotInfo[m_slotBeingLoaded].m_daysSurvived = saveData.info.m_daysSurvived;
					m_slotInfo[m_slotBeingLoaded].m_familyName = saveData.info.m_familyName;
					m_slotInfo[m_slotBeingLoaded].m_dateSaved = saveData.info.m_saveTime;
					m_slotInfo[m_slotBeingLoaded].m_rainDiff = saveData.info.m_rainDiff;
					m_slotInfo[m_slotBeingLoaded].m_resourceDiff = saveData.info.m_resourceDiff;
					m_slotInfo[m_slotBeingLoaded].m_breachDiff = saveData.info.m_breachDiff;
					m_slotInfo[m_slotBeingLoaded].m_factionDiff = saveData.info.m_factionDiff;
					m_slotInfo[m_slotBeingLoaded].m_moodDiff = saveData.info.m_moodDiff;
					m_slotInfo[m_slotBeingLoaded].m_mapSize = saveData.info.m_mapSize;
					m_slotInfo[m_slotBeingLoaded].m_fog = saveData.info.m_fog;
					m_slotInfo[m_slotBeingLoaded].m_diffSetting = saveData.info.m_diffSetting;
					saveData.Finished();
					flag = true;
				}
			}
			if (flag)
			{
				m_slotInfo[m_slotBeingLoaded].m_state = SlotState.Loaded;
			}
			else
			{
				m_slotInfo[m_slotBeingLoaded].m_state = SlotState.Corrupt;
			}
		}
		m_slotBeingLoaded = -1;
		for (int i = 0; i < m_slotInfo.Count; i++)
		{
			if (m_slotInfo[i].m_state == SlotState.Pending)
			{
				m_slotBeingLoaded = i;
				if (SaveManager.instance.platformSave.PlatformLoad((SaveManager.SaveType)(1 + m_slotBeingLoaded)))
				{
					break;
				}
				if (m_slotBeingLoaded < m_slotInfo.Count)
				{
					m_slotInfo[m_slotBeingLoaded].m_state = SlotState.Corrupt;
				}
				m_slotBeingLoaded = -1;
			}
		}
		if (m_slotBeingLoaded == -1)
		{
			RefreshSlotLabels();
			if ((Object)(object)m_tween != (Object)null)
			{
				m_tween.PlayForward();
			}
			else
			{
				m_inputEnabled = true;
			}
			if ((Object)(object)m_loadingGraphic != (Object)null)
			{
				m_loadingGraphic.SetActive(false);
			}
		}
	}

	public void OnSlotSelected(SaveSlotButton button)
	{
		if ((Object)(object)button != (Object)null)
		{
			m_selectedSlot = button.slotNumber;
		}
	}

	public void OnSlotChosen()
	{
		if (!m_inputEnabled || ((Object)(object)SaveManager.instance != (Object)null && SaveManager.instance.isDeleting))
		{
			return;
		}
		m_inputEnabled = false;
		m_chosenSlot = m_selectedSlot;
		if (m_chosenSlot <= -1 || m_chosenSlot >= m_slotInfo.Count)
		{
			return;
		}
		SlotInfo slotInfo = m_slotInfo[m_chosenSlot];
		if (slotInfo == null)
		{
			return;
		}
		if (slotInfo.m_state == SlotState.Empty)
		{
			TriggerHatchAnim();
			SaveManager.instance.SetCurrentSlot(m_chosenSlot + 1);
			if ((Object)(object)m_tween != (Object)null)
			{
				m_goingBack = false;
				m_tween.PlayReverse();
				m_tween.ResetToBeginning();
			}
			else
			{
				ShowCustomizationScreen();
			}
		}
		else if (slotInfo.m_state == SlotState.Loaded || slotInfo.m_state == SlotState.Corrupt)
		{
			DifficultyManager.StoreMenuDifficultySettings(slotInfo.m_rainDiff, slotInfo.m_resourceDiff, slotInfo.m_breachDiff, slotInfo.m_factionDiff, slotInfo.m_moodDiff, slotInfo.m_mapSize, slotInfo.m_fog);
			if ((Object)(object)m_loadingGraphic != (Object)null)
			{
				m_loadingGraphic.SetActive(true);
			}
			m_loadingSave = SaveManager.instance.SetSlotToLoad(m_chosenSlot + 1);
		}
	}

	public void OnTweenFinished()
	{
		if ((Object)(object)m_tween != (Object)null && m_tween.direction == Direction.Reverse)
		{
			if (!m_goingBack)
			{
				ShowCustomizationScreen();
			}
			else if ((Object)(object)UIPanelManager.instance != (Object)null)
			{
				UIPanelManager.instance.PopPanel(this);
			}
		}
		else
		{
			m_inputEnabled = true;
		}
	}

	private void ShowCustomizationScreen()
	{
		if (m_chosenSlot < 0 || m_chosenSlot >= m_slotInfo.Count || (Object)(object)SaveManager.instance == (Object)null)
		{
			return;
		}
		SlotInfo slotInfo = m_slotInfo[m_chosenSlot];
		if (slotInfo != null && slotInfo.m_state == SlotState.Empty)
		{
			SaveManager.instance.SetCurrentSlot(m_chosenSlot + 1);
			if ((Object)(object)ScreenFade.instance != (Object)null)
			{
				ScreenFade.instance.m_fadeComplete += OnFadeComplete;
				ScreenFade.instance.StartFade(1f);
			}
			else if ((Object)(object)m_customizationPanel != (Object)null && (Object)(object)UIPanelManager.instance != (Object)null)
			{
				UIPanelManager.instance.PushPanel(m_customizationPanel);
			}
		}
	}

	private void TriggerHatchAnim()
	{
		if ((Object)(object)m_hatchAnimator != (Object)null)
		{
			m_hatchAnimator.SetTrigger("Open");
		}
		if (m_chosenSlot >= 0 && m_chosenSlot < m_slotInfo.Count)
		{
			SlotInfo slotInfo = m_slotInfo[m_chosenSlot];
			if (slotInfo != null)
			{
				AudioManager.Instance.PlayUI((slotInfo.m_state != SlotState.Empty) ? load_game_sound : new_game_sound);
			}
		}
	}

	private void OnSaveLoaded(bool success)
	{
		m_inputEnabled = !success;
		if ((Object)(object)m_loadingGraphic != (Object)null)
		{
			m_loadingGraphic.SetActive(false);
		}
		if (success)
		{
			TriggerHatchAnim();
		}
		else
		{
			MessageBox.Show(MessageBoxButtons.Okay_Button, "text.ui.failedtoload");
		}
	}

	private void OnFadeComplete()
	{
		if ((Object)(object)m_customizationPanel != (Object)null && (Object)(object)UIPanelManager.instance != (Object)null)
		{
			UIPanelManager.instance.PushPanel(m_customizationPanel);
		}
		if ((Object)(object)ScreenFade.instance != (Object)null)
		{
			ScreenFade.instance.m_fadeComplete -= OnFadeComplete;
			ScreenFade.instance.ClearFade(1f);
		}
		if ((Object)(object)m_hatchAnimator != (Object)null)
		{
			m_hatchAnimator.SetTrigger("Close");
		}
	}
}
