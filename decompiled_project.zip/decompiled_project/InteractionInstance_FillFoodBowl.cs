using UnityEngine;

public class InteractionInstance_FillFoodBowl : InteractionInstance_Base
{
	private Int_FillFoodBowl interaction;

	private Obj_FoodBowl m_bowl;

	private Obj_Pet m_petBowl;

	private string m_typeOfFoodTaken = string.Empty;

	protected override bool OnInteractionStarted()
	{
		m_bowl = obj_base as Obj_FoodBowl;
		m_petBowl = obj_base as Obj_Pet;
		if (((Object)(object)m_bowl == (Object)null || m_bowl.hasFood) && ((Object)(object)m_petBowl == (Object)null || m_petBowl.hasFood))
		{
			return false;
		}
		interaction = base_interaction as Int_FillFoodBowl;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		if ((Object)(object)FoodManager.Instance == (Object)null || (FoodManager.Instance.Rations < 1 && FoodManager.Instance.TotalMeat < 1))
		{
			return false;
		}
		if (FoodManager.Instance.DesperateMeat > 0)
		{
			FoodManager.Instance.TakeDesperateMeat(1);
			m_typeOfFoodTaken = "DesperateMeat";
		}
		else if (FoodManager.Instance.Meat > 0)
		{
			FoodManager.Instance.TakeMeat(1);
			m_typeOfFoodTaken = "Meat";
		}
		else
		{
			FoodManager.Instance.TakeRations(1);
			m_typeOfFoodTaken = "Ration";
		}
		if (interaction.crouch)
		{
			member.SetAnimBool("Crouch", truth: true);
		}
		member.TriggerAnim("Rummage");
		if ((Object)(object)m_bowl != (Object)null)
		{
			m_bowl.PlayFillSound();
		}
		if ((Object)(object)m_petBowl != (Object)null)
		{
			m_petBowl.PlayFeedSound();
		}
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		member.SetAnimBool("Crouch", truth: false);
		if (!base.cancelled)
		{
			if ((Object)(object)m_bowl != (Object)null)
			{
				m_bowl.FillWithFood();
			}
			if ((Object)(object)m_petBowl != (Object)null)
			{
				m_petBowl.FillBowl();
			}
		}
		else if ((Object)(object)FoodManager.Instance != (Object)null)
		{
			switch (m_typeOfFoodTaken)
			{
			case "DesperateMeat":
				FoodManager.Instance.AddDesperateMeat(1);
				break;
			case "Meat":
				FoodManager.Instance.AddMeat(1);
				break;
			case "Ration":
				FoodManager.Instance.AddRations(1);
				break;
			}
		}
		return true;
	}
}
