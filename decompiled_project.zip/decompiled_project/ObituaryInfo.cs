using System;
using UnityEngine;

public class ObituaryInfo : MonoBehaviour
{
	[SerializeField]
	private UI2DSprite avatarSprite;

	[SerializeField]
	private UILabel nameLabel;

	[SerializeField]
	private UILabel dayLabel;

	[SerializeField]
	private UILabel deathLabel;

	public bool SetupObituary(FamilyManager.DeadCharacterInfo info)
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		if (info == null)
		{
			return false;
		}
		if ((Object)(object)avatarSprite != (Object)null && (Object)(object)CharacterMeshOptions.instance != (Object)null)
		{
			avatarSprite.sprite2D = null;
			avatarSprite.sprite2D = GetAvatarSprite(info.mesh_id, info.head_texture);
			avatarSprite.material.SetColor("_HairColour", info.hair_colour);
			avatarSprite.material.SetColor("_SkinColour", info.skin_color);
			avatarSprite.material.SetColor("_ShirtColour", info.shirt_color);
			avatarSprite.material.SetColor("_PantsColour", info.pants_color);
		}
		if ((Object)(object)nameLabel != (Object)null)
		{
			nameLabel.text = info.first_name;
		}
		if ((Object)(object)dayLabel != (Object)null)
		{
			string text = Localization.Get("Text.UI.Day");
			text = text.Replace("$day$", info.death_date.ToString());
			dayLabel.text = (info.catatonic ? string.Empty : text);
		}
		if ((Object)(object)deathLabel != (Object)null)
		{
			string text2 = (info.catatonic ? "Catatonic" : Enum.GetName(typeof(BaseCharacter.DamageType), info.death_cause));
			deathLabel.text = Localization.Get("CauseOfDeath." + text2);
		}
		return true;
	}

	private Sprite GetAvatarSprite(string meshID, string headTexture)
	{
		if (string.IsNullOrEmpty(meshID) || string.IsNullOrEmpty(headTexture))
		{
			return null;
		}
		CharacterMeshOptions.CharacterMeshType characterMeshType = CharacterMeshOptions.instance.FindCharacterMesh(meshID);
		if (characterMeshType == null)
		{
			return null;
		}
		for (int i = 0; i < characterMeshType.m_headTextures.Count; i++)
		{
			if (string.Compare(characterMeshType.m_headTextures[i].m_id, headTexture) == 0)
			{
				return characterMeshType.m_headTextures[i].m_avatar;
			}
		}
		return null;
	}
}
