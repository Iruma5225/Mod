using System;
using UnityEngine;

public class SettingsTimeoutPanel : BasePanel
{
	public AudioClip m_OpenSound;

	public AudioClip m_CloseSound;

	public GameObject m_focus_button;

	public UILabel m_label;

	private Action<bool> m_callback;

	public int m_timeout_length;

	private float m_timeout_remaining;

	private float previous_value = -1f;

	public void Show(Action<bool> callback)
	{
		m_callback = callback;
		UIPanelManager.instance.PushPanel(this);
	}

	public override void OnShow()
	{
		if ((Object)(object)m_OpenSound != (Object)null)
		{
			UISound.instance.Play(m_OpenSound);
		}
		m_timeout_remaining = m_timeout_length;
		base.OnShow();
	}

	public override void Update()
	{
		m_timeout_remaining -= RealTime.deltaTime;
		if (m_timeout_remaining <= 0f)
		{
			OnCancel();
		}
		if (Mathf.Floor(m_timeout_remaining) != previous_value)
		{
			previous_value = Mathf.Floor(m_timeout_remaining);
			if ((Object)(object)m_label != (Object)null)
			{
				m_label.text = Localization.Get("ui.settingstimeout") + " " + previous_value.ToString("0");
			}
		}
	}

	public override void OnClose()
	{
		if ((Object)(object)m_CloseSound != (Object)null)
		{
			UISound.instance.Play(m_CloseSound);
		}
		base.OnClose();
	}

	public override void OnSelect()
	{
		base.OnSelect();
		UIPanelManager.Instance().PopPanel(this);
		if (m_callback != null)
		{
			m_callback(obj: true);
		}
	}

	public override void OnCancel()
	{
		base.OnCancel();
		UIPanelManager.Instance().PopPanel(this);
		if (m_callback != null)
		{
			m_callback(obj: false);
		}
	}

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool DestroyOnClose()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool Popup()
	{
		return true;
	}
}
