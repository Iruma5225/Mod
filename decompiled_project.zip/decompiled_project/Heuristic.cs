public enum Heuristic
{
	Manhattan,
	DiagonalManhattan,
	Euclidean,
	None
}
