using System.Collections.Generic;
using UnityEngine;

public class InteractionInstance_BuryCorpse : InteractionInstance_Base
{
	private Int_BuryCorpse interaction;

	private Obj_Grave grave_object;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_BuryCorpse;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		grave_object = ((Component)this).GetComponent<Obj_Grave>();
		if ((Object)(object)grave_object == (Object)null)
		{
			return false;
		}
		if (!member.isCarryingCorpse)
		{
			return false;
		}
		if (grave_object.isOccupied)
		{
			return false;
		}
		member.SetAnimBool("Crouch", truth: true);
		member.TriggerAnim("Rummage");
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		member.SetAnimBool("Crouch", truth: false);
		if (!base.cancelled && (Object)(object)grave_object != (Object)null && (Object)(object)member != (Object)null && (Object)(object)member.CarriedCorpse != (Object)null)
		{
			Obj_Corpse obj_Corpse = member.StopCarryingCorpse();
			if ((Object)(object)obj_Corpse != (Object)null)
			{
				if (obj_Corpse.HazmatSuit != null)
				{
					Obj_HazmatSuit.HazmatSuit suit = obj_Corpse.RemoveHazmatSuit();
					List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.HazmatSuits);
					if (objectsOfType != null && objectsOfType.Count > 0)
					{
						Obj_HazmatSuit obj_HazmatSuit = null;
						for (int i = 0; i < objectsOfType.Count; i++)
						{
							obj_HazmatSuit = objectsOfType[i] as Obj_HazmatSuit;
							if ((Object)(object)obj_HazmatSuit != (Object)null && !obj_HazmatSuit.IsFullOfSuits())
							{
								obj_HazmatSuit.ReturnSuit(suit);
								break;
							}
						}
					}
				}
				grave_object.InterCorpse(obj_Corpse);
				ObjectManager.Instance.RemoveObject(obj_Corpse);
			}
			if ((Object)(object)JournalManager.Instance != (Object)null)
			{
				JournalManager.Instance.RecordEvent(JournalEvents.Event.BodyBuried, new ActivityLog.ExtraInfoString(obj_Corpse.FirstName, isLocalizationKey: false));
				if (obj_Corpse.loyalty >= 1f)
				{
					JournalManager.Instance.CreateJournalEntry(JournalManager.JournalEntryType.Death);
				}
			}
		}
		return true;
	}
}
