using System.Collections.Generic;
using UnityEngine;

public class SettlementNameGenerator : MonoBehaviour
{
	public List<string> firstParts = new List<string>();

	public List<string> townSecondParts = new List<string>();

	public List<string> villageSecondParts = new List<string>();

	private static SettlementNameGenerator m_instance;

	private void Start()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
	}

	public static string TownName()
	{
		string result = string.Empty;
		if ((Object)(object)m_instance != (Object)null)
		{
			result = GenerateName(m_instance.townSecondParts);
		}
		return result;
	}

	public static string VillageName()
	{
		string result = string.Empty;
		if ((Object)(object)m_instance != (Object)null)
		{
			result = GenerateName(m_instance.villageSecondParts);
		}
		return result;
	}

	private static string GenerateName(List<string> secondParts)
	{
		string result = string.Empty;
		if ((Object)(object)m_instance != (Object)null && secondParts != null)
		{
			int count = m_instance.firstParts.Count;
			int count2 = secondParts.Count;
			if (count > 0 && count2 > 0)
			{
				int index = Random.Range(0, count);
				int index2 = Random.Range(0, count2);
				result = m_instance.firstParts[index] + secondParts[index2];
			}
		}
		return result;
	}
}
