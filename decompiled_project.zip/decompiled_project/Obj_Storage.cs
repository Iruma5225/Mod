using System.Collections.Generic;
using UnityEngine;

public class Obj_Storage : Obj_Base
{
	[SerializeField]
	private int m_storageCapacity;

	public int storageCapacity => m_storageCapacity;

	public override void Awake()
	{
		base.Awake();
		if ((Object)(object)InventoryManager.Instance != (Object)null)
		{
			InventoryManager.Instance.RegisterStorage(this);
		}
	}

	public override void Start()
	{
		base.Start();
		if ((Object)(object)InventoryManager.Instance != (Object)null)
		{
			InventoryManager.Instance.RegisterStorage(this);
		}
	}

	public override void OnDestroy()
	{
		base.OnDestroy();
		if ((Object)(object)InventoryManager.Instance != (Object)null)
		{
			InventoryManager.Instance.UnRegisterStorage(this);
		}
	}

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.StorageArea;
	}

	public override List<string> GetTooltipExtraInfo()
	{
		List<string> list = new List<string>();
		list.Add(Localization.Get("ui.tooltip.storage"));
		list.Add(InventoryManager.Instance.GetTotalStackCount() + "/" + InventoryManager.Instance.storageCapacity);
		return list;
	}
}
