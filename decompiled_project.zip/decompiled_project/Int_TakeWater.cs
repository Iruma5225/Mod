using UnityEngine;

public class Int_TakeWater : Int_Base
{
	[SerializeField]
	private int m_WaterUsed = 1;

	[SerializeField]
	private float m_ThirstReduction = 25f;

	public int WaterUsed => m_WaterUsed;

	public float ThirstReduction => m_ThirstReduction;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_TakeWater";
	}

	public override string GetInteractionType()
	{
		return "take_water";
	}

	public override bool IsPlayerSelectable()
	{
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}
}
