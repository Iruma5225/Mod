using UnityEngine;

namespace Pathfinding.RVO;

public struct Line
{
	public Vector2 point;

	public Vector2 dir;
}
