using System;
using Pathfinding.RVO.Sampled;
using UnityEngine;

namespace Pathfinding.RVO;

public class RVOQuadtree
{
	private struct Node
	{
		public int child00;

		public int child01;

		public int child10;

		public int child11;

		public byte count;

		public Agent linkedList;

		public void Add(Agent agent)
		{
			agent.next = linkedList;
			linkedList = agent;
		}

		public void Distribute(Node[] nodes, Rect r)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			Vector2 center = ((Rect)(ref r)).center;
			while (linkedList != null)
			{
				Agent next = linkedList.next;
				if (linkedList.position.x > center.x)
				{
					if (linkedList.position.z > center.y)
					{
						nodes[child11].Add(linkedList);
					}
					else
					{
						nodes[child10].Add(linkedList);
					}
				}
				else if (linkedList.position.z > center.y)
				{
					nodes[child01].Add(linkedList);
				}
				else
				{
					nodes[child00].Add(linkedList);
				}
				linkedList = next;
			}
			count = 0;
		}
	}

	private const int LeafSize = 15;

	private float maxRadius;

	private Node[] nodes = new Node[42];

	private int filledNodes = 1;

	private Rect bounds;

	public void Clear()
	{
		nodes[0] = default(Node);
		filledNodes = 1;
		maxRadius = 0f;
	}

	public void SetBounds(Rect r)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		bounds = r;
	}

	public int GetNodeIndex()
	{
		if (filledNodes == nodes.Length)
		{
			Node[] array = new Node[nodes.Length * 2];
			for (int i = 0; i < nodes.Length; i++)
			{
				ref Node reference = ref array[i];
				reference = nodes[i];
			}
			nodes = array;
		}
		nodes[filledNodes] = default(Node);
		nodes[filledNodes].child00 = filledNodes;
		filledNodes++;
		return filledNodes - 1;
	}

	public void Insert(Agent agent)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		Rect r = bounds;
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(agent.position.x, agent.position.z);
		agent.next = null;
		maxRadius = Math.Max(agent.radius, maxRadius);
		int num2 = 0;
		while (true)
		{
			num2++;
			if (nodes[num].child00 == num)
			{
				if (nodes[num].count < 15 || num2 > 10)
				{
					break;
				}
				Node node = nodes[num];
				node.child00 = GetNodeIndex();
				node.child01 = GetNodeIndex();
				node.child10 = GetNodeIndex();
				node.child11 = GetNodeIndex();
				nodes[num] = node;
				nodes[num].Distribute(nodes, r);
			}
			if (nodes[num].child00 == num)
			{
				continue;
			}
			Vector2 center = ((Rect)(ref r)).center;
			if (val.x > center.x)
			{
				if (val.y > center.y)
				{
					num = nodes[num].child11;
					r = Rect.MinMaxRect(center.x, center.y, ((Rect)(ref r)).xMax, ((Rect)(ref r)).yMax);
				}
				else
				{
					num = nodes[num].child10;
					r = Rect.MinMaxRect(center.x, ((Rect)(ref r)).yMin, ((Rect)(ref r)).xMax, center.y);
				}
			}
			else if (val.y > center.y)
			{
				num = nodes[num].child01;
				r = Rect.MinMaxRect(((Rect)(ref r)).xMin, center.y, center.x, ((Rect)(ref r)).yMax);
			}
			else
			{
				num = nodes[num].child00;
				r = Rect.MinMaxRect(((Rect)(ref r)).xMin, ((Rect)(ref r)).yMin, center.x, center.y);
			}
		}
		nodes[num].Add(agent);
		nodes[num].count++;
	}

	public void Query(Vector2 p, float radius, Agent agent)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		QueryRec(0, p, radius, agent, bounds);
	}

	private float QueryRec(int i, Vector2 p, float radius, Agent agent, Rect r)
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		if (nodes[i].child00 == i)
		{
			for (Agent agent2 = nodes[i].linkedList; agent2 != null; agent2 = agent2.next)
			{
				float num = agent.InsertAgentNeighbour(agent2, radius * radius);
				if (num < radius * radius)
				{
					radius = Mathf.Sqrt(num);
				}
			}
		}
		else
		{
			Vector2 center = ((Rect)(ref r)).center;
			if (p.x - radius < center.x)
			{
				if (p.y - radius < center.y)
				{
					radius = QueryRec(nodes[i].child00, p, radius, agent, Rect.MinMaxRect(((Rect)(ref r)).xMin, ((Rect)(ref r)).yMin, center.x, center.y));
				}
				if (p.y + radius > center.y)
				{
					radius = QueryRec(nodes[i].child01, p, radius, agent, Rect.MinMaxRect(((Rect)(ref r)).xMin, center.y, center.x, ((Rect)(ref r)).yMax));
				}
			}
			if (p.x + radius > center.x)
			{
				if (p.y - radius < center.y)
				{
					radius = QueryRec(nodes[i].child10, p, radius, agent, Rect.MinMaxRect(center.x, ((Rect)(ref r)).yMin, ((Rect)(ref r)).xMax, center.y));
				}
				if (p.y + radius > center.y)
				{
					radius = QueryRec(nodes[i].child11, p, radius, agent, Rect.MinMaxRect(center.x, center.y, ((Rect)(ref r)).xMax, ((Rect)(ref r)).yMax));
				}
			}
		}
		return radius;
	}

	public void DebugDraw()
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		DebugDrawRec(0, bounds);
	}

	private void DebugDrawRec(int i, Rect r)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		Debug.DrawLine(new Vector3(((Rect)(ref r)).xMin, 0f, ((Rect)(ref r)).yMin), new Vector3(((Rect)(ref r)).xMax, 0f, ((Rect)(ref r)).yMin), Color.white);
		Debug.DrawLine(new Vector3(((Rect)(ref r)).xMax, 0f, ((Rect)(ref r)).yMin), new Vector3(((Rect)(ref r)).xMax, 0f, ((Rect)(ref r)).yMax), Color.white);
		Debug.DrawLine(new Vector3(((Rect)(ref r)).xMax, 0f, ((Rect)(ref r)).yMax), new Vector3(((Rect)(ref r)).xMin, 0f, ((Rect)(ref r)).yMax), Color.white);
		Debug.DrawLine(new Vector3(((Rect)(ref r)).xMin, 0f, ((Rect)(ref r)).yMax), new Vector3(((Rect)(ref r)).xMin, 0f, ((Rect)(ref r)).yMin), Color.white);
		if (nodes[i].child00 != i)
		{
			Vector2 center = ((Rect)(ref r)).center;
			DebugDrawRec(nodes[i].child11, Rect.MinMaxRect(center.x, center.y, ((Rect)(ref r)).xMax, ((Rect)(ref r)).yMax));
			DebugDrawRec(nodes[i].child10, Rect.MinMaxRect(center.x, ((Rect)(ref r)).yMin, ((Rect)(ref r)).xMax, center.y));
			DebugDrawRec(nodes[i].child01, Rect.MinMaxRect(((Rect)(ref r)).xMin, center.y, center.x, ((Rect)(ref r)).yMax));
			DebugDrawRec(nodes[i].child00, Rect.MinMaxRect(((Rect)(ref r)).xMin, ((Rect)(ref r)).yMin, center.x, center.y));
		}
		for (Agent agent = nodes[i].linkedList; agent != null; agent = agent.next)
		{
			Debug.DrawLine(nodes[i].linkedList.position + Vector3.up, agent.position + Vector3.up, new Color(1f, 1f, 0f, 0.5f));
		}
	}
}
