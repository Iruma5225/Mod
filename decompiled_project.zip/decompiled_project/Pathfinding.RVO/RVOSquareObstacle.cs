using UnityEngine;

namespace Pathfinding.RVO;

[AddComponentMenu("Pathfinding/Local Avoidance/Square Obstacle")]
public class RVOSquareObstacle : RVOObstacle
{
	public float height = 1f;

	public Vector2 size = Vector2.op_Implicit(Vector3.one);

	public Vector2 center = Vector2.op_Implicit(Vector3.one);

	protected override bool StaticObstacle => false;

	protected override bool ExecuteInEditor => true;

	protected override bool LocalCoordinates => true;

	protected override float Height => height;

	protected override bool AreGizmosDirty()
	{
		return false;
	}

	protected override void CreateObstacles()
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		size.x = Mathf.Abs(size.x);
		size.y = Mathf.Abs(size.y);
		height = Mathf.Abs(height);
		Vector3[] array = (Vector3[])(object)new Vector3[4]
		{
			new Vector3(1f, 0f, -1f),
			new Vector3(1f, 0f, 1f),
			new Vector3(-1f, 0f, 1f),
			new Vector3(-1f, 0f, -1f)
		};
		for (int i = 0; i < array.Length; i++)
		{
			((Vector3)(ref array[i])).Scale(new Vector3(size.x * 0.5f, 0f, size.y * 0.5f));
			ref Vector3 reference = ref array[i];
			reference += new Vector3(center.x, 0f, center.y);
		}
		AddObstacle(array, height);
	}
}
