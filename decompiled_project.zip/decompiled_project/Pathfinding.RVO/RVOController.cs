using System.Collections.Generic;
using UnityEngine;

namespace Pathfinding.RVO;

[AddComponentMenu("Pathfinding/Local Avoidance/RVO Controller")]
public class RVOController : MonoBehaviour
{
	[Tooltip("Radius of the agent")]
	public float radius = 5f;

	[Tooltip("Max speed of the agent. In world units/second")]
	public float maxSpeed = 2f;

	[Tooltip("Height of the agent. In world units")]
	public float height = 1f;

	[Tooltip("A locked unit cannot move. Other units will still avoid it. But avoidance quailty is not the best")]
	public bool locked;

	[Tooltip("Automatically set #locked to true when desired velocity is approximately zero")]
	public bool lockWhenNotMoving = true;

	[Tooltip("How far in the time to look for collisions with other agents")]
	public float agentTimeHorizon = 2f;

	[HideInInspector]
	public float obstacleTimeHorizon = 2f;

	[Tooltip("Maximum distance to other agents to take them into account for collisions.\nDecreasing this value can lead to better performance, increasing it can lead to better quality of the simulation")]
	public float neighbourDist = 10f;

	[Tooltip("Max number of other agents to take into account.\nA smaller value can reduce CPU load, a higher value can lead to better local avoidance quality.")]
	public int maxNeighbours = 10;

	[Tooltip("Layer mask for the ground. The RVOController will raycast down to check for the ground to figure out where to place the agent")]
	public LayerMask mask = LayerMask.op_Implicit(-1);

	public RVOLayer layer = RVOLayer.DefaultAgent;

	[AstarEnumFlag]
	public RVOLayer collidesWith = (RVOLayer)(-1);

	[HideInInspector]
	public float wallAvoidForce = 1f;

	[HideInInspector]
	public float wallAvoidFalloff = 1f;

	[Tooltip("Center of the agent relative to the pivot point of this game object")]
	public Vector3 center;

	private IAgent rvoAgent;

	public bool enableRotation = true;

	public float rotationSpeed = 30f;

	private Simulator simulator;

	private float adjustedY;

	private Transform tr;

	private Vector3 desiredVelocity;

	public bool debug;

	private Vector3 lastPosition;

	private static readonly Color GizmoColor = new Color(0.9411765f, 71f / 85f, 0.11764706f);

	public Vector3 position => rvoAgent.InterpolatedPosition;

	public Vector3 velocity => rvoAgent.Velocity;

	public void OnDisable()
	{
		if (simulator != null)
		{
			simulator.RemoveAgent(rvoAgent);
		}
	}

	public void Awake()
	{
		tr = ((Component)this).transform;
		RVOSimulator rVOSimulator = Object.FindObjectOfType(typeof(RVOSimulator)) as RVOSimulator;
		if ((Object)(object)rVOSimulator == (Object)null)
		{
			Debug.LogError((object)"No RVOSimulator component found in the scene. Please add one.");
		}
		else
		{
			simulator = rVOSimulator.GetSimulator();
		}
	}

	public void OnEnable()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		if (simulator != null)
		{
			if (rvoAgent != null)
			{
				simulator.AddAgent(rvoAgent);
			}
			else
			{
				rvoAgent = simulator.AddAgent(((Component)this).transform.position);
			}
			UpdateAgentProperties();
			rvoAgent.Teleport(((Component)this).transform.position);
			adjustedY = rvoAgent.Position.y;
		}
	}

	protected void UpdateAgentProperties()
	{
		rvoAgent.Radius = radius;
		rvoAgent.MaxSpeed = maxSpeed;
		rvoAgent.Height = height;
		rvoAgent.AgentTimeHorizon = agentTimeHorizon;
		rvoAgent.ObstacleTimeHorizon = obstacleTimeHorizon;
		rvoAgent.Locked = locked;
		rvoAgent.MaxNeighbours = maxNeighbours;
		rvoAgent.DebugDraw = debug;
		rvoAgent.NeighbourDist = neighbourDist;
		rvoAgent.Layer = layer;
		rvoAgent.CollidesWith = collidesWith;
	}

	public void Move(Vector3 vel)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		desiredVelocity = vel;
	}

	public void Teleport(Vector3 pos)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		tr.position = pos;
		lastPosition = pos;
		rvoAgent.Teleport(pos);
		adjustedY = pos.y;
	}

	public void Update()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_024c: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0283: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		if (rvoAgent == null)
		{
			return;
		}
		if (lastPosition != tr.position)
		{
			Teleport(tr.position);
		}
		if (lockWhenNotMoving)
		{
			locked = desiredVelocity == Vector3.zero;
		}
		UpdateAgentProperties();
		Vector3 interpolatedPosition = rvoAgent.InterpolatedPosition;
		interpolatedPosition.y = adjustedY;
		RaycastHit val = default(RaycastHit);
		if (LayerMask.op_Implicit(mask) != 0 && Physics.Raycast(interpolatedPosition + Vector3.up * height * 0.5f, Vector3.down, ref val, float.PositiveInfinity, LayerMask.op_Implicit(mask)))
		{
			adjustedY = ((RaycastHit)(ref val)).point.y;
		}
		else
		{
			adjustedY = 0f;
		}
		interpolatedPosition.y = adjustedY;
		rvoAgent.SetYPosition(adjustedY);
		Vector3 val2 = Vector3.zero;
		if (wallAvoidFalloff > 0f && wallAvoidForce > 0f)
		{
			List<ObstacleVertex> neighbourObstacles = rvoAgent.NeighbourObstacles;
			if (neighbourObstacles != null)
			{
				for (int i = 0; i < neighbourObstacles.Count; i++)
				{
					Vector3 val3 = neighbourObstacles[i].position;
					Vector3 val4 = neighbourObstacles[i].next.position;
					Vector3 val5 = position - AstarMath.NearestPointStrict(val3, val4, position);
					if (!(val5 == val3) && !(val5 == val4))
					{
						float sqrMagnitude = ((Vector3)(ref val5)).sqrMagnitude;
						val5 /= sqrMagnitude * wallAvoidFalloff;
						val2 += val5;
					}
				}
			}
		}
		rvoAgent.DesiredVelocity = desiredVelocity + val2 * wallAvoidForce;
		tr.position = interpolatedPosition + Vector3.up * height * 0.5f - center;
		lastPosition = tr.position;
		if (enableRotation && velocity != Vector3.zero)
		{
			Transform transform = ((Component)this).transform;
			Quaternion rotation = ((Component)this).transform.rotation;
			Quaternion val6 = Quaternion.LookRotation(velocity);
			float num = Time.deltaTime * rotationSpeed;
			Vector3 val7 = velocity;
			transform.rotation = Quaternion.Lerp(rotation, val6, num * Mathf.Min(((Vector3)(ref val7)).magnitude, 0.2f));
		}
	}

	public void OnDrawGizmos()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		Gizmos.color = GizmoColor;
		Gizmos.DrawWireSphere(((Component)this).transform.position + center - Vector3.up * height * 0.5f + Vector3.up * radius * 0.5f, radius);
		Gizmos.DrawLine(((Component)this).transform.position + center - Vector3.up * height * 0.5f, ((Component)this).transform.position + center + Vector3.up * height * 0.5f);
		Gizmos.DrawWireSphere(((Component)this).transform.position + center + Vector3.up * height * 0.5f - Vector3.up * radius * 0.5f, radius);
	}
}
