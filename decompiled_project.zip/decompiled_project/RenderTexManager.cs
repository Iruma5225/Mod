using UnityEngine;

public class RenderTexManager : MonoBehaviour
{
	[SerializeField]
	private float m_pixellation = 1f;

	[SerializeField]
	private bool m_refresh;

	private RenderTexture m_zoomedIn;

	private RenderTexture m_zoomedOut;

	private RenderTexture m_encounter;

	[SerializeField]
	private CharacterRenderCam m_characterCamera;

	[SerializeField]
	private UICharacterRenderCam m_encounterCamera;

	[SerializeField]
	private BasicCamera m_gameCamera;

	private bool m_firstUpdate = true;

	private bool m_wasFullscreen;

	private static RenderTexManager m_instance;

	public RenderTexture zoomedIn => m_zoomedIn;

	public RenderTexture zoomedOut => m_zoomedOut;

	public RenderTexture encounter => m_encounter;

	public static RenderTexManager instance => m_instance;

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
			return;
		}
		m_wasFullscreen = Screen.fullScreen;
	}

	public void OnResolutionChanged()
	{
		float scaleFactor = 1f;
		if ((Object)(object)m_gameCamera != (Object)null)
		{
			m_gameCamera.SetCameraBoundsToShelterBounds();
			scaleFactor = m_gameCamera.postZoomSizeMultiplier;
		}
		RefreshRenderTexture(ref m_zoomedIn, 1f);
		RefreshRenderTexture(ref m_zoomedOut, scaleFactor);
		RefreshRenderTexture(ref m_encounter, 1f);
		if ((Object)(object)m_characterCamera != (Object)null)
		{
			m_characterCamera.RefreshRenderTexture();
		}
		if ((Object)(object)m_encounterCamera != (Object)null)
		{
			m_encounterCamera.RefreshRenderTexture();
		}
	}

	public void OnEncounterStarted()
	{
		if ((Object)(object)m_characterCamera != (Object)null)
		{
			m_characterCamera.SetRenderingEnabled(enabled: false);
		}
		if ((Object)(object)m_encounterCamera != (Object)null)
		{
			m_encounterCamera.SetRenderingEnabled(enabled: true);
		}
	}

	public void OnEncounterFinished()
	{
		if ((Object)(object)m_characterCamera != (Object)null)
		{
			m_characterCamera.SetRenderingEnabled(enabled: true);
		}
		if ((Object)(object)m_encounterCamera != (Object)null)
		{
			m_encounterCamera.SetRenderingEnabled(enabled: false);
		}
	}

	private void RefreshRenderTexture(ref RenderTexture tex, float scaleFactor)
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Expected O, but got Unknown
		m_pixellation = Mathf.Max(m_pixellation, 1f);
		float num = (float)Screen.width / (float)Screen.height;
		float num2 = 1080f * num / m_pixellation * scaleFactor;
		float num3 = 1080f / m_pixellation * scaleFactor;
		tex = new RenderTexture(Mathf.CeilToInt(num2) / 2, Mathf.CeilToInt(num3) / 2, 24);
		((Texture)tex).anisoLevel = 1;
		tex.antiAliasing = 1;
		tex.autoGenerateMips = false;
		tex.format = (RenderTextureFormat)0;
		((Texture)tex).wrapMode = (TextureWrapMode)1;
		((Texture)tex).filterMode = (FilterMode)0;
	}

	public void Update()
	{
		if (m_firstUpdate && (Object)(object)ShelterRoomGrid.Instance != (Object)null && ShelterRoomGrid.Instance.isInitialized)
		{
			m_firstUpdate = false;
			OnResolutionChanged();
		}
		if (Screen.fullScreen != m_wasFullscreen)
		{
			OnResolutionChanged();
			ExpeditionMap.Instance.OnResolutionChanged();
		}
		m_wasFullscreen = Screen.fullScreen;
		if (m_refresh)
		{
			m_refresh = false;
			OnResolutionChanged();
			ExpeditionMap.Instance.OnResolutionChanged();
		}
	}
}
