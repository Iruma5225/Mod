using System.Collections;
using UnityEngine;

public class ItemGridScrollWidget : MonoBehaviour
{
	public delegate void OnSelectionDelegate();

	public OnSelectionDelegate onSelection;

	private bool m_SelectNextFrame;

	public void OnSelect(bool selected)
	{
		if (selected && onSelection != null && !m_SelectNextFrame)
		{
			((MonoBehaviour)this).StartCoroutine("SelectNextFrame");
		}
	}

	private IEnumerator SelectNextFrame()
	{
		if (!m_SelectNextFrame)
		{
			m_SelectNextFrame = true;
			yield return (object)new WaitForEndOfFrame();
			onSelection();
			m_SelectNextFrame = false;
		}
	}
}
