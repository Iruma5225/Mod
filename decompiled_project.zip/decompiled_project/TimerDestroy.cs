using UnityEngine;

public class TimerDestroy : MonoBehaviour
{
	public float lifetime = 1f;

	private void Start()
	{
	}

	private void Update()
	{
	}

	private void Awake()
	{
		Object.Destroy((Object)(object)((Component)this).gameObject, lifetime);
	}
}
