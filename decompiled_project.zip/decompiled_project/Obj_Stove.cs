public class Obj_Stove : Obj_Integrity
{
	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.Stove;
	}

	public override void OnCheck()
	{
		base.OnCheck();
	}
}
