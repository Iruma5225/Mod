using System.Collections.Generic;
using UnityEngine;

public class AchievementManager : MonoBehaviour
{
	public enum Achievement
	{
		GettingComfy,
		TrueSurvivor,
		DayTripper,
		WellTravelled,
		Globetrotter,
		RelicHunter,
		Handyman,
		TooledUp,
		TKO,
		Gunslinger,
		Tinkerer,
		PushItToTheLimit,
		GivingYouAllShesGot,
		HunterGatherer,
		FatOfTheLand,
		GreenFingers,
		Botanist,
		GreaseMonkey,
		HelpingHand,
		NiceTry,
		CorrectCode
	}

	public enum Stat
	{
		MilesTravelled,
		LocationsSearched,
		AnimalsTrapped
	}

	private const int GettingComfy = 7;

	private const int TrueSurvivor = 100;

	private const int DayTripper = 100;

	private const int WellTravelled = 500;

	private const int Globetrotter = 1000;

	private const int RelicHunter = 200;

	private const int HandyMan = 1;

	private const int TooledUp = 10;

	private const int TKO = 1;

	private const int Gunslinger = 1;

	private const int Tinkerer = 1;

	private const int PushItToTheLimit = 1;

	private const int GivingYouAllShesGot = 5;

	private const int HunterGatherer = 1;

	private const int FatOfTheLand = 100;

	private const int GreenFingers = 1;

	private const int Botanist = 5;

	private const int GreaseMonkey = 1;

	private const int HelpingHand = 10;

	private int m_milesTravelled;

	private int m_locationsSearched;

	private int m_animalsTrapped;

	private static AchievementHandler_Base m_handler = new AchievementHandler_GPS();

	private static AchievementManager m_instance = null;

	[SerializeField]
	private bool m_submitStats;

	public static AchievementManager instance => m_instance;

	private void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void Start()
	{
		if (m_handler != null)
		{
			m_handler.Initialise();
		}
	}

	public void SubmitStats()
	{
		m_submitStats = true;
	}

	private void Update()
	{
		if (m_submitStats)
		{
			m_submitStats = false;
			if (m_handler != null)
			{
				m_handler.SubmitStats();
			}
		}
	}

	public void UpdateStats()
	{
		if (m_handler != null)
		{
			m_milesTravelled = m_handler.GetStatProgress(Stat.MilesTravelled);
			m_locationsSearched = m_handler.GetStatProgress(Stat.LocationsSearched);
			m_animalsTrapped = m_handler.GetStatProgress(Stat.AnimalsTrapped);
		}
	}

	public bool UnlockAchievement(Achievement achievement)
	{
		if (m_handler == null)
		{
			return false;
		}
		bool flag = m_handler.SetAchievement(achievement);
		if (flag)
		{
		}
		return flag;
	}

	public bool SetStat(Stat stat, int progress)
	{
		if (m_handler == null)
		{
			return false;
		}
		bool flag = m_handler.SetStat(stat, progress);
		if (flag)
		{
		}
		return flag;
	}

	public bool IncreaseStat(Stat stat, int increase)
	{
		if (m_handler == null)
		{
			return false;
		}
		bool flag = m_handler.IncreaseStat(stat, increase);
		if (flag)
		{
		}
		return flag;
	}

	public void OnNewDay(int day)
	{
		if (day >= 7)
		{
			UnlockAchievement(Achievement.GettingComfy);
		}
		if (day >= 100)
		{
			UnlockAchievement(Achievement.TrueSurvivor);
		}
	}

	public void OnLocationSearched(MapRegion location)
	{
		if ((Object)(object)location != (Object)null)
		{
			m_locationsSearched++;
		}
		IncreaseStat(Stat.LocationsSearched, 1);
		if (m_locationsSearched >= 200)
		{
			UnlockAchievement(Achievement.RelicHunter);
		}
	}

	public void OnEnemyKilled(EncounterCharacter enemy)
	{
		if ((Object)(object)enemy != (Object)null)
		{
			ItemDefinition_Combat combatDefinition = ItemManager.Instance.GetCombatDefinition(enemy.lastDamagedBy);
			if ((Object)(object)combatDefinition != (Object)null && combatDefinition.WeaponType == ItemDefinition_Combat.WeaponTypeEnum.Ranged && enemy.lastDamageType == ItemDefinition_Combat.DamageTypeEnum.Piercing)
			{
				UnlockAchievement(Achievement.Gunslinger);
			}
		}
	}

	public void OnEnemySubdued(EncounterCharacter enemy)
	{
		int num = 0;
		List<EncounterCharacter> nPCs = EncounterManager.Instance.GetNPCs();
		for (int i = 0; i < nPCs.Count; i++)
		{
			if (nPCs[i].isSubdued && !nPCs[i].isDead)
			{
				num++;
			}
		}
		if (num >= 1)
		{
			UnlockAchievement(Achievement.TKO);
		}
	}

	public void OnExpeditionStarted(int id)
	{
		Obj_CamperVan partyVehicle = ExplorationManager.Instance.GetPartyVehicle(id);
		if ((Object)(object)partyVehicle != (Object)null)
		{
			UnlockAchievement(Achievement.GreaseMonkey);
		}
	}

	public void OnExpeditionOver(int id)
	{
		int num = 0;
		float partyDistanceTravelled = ExplorationManager.Instance.GetPartyDistanceTravelled(id);
		if (partyDistanceTravelled >= 0f)
		{
			num = Mathf.RoundToInt(partyDistanceTravelled / ExplorationManager.Instance.worldUnitsPerMile);
			m_milesTravelled += num;
		}
		IncreaseStat(Stat.MilesTravelled, num);
		if (m_milesTravelled >= 100)
		{
			UnlockAchievement(Achievement.DayTripper);
		}
		if (m_milesTravelled >= 500)
		{
			UnlockAchievement(Achievement.WellTravelled);
		}
		if (m_milesTravelled >= 1000)
		{
			UnlockAchievement(Achievement.Globetrotter);
		}
	}

	public void OnItemAddedToInventory(ItemManager.ItemType item, int quantity)
	{
		if (InventoryManager.Instance.ToolCount >= 10)
		{
			UnlockAchievement(Achievement.TooledUp);
		}
	}

	public void OnCraftFinished(ItemManager.ItemType item)
	{
		UnlockAchievement(Achievement.Handyman);
		List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Planter);
		if (objectsOfType.Count >= 5)
		{
			UnlockAchievement(Achievement.Botanist);
		}
	}

	public void OnObjectUpgraded(Obj_Base obj)
	{
		bool flag = false;
		if ((Object)(object)obj != (Object)null && (obj.GetObjectType() == ObjectManager.ObjectType.Generator || obj.GetObjectType() == ObjectManager.ObjectType.OxygenFilter || obj.GetObjectType() == ObjectManager.ObjectType.WaterFilter))
		{
			flag = true;
		}
		if (flag)
		{
			UnlockAchievement(Achievement.Tinkerer);
			if (obj.IsFullyUpgraded())
			{
				UnlockAchievement(Achievement.PushItToTheLimit);
			}
		}
		bool flag2 = true;
		List<Obj_Base> allObjects = ObjectManager.Instance.GetAllObjects();
		for (int i = 0; i < allObjects.Count; i++)
		{
			if (allObjects[i].IsUpgradable() && !allObjects[i].IsFullyUpgraded())
			{
				flag2 = false;
				break;
			}
		}
		if (flag2)
		{
			UnlockAchievement(Achievement.GivingYouAllShesGot);
		}
	}

	public void OnAnimalTrapped(Obj_Base trap)
	{
		if ((Object)(object)trap != (Object)null)
		{
			m_animalsTrapped++;
		}
		IncreaseStat(Stat.AnimalsTrapped, 1);
		if (m_animalsTrapped >= 1)
		{
			UnlockAchievement(Achievement.HunterGatherer);
		}
		if (m_animalsTrapped >= 100)
		{
			UnlockAchievement(Achievement.FatOfTheLand);
		}
	}

	public void OnPlantsHarvested(Obj_Planter planter, int quantity)
	{
		if ((Object)(object)planter != (Object)null && quantity > 0)
		{
			UnlockAchievement(Achievement.GreenFingers);
		}
	}

	public void OnQuestCompleted()
	{
		if ((Object)(object)QuestManager.instance != (Object)null && QuestManager.instance.successfullyCompleted >= 10)
		{
			UnlockAchievement(Achievement.HelpingHand);
		}
	}

	public void OnColorComparison()
	{
		if ((Object)(object)UI_PanelContainer.Instance != (Object)null && (Object)(object)UI_PanelContainer.Instance.ColourComparisonPanel != (Object)null && UI_PanelContainer.Instance.ColourComparisonPanel.GetSuccess())
		{
			UnlockAchievement(Achievement.CorrectCode);
		}
	}

	public void OnAllBreachNpcsKilled()
	{
		UnlockAchievement(Achievement.NiceTry);
	}

	public virtual bool IsReadyForLoad()
	{
		return true;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("AchievementManager");
		data.GroupEnd();
		return true;
	}
}
