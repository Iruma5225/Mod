using Pathfinding;

public delegate void OnGraphDelegate(NavGraph graph);
