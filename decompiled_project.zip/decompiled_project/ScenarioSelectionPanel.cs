using System.Collections.Generic;
using UnityEngine;

public class ScenarioSelectionPanel : BasePanel
{
	[SerializeField]
	private List<UIButton> m_scenarioButtons = new List<UIButton>();

	[SerializeField]
	private UILabel m_scenarioNameLabel;

	[SerializeField]
	private UILabel m_scenarioDescLabel;

	[SerializeField]
	private UILabel m_scenarioHighScore;

	private bool m_goingBack;

	private bool m_inputEnabled;

	private int m_selectedScenario = -1;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return false;
	}

	public void Start()
	{
	}

	public void OnDestroy()
	{
	}

	public override void OnShow()
	{
		base.OnShow();
		m_goingBack = false;
		m_inputEnabled = true;
	}

	public override void OnResume()
	{
		base.OnResume();
	}

	public override void OnCancel()
	{
		if (m_inputEnabled)
		{
			base.OnCancel();
			m_goingBack = true;
			m_inputEnabled = false;
			if ((Object)(object)UIPanelManager.instance != (Object)null)
			{
				UIPanelManager.instance.PopPanel(this);
			}
		}
	}

	public override void Update()
	{
		for (int i = 0; i < m_scenarioButtons.Count; i++)
		{
			if (m_scenarioButtons[i].state == UIButtonColor.State.Hover || m_scenarioButtons[i].state == UIButtonColor.State.Pressed)
			{
				m_selectedScenario = i;
				OnScenarioSelected();
				break;
			}
			if (i == m_scenarioButtons.Count - 1)
			{
				m_selectedScenario = -1;
				m_scenarioNameLabel.text = string.Empty;
				m_scenarioDescLabel.text = string.Empty;
			}
		}
	}

	public void OnScenarioSelected()
	{
		if ((Object)(object)m_scenarioDescLabel != (Object)null && (Object)(object)m_scenarioNameLabel != (Object)null && m_selectedScenario == 0)
		{
			m_scenarioNameLabel.text = Localization.Get("ui.scenariomodename.surrounded");
			m_scenarioDescLabel.text = Localization.Get("ui.scenariomodedesc.surrounded");
		}
	}

	public void OnScenarioChosen()
	{
	}
}
