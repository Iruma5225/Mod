using System.Collections.Generic;
using UnityEngine;

public class AmmoCraftingPanel : CraftingPanel
{
	protected override List<CraftingManager.Recipe> GetRecipes()
	{
		List<CraftingManager.Recipe> list = new List<CraftingManager.Recipe>();
		if ((Object)(object)CraftingManager.Instance != (Object)null)
		{
			list.AddRange(CraftingManager.Instance.GetAllRecipes(CraftingManager.CraftLocation.AmmoPress));
			return list;
		}
		return list;
	}

	public override void SetSubHeadingLabel()
	{
		if ((Object)(object)m_workbench != (Object)null)
		{
			string text = Localization.Get("UI.AmmoPressLevel");
			text = text.Replace("$number$", (m_workbench.GetUpgradeLevel(UpgradeObject.PathEnum.Base) + 1).ToString());
			SetSubHeadingLabelText(text);
		}
	}
}
