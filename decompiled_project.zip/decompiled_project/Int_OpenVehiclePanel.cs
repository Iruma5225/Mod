using UnityEngine;

public class Int_OpenVehiclePanel : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "open_vehicle_panel";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		return !obj.isBurningOrBurntOut && base.InteractionEnabled;
	}

	public override bool IsPlayerSelectableWithoutValidMember()
	{
		return IsPlayerSelectable();
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		if ((Object)(object)UI_PanelContainer.Instance.VehiclePanel != (Object)null)
		{
			UIPanelManager.Instance().PushPanel(UI_PanelContainer.Instance.VehiclePanel);
			return true;
		}
		return false;
	}
}
