using System.Collections.Generic;
using UnityEngine;

public class CombatAIDog : CombatAIBase
{
	public CombatAIDog(EncounterCharacter character)
		: base(character)
	{
	}

	public override EncounterCombatPanel.CombatActionInfo GetNextAction(List<EncounterCharacter> enemies, List<EncounterCharacter> friends)
	{
		EncounterCombatPanel.CombatActionInfo combatActionInfo = new EncounterCombatPanel.CombatActionInfo();
		List<EncounterCharacter> list = new List<EncounterCharacter>(enemies);
		list.RemoveAll((EncounterCharacter x) => !x.canStillFight || x.hasEscaped);
		list.Sort((EncounterCharacter x, EncounterCharacter y) => y.Health.CompareTo(x.Health));
		EncounterCharacter lowest = list[0];
		list.RemoveAll((EncounterCharacter x) => x.Health > lowest.Health);
		combatActionInfo.target = list[Random.Range(0, list.Count)];
		combatActionInfo.action = EncounterCombatPanel.CombatActionEnum.Melee;
		return combatActionInfo;
	}

	public override void OnActionExecuted(EncounterCombatPanel.CombatActionEnum action, EncounterCharacter target)
	{
		base.OnActionExecuted(action, target);
	}
}
