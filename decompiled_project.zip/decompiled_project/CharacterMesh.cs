using System.Collections.Generic;
using UnityEngine;

public class CharacterMesh : MonoBehaviour
{
	public enum TextureType
	{
		Head,
		Torso,
		Legs
	}

	public enum ColorCustomization
	{
		HairColor,
		SkinColor,
		ShirtColor,
		PantsColor
	}

	private CharacterMeshOptions.CharacterMeshType m_mesh;

	private List<Material> m_materials = new List<Material>();

	[SerializeField]
	private string m_headTexture = "default";

	[SerializeField]
	private string m_torsoTexture = "default";

	[SerializeField]
	private string m_legTexture = "default";

	[SerializeField]
	private string m_torsoOverlay = "none";

	[SerializeField]
	private Color m_hairColor = Color.white;

	[SerializeField]
	private Color m_skinColor = Color.white;

	[SerializeField]
	private Color m_shirtColor = Color.white;

	[SerializeField]
	private Color m_pantsColor = Color.white;

	[SerializeField]
	private bool m_refreshAppearance;

	public string meshId => (m_mesh == null) ? string.Empty : m_mesh.m_id;

	public string headTexture => m_headTexture;

	public string torsoTexture => m_torsoTexture;

	public string legTexture => m_legTexture;

	public string torsoOverlay => m_torsoOverlay;

	public Color hairColor => m_hairColor;

	public Color skinColor => m_skinColor;

	public Color shirtColor => m_shirtColor;

	public Color pantsColor => m_pantsColor;

	public void Update()
	{
	}

	public void SetMeshType(CharacterMeshOptions.CharacterMeshType mesh, string meshLayer)
	{
		if (mesh != null && m_mesh == null)
		{
			m_mesh = mesh;
			CacheMaterials();
			Recursive_SetMeshLayer(((Component)this).gameObject.transform, meshLayer);
		}
	}

	public void SetLayer(string layer)
	{
		Recursive_SetMeshLayer(((Component)this).gameObject.transform, layer);
	}

	private void Recursive_SetMeshLayer(Transform obj, string meshLayer)
	{
		if (!((Object)(object)obj != (Object)null))
		{
			return;
		}
		((Component)obj).gameObject.layer = LayerMask.NameToLayer(meshLayer);
		for (int i = 0; i < obj.childCount; i++)
		{
			Transform child = obj.GetChild(i);
			if ((Object)(object)child != (Object)null)
			{
				Recursive_SetMeshLayer(child, meshLayer);
			}
		}
	}

	private void CacheMaterials()
	{
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Expected O, but got Unknown
		List<MeshRenderer> list = new List<MeshRenderer>();
		FindMeshRenderers_Recursive(((Component)this).transform, list);
		Dictionary<string, Material> dictionary = new Dictionary<string, Material>();
		for (int i = 0; i < list.Count; i++)
		{
			if (!dictionary.ContainsKey(((Object)((Renderer)list[i]).material).name.ToLowerInvariant()))
			{
				dictionary[((Object)((Renderer)list[i]).material).name.ToLowerInvariant()] = new Material(((Renderer)list[i]).material);
			}
		}
		for (int j = 0; j < list.Count; j++)
		{
			((Renderer)list[j]).material = dictionary[((Object)((Renderer)list[j]).material).name.ToLowerInvariant()];
		}
		m_materials.Clear();
		m_materials.AddRange(dictionary.Values);
	}

	private void FindMeshRenderers_Recursive(Transform current, List<MeshRenderer> renderers)
	{
		if ((Object)(object)current == (Object)null)
		{
			return;
		}
		MeshRenderer component = ((Component)current).GetComponent<MeshRenderer>();
		if ((Object)(object)component != (Object)null && (Object)(object)((Renderer)component).material != (Object)null)
		{
			renderers?.Add(component);
		}
		for (int i = 0; i < current.childCount; i++)
		{
			Transform child = current.GetChild(i);
			if ((Object)(object)child != (Object)null && (Object)(object)child != (Object)(object)current)
			{
				FindMeshRenderers_Recursive(child, renderers);
			}
		}
	}

	public void RefreshTextures()
	{
		SetTexture(TextureType.Head, m_headTexture);
		SetTexture(TextureType.Torso, m_torsoTexture);
		SetTexture(TextureType.Legs, m_legTexture);
		SetOverlayTexture(m_torsoOverlay);
	}

	public void SetTexture(TextureType type, string id)
	{
		if (m_mesh == null || string.IsNullOrEmpty(id))
		{
			return;
		}
		CharacterMeshOptions.CharacterTexture characterTexture = null;
		List<CharacterMeshOptions.CharacterTexture> list = null;
		switch (type)
		{
		case TextureType.Head:
			list = m_mesh.m_headTextures;
			break;
		case TextureType.Torso:
			list = m_mesh.m_torsoTextures;
			break;
		case TextureType.Legs:
			list = m_mesh.m_legTextures;
			break;
		}
		if (list == null)
		{
			return;
		}
		for (int i = 0; i < list.Count; i++)
		{
			if (string.Compare(list[i].m_id, id, ignoreCase: true) == 0)
			{
				characterTexture = list[i];
				break;
			}
		}
		if (characterTexture == null)
		{
			return;
		}
		string text = string.Empty;
		switch (type)
		{
		case TextureType.Head:
			text = "Head (Instance)";
			m_headTexture = characterTexture.m_id;
			break;
		case TextureType.Torso:
			text = "Torso (Instance)";
			m_torsoTexture = characterTexture.m_id;
			break;
		case TextureType.Legs:
			text = "Legs (Instance)";
			m_legTexture = characterTexture.m_id;
			break;
		}
		for (int j = 0; j < m_materials.Count; j++)
		{
			string text2 = ((Object)m_materials[j]).name.ToLowerInvariant();
			if (text2.Contains(text.ToLowerInvariant()))
			{
				m_materials[j].mainTexture = (Texture)(object)characterTexture.m_texture;
			}
		}
	}

	public void SetOverlayTexture(string id)
	{
		if (m_mesh == null)
		{
			return;
		}
		CharacterMeshOptions.OverlayTexture overlayTexture = null;
		List<CharacterMeshOptions.OverlayTexture> torsoOverlayTextures = m_mesh.m_torsoOverlayTextures;
		if (torsoOverlayTextures == null)
		{
			return;
		}
		if (!string.IsNullOrEmpty(id))
		{
			for (int i = 0; i < torsoOverlayTextures.Count; i++)
			{
				if (string.Compare(torsoOverlayTextures[i].m_id, id, ignoreCase: true) == 0)
				{
					overlayTexture = torsoOverlayTextures[i];
					break;
				}
			}
		}
		if (overlayTexture != null)
		{
			m_torsoOverlay = id;
		}
		else
		{
			m_torsoOverlay = "none";
		}
		string text = "Torso (Instance)";
		for (int j = 0; j < m_materials.Count; j++)
		{
			string text2 = ((Object)m_materials[j]).name.ToLowerInvariant();
			if (text2.Contains(text.ToLowerInvariant()))
			{
				m_materials[j].SetTexture("_OverlayTex", (Texture)(object)overlayTexture?.m_texture);
			}
		}
	}

	public void RandomizeTextures()
	{
		if (m_mesh != null)
		{
			SetTexture(TextureType.Head, m_mesh.GetRandomTexture(TextureType.Head));
			SetTexture(TextureType.Torso, m_mesh.GetRandomTexture(TextureType.Torso));
			SetTexture(TextureType.Legs, m_mesh.GetRandomTexture(TextureType.Legs));
			SetOverlayTexture("none");
		}
	}

	public void RefreshColors()
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		SetColor(ColorCustomization.HairColor, m_hairColor);
		SetColor(ColorCustomization.SkinColor, m_skinColor);
		SetColor(ColorCustomization.ShirtColor, m_shirtColor);
		SetColor(ColorCustomization.PantsColor, m_pantsColor);
	}

	public void SetColor(ColorCustomization customization, Color color)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		string text = string.Empty;
		switch (customization)
		{
		case ColorCustomization.HairColor:
			text = "_HairColour";
			m_hairColor = color;
			break;
		case ColorCustomization.SkinColor:
			text = "_SkinColour";
			m_skinColor = color;
			break;
		case ColorCustomization.ShirtColor:
			text = "_ShirtColour";
			m_shirtColor = color;
			break;
		case ColorCustomization.PantsColor:
			text = "_PantsColour";
			m_pantsColor = color;
			break;
		}
		if (text.Length > 0)
		{
			for (int i = 0; i < m_materials.Count; i++)
			{
				m_materials[i].SetColor(text, color);
			}
		}
	}

	public void SetTintColor(Color color)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < m_materials.Count; i++)
		{
			m_materials[i].SetColor("_TintColour", color);
		}
	}

	public void SetHighlight(float highlight)
	{
		for (int i = 0; i < m_materials.Count; i++)
		{
			m_materials[i].SetFloat("_Highlight", highlight);
		}
	}

	public void SaveLoadCharacterMesh(SaveData data)
	{
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		data.GroupStart("CharacterMesh");
		data.SaveLoadTransform(((Component)this).transform);
		data.SaveLoad("headTex", ref m_headTexture);
		data.SaveLoad("torsoTex", ref m_torsoTexture);
		data.SaveLoad("legTex", ref m_legTexture);
		data.SaveLoad("torsoOverlay", ref m_torsoOverlay);
		data.SaveLoad("hairCol", ref m_hairColor);
		data.SaveLoad("skinCol", ref m_skinColor);
		data.SaveLoad("shirtCol", ref m_shirtColor);
		data.SaveLoad("pantsCol", ref m_pantsColor);
		if (data.isLoading)
		{
			SetColor(ColorCustomization.HairColor, m_hairColor);
			SetColor(ColorCustomization.SkinColor, m_skinColor);
			SetColor(ColorCustomization.ShirtColor, m_shirtColor);
			SetColor(ColorCustomization.PantsColor, m_pantsColor);
			RefreshTextures();
		}
		data.GroupEnd();
	}
}
