using UnityEngine;

public class MainMenuSound : MonoBehaviour
{
	[SerializeField]
	private AudioClip music;

	[SerializeField]
	private AudioClip weather;

	private static bool ignoreNextLoad;

	[SerializeField]
	private bool m_ignoreNextLoad;

	private void Start()
	{
		bool flag = ignoreNextLoad;
		ignoreNextLoad = m_ignoreNextLoad;
		if (!flag)
		{
			AudioManager.Instance.TransitionToShelter();
			AudioManager.Instance.PlayMusic(music);
			WeatherSound.SetPendingSound(weather);
		}
	}
}
