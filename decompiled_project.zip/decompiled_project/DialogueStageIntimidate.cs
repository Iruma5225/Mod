using System.Collections.Generic;
using UnityEngine;

public class DialogueStageIntimidate : BaseDialogueStage
{
	private string m_textId = string.Empty;

	private string m_npcPersonality = string.Empty;

	private bool m_attemptEscape;

	public DialogueStageIntimidate()
	{
		m_npcPersonality = EncounterManager.Instance.GetLeadNpc().Personality.ToString();
		if ((Object)(object)FactionMan.instance != (Object)null && (Object)(object)EncounterManager.Instance != (Object)null && EncounterManager.Instance.encounterFactionId > -1)
		{
			string factionDialogueId = FactionMan.instance.GetFactionDialogueId(EncounterManager.Instance.encounterFactionId);
			if (!string.IsNullOrEmpty(factionDialogueId))
			{
				m_npcPersonality = factionDialogueId;
			}
		}
		if (EncounterDialoguePanel.Instance.PlayerControlled)
		{
			SetState(State_Player_Begin);
		}
		else
		{
			SetState(State_Npc_Begin);
		}
	}

	private DialogueResult State_Player_Begin()
	{
		int strength = EncounterDialoguePanel.Instance.LeadPlayerCharacter.Strength;
		int strength2 = EncounterManager.Instance.GetLeadNpc().Strength;
		EncounterLogic.StatCheckResult statCheckResult = EncounterLogic.StatCheck(strength, strength2);
		Debug.Log((object)("Intimidation check result was " + statCheckResult));
		if (statCheckResult >= EncounterLogic.StatCheckResult.PoorSuccess)
		{
			return DialogueResult.DoCombat;
		}
		SetState(State_Player_ShowNpcComeback);
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_ShowNpcComeback()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText("Encounter.Npc." + m_npcPersonality + ".Intimidate.Failed"))
		{
			SetState(State_Player_WaitNpcComeback);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitNpcComeback()
	{
		if (!EncounterDialoguePanel.Instance.IsTextDone())
		{
			return DialogueResult.Continue;
		}
		EncounterDialoguePanel.Instance.PushPlayerOptions(new List<string> { "Text.UI.Fight", "Text.UI.WalkAway" });
		SetState(State_Player_WaitChoice);
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitChoice()
	{
		string chosenOption = EncounterDialoguePanel.Instance.GetChosenOption();
		if (string.IsNullOrEmpty(chosenOption))
		{
			return DialogueResult.Continue;
		}
		switch (chosenOption)
		{
		case "Text.UI.Fight":
			m_textId = "Encounter.Player." + m_npcPersonality + ".Intimidate.ConfirmingCombat";
			m_attemptEscape = false;
			break;
		case "Text.UI.WalkAway":
			m_textId = "Encounter.Player." + m_npcPersonality + ".Intimidate.EscapingCombat";
			m_attemptEscape = true;
			break;
		}
		SetState(State_Player_ShowPlayerChoice);
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_ShowPlayerChoice()
	{
		if (EncounterDialoguePanel.Instance.PushPlayerText(m_textId))
		{
			SetState(State_Player_WaitPlayerChoiceText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitPlayerChoiceText()
	{
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			if (!m_attemptEscape)
			{
				return DialogueResult.DoCombat;
			}
			EncounterDialoguePanel.Instance.PushPlayerText(null);
			EncounterDialoguePanel.Instance.Escape(EncounterManager.Instance.GetPlayerCharacters(), EncounterManager.Instance.GetNPCs());
			m_timer = 4f;
			SetState(State_Player_Escaping);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_Escaping()
	{
		DialogueResult result = DialogueResult.Continue;
		if (m_timer <= Mathf.Epsilon)
		{
			bool flag = EncounterDialoguePanel.Instance.DidEscapeSucceed(EncounterManager.Instance.GetPlayerCharacters(), EncounterManager.Instance.GetNPCs());
			result = ((!flag) ? DialogueResult.DoCombat : DialogueResult.EndEncounter);
			EncounterDialoguePanel.Instance.EscapeOver(EncounterManager.Instance.GetPlayerCharacters(), EncounterManager.Instance.GetNPCs(), flag);
		}
		return result;
	}

	private DialogueResult State_Npc_Begin()
	{
		int strength = EncounterManager.Instance.GetLeadNpc().Strength;
		int strength2 = EncounterDialoguePanel.Instance.LeadPlayerCharacter.Strength;
		EncounterLogic.StatCheckResult statCheckResult = EncounterLogic.StatCheck(strength, strength2);
		Debug.Log((object)("Strength check result was " + statCheckResult));
		if (statCheckResult >= EncounterLogic.StatCheckResult.PoorSuccess)
		{
			EncounterDialoguePanel.Instance.PushPlayerOptions(new List<string> { "Text.UI.Fight", "Text.UI.Flee" });
			SetState(State_Npc_WaitPlayerChoice_EscapeOrFight);
		}
		else
		{
			SetState(State_Npc_ShowIntimidationFailedText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_ShowIntimidationFailedText()
	{
		if (EncounterDialoguePanel.Instance.PushPlayerText("Encounter.Player." + m_npcPersonality + ".Intimidate.Failed"))
		{
			SetState(State_Npc_WaitIntimidationFailedText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_WaitIntimidationFailedText()
	{
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			EncounterDialoguePanel.Instance.PushPlayerOptions(new List<string> { "Text.UI.Fight", "Text.UI.WalkAway" });
			SetState(State_Npc_WaitPlayerChoice_WalkOrFight);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_WaitPlayerChoice_WalkOrFight()
	{
		string chosenOption = EncounterDialoguePanel.Instance.GetChosenOption();
		if (string.IsNullOrEmpty(chosenOption))
		{
			return DialogueResult.Continue;
		}
		switch (chosenOption)
		{
		case "Text.UI.Fight":
			SetState(State_Npc_ShowPlayerFightText);
			break;
		case "Text.UI.WalkAway":
		case "Text.UI.Flee":
			SetState(State_Npc_ShowPlayerWalkText);
			break;
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_ShowPlayerWalkText()
	{
		if (EncounterDialoguePanel.Instance.PushPlayerText("Encounter.Player." + m_npcPersonality + ".Intimidate.WalkAway"))
		{
			SetState(State_Npc_WaitPlayerWalkText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_WaitPlayerWalkText()
	{
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			return DialogueResult.EndEncounter;
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_ShowPlayerFightText()
	{
		if (EncounterDialoguePanel.Instance.PushPlayerText("Encounter.Player." + m_npcPersonality + ".Intimidate.BringItOn"))
		{
			SetState(State_Npc_ShowEscapingText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_ShowEscapingText()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText("Encounter.Npc." + m_npcPersonality + ".Intimidate.EscapingCombat"))
		{
			SetState(State_Npc_WaitEscapingText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_WaitEscapingText()
	{
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			EncounterDialoguePanel.Instance.PushNpcText(null);
			EncounterDialoguePanel.Instance.Escape(EncounterManager.Instance.GetNPCs(), EncounterManager.Instance.GetPlayerCharacters());
			m_timer = 4f;
			SetState(State_Npc_Escaping);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_Escaping()
	{
		DialogueResult result = DialogueResult.Continue;
		if (m_timer <= Mathf.Epsilon)
		{
			bool flag = EncounterDialoguePanel.Instance.DidEscapeSucceed(EncounterManager.Instance.GetNPCs(), EncounterManager.Instance.GetPlayerCharacters());
			result = ((!flag) ? DialogueResult.DoCombat : DialogueResult.EndEncounter);
			EncounterDialoguePanel.Instance.EscapeOver(EncounterManager.Instance.GetNPCs(), EncounterManager.Instance.GetPlayerCharacters(), flag);
		}
		return result;
	}

	private DialogueResult State_Npc_WaitPlayerChoice_EscapeOrFight()
	{
		string chosenOption = EncounterDialoguePanel.Instance.GetChosenOption();
		if (string.IsNullOrEmpty(chosenOption))
		{
			return DialogueResult.Continue;
		}
		switch (chosenOption)
		{
		case "Text.UI.Fight":
			SetState(State_Npc_GoToCombat);
			break;
		case "Text.UI.Flee":
		case "Text.UI.WalkAway":
			SetState(State_Npc_ShowPlayerEscapeText);
			break;
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_GoToCombat()
	{
		return DialogueResult.DoCombat;
	}

	private DialogueResult State_Npc_ShowPlayerEscapeText()
	{
		if (EncounterDialoguePanel.Instance.PushPlayerText("Encounter.Player." + m_npcPersonality + ".Intimidate.EscapingCombat"))
		{
			SetState(State_Npc_WaitPlayerEscapeText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Npc_WaitPlayerEscapeText()
	{
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			EncounterDialoguePanel.Instance.PushPlayerText(null);
			EncounterDialoguePanel.Instance.Escape(EncounterManager.Instance.GetPlayerCharacters(), EncounterManager.Instance.GetNPCs());
			m_timer = 4f;
			SetState(State_Player_Escaping);
		}
		return DialogueResult.Continue;
	}
}
