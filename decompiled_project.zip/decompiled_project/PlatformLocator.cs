using UnityEngine;

public class PlatformLocator : MonoBehaviour
{
	private void Start()
	{
		PerformBuildConstantCheck();
		AttachPlatformScript();
	}

	private void AttachPlatformScript()
	{
	}

	private void PerformBuildConstantCheck()
	{
	}
}
