using System.Text;
using UnityEngine;

public class UI_GameTime : MonoBehaviour
{
	[SerializeField]
	private UILabel m_timeLabel;

	[SerializeField]
	private UILabel m_dayLabel;

	[SerializeField]
	private UILabel m_foodLabel;

	[SerializeField]
	private UILabel m_waterLabel;

	[SerializeField]
	private UILabel m_petrolLabel;

	[SerializeField]
	private UILabel m_oxygenLabel;

	[SerializeField]
	private int m_foodLowThreshold;

	[SerializeField]
	private int m_waterLowThreshold;

	[SerializeField]
	private int m_petrolLowThreshold;

	[SerializeField]
	private int m_oxygenLowThreshold;

	[SerializeField]
	private UITweener dropdownTween;

	[SerializeField]
	private UI_PlatformButton zoom_button;

	[SerializeField]
	private UI_PlatformButton zoom_button_toggled;

	[SerializeField]
	private UI_PlatformButton ff_button;

	[SerializeField]
	private UI_PlatformButton ff_button_toggled;

	[SerializeField]
	private UI_PlatformButton sd_button;

	[SerializeField]
	private UI_PlatformButton sd_button_toggled;

	private UITweener m_foodLowTween;

	private UITweener m_waterLowTween;

	private UITweener m_petrolLowTween;

	private UITweener m_oxygenLowTween;

	private StringBuilder str = new StringBuilder();

	private BasicCamera game_cam;

	[SerializeField]
	private AudioClip show_dropdown_sound;

	[SerializeField]
	private AudioClip hide_dropdown_sound;

	private void Awake()
	{
		game_cam = ((Component)Camera.main).GetComponent<BasicCamera>();
		if ((Object)(object)m_foodLabel != (Object)null)
		{
			m_foodLowTween = ((Component)m_foodLabel).GetComponent<UITweener>();
		}
		if ((Object)(object)m_waterLabel != (Object)null)
		{
			m_waterLowTween = ((Component)m_waterLabel).GetComponent<UITweener>();
		}
		if ((Object)(object)m_petrolLabel != (Object)null)
		{
			m_petrolLowTween = ((Component)m_petrolLabel).GetComponent<UITweener>();
		}
		if ((Object)(object)m_oxygenLabel != (Object)null)
		{
			m_oxygenLowTween = ((Component)m_oxygenLabel).GetComponent<UITweener>();
		}
		UpdateZoomButton();
		UpdateFFButton();
		UpdateSDButton();
	}

	public void Start()
	{
		ShowDropdown(show: true);
	}

	public void Update()
	{
		if (EncounterManager.Instance.GetEncounterState() == EncounterManager.EncounterState.ShowEncounter)
		{
			if (game_cam.isSpedUp)
			{
				ToggleFFOff();
			}
			if (game_cam.isSlowedDown)
			{
				ToggleSlowDownOff();
			}
			AudioManager.Instance.TransitionToEncounter();
		}
		if ((Object)(object)m_timeLabel != (Object)null)
		{
			str.Length = 0;
			str.Append(GameTime.Hour.ToString("D2"));
			str.Append(":");
			str.Append(GameTime.Minute.ToString("D2"));
			m_timeLabel.text = str.ToString();
		}
		if ((Object)(object)m_dayLabel != (Object)null)
		{
			m_dayLabel.text = GameTime.Day.ToString();
		}
		if ((Object)(object)m_foodLabel != (Object)null)
		{
			if ((Object)(object)FoodManager.Instance != (Object)null)
			{
				int num = FoodManager.Instance.Rations + FoodManager.Instance.TotalMeat;
				m_foodLabel.text = num.ToString();
				if ((Object)(object)m_foodLowTween != (Object)null)
				{
					if (num <= m_foodLowThreshold && !((Behaviour)m_foodLowTween).enabled)
					{
						m_foodLowTween.style = UITweener.Style.Loop;
						m_foodLowTween.PlayForward();
					}
					else if (num > m_foodLowThreshold && ((Behaviour)m_foodLowTween).enabled)
					{
						m_foodLowTween.style = UITweener.Style.Once;
					}
				}
			}
			else
			{
				m_foodLabel.text = string.Empty;
			}
		}
		if ((Object)(object)m_waterLabel != (Object)null)
		{
			if ((Object)(object)WaterManager.Instance != (Object)null)
			{
				int num2 = Mathf.FloorToInt(WaterManager.Instance.StoredWater);
				m_waterLabel.text = num2.ToString();
				if ((Object)(object)m_waterLowTween != (Object)null)
				{
					if (num2 <= m_waterLowThreshold && !((Behaviour)m_waterLowTween).enabled)
					{
						m_waterLowTween.style = UITweener.Style.Loop;
						m_waterLowTween.PlayForward();
					}
					else if (num2 > m_waterLowThreshold && ((Behaviour)m_waterLowTween).enabled)
					{
						m_waterLowTween.style = UITweener.Style.Once;
					}
				}
			}
			else
			{
				m_waterLabel.text = string.Empty;
			}
		}
		if ((Object)(object)m_petrolLabel != (Object)null)
		{
			if ((Object)(object)InventoryManager.Instance != (Object)null)
			{
				int numItemsOfType = InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.Petrol);
				m_petrolLabel.text = numItemsOfType.ToString();
				if ((Object)(object)m_petrolLowTween != (Object)null)
				{
					if (numItemsOfType <= m_petrolLowThreshold && !((Behaviour)m_petrolLowTween).enabled)
					{
						m_petrolLowTween.style = UITweener.Style.Loop;
						m_petrolLowTween.PlayForward();
					}
					else if (numItemsOfType > m_petrolLowThreshold && ((Behaviour)m_petrolLowTween).enabled)
					{
						m_petrolLowTween.style = UITweener.Style.Once;
					}
				}
			}
			else
			{
				m_petrolLabel.text = string.Empty;
			}
		}
		if ((Object)(object)m_oxygenLabel != (Object)null)
		{
			if ((Object)(object)EnvironmentManager.Instance != (Object)null)
			{
				float oxygenLevel = EnvironmentManager.Instance.OxygenLevel;
				m_oxygenLabel.text = Mathf.CeilToInt(oxygenLevel).ToString();
				if ((Object)(object)m_oxygenLowTween != (Object)null)
				{
					if (oxygenLevel <= (float)m_oxygenLowThreshold && !((Behaviour)m_oxygenLowTween).enabled)
					{
						m_oxygenLowTween.style = UITweener.Style.Loop;
						m_oxygenLowTween.PlayForward();
					}
					else if (oxygenLevel > (float)m_oxygenLowThreshold && ((Behaviour)m_oxygenLowTween).enabled)
					{
						m_oxygenLowTween.style = UITweener.Style.Once;
					}
				}
			}
			else
			{
				m_oxygenLabel.text = string.Empty;
			}
		}
		UpdateZoomButton();
		UpdateFFButton();
		UpdateSDButton();
	}

	private void UpdateZoomButton()
	{
		if (!((Object)(object)game_cam == (Object)null))
		{
			if ((Object)(object)zoom_button != (Object)null)
			{
				((Component)zoom_button).gameObject.SetActive(!game_cam.isZoomed);
			}
			if ((Object)(object)zoom_button_toggled != (Object)null)
			{
				((Component)zoom_button_toggled).gameObject.SetActive(game_cam.isZoomed);
			}
		}
	}

	private void UpdateFFButton()
	{
		if (!((Object)(object)game_cam == (Object)null))
		{
			if ((Object)(object)ff_button != (Object)null)
			{
				((Component)ff_button).gameObject.SetActive(!game_cam.isSpedUp);
			}
			if ((Object)(object)ff_button_toggled != (Object)null)
			{
				((Component)ff_button_toggled).gameObject.SetActive(game_cam.isSpedUp);
			}
		}
	}

	private void UpdateSDButton()
	{
		if (!((Object)(object)game_cam == (Object)null))
		{
			if ((Object)(object)sd_button != (Object)null)
			{
				((Component)sd_button).gameObject.SetActive(!game_cam.isSlowedDown);
			}
			if ((Object)(object)sd_button_toggled != (Object)null)
			{
				((Component)sd_button_toggled).gameObject.SetActive(game_cam.isSlowedDown);
			}
		}
	}

	public void ShowDropdown(bool show)
	{
		if ((Object)(object)TutorialManager.Instance != (Object)null && !TutorialManager.Instance.TutorialActive && (Object)(object)InteractionManager.Instance.SelectedObject != (Object)null)
		{
			InteractionManager.Instance.UnSelectObject(InteractionManager.Instance.SelectedObject);
		}
		if (!((Object)(object)dropdownTween == (Object)null))
		{
			if (show)
			{
				dropdownTween.PlayForward();
			}
			else
			{
				dropdownTween.PlayReverse();
			}
		}
	}

	public void ShowDropdown()
	{
		ShowDropdown(show: true);
	}

	public void HideDropdown()
	{
		ShowDropdown(show: false);
	}

	public void ToggleDropdown()
	{
		ShowDropdown(!IsDropdownOpen());
	}

	public bool IsDropdownOpen()
	{
		if ((Object)(object)dropdownTween != (Object)null)
		{
			return dropdownTween.tweenFactor > 0f;
		}
		return false;
	}

	public void OnToggleClicked()
	{
		AudioManager.Instance.PlayUI((!IsDropdownOpen()) ? show_dropdown_sound : hide_dropdown_sound);
		ToggleDropdown();
	}

	public void ToggleZoomOn()
	{
		if ((!((Object)(object)InteractionManager.Instance != (Object)null) || InteractionManager.Instance.Mode == InteractionManager.InteractionMode.Standard) && (Object)(object)game_cam != (Object)null)
		{
			game_cam.SetPendingZoom(zoomOut: true);
		}
	}

	public void ToggleZoomOff()
	{
		if ((!((Object)(object)InteractionManager.Instance != (Object)null) || InteractionManager.Instance.Mode == InteractionManager.InteractionMode.Standard) && (Object)(object)game_cam != (Object)null)
		{
			game_cam.SetPendingZoom(zoomOut: false);
		}
	}

	public void ToggleFFOn()
	{
		if ((!((Object)(object)InteractionManager.Instance != (Object)null) || InteractionManager.Instance.Mode == InteractionManager.InteractionMode.Standard) && UIPanelManager.instance.IsGameInputActive() && (Object)(object)game_cam != (Object)null)
		{
			game_cam.SetForcedFastForward(active: true);
			if ((Object)(object)InteractionManager.Instance.SelectedObject != (Object)null)
			{
				InteractionManager.Instance.UnSelectObject(InteractionManager.Instance.SelectedObject);
			}
		}
	}

	public void ToggleFFOff()
	{
		if ((!((Object)(object)InteractionManager.Instance != (Object)null) || InteractionManager.Instance.Mode == InteractionManager.InteractionMode.Standard) && (Object)(object)game_cam != (Object)null)
		{
			game_cam.SetForcedFastForward(active: false);
			if ((Object)(object)InteractionManager.Instance.SelectedObject != (Object)null)
			{
				InteractionManager.Instance.UnSelectObject(InteractionManager.Instance.SelectedObject);
			}
		}
	}

	public void ToggleSlowDownOn()
	{
		if ((!((Object)(object)InteractionManager.Instance != (Object)null) || InteractionManager.Instance.Mode == InteractionManager.InteractionMode.Standard) && UIPanelManager.instance.IsGameInputActive() && (Object)(object)game_cam != (Object)null)
		{
			game_cam.SetForcedSlowDown(active: true);
			if ((Object)(object)InteractionManager.Instance.SelectedObject != (Object)null)
			{
				InteractionManager.Instance.UnSelectObject(InteractionManager.Instance.SelectedObject);
			}
		}
	}

	public void ToggleSlowDownOff()
	{
		if ((!((Object)(object)InteractionManager.Instance != (Object)null) || InteractionManager.Instance.Mode == InteractionManager.InteractionMode.Standard) && (Object)(object)game_cam != (Object)null)
		{
			game_cam.SetForcedSlowDown(active: false);
			if ((Object)(object)InteractionManager.Instance.SelectedObject != (Object)null)
			{
				InteractionManager.Instance.UnSelectObject(InteractionManager.Instance.SelectedObject);
			}
		}
	}
}
