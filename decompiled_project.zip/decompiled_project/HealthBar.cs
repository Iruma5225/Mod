using UnityEngine;

public class HealthBar : MonoBehaviour
{
	[SerializeField]
	private UILabel nameLabel;

	[SerializeField]
	private UI2DSprite portrait;

	[SerializeField]
	private UIProgressBar healthBar;

	[SerializeField]
	private UITablePivot debuffTable;

	[SerializeField]
	private UISprite bleedSprite;

	[SerializeField]
	private UISprite dazedSprite;

	private EncounterCharacter current_character;

	private float current_health;

	private bool updateTable;

	public void SetCharacter(EncounterCharacter character)
	{
		if ((Object)(object)portrait != (Object)null)
		{
			character.ColorizeAvatarSprite(portrait);
		}
		if ((Object)(object)nameLabel != (Object)null)
		{
			nameLabel.text = character.Name_Short;
		}
		current_character = character;
	}

	public void UpdateHealthBar()
	{
		if (!((Object)(object)current_character == (Object)null))
		{
			current_health = (float)current_character.Health / (float)current_character.maxHealth;
			if (healthBar.value != current_health)
			{
				healthBar.value = current_health;
			}
			if ((Object)(object)bleedSprite != (Object)null && ((Component)bleedSprite).gameObject.activeSelf != current_character.isBleeding)
			{
				((Component)bleedSprite).gameObject.SetActive(current_character.isBleeding);
				updateTable = true;
			}
			if ((Object)(object)dazedSprite != (Object)null && ((Component)dazedSprite).gameObject.activeSelf != current_character.isDazed)
			{
				((Component)dazedSprite).gameObject.SetActive(current_character.isDazed);
				updateTable = true;
			}
			if (updateTable && (Object)(object)debuffTable != (Object)null)
			{
				debuffTable.Reposition();
				updateTable = false;
			}
		}
	}
}
