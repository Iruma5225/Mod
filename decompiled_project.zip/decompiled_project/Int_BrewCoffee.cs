using UnityEngine;

public class Int_BrewCoffee : Int_Base
{
	public AudioClip m_brewCoffeeSFX;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_BrewCoffee";
	}

	public override string GetInteractionType()
	{
		return "brew_coffee";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public void BrewSoundEffect()
	{
		if ((Object)(object)m_brewCoffeeSFX != (Object)null)
		{
			((Component)this).GetComponent<AudioSource>().PlayOneShot(m_brewCoffeeSFX);
		}
	}

	public override bool IsPlayerSelectable()
	{
		if (base.IsPlayerSelectable())
		{
			Obj_CoffeeMachine obj_CoffeeMachine = obj as Obj_CoffeeMachine;
			if ((Object)(object)obj_CoffeeMachine != (Object)null && (Object)(object)WaterManager.Instance != (Object)null && (Object)(object)InventoryManager.Instance != (Object)null && obj_CoffeeMachine.HasEnoughPower() && obj_CoffeeMachine.IsEnabled() && !obj_CoffeeMachine.brewing && obj_CoffeeMachine.cupsOfCoffee <= 0 && WaterManager.Instance.StoredWater >= 5f && InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.CoffeeBeans) > 0)
			{
				return true;
			}
		}
		return false;
	}
}
