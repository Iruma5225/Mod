using UnityEngine;

[AddComponentMenu("Sheltered/Interaction/Fix")]
public class Int_Fix : Int_Base
{
	public bool m_CrouchAnim;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_Fix";
	}

	public override string GetInteractionType()
	{
		return "fix";
	}

	public override int GetInteractionPriority()
	{
		return 10;
	}

	public override bool IsPlayerSelectable()
	{
		if (obj.isBurningOrBurntOut || !base.InteractionEnabled)
		{
			return false;
		}
		Obj_Integrity obj_Integrity = obj as Obj_Integrity;
		if ((Object)(object)obj_Integrity != (Object)null && obj_Integrity.Integrity < 100)
		{
			return true;
		}
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}
}
