using UnityEngine;

public class Obj_Placeholder : MonoBehaviour
{
	[SerializeField]
	private ObjectManager.ObjectType m_objectType = ObjectManager.ObjectType.Undefined;

	[SerializeField]
	private int m_objectLevel;

	public ObjectManager.ObjectType objectType => m_objectType;

	public int objectLevel => m_objectLevel;
}
