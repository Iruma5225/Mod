using UnityEngine;

public class InteractionInstance_TakeFood : InteractionInstance_Base
{
	private Int_TakeFood interaction;

	private Obj_Base food_container;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_TakeFood;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		food_container = ((Component)this).GetComponent<Obj_Base>();
		if ((Object)(object)food_container == (Object)null)
		{
			return false;
		}
		FamilyAI component = ((Component)member).GetComponent<FamilyAI>();
		if ((Object)(object)component == (Object)null)
		{
			return false;
		}
		if (component.carriedFoodType == FamilyAI.FoodType.Ration)
		{
			Obj_Pantry obj_Pantry = food_container as Obj_Pantry;
			if ((Object)(object)obj_Pantry != (Object)null && obj_Pantry.GetRations() <= 0)
			{
				return false;
			}
		}
		else
		{
			Obj_Freezer obj_Freezer = food_container as Obj_Freezer;
			if ((Object)(object)obj_Freezer != (Object)null)
			{
				if (component.carriedFoodType == FamilyAI.FoodType.DesperateMeat)
				{
					if (!obj_Freezer.IsDesperateMeatAvailable())
					{
						return false;
					}
				}
				else if (component.carriedFoodType == FamilyAI.FoodType.Meat && !obj_Freezer.IsMeatAvailable())
				{
					return false;
				}
				obj_Freezer.PlayOpenFreezerSound();
			}
		}
		member.TriggerAnim("Rummage");
		interaction.RummageSoundEffect();
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled)
		{
			FamilyAI component = ((Component)member).GetComponent<FamilyAI>();
			if ((Object)(object)component != (Object)null)
			{
				if (component.carriedFoodType == FamilyAI.FoodType.Ration)
				{
					Obj_Pantry obj_Pantry = food_container as Obj_Pantry;
					if ((Object)(object)obj_Pantry != (Object)null)
					{
						int num = obj_Pantry.TakeRations(interaction.FoodUsed);
						component.CarriedFood_SetFoodTaken(num, rotten: false);
						component.CarriedFood_SetHungerReduction((float)num * interaction.HungerReduction);
					}
				}
				else if (component.carriedFoodType == FamilyAI.FoodType.Meat)
				{
					Obj_Freezer obj_Freezer = food_container as Obj_Freezer;
					if ((Object)(object)obj_Freezer != (Object)null)
					{
						int num2 = obj_Freezer.RemoveMeat(interaction.FoodUsed);
						bool rotten = obj_Freezer.IsMeatContaminated();
						component.CarriedFood_SetFoodTaken(num2, rotten);
						component.CarriedFood_SetHungerReduction((float)num2 * interaction.HungerReduction);
						obj_Freezer.PlayCloseFreezerSound();
					}
				}
				else if (component.carriedFoodType == FamilyAI.FoodType.DesperateMeat)
				{
					Obj_Freezer obj_Freezer2 = food_container as Obj_Freezer;
					if ((Object)(object)obj_Freezer2 != (Object)null)
					{
						int num3 = obj_Freezer2.RemoveDesperateMeat(interaction.FoodUsed);
						bool rotten2 = obj_Freezer2.IsMeatContaminated();
						component.CarriedFood_SetFoodTaken(num3, rotten2);
						component.CarriedFood_SetHungerReduction((float)num3 * interaction.HungerReduction);
						obj_Freezer2.PlayCloseFreezerSound();
					}
				}
			}
		}
		interaction.FinishedSoundEffect();
		return true;
	}
}
