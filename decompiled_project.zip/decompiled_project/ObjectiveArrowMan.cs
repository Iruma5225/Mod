using System.Collections.Generic;
using UnityEngine;

public class ObjectiveArrowMan : BaseManager
{
	public class ObjectiveInfo
	{
		public Transform target;

		public AudioClip reminderSound;

		public float reminderStartDelay;

		public float reminderWaitTime;

		public float reminderTimer;
	}

	private List<ObjectiveInfo> m_objectives = new List<ObjectiveInfo>();

	private List<ObjectiveArrow> m_arrows = new List<ObjectiveArrow>();

	private static ObjectiveArrowMan m_theInstance;

	[SerializeField]
	[Header("Door Stuff")]
	private Transform shelterDoors;

	[SerializeField]
	private AudioClip doorReminderSound;

	[SerializeField]
	private float doorReminderDelay;

	[SerializeField]
	private float doorReminderInterval;

	private List<BaseCharacter> waitingList = new List<BaseCharacter>();

	public static ObjectiveArrowMan Instance => m_theInstance;

	private void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
		}
		else
		{
			Debug.Log((object)"Duplicate ObjectiveArrowMan created!");
		}
	}

	public override void StartManager()
	{
		ObjectiveArrow[] componentsInChildren = ((Component)this).GetComponentsInChildren<ObjectiveArrow>();
		if (componentsInChildren != null && componentsInChildren.Length > 0)
		{
			m_arrows.AddRange(componentsInChildren);
		}
		for (int i = 0; i < m_arrows.Count; i++)
		{
			((Component)m_arrows[i]).gameObject.SetActive(false);
		}
	}

	public override void UpdateManager()
	{
		for (int i = 0; i < m_arrows.Count; i++)
		{
			m_arrows[i].UpdateArrow();
		}
		for (int j = 0; j < m_objectives.Count; j++)
		{
			m_objectives[j].reminderTimer -= PausableTime.deltaTime;
			if (m_objectives[j].reminderTimer <= 0f)
			{
				AudioManager.Instance.PlaySFX(m_objectives[j].reminderSound);
				m_objectives[j].reminderTimer = m_objectives[j].reminderWaitTime;
			}
		}
	}

	private void ReassignArrows()
	{
		int num = 0;
		for (num = 0; num < m_objectives.Count && num < m_arrows.Count; num++)
		{
			m_arrows[num].SetTarget(m_objectives[num].target);
			((Component)m_arrows[num]).gameObject.SetActive(true);
			m_arrows[num].UpdateArrow();
		}
		for (; num < m_arrows.Count; num++)
		{
			m_arrows[num].SetTarget(null);
			((Component)m_arrows[num]).gameObject.SetActive(false);
		}
	}

	public void AddObjective(Transform target, AudioClip reminderSound = null, float reminderTime = 0f, float reminderDelay = 0f)
	{
		if (!((Object)(object)target == (Object)null) && m_objectives.Find((ObjectiveInfo x) => (Object)(object)x.target == (Object)(object)target) == null)
		{
			ObjectiveInfo objectiveInfo = new ObjectiveInfo();
			objectiveInfo.target = target;
			objectiveInfo.reminderSound = reminderSound;
			objectiveInfo.reminderStartDelay = reminderDelay;
			objectiveInfo.reminderWaitTime = reminderTime;
			objectiveInfo.reminderTimer = reminderDelay;
			m_objectives.Add(objectiveInfo);
			ReassignArrows();
		}
	}

	public void RemoveObjective(Transform target)
	{
		if (!((Object)(object)target == (Object)null))
		{
			m_objectives.RemoveAll((ObjectiveInfo x) => (Object)(object)x.target == (Object)(object)target);
			ReassignArrows();
		}
	}

	public void AddWaitingCharacter(BaseCharacter character)
	{
		if (waitingList.Count <= 0)
		{
			AddObjective(shelterDoors, doorReminderSound, doorReminderDelay, doorReminderInterval);
		}
		waitingList.Add(character);
	}

	public void RemoveWaitingCharacter(BaseCharacter character)
	{
		waitingList.Remove(character);
		if (waitingList.Count <= 0)
		{
			RemoveObjective(shelterDoors);
		}
	}
}
