using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class JobQueue
{
	private List<Job> jobs = new List<Job>();

	private int max_size;

	[CompilerGenerated]
	private static Dictionary<string, int> _003C_003Ef__switch_0024map2;

	public int size => jobs.Count;

	public bool is_empty => jobs.Count == 0;

	public bool isFull => jobs.Count == max_size;

	public JobQueue(int max_queue_size)
	{
		max_size = Mathf.Max(0, max_queue_size);
	}

	public bool AddJob(Job new_job)
	{
		if (size >= max_size)
		{
			return false;
		}
		jobs.Add(new_job);
		return true;
	}

	public Job GetCurrent()
	{
		if (jobs.Count > 0)
		{
			return jobs[0];
		}
		return null;
	}

	public Job GetAt(int index)
	{
		if (index >= 0 && index < jobs.Count)
		{
			return jobs[index];
		}
		return null;
	}

	public void RemoveCurrent()
	{
		RemoveAt(0);
	}

	public void RemoveAt(int index)
	{
		if (index >= 0 && index < jobs.Count && jobs[index].state != Job.JobState.Started)
		{
			if (jobs[index].state != Job.JobState.Finished && jobs[index].GetCancelState() == Job.JobCancelState.Active)
			{
				jobs[index].Cancel(forced: true);
			}
			jobs.RemoveAt(index);
		}
	}

	public void IncreasePriority(int index)
	{
		if (index < 0 || index >= jobs.Count)
		{
			return;
		}
		switch (index)
		{
		case 0:
			break;
		case 1:
			if (jobs[0].state != Job.JobState.Started)
			{
				Job job = new Job(jobs[0]);
				job.Reset();
				jobs[0].Cancel(forced: false);
				jobs.Insert(2, job);
			}
			break;
		default:
		{
			Job value = jobs[index - 1];
			jobs[index - 1] = jobs[index];
			jobs[index] = value;
			break;
		}
		}
	}

	public void DecreasePriority(int index)
	{
		if (index < 0 || index >= jobs.Count)
		{
			return;
		}
		if (index == 0)
		{
			if (jobs[0].state != Job.JobState.Started && jobs.Count > 1)
			{
				Job job = new Job(jobs[0]);
				job.Reset();
				jobs[0].Cancel(forced: false);
				jobs.Insert(2, job);
			}
		}
		else if (index < jobs.Count - 1)
		{
			Job value = jobs[index + 1];
			jobs[index + 1] = jobs[index];
			jobs[index] = value;
		}
	}

	public void ForceClear()
	{
		for (int i = 0; i < jobs.Count; i++)
		{
			jobs[i].Cancel(forced: true);
		}
		if (jobs.Count > 1)
		{
			jobs.RemoveRange(1, jobs.Count - 1);
		}
	}

	public void SaveLoadJobQueue(SaveData data, string groupName)
	{
		data.GroupStart(groupName);
		data.SaveLoadList("jobs", jobs, delegate(int i)
		{
			jobs[i].SaveLoadJob(data);
		}, delegate
		{
			string value = string.Empty;
			data.SaveLoad("jobType", ref value);
			if (string.IsNullOrEmpty(value))
			{
				return;
			}
			Job job = null;
			if (value != null)
			{
				if (_003C_003Ef__switch_0024map2 == null)
				{
					_003C_003Ef__switch_0024map2 = new Dictionary<string, int>(11)
					{
						{ "Job", 0 },
						{ "Job_Craft", 1 },
						{ "Job_CraftRoom", 2 },
						{ "Job_GoToLocation", 3 },
						{ "Job_MoveCorpse", 4 },
						{ "Job_EatFood", 5 },
						{ "Job_Clean", 6 },
						{ "Job_Feed", 7 },
						{ "Job_Murder", 8 },
						{ "Job_LeaveShelter", 9 },
						{ "Job_ExtinguishFires", 10 }
					};
				}
				if (_003C_003Ef__switch_0024map2.TryGetValue(value, out var value2))
				{
					switch (value2)
					{
					case 0:
						break;
					case 1:
						goto IL_0122;
					case 2:
						goto IL_012d;
					case 3:
						goto IL_0138;
					case 4:
						goto IL_0143;
					case 5:
						goto IL_014e;
					case 6:
						goto IL_0159;
					case 7:
						goto IL_0164;
					case 8:
						goto IL_016f;
					case 9:
						goto IL_017a;
					case 10:
						goto IL_0185;
					default:
						goto IL_0190;
					}
					job = new Job();
					goto IL_019b;
				}
			}
			goto IL_0190;
			IL_0164:
			job = new Job_Feed();
			goto IL_019b;
			IL_016f:
			job = new Job_Murder();
			goto IL_019b;
			IL_0185:
			job = new Job_ExtinguishFires();
			goto IL_019b;
			IL_017a:
			job = new Job_LeaveShelter();
			goto IL_019b;
			IL_0190:
			job = new Job();
			goto IL_019b;
			IL_019b:
			if (job != null)
			{
				job.SaveLoadJob(data);
				jobs.Add(job);
			}
			return;
			IL_0122:
			job = new Job_Craft();
			goto IL_019b;
			IL_012d:
			job = new Job_CraftRoom();
			goto IL_019b;
			IL_0138:
			job = new Job_GoToLocation();
			goto IL_019b;
			IL_0143:
			job = new Job_MoveCorpse();
			goto IL_019b;
			IL_014e:
			job = new Job_EatFood();
			goto IL_019b;
			IL_0159:
			job = new Job_Clean();
			goto IL_019b;
		});
		data.GroupEnd();
	}
}
