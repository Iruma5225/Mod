using System;
using UnityEngine;

[AddComponentMenu("Pathfinding/Navmesh/RecastTileUpdate")]
public class RecastTileUpdate : MonoBehaviour
{
	public static event Action<Bounds> OnNeedUpdates;

	private void Start()
	{
		ScheduleUpdate();
	}

	private void OnDestroy()
	{
		ScheduleUpdate();
	}

	public void ScheduleUpdate()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		Collider component = ((Component)this).GetComponent<Collider>();
		if ((Object)(object)component != (Object)null)
		{
			if (RecastTileUpdate.OnNeedUpdates != null)
			{
				RecastTileUpdate.OnNeedUpdates(component.bounds);
			}
		}
		else if (RecastTileUpdate.OnNeedUpdates != null)
		{
			RecastTileUpdate.OnNeedUpdates(new Bounds(((Component)this).transform.position, Vector3.zero));
		}
	}
}
