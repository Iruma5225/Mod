using UnityEngine;

public class HatchAnimEvents : MonoBehaviour
{
	[SerializeField]
	private SpriteRenderer overlaySprite;

	private string prevSortLayer = string.Empty;

	private int prevSortOrder;

	private SpriteRenderer hatchSprite;

	private void Awake()
	{
		hatchSprite = ((Component)this).GetComponent<SpriteRenderer>();
	}

	public void OnHatchClose()
	{
		if ((Object)(object)hatchSprite != (Object)null && (Object)(object)overlaySprite != (Object)null)
		{
			prevSortLayer = ((Renderer)hatchSprite).sortingLayerName;
			prevSortOrder = ((Renderer)hatchSprite).sortingOrder;
			((Renderer)hatchSprite).sortingLayerName = ((Renderer)overlaySprite).sortingLayerName;
			((Renderer)hatchSprite).sortingOrder = ((Renderer)overlaySprite).sortingOrder + 1;
		}
	}

	public void OnHatchOpen()
	{
		if ((Object)(object)hatchSprite != (Object)null && !string.IsNullOrEmpty(prevSortLayer))
		{
			((Renderer)hatchSprite).sortingLayerName = prevSortLayer;
			((Renderer)hatchSprite).sortingOrder = prevSortOrder;
		}
	}
}
