using System.Collections.Generic;
using UnityEngine;

public class RelocationTransition_Entering : RelocationTransition_Base
{
	private List<FamilyMember> members = new List<FamilyMember>();

	private CompanionAnimal pet;

	private Obj_CamperVan vehicle;

	private Vector3 offscreenPos = Vector3.zero;

	private const float leaveVehicleDuration = 0.5f;

	private float leaveVehicleTimer;

	private List<GameObject> shelterNodes = new List<GameObject>();

	private int nodeIndex;

	private int memberIndex;

	private const float fadeDuration = 6f;

	private const float fadeDuration_Short = 2f;

	public RelocationTransition_Entering()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (Initialise())
		{
			Begin_SurfaceFade();
		}
	}

	private bool Initialise()
	{
		if ((Object)(object)RelocationManager.instance == (Object)null)
		{
			return false;
		}
		members = RelocationManager.instance.GetOldFamilyMembers();
		pet = FamilyManager.Instance.GetPet();
		if ((Object)(object)pet != (Object)null && ((pet.m_type != FamilySpawner.PetType.Dog && pet.m_type != FamilySpawner.PetType.Cat) || pet.isDead || pet.isAway || !pet.isVisible))
		{
			pet = null;
		}
		if ((Object)(object)ObjectManager.Instance != (Object)null)
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.CamperVan);
			if (objectsOfType != null && objectsOfType.Count > 0)
			{
				vehicle = objectsOfType[0] as Obj_CamperVan;
			}
		}
		return true;
	}

	private void Begin_SurfaceFade()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < members.Count; i++)
		{
			LockCharacter(members[i]);
		}
		Vector3 pos = Vector3.zero;
		if ((Object)(object)ExplorationManager.Instance != (Object)null)
		{
			List<GameObject> offScreenNodes = ExplorationManager.Instance.offScreenNodes;
			if (offScreenNodes.Count > 0)
			{
				pos = offScreenNodes[0].transform.position;
			}
		}
		for (int j = 0; j < members.Count; j++)
		{
			SetCharacterPosition(members[j], pos);
		}
		if ((Object)(object)pet != (Object)null)
		{
			pet.ReturnToShelter(6f);
		}
		Vector3 zero = Vector3.zero;
		if ((Object)(object)ShelterRoomGrid.Instance != (Object)null)
		{
			zero.x = (float)ShelterRoomGrid.Instance.grid_width * ShelterRoomGrid.Instance.grid_cell_width;
		}
		SetCameraZoom(zoom: false);
		SetCameraPosition(zero);
		FadeIn(2f);
		Begin_VehicleEntering();
	}

	private void Begin_VehicleEntering()
	{
		if ((Object)(object)vehicle != (Object)null)
		{
			vehicle.ReturnFromExpedition();
		}
		m_update = Update_VehicleEntering;
	}

	private TransitionResult Update_VehicleEntering()
	{
		if (!vehicle.isStationary)
		{
			return TransitionResult.Continue;
		}
		Begin_EnterShelter();
		return TransitionResult.Continue;
	}

	private void Begin_EnterShelter()
	{
		if ((Object)(object)RelocationManager.instance != (Object)null)
		{
			shelterNodes.AddRange(RelocationManager.instance.GetTransitionShelterNodes());
		}
		memberIndex = 0;
		leaveVehicleTimer = 0.5f;
		FadeOut(6f);
		m_update = Update_WaitForEnterShelter;
	}

	private TransitionResult Update_WaitForEnterShelter()
	{
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		if (IsFadeOver())
		{
			Begin_ShelterFade();
			return TransitionResult.Continue;
		}
		leaveVehicleTimer -= Time.deltaTime;
		if (leaveVehicleTimer <= 0f)
		{
			leaveVehicleTimer = 0.5f;
			if (memberIndex >= 0 && memberIndex < members.Count)
			{
				FamilyMember familyMember = members[memberIndex];
				if ((Object)(object)familyMember != (Object)null)
				{
					SetCharacterPosition(familyMember, vehicle.GetBoardingPosition());
					if (nodeIndex >= 0 && nodeIndex < shelterNodes.Count)
					{
						QueueCharacterMove(familyMember, shelterNodes[nodeIndex].transform.position);
						if (++nodeIndex >= shelterNodes.Count)
						{
							nodeIndex = 0;
						}
					}
				}
				memberIndex++;
			}
		}
		return TransitionResult.Continue;
	}

	private void Begin_ShelterFade()
	{
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)RelocationManager.instance != (Object)null)
		{
			shelterNodes.AddRange(RelocationManager.instance.GetTransitionShelterNodes());
		}
		for (int i = 0; i < members.Count; i++)
		{
			if (nodeIndex >= 0 && nodeIndex < shelterNodes.Count)
			{
				SetCharacterPosition(members[i], shelterNodes[nodeIndex].transform.position);
				if (++nodeIndex >= shelterNodes.Count)
				{
					nodeIndex = 0;
				}
			}
		}
		if ((Object)(object)pet != (Object)null && (Object)(object)FamilySpawner.instance != (Object)null)
		{
			((Component)pet).transform.position = FamilySpawner.instance.GetDefaultPositionForPet(pet.m_type);
		}
		for (int j = 0; j < members.Count; j++)
		{
			UnlockCharacter(members[j]);
		}
		SetCameraZoom(zoom: true);
		FadeIn(2f);
		m_update = Update_WaitForShelterFade;
	}

	private TransitionResult Update_WaitForShelterFade()
	{
		if (!IsFadeOver())
		{
			return TransitionResult.Continue;
		}
		return TransitionResult.End;
	}
}
