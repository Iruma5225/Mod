using UnityEngine;

[AddComponentMenu("Sheltered/Interaction/Add Fuel")]
public class Int_AddFuel : Int_Base
{
	public const float FuelPerJerryCan = 50f;

	[SerializeField]
	private AudioClip m_fillSound;

	public AudioClip fillSound => m_fillSound;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_AddFuel";
	}

	public override string GetInteractionType()
	{
		return "add_fuel";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		if (base.IsPlayerSelectable() && (Object)(object)InventoryManager.Instance != (Object)null && InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.Petrol) > 0)
		{
			return true;
		}
		return false;
	}
}
