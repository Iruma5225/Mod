using System;
using System.Collections.Generic;
using UnityEngine;

public class ShelterRoomGrid : MonoBehaviour, ISaveable
{
	public enum CellType
	{
		Empty,
		Dirt,
		Room,
		RoomTop,
		Surface,
		InProgress,
		Bedrock,
		BedrockTop,
		Max
	}

	public enum Direction
	{
		Up,
		Down,
		Left,
		Right,
		Max
	}

	public class GridCell
	{
		public GameObject prefab;

		public CellType type = CellType.Max;

		public GridCell[] neighbours = new GridCell[4];

		public Obj_Light lightObject;

		public List<ShelterLadder> ladders = new List<ShelterLadder>();

		public GridCell()
		{
			for (int i = 0; i < neighbours.Length; i++)
			{
				neighbours[i] = null;
			}
		}
	}

	public delegate void GridUpdateDelegate();

	private class SaveLoadCell
	{
		public int cellType = -1;

		public bool light;

		public bool lightEnabled;

		public int wall = -1;

		public bool isPainted;

		public Color paintColor = Color.white;

		public float paintApplyTime = -1f;

		public List<ShelterRoom.RoomGraffiti> graffiti = new List<ShelterRoom.RoomGraffiti>();

		public Sprite wires;
	}

	private static ShelterRoomGrid m_instance;

	private bool initialized;

	private GridCell[] grid;

	public int grid_width = 5;

	public int grid_height = 5;

	public float grid_cell_width = 4f;

	public float grid_cell_height = 4f;

	public int usable_layers = 1;

	public float floor_offset = 0.3f;

	public GameObject[] dirt_prefabs;

	public GameObject room_prefab;

	public GameObject room_prefab_top;

	public GameObject surface_prefab;

	public GameObject ladder_prefab;

	public GameObject in_progress_prefab;

	public GameObject bedrock_prefab;

	public GameObject bedrock_prefab_top;

	public GameObject path_root;

	private Rect shelter_bounds = default(Rect);

	private int m_uniqueLadderId = 1;

	private int m_numInitialLadders;

	private ShelterLadder m_hatchLadder;

	private List<ShelterLadder> m_spawnedLadders = new List<ShelterLadder>();

	[SerializeField]
	[Header("Graffiti")]
	private int maxGraffitiPerRoom = 3;

	[SerializeField]
	private List<Sprite> graffitiSprites = new List<Sprite>();

	[SerializeField]
	private List<Color> graffitiColours = new List<Color>();

	[SerializeField]
	[Header("Paint")]
	private float paintLifetime;

	[SerializeField]
	private float paintUpdateInterval = 5f;

	private float nextPaintUpdateTime;

	[SerializeField]
	private List<Sprite> paintSprites = new List<Sprite>();

	[Header("Wires")]
	[SerializeField]
	private List<Sprite> wiresSprites = new List<Sprite>();

	private GridUpdateDelegate onGridUpdate;

	public static ShelterRoomGrid Instance => m_instance;

	public bool isInitialized => initialized;

	public Rect GetShelterBounds()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return shelter_bounds;
	}

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
			return;
		}
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
	}

	private GameObject GetPrefab(CellType type)
	{
		return (GameObject)(type switch
		{
			CellType.Dirt => dirt_prefabs[Random.Range(0, dirt_prefabs.Length)], 
			CellType.Room => room_prefab, 
			CellType.RoomTop => room_prefab_top, 
			CellType.Surface => surface_prefab, 
			CellType.InProgress => in_progress_prefab, 
			CellType.Bedrock => bedrock_prefab, 
			CellType.BedrockTop => bedrock_prefab_top, 
			_ => null, 
		});
	}

	private GameObject GetRandomDirtPrefab()
	{
		return dirt_prefabs[Random.Range(0, dirt_prefabs.Length)];
	}

	private void InitializeGrid()
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		if (grid_width * grid_height <= 0 || dirt_prefabs.Length <= 0 || (Object)(object)room_prefab == (Object)null)
		{
			return;
		}
		grid = new GridCell[grid_width * grid_height];
		Vector3 zero = Vector3.zero;
		for (int i = 0; i < grid_height; i++)
		{
			for (int j = 0; j < grid_width; j++)
			{
				((Vector3)(ref zero)).Set((float)j * grid_cell_width, (float)(i + 1) * (0f - grid_cell_height), 0f);
				grid[i * grid_width + j] = new GridCell();
				GridCell gridCell = grid[i * grid_width + j];
				gridCell.type = CellType.Dirt;
				gridCell.prefab = Object.Instantiate<GameObject>(GetRandomDirtPrefab(), zero, Quaternion.identity);
				if ((Object)(object)gridCell.prefab != (Object)null)
				{
					((Object)gridCell.prefab).name = "X" + j.ToString("D2") + ":Y" + i.ToString("D2");
					gridCell.prefab.transform.parent = ((Component)this).transform;
				}
			}
		}
		GridCell gridCell2 = null;
		for (int k = 0; k < grid_height; k++)
		{
			for (int l = 0; l < grid_width; l++)
			{
				gridCell2 = grid[k * grid_width + l];
				if (l > 0)
				{
					gridCell2.neighbours[2] = grid[k * grid_width + l - 1];
				}
				if (l < grid_width - 1)
				{
					gridCell2.neighbours[3] = grid[k * grid_width + l + 1];
				}
				if (k > 0)
				{
					gridCell2.neighbours[0] = grid[(k - 1) * grid_width + l];
				}
				if (k < grid_height - 1)
				{
					gridCell2.neighbours[1] = grid[(k + 1) * grid_width + l];
				}
			}
		}
		int num = Mathf.Max(usable_layers + 1, 0);
		for (int num2 = grid_height - 1; num2 >= num; num2--)
		{
			for (int num3 = grid_width - 1; num3 >= 0; num3--)
			{
				SetCellType(num3, num2, (num2 <= num) ? CellType.BedrockTop : CellType.Bedrock);
			}
		}
		for (int m = 0; m < grid_width; m++)
		{
			SetCellType(m, 0, CellType.Surface);
		}
		if (grid_width > 2)
		{
			for (int n = 2; n < grid_width; n++)
			{
				SetCellType(n, 1, CellType.RoomTop);
			}
		}
		if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
		{
			AddLight(grid_width - 1, 1);
			AddLight(grid_width - 3, 1);
		}
		SetCellType(0, 1, CellType.Empty);
		SetCellType(1, 1, CellType.Empty);
		SetCellType(4, 2, CellType.Room);
		AddLadder(4, 1, 0.25f, initialLadder: true);
		if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
		{
			SetupRandomGraffiti();
			if (wiresSprites.Count > 0)
			{
				FillRoomsWithWires();
			}
		}
	}

	public bool SetCellType(int cell_x, int cell_y, CellType new_type)
	{
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		if (cell_x < 0 || cell_x > grid_width || cell_y < 0 || cell_y > grid_height)
		{
			return false;
		}
		GridCell gridCell = grid[cell_y * grid_width + cell_x];
		if (new_type == gridCell.type)
		{
			return false;
		}
		if (gridCell.type != CellType.Dirt && gridCell.type != CellType.Bedrock && gridCell.type != CellType.BedrockTop && gridCell.type != CellType.InProgress)
		{
			return false;
		}
		if ((Object)(object)gridCell.prefab != (Object)null)
		{
			ShelterRoom component = gridCell.prefab.GetComponent<ShelterRoom>();
			if ((Object)(object)component != (Object)null)
			{
				component.RemovePathnodes();
			}
			Object.Destroy((Object)(object)gridCell.prefab);
		}
		gridCell.type = new_type;
		GameObject prefab = GetPrefab(new_type);
		if ((Object)(object)prefab != (Object)null)
		{
			RemoveLight(cell_x, cell_y);
			Vector3 val = default(Vector3);
			((Vector3)(ref val))._002Ector((float)cell_x * grid_cell_width, (float)(cell_y + 1) * (0f - grid_cell_height), 0f);
			gridCell.prefab = Object.Instantiate<GameObject>(prefab, val, Quaternion.identity);
			if ((Object)(object)gridCell.prefab != (Object)null)
			{
				((Object)gridCell.prefab).name = "X" + cell_x.ToString("D2") + ":Y" + cell_y.ToString("D2");
				gridCell.prefab.transform.parent = ((Component)this).transform;
			}
			ShelterRoom component2 = gridCell.prefab.GetComponent<ShelterRoom>();
			if ((Object)(object)component2 != (Object)null)
			{
				if (wiresSprites.Count > 0)
				{
					component2.SetWiring(wiresSprites[Random.Range(0, wiresSprites.Count)]);
				}
				List<ShelterLadder> laddersForRoom = GetLaddersForRoom(cell_x, cell_y - 1);
				if (laddersForRoom != null && laddersForRoom.Count > 0)
				{
					for (int i = 0; i < laddersForRoom.Count; i++)
					{
						component2.OnLadderPlaced(laddersForRoom[i]);
					}
				}
			}
		}
		else if (gridCell.type != CellType.Empty)
		{
			return false;
		}
		OnGridUpdated(cell_x, cell_y);
		return true;
	}

	public bool SetCellType(Vector3 world_pos, CellType new_type)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		int cell_x = -1;
		int cell_y = -1;
		if (WorldCoordsToCellCoords(world_pos, out cell_x, out cell_y))
		{
			return SetCellType(cell_x, cell_y, new_type);
		}
		return false;
	}

	public ShelterLadder GetLadder(int ladderId)
	{
		if ((Object)(object)m_hatchLadder != (Object)null && m_hatchLadder.ladderId == ladderId)
		{
			return m_hatchLadder;
		}
		for (int i = 0; i < m_spawnedLadders.Count; i++)
		{
			if ((Object)(object)m_spawnedLadders[i] != (Object)null && m_spawnedLadders[i].ladderId == ladderId)
			{
				return m_spawnedLadders[i];
			}
		}
		return null;
	}

	public void RegisterHatchLadder(ShelterLadder ladder)
	{
		m_hatchLadder = ladder;
		m_hatchLadder.SetLadderId(0);
	}

	public ShelterLadder AddLadder(int top_x, int top_y, float horizontal_pos, bool initialLadder = false)
	{
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		if (top_x < 0 || top_x > grid_width || top_y < 0 || top_y > grid_height)
		{
			return null;
		}
		GridCell gridCell = grid[top_y * grid_width + top_x];
		if (top_y >= grid_height - 1)
		{
			return null;
		}
		GridCell gridCell2 = grid[(top_y + 1) * grid_width + top_x];
		if (gridCell == null || gridCell2 == null || (gridCell.type != CellType.Room && gridCell.type != CellType.RoomTop) || (gridCell2.type != CellType.Room && gridCell2.type != CellType.InProgress))
		{
			return null;
		}
		if ((Object)(object)ladder_prefab == (Object)null)
		{
			return null;
		}
		GameObject val = Object.Instantiate<GameObject>(ladder_prefab, gridCell.prefab.transform.position, Quaternion.identity);
		if ((Object)(object)val != (Object)null)
		{
			ShelterLadder componentInChildren = val.GetComponentInChildren<ShelterLadder>();
			if ((Object)(object)componentInChildren != (Object)null)
			{
				horizontal_pos = Mathf.Clamp(horizontal_pos, 0f, 1f);
				if ((Object)(object)componentInChildren.ladder_object != (Object)null)
				{
					Vector3 position = componentInChildren.ladder_object.transform.position;
					position.x += Mathf.Clamp(horizontal_pos, 0f, 1f) * grid_cell_width;
					componentInChildren.ladder_object.transform.position = position;
				}
				componentInChildren.SetLadderId(m_uniqueLadderId++);
				m_spawnedLadders.Add(componentInChildren);
				gridCell.ladders.Add(componentInChildren);
				if (initialLadder)
				{
					m_numInitialLadders++;
				}
				componentInChildren.m_topCellX = top_x;
				componentInChildren.m_topCellY = top_y;
				componentInChildren.m_horizontalPos = Mathf.Clamp(horizontal_pos, 0f, 1f);
			}
			((Object)val).name = "ladder";
			val.transform.parent = gridCell.prefab.transform;
			ShelterRoom component = gridCell2.prefab.GetComponent<ShelterRoom>();
			if ((Object)(object)component != (Object)null)
			{
				component.OnLadderPlaced(componentInChildren);
			}
			return componentInChildren;
		}
		return null;
	}

	public bool RemoveLadders(int top_x, int top_y)
	{
		if (top_x < 0 || top_x > grid_width || top_y < 0 || top_y > grid_height)
		{
			return false;
		}
		GridCell gridCell = grid[top_y * grid_width + top_x];
		if (gridCell == null)
		{
			return false;
		}
		if ((Object)(object)gridCell.prefab == (Object)null)
		{
			return false;
		}
		List<Transform> list = new List<Transform>();
		for (int i = 0; i < gridCell.prefab.transform.childCount; i++)
		{
			Transform child = gridCell.prefab.transform.GetChild(i);
			if ((Object)(object)child != (Object)null && ((Object)child).name == "ladder")
			{
				list.Add(child);
			}
		}
		if (list.Count < 0)
		{
			return false;
		}
		for (int j = 0; j < list.Count; j++)
		{
			if ((Object)(object)list[j] == (Object)null)
			{
				continue;
			}
			ShelterLadder componentInChildren = ((Component)list[j]).GetComponentInChildren<ShelterLadder>();
			if ((Object)(object)componentInChildren != (Object)null)
			{
				componentInChildren.RemovePathnodes();
				gridCell.ladders.Remove(componentInChildren);
				if (m_spawnedLadders.Contains(componentInChildren))
				{
					m_spawnedLadders.Remove(componentInChildren);
				}
			}
			Object.Destroy((Object)(object)((Component)list[j]).gameObject);
		}
		return true;
	}

	private List<ShelterLadder> GetLaddersForRoom(int top_x, int top_y)
	{
		if (top_x < 0 || top_x > grid_width || top_y < 0 || top_y > grid_height)
		{
			return null;
		}
		return grid[top_y * grid_width + top_x]?.ladders;
	}

	public bool HasLadder(int top_x, int top_y)
	{
		List<ShelterLadder> laddersForRoom = GetLaddersForRoom(top_x, top_y);
		return laddersForRoom != null && laddersForRoom.Count > 0;
	}

	public bool AddLight(int cell_x, int cell_y)
	{
		if (cell_x < 0 || cell_x > grid_width || cell_y < 0 || cell_y > grid_height)
		{
			return false;
		}
		GridCell gridCell = grid[cell_y * grid_width + cell_x];
		if (gridCell.type != CellType.RoomTop && gridCell.type != CellType.Room)
		{
			return false;
		}
		if ((Object)(object)gridCell.lightObject != (Object)null)
		{
			return false;
		}
		if ((Object)(object)gridCell.prefab != (Object)null)
		{
			ShelterRoom component = gridCell.prefab.GetComponent<ShelterRoom>();
			if ((Object)(object)component != (Object)null)
			{
				gridCell.lightObject = component.SpawnRoomLight();
				if ((Object)(object)gridCell.lightObject != (Object)null)
				{
					gridCell.lightObject.switchOnLightResetTimer();
				}
				return true;
			}
		}
		return false;
	}

	public bool RemoveLight(int cell_x, int cell_y)
	{
		if (cell_x < 0 || cell_x > grid_width || cell_y < 0 || cell_y > grid_height)
		{
			return false;
		}
		GridCell gridCell = grid[cell_y * grid_width + cell_x];
		if (gridCell.type != CellType.RoomTop && gridCell.type != CellType.Room)
		{
			return false;
		}
		if ((Object)(object)gridCell.lightObject != (Object)null)
		{
			ObjectManager.Instance.RemoveObject(gridCell.lightObject);
			gridCell.lightObject = null;
		}
		return true;
	}

	public bool SetWall(int cell_x, int cell_y, int index)
	{
		if (cell_x < 0 || cell_x > grid_width || cell_y < 0 || cell_y > grid_height)
		{
			return false;
		}
		GridCell gridCell = grid[cell_y * grid_width + cell_x];
		if (gridCell.type != CellType.RoomTop && gridCell.type != CellType.Room)
		{
			return false;
		}
		if ((Object)(object)gridCell.prefab != (Object)null)
		{
			ShelterRoom component = gridCell.prefab.GetComponent<ShelterRoom>();
			if ((Object)(object)component != (Object)null)
			{
				component.SetWallSprite(index);
				return true;
			}
		}
		return false;
	}

	public bool SetupRandomGraffiti()
	{
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		List<ShelterRoom> list = new List<ShelterRoom>();
		for (int i = 0; i < grid_height; i++)
		{
			for (int j = 0; j < grid_width; j++)
			{
				GridCell gridCell = grid[i * grid_width + j];
				if ((gridCell.type == CellType.RoomTop || gridCell.type == CellType.Room) && (Object)(object)gridCell.prefab != (Object)null)
				{
					ShelterRoom component = gridCell.prefab.GetComponent<ShelterRoom>();
					if ((Object)(object)component != (Object)null)
					{
						list.Add(component);
					}
				}
			}
		}
		List<int> list2 = new List<int>();
		for (int k = 0; k < list.Count; k++)
		{
			list2.Add(Random.Range(0, maxGraffitiPerRoom));
		}
		List<Sprite> list3 = new List<Sprite>(graffitiSprites);
		for (int l = 0; l < list.Count * maxGraffitiPerRoom; l++)
		{
			if (list3.Count <= 0)
			{
				break;
			}
			int index = l % list.Count;
			if (list2[index] > 0)
			{
				Color color = Color.white;
				if (graffitiColours.Count > 0)
				{
					color = graffitiColours[Random.Range(0, graffitiColours.Count)];
				}
				int index2 = Random.Range(0, list3.Count);
				list[index].ShowGraffiti(list3[index2], color);
				list3.RemoveAt(index2);
				list2[index]--;
			}
		}
		return true;
	}

	public bool SetGraffiti(int cell_x, int cell_y, Sprite sprite, Color color)
	{
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		if (cell_x < 0 || cell_x > grid_width || cell_y < 0 || cell_y > grid_height)
		{
			return false;
		}
		GridCell gridCell = grid[cell_y * grid_width + cell_x];
		if (gridCell.type != CellType.RoomTop && gridCell.type != CellType.Room)
		{
			return false;
		}
		if ((Object)(object)gridCell.prefab != (Object)null)
		{
			ShelterRoom component = gridCell.prefab.GetComponent<ShelterRoom>();
			if ((Object)(object)component != (Object)null)
			{
				component.ShowGraffiti(sprite, color);
				return true;
			}
		}
		return false;
	}

	public bool ClearGraffiti(int cell_x, int cell_y)
	{
		if (cell_x < 0 || cell_x > grid_width || cell_y < 0 || cell_y > grid_height)
		{
			return false;
		}
		GridCell gridCell = grid[cell_y * grid_width + cell_x];
		if (gridCell.type != CellType.RoomTop && gridCell.type != CellType.Room)
		{
			return false;
		}
		if ((Object)(object)gridCell.prefab != (Object)null)
		{
			ShelterRoom component = gridCell.prefab.GetComponent<ShelterRoom>();
			if ((Object)(object)component != (Object)null)
			{
				component.RemoveAllGraffiti();
				return true;
			}
		}
		return false;
	}

	public bool PaintRoom(int cell_x, int cell_y, Color color, float apply_time = -1f)
	{
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		if (cell_x < 0 || cell_x > grid_width || cell_y < 0 || cell_y > grid_height)
		{
			return false;
		}
		GridCell gridCell = grid[cell_y * grid_width + cell_x];
		if (gridCell.type != CellType.RoomTop && gridCell.type != CellType.Room)
		{
			return false;
		}
		if ((Object)(object)gridCell.prefab != (Object)null)
		{
			ShelterRoom component = gridCell.prefab.GetComponent<ShelterRoom>();
			if ((Object)(object)component != (Object)null && (gridCell.type == CellType.RoomTop || gridCell.type == CellType.Room) && paintSprites.Count > 0)
			{
				component.PaintWall(paintSprites[0], color, apply_time);
				return true;
			}
		}
		return false;
	}

	public bool RemovePaint(int cell_x, int cell_y)
	{
		if (cell_x < 0 || cell_x > grid_width || cell_y < 0 || cell_y > grid_height)
		{
			return false;
		}
		GridCell gridCell = grid[cell_y * grid_width + cell_x];
		if (gridCell.type != CellType.RoomTop && gridCell.type != CellType.Room)
		{
			return false;
		}
		if ((Object)(object)gridCell.prefab != (Object)null)
		{
			ShelterRoom component = gridCell.prefab.GetComponent<ShelterRoom>();
			if ((Object)(object)component != (Object)null)
			{
				component.RemovePaint();
				return true;
			}
		}
		return false;
	}

	public bool PaintOverRoom(int cell_x, int cell_y, float progress)
	{
		if (cell_x < 0 || cell_x > grid_width || cell_y < 0 || cell_y > grid_height)
		{
			return false;
		}
		GridCell gridCell = grid[cell_y * grid_width + cell_x];
		if (gridCell.type != CellType.RoomTop && gridCell.type != CellType.Room)
		{
			return false;
		}
		if ((Object)(object)gridCell.prefab != (Object)null)
		{
			ShelterRoom component = gridCell.prefab.GetComponent<ShelterRoom>();
			if ((Object)(object)component != (Object)null)
			{
				component.PaintOverRoom(progress);
				return true;
			}
		}
		return false;
	}

	private void UpdateRoomPaint()
	{
		for (int i = 0; i < grid.Length; i++)
		{
			if ((grid[i].type != CellType.RoomTop && grid[i].type != CellType.Room) || !((Object)(object)grid[i].prefab != (Object)null))
			{
				continue;
			}
			ShelterRoom component = grid[i].prefab.GetComponent<ShelterRoom>();
			if (!((Object)(object)component == (Object)null) && !(component.PaintApplyTime < 0f))
			{
				float num = (Time.time - component.PaintApplyTime) / (component.PaintApplyTime + paintLifetime);
				Sprite paintSprite = null;
				if (grid[i].type == CellType.RoomTop || grid[i].type == CellType.Room)
				{
					int index = Mathf.Clamp(Mathf.FloorToInt(num * (float)paintSprites.Count), 0, paintSprites.Count - 1);
					paintSprite = paintSprites[index];
				}
				component.SetPaintSprite(paintSprite);
			}
		}
	}

	public bool FillRoomsWithWires()
	{
		if (wiresSprites.Count <= 0)
		{
			return false;
		}
		for (int i = 0; i < grid_height; i++)
		{
			for (int j = 0; j < grid_width; j++)
			{
				GridCell gridCell = grid[i * grid_width + j];
				if ((gridCell.type == CellType.RoomTop || gridCell.type == CellType.Room) && (Object)(object)gridCell.prefab != (Object)null)
				{
					ShelterRoom component = gridCell.prefab.GetComponent<ShelterRoom>();
					if ((Object)(object)component != (Object)null && (Object)(object)component.GetWires() == (Object)null)
					{
						component.SetWiring(wiresSprites[Random.Range(0, wiresSprites.Count)]);
					}
				}
			}
		}
		SetWiring(2, 1, wiresSprites[0]);
		return true;
	}

	public bool SetWiring(int cell_x, int cell_y, Sprite sprite)
	{
		if (cell_x < 0 || cell_x > grid_width || cell_y < 0 || cell_y > grid_height)
		{
			return false;
		}
		GridCell gridCell = grid[cell_y * grid_width + cell_x];
		if (gridCell.type != CellType.RoomTop && gridCell.type != CellType.Room)
		{
			return false;
		}
		if ((Object)(object)gridCell.prefab != (Object)null)
		{
			ShelterRoom component = gridCell.prefab.GetComponent<ShelterRoom>();
			if ((Object)(object)component != (Object)null)
			{
				component.SetWiring(sprite);
				return true;
			}
		}
		return false;
	}

	private void OnGridUpdated(int cell_x, int cell_y)
	{
		GridCell gridCell = grid[cell_y * grid_width + cell_x];
		RefreshCellNeighbourStates(gridCell);
		for (int i = 0; i < 4; i++)
		{
			RefreshCellNeighbourStates(gridCell.neighbours[i]);
		}
		UpdateCurrentShelterBounds();
		if (onGridUpdate != null)
		{
			onGridUpdate();
		}
	}

	private void RefreshCellNeighbourStates(GridCell cell)
	{
		if (cell == null || (cell.type != CellType.Room && cell.type != CellType.RoomTop))
		{
			return;
		}
		CellType[] array = new CellType[4];
		for (int i = 0; i < 4; i++)
		{
			if (cell.neighbours[i] == null)
			{
				array[i] = CellType.Max;
			}
			else
			{
				array[i] = cell.neighbours[i].type;
			}
		}
		ShelterRoom component = cell.prefab.GetComponent<ShelterRoom>();
		if ((Object)(object)component != (Object)null)
		{
			component.OnNeighboursChanged(array);
		}
	}

	public bool WorldCoordsToCellCoords(Vector3 world_pos, out int cell_x, out int cell_y)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = world_pos - ((Component)this).transform.position;
		val.y *= -1f;
		int num = Mathf.FloorToInt(val.x / grid_cell_width);
		int num2 = Mathf.FloorToInt(val.y / grid_cell_height);
		if (num >= 0 && num < grid_width && num2 >= 0 && num2 < grid_height)
		{
			cell_x = num;
			cell_y = num2;
			return true;
		}
		cell_x = -1;
		cell_y = -1;
		return false;
	}

	public Vector3 CellCoordsToWorldCoords(int cell_x, int cell_y)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		Vector3 zero = Vector3.zero;
		zero.x = (float)cell_x * grid_cell_width;
		zero.y = (float)cell_y * grid_cell_height;
		zero.y *= -1f;
		return zero;
	}

	public GridCell GetCell(int cell_x, int cell_y)
	{
		if (cell_x >= 0 && cell_x < grid_width && cell_y >= 0 && cell_y < grid_height)
		{
			return grid[cell_y * grid_width + cell_x];
		}
		return null;
	}

	public GridCell GetCell(Vector3 world_pos)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		int cell_x = -1;
		int cell_y = -1;
		if (WorldCoordsToCellCoords(world_pos, out cell_x, out cell_y))
		{
			return GetCell(cell_x, cell_y);
		}
		return null;
	}

	public float GetFloorY(int cell_x, int cell_y)
	{
		float result = 0f;
		GridCell cell = Instance.GetCell(cell_x, cell_y);
		if (cell != null)
		{
			result = 0f - (float)(cell_y + 1) * Instance.grid_cell_height;
			result += Instance.floor_offset;
		}
		return result;
	}

	public float GetFloorY(Vector3 world_pos)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		float result = 0f;
		int cell_x = -1;
		int cell_y = -1;
		if (WorldCoordsToCellCoords(world_pos, out cell_x, out cell_y))
		{
			result = GetFloorY(cell_x, cell_y);
		}
		return result;
	}

	public bool IsOnSurface(int cell_x, int cell_y)
	{
		GridCell cell = GetCell(cell_x, cell_y);
		if (cell != null && cell.type == CellType.Surface)
		{
			return true;
		}
		return false;
	}

	public bool IsOnSurface(Vector3 world_pos)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		int cell_x = -1;
		int cell_y = -1;
		if (WorldCoordsToCellCoords(world_pos, out cell_x, out cell_y))
		{
			return IsOnSurface(cell_x, cell_y);
		}
		return true;
	}

	public bool NeedsLadder(int cell_x, int cell_y)
	{
		GridCell cell = GetCell(cell_x, cell_y);
		if (cell != null && (cell.neighbours[2] == null || (cell.neighbours[2].type != CellType.Room && cell.neighbours[2].type != CellType.RoomTop)) && (cell.neighbours[3] == null || (cell.neighbours[3].type != CellType.Room && cell.neighbours[3].type != CellType.RoomTop)))
		{
			return true;
		}
		return false;
	}

	public bool NeedsLadder(Vector3 world_pos)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		int cell_x = -1;
		int cell_y = -1;
		if (WorldCoordsToCellCoords(world_pos, out cell_x, out cell_y))
		{
			return NeedsLadder(cell_x, cell_y);
		}
		return true;
	}

	public void Update()
	{
		if (!initialized && (Object)(object)AstarPath.active != (Object)null)
		{
			InitializeGrid();
			initialized = true;
		}
	}

	public void UpdateCurrentShelterBounds()
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		for (int num = grid_width * grid_height - 1; num >= 0; num--)
		{
			flag = false;
			if (grid[num].type == CellType.Room || grid[num].type == CellType.RoomTop || grid[num].type == CellType.InProgress)
			{
				flag = true;
			}
			if (flag)
			{
				((Rect)(ref shelter_bounds)).Set(((Component)this).transform.position.x, ((Component)this).transform.position.y, (float)grid_width * grid_cell_width, ((float)Mathf.CeilToInt((float)(num + 1) / (float)grid_width) * grid_cell_height + grid_cell_height) * -1f);
				return;
			}
		}
		((Rect)(ref shelter_bounds)).Set(0f, 0f, 0f, 0f);
	}

	public void RegisterForGridUpdate(GridUpdateDelegate onGU)
	{
		onGridUpdate = (GridUpdateDelegate)Delegate.Combine(onGridUpdate, onGU);
	}

	public bool FindReachableRooms(Vector2 currentPos, int maxRooms, out int leftmostX, out int rightmostX, out int currentY)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		leftmostX = -1;
		rightmostX = -1;
		currentY = -1;
		int cell_x = -1;
		int cell_y = -1;
		if (WorldCoordsToCellCoords(Vector2.op_Implicit(currentPos), out cell_x, out cell_y))
		{
			int num = 0;
			for (int i = 1; i <= maxRooms; i++)
			{
				GridCell cell = GetCell(cell_x - i, cell_y);
				if (cell == null || (cell.type != CellType.Room && cell.type != CellType.RoomTop))
				{
					break;
				}
				num++;
			}
			int num2 = 0;
			for (int j = 1; j <= maxRooms; j++)
			{
				GridCell cell2 = Instance.GetCell(cell_x + j, cell_y);
				if (cell2 == null || (cell2.type != CellType.Room && cell2.type != CellType.RoomTop))
				{
					break;
				}
				num2++;
			}
			leftmostX = cell_x - num;
			rightmostX = cell_x + num2;
			currentY = cell_y;
			return true;
		}
		return false;
	}

	public bool IsRelocationEnabled()
	{
		return false;
	}

	public bool IsReadyForLoad()
	{
		return initialized;
	}

	public bool SaveLoad(SaveData data)
	{
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		data.GroupStart("ShelterRoomGrid");
		List<SaveLoadCell> cellInfo = new List<SaveLoadCell>();
		for (int i = 0; i < grid.Length; i++)
		{
			SaveLoadCell saveLoadCell = new SaveLoadCell();
			saveLoadCell.cellType = (int)grid[i].type;
			saveLoadCell.light = (Object.op_Implicit((Object)(object)grid[i].lightObject) ? true : false);
			saveLoadCell.lightEnabled = Object.op_Implicit((Object)(object)grid[i].lightObject) && grid[i].lightObject.IsEnabled();
			if ((grid[i].type == CellType.RoomTop || grid[i].type == CellType.Room) && (Object)(object)grid[i].prefab != (Object)null)
			{
				ShelterRoom component = grid[i].prefab.GetComponent<ShelterRoom>();
				if ((Object)(object)component != (Object)null)
				{
					saveLoadCell.wall = component.GetWallSprite();
					saveLoadCell.isPainted = component.isPainted;
					saveLoadCell.paintColor = component.PaintColor;
					saveLoadCell.paintApplyTime = component.PaintApplyTime;
					saveLoadCell.graffiti = component.GetAllGraffiti();
					saveLoadCell.wires = component.GetWires();
				}
			}
			cellInfo.Add(saveLoadCell);
		}
		data.SaveLoadList("cell_info", cellInfo, delegate(int index)
		{
			SaveLoadCell cell = cellInfo[index];
			data.SaveLoad("type", ref cell.cellType);
			data.SaveLoad("light", ref cell.light);
			data.SaveLoad("lightEnabled", ref cell.lightEnabled);
			if (cell.cellType == 2 || cell.cellType == 3)
			{
				data.SaveLoad("wall", ref cell.wall);
				data.SaveLoad("is_painted", ref cell.isPainted);
				if (cell.isPainted)
				{
					data.SaveLoad("paint_color", ref cell.paintColor);
					data.SaveLoadAbsoluteTime("paint_time", ref cell.paintApplyTime);
				}
				int value = cell.graffiti.Count;
				data.SaveLoad("graffitiCount", ref value);
				for (int j = 0; j < value; j++)
				{
					int value2 = graffitiSprites.FindIndex((Sprite sprite) => (Object)(object)sprite == (Object)(object)cell.graffiti[j].sprite);
					if (value2 >= 0)
					{
						data.SaveLoad("graffiti" + j, ref value2);
						data.SaveLoad("graffiti" + j + "_color", ref cell.graffiti[j].color);
					}
				}
				int value3 = wiresSprites.FindIndex((Sprite sprite) => (Object)(object)sprite == (Object)(object)cell.wires);
				if (value3 >= 0)
				{
					data.SaveLoad("wires", ref value3);
				}
			}
		}, delegate(int num)
		{
			//IL_02e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_0335: Unknown result type (might be due to invalid IL or missing references)
			SaveLoadCell saveLoadCell2 = new SaveLoadCell();
			data.SaveLoad("type", ref saveLoadCell2.cellType);
			data.SaveLoad("light", ref saveLoadCell2.light);
			data.SaveLoad("lightEnabled", ref saveLoadCell2.lightEnabled);
			if (saveLoadCell2.cellType == 2 || saveLoadCell2.cellType == 3)
			{
				data.SaveLoad("wall", ref saveLoadCell2.wall);
				data.SaveLoad("is_painted", ref saveLoadCell2.isPainted);
				if (saveLoadCell2.isPainted)
				{
					data.SaveLoad("paint_color", ref saveLoadCell2.paintColor);
					data.SaveLoadAbsoluteTime("paint_time", ref saveLoadCell2.paintApplyTime);
				}
				int value = 0;
				data.SaveLoad("graffitiCount", ref value);
				for (int j = 0; j < value; j++)
				{
					ShelterRoom.RoomGraffiti roomGraffiti = new ShelterRoom.RoomGraffiti();
					int value2 = -1;
					data.SaveLoad("graffiti" + j, ref value2);
					if (value2 >= 0 && value2 < graffitiSprites.Count)
					{
						roomGraffiti.sprite = graffitiSprites[value2];
						data.SaveLoad("graffiti" + j + "_color", ref roomGraffiti.color);
						saveLoadCell2.graffiti.Add(roomGraffiti);
					}
				}
				int value3 = -1;
				data.SaveLoad("wires", ref value3);
				if (value3 >= 0 && value3 < wiresSprites.Count)
				{
					saveLoadCell2.wires = wiresSprites[value3];
				}
			}
			int cell_x = num % grid_width;
			int cell_y = num / grid_width;
			if (saveLoadCell2.cellType != (int)grid[num].type)
			{
				SetCellType(cell_x, cell_y, (CellType)saveLoadCell2.cellType);
			}
			if (saveLoadCell2.light)
			{
				AddLight(cell_x, cell_y);
			}
			if ((Object)(object)grid[num].lightObject != (Object)null)
			{
				if (saveLoadCell2.lightEnabled)
				{
					grid[num].lightObject.EnableObject();
				}
				else
				{
					grid[num].lightObject.DisableObject();
				}
			}
			if (saveLoadCell2.wall >= 0)
			{
				SetWall(cell_x, cell_y, saveLoadCell2.wall);
			}
			RemovePaint(cell_x, cell_y);
			if (saveLoadCell2.isPainted)
			{
				PaintRoom(cell_x, cell_y, saveLoadCell2.paintColor, saveLoadCell2.paintApplyTime);
			}
			ClearGraffiti(cell_x, cell_y);
			for (int k = 0; k < saveLoadCell2.graffiti.Count; k++)
			{
				SetGraffiti(cell_x, cell_y, saveLoadCell2.graffiti[k].sprite, saveLoadCell2.graffiti[k].color);
			}
			SetWiring(cell_x, cell_y, saveLoadCell2.wires);
		});
		if (data.isLoading)
		{
			UpdateRoomPaint();
		}
		if (data.isLoading)
		{
			FillRoomsWithWires();
		}
		List<ShelterLadder> initialLadders = new List<ShelterLadder>();
		initialLadders.AddRange(m_spawnedLadders);
		data.SaveLoadList("spawnedLadders", m_spawnedLadders, delegate(int index)
		{
			int value = m_spawnedLadders[index].ladderId;
			int value2 = m_spawnedLadders[index].m_topCellX;
			int value3 = m_spawnedLadders[index].m_topCellY;
			float value4 = m_spawnedLadders[index].m_horizontalPos;
			data.SaveLoad("id", ref value);
			data.SaveLoad("cellx", ref value2);
			data.SaveLoad("celly", ref value3);
			data.SaveLoad("hpos", ref value4);
		}, delegate(int num)
		{
			if (num >= m_numInitialLadders)
			{
				int value = -1;
				int value2 = -1;
				int value3 = -1;
				float value4 = 0f;
				data.SaveLoad("id", ref value);
				data.SaveLoad("cellx", ref value2);
				data.SaveLoad("celly", ref value3);
				data.SaveLoad("hpos", ref value4);
				ShelterLadder shelterLadder = AddLadder(value2, value3, value4);
				if ((Object)(object)shelterLadder != (Object)null)
				{
					shelterLadder.SetLadderId(value);
					initialLadders.Add(shelterLadder);
				}
			}
		});
		m_spawnedLadders.Clear();
		m_spawnedLadders.AddRange(initialLadders);
		data.SaveLoad("nextLadderId", ref m_uniqueLadderId);
		data.SaveLoadTransform(((Component)this).transform);
		data.GroupEnd();
		return true;
	}
}
