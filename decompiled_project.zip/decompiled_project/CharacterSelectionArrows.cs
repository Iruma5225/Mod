using UnityEngine;

public class CharacterSelectionArrows : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}

	public void SelectNextCharacter()
	{
		if ((Object)(object)InteractionManager.Instance != (Object)null)
		{
			if ((Object)(object)InteractionManager.Instance.SelectedObject != (Object)null)
			{
				InteractionManager.Instance.UnSelectObject(InteractionManager.Instance.SelectedObject);
			}
			InteractionManager.Instance.SelectNextFamilyMember();
		}
	}

	public void SelectPreviousCharacter()
	{
		if ((Object)(object)InteractionManager.Instance != (Object)null)
		{
			if ((Object)(object)InteractionManager.Instance.SelectedObject != (Object)null)
			{
				InteractionManager.Instance.UnSelectObject(InteractionManager.Instance.SelectedObject);
			}
			InteractionManager.Instance.SelectPrevFamilyMember();
		}
	}
}
