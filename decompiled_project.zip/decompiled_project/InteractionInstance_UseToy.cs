using System.Collections.Generic;
using UnityEngine;

public class InteractionInstance_UseToy : InteractionInstance_Base
{
	private Int_UseToy interaction;

	protected override bool CanCancelImmediately()
	{
		return false;
	}

	private void Start()
	{
	}

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_UseToy;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		if ((Object)(object)member != (Object)null)
		{
			if (!member.isChild)
			{
				member.Say(Localization.Get("text.speech.adultnotoy"));
				return false;
			}
			if (EntertainmentManager.Instance.Toys <= 0)
			{
				return false;
			}
			if (member.stats.fatigue.Value >= 75f)
			{
				member.Say(Localization.Get("text.speech.tooTired"));
				return false;
			}
			member.TriggerAnim("Rummage");
		}
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		float num = 0f;
		if (!base.cancelled)
		{
			float num2 = EntertainmentManager.Instance.OnToyUsed(member);
			member.stats.stress.Modify(0f - num2);
			int num3 = EntertainmentManager.Instance.Toys * interaction.toyExpAward;
			int num4 = num3;
			int num5 = 0;
			List<BaseStats.StatType> toyStatsToAwardExp = interaction.ToyStatsToAwardExp;
			for (int i = 0; i < toyStatsToAwardExp.Count; i++)
			{
				if (i == toyStatsToAwardExp.Count - 1)
				{
					member.BaseStats.GetStatByEnum(toyStatsToAwardExp[i]).IncreaseExp(num4);
					break;
				}
				num5 = Random.Range(0, num4 + 1);
				member.BaseStats.GetStatByEnum(toyStatsToAwardExp[i]).IncreaseExp(num5);
				num4 -= num5;
			}
		}
		return true;
	}
}
