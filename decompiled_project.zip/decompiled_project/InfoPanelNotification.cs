using System;
using UnityEngine;

public class InfoPanelNotification : MonoBehaviour
{
	private UISprite m_sprite;

	[SerializeField]
	private UILabel m_helpText;

	[SerializeField]
	private int m_helpTextCount = 2;

	[SerializeField]
	private float m_minAlpha;

	[SerializeField]
	private float m_pulseInterval = 1f;

	private float m_pulseTimeOffset;

	public bool isShowing => (Object)(object)m_sprite != (Object)null && ((Behaviour)m_sprite).enabled;

	public void Awake()
	{
		m_sprite = ((Component)this).GetComponent<UISprite>();
	}

	public void Activate()
	{
		if ((Object)(object)m_sprite != (Object)null)
		{
			((Behaviour)m_sprite).enabled = true;
			m_sprite.alpha = 0f;
			m_pulseTimeOffset = m_pulseInterval - (Time.realtimeSinceStartup + Time.deltaTime) % m_pulseInterval;
		}
		if ((Object)(object)m_helpText != (Object)null && m_helpTextCount > 0)
		{
			((Component)m_helpText).gameObject.SetActive(true);
			m_helpText.alpha = 0f;
		}
		BoxCollider2D component = ((Component)this).GetComponent<BoxCollider2D>();
		if ((Object)(object)component != (Object)null)
		{
			((Behaviour)component).enabled = true;
		}
	}

	public void Deactivate()
	{
		if ((Object)(object)m_sprite != (Object)null)
		{
			((Behaviour)m_sprite).enabled = false;
		}
		if ((Object)(object)m_helpText != (Object)null)
		{
			((Component)m_helpText).gameObject.SetActive(false);
		}
		if (m_helpTextCount > 0)
		{
			m_helpTextCount--;
		}
		BoxCollider2D component = ((Component)this).GetComponent<BoxCollider2D>();
		if ((Object)(object)component != (Object)null)
		{
			((Behaviour)component).enabled = false;
		}
	}

	public void Update()
	{
		if ((Object)(object)m_sprite != (Object)null && ((Behaviour)m_sprite).enabled)
		{
			float num = Mathf.Sin((m_pulseTimeOffset + Time.realtimeSinceStartup) / m_pulseInterval * 2f * (float)Math.PI);
			num = (num + 1f) * 0.5f;
			m_sprite.alpha = m_minAlpha + num * (1f - m_minAlpha);
			if ((Object)(object)m_helpText != (Object)null && m_helpTextCount > 0)
			{
				m_helpText.alpha = m_minAlpha + num * (1f - m_minAlpha);
			}
		}
	}

	public void OpenInfoPanel()
	{
		if (UIPanelManager.Instance().IsGameInputActive() && (!((Object)(object)RelocationManager.instance != (Object)null) || !RelocationManager.instance.isTransitioning) && (Object)(object)UI_PanelContainer.Instance.InfoPanel != (Object)null && !UI_PanelContainer.Instance.InfoPanel.IsShowing())
		{
			UIPanelManager.Instance().PushPanel(UI_PanelContainer.Instance.InfoPanel);
		}
	}
}
