using System;
using UnityEngine;

[Serializable]
public abstract class Interruption_Base
{
	protected FamilyMember m_member;

	private bool m_active;

	[SerializeField]
	private float duration;

	protected float start_time;

	protected float end_time;

	public bool isActive => m_active;

	public virtual void UpdateInterruption()
	{
	}

	protected virtual void OnStartInterruption()
	{
		m_member.OnInterruptionStarted();
	}

	protected virtual void OnEndInterruption()
	{
		m_member.OnInterruptionFinished();
	}

	public virtual void Initialize(FamilyMember member)
	{
		m_member = member;
	}

	public void Activate()
	{
		if (!m_active)
		{
			m_active = true;
			start_time = Time.time;
			end_time = start_time + duration;
			OnStartInterruption();
		}
	}

	protected void Deactivate()
	{
		if (m_active)
		{
			m_active = false;
			OnEndInterruption();
		}
	}

	public virtual void SaveLoadInterruption(SaveData data)
	{
		data.SaveLoad("active", ref m_active);
		data.SaveLoadAbsoluteTime("start_time", ref start_time);
		data.SaveLoadAbsoluteTime("end_time", ref end_time);
	}
}
