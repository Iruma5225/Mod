using System.Collections.Generic;

public class Obj_AmmoPress : Obj_Integrity
{
	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.AmmoPress;
	}

	public override void Awake()
	{
		base.Awake();
	}

	public override List<string> GetTooltipExtraInfo()
	{
		return new List<string>();
	}
}
