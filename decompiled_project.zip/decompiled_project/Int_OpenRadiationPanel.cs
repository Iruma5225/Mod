public class Int_OpenRadiationPanel : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "open_radiation_panel";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		return !obj.isBurningOrBurntOut && base.InteractionEnabled;
	}

	public override bool IsPlayerSelectableWithoutValidMember()
	{
		return IsPlayerSelectable();
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		return false;
	}
}
