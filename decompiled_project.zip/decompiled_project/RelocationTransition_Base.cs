using System.Collections.Generic;
using UnityEngine;

public class RelocationTransition_Base
{
	public enum TransitionResult
	{
		Continue,
		End
	}

	public delegate TransitionResult TransitionUpdate();

	protected TransitionUpdate m_update;

	private BasicCamera gameCam;

	public RelocationTransition_Base()
	{
		Begin_Transition();
	}

	public TransitionResult UpdateTransition()
	{
		TransitionResult transitionResult = TransitionResult.End;
		if (m_update != null)
		{
			transitionResult = m_update();
		}
		if (transitionResult == TransitionResult.End)
		{
			Finish_Transition();
		}
		return transitionResult;
	}

	private void Begin_Transition()
	{
		Camera main = Camera.main;
		if ((Object)(object)main != (Object)null)
		{
			gameCam = ((Component)main).GetComponent<BasicCamera>();
		}
		if ((Object)(object)RelocationManager.instance != (Object)null)
		{
			List<UIPanel> panelsToDisableDuringTransition = RelocationManager.instance.GetPanelsToDisableDuringTransition();
			if (panelsToDisableDuringTransition != null && panelsToDisableDuringTransition.Count > 0)
			{
				for (int i = 0; i < panelsToDisableDuringTransition.Count; i++)
				{
					((Component)panelsToDisableDuringTransition[i]).gameObject.SetActive(false);
				}
			}
		}
		TooltipperObj.ShowTooltip(null);
	}

	private void Finish_Transition()
	{
		if ((Object)(object)RelocationManager.instance != (Object)null)
		{
			List<UIPanel> panelsToDisableDuringTransition = RelocationManager.instance.GetPanelsToDisableDuringTransition();
			if (panelsToDisableDuringTransition != null && panelsToDisableDuringTransition.Count > 0)
			{
				for (int i = 0; i < panelsToDisableDuringTransition.Count; i++)
				{
					((Component)panelsToDisableDuringTransition[i]).gameObject.SetActive(true);
				}
			}
		}
		if ((Object)(object)gameCam != (Object)null)
		{
			gameCam.SetCursor(CursorBase.CursorType.Standard);
		}
	}

	protected bool SetCameraPosition(Vector3 pos)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)gameCam != (Object)null)
		{
			gameCam.SnapToPosition(Vector2.op_Implicit(pos));
			return true;
		}
		return false;
	}

	protected bool SetCameraZoom(bool zoom)
	{
		if ((Object)(object)gameCam != (Object)null)
		{
			gameCam.SetPendingZoom(zoom);
			return true;
		}
		return false;
	}

	protected bool IsFadeOver()
	{
		return (Object)(object)FadeManager.Instance == (Object)null || !FadeManager.Instance.IsFading();
	}

	protected void FadeOut(float duration)
	{
		if ((Object)(object)FadeManager.Instance != (Object)null)
		{
			FadeManager.Instance.SetFadeLength(duration);
			FadeManager.Instance.FadeToBlack(force: true);
		}
	}

	protected void FadeIn(float duration)
	{
		if ((Object)(object)FadeManager.Instance != (Object)null)
		{
			FadeManager.Instance.SetFadeLength(duration);
			FadeManager.Instance.FadeFromBlack(force: true);
		}
	}

	protected void LockCharacter(BaseCharacter character)
	{
		SetCharacterLocked(character, locked: true);
	}

	protected void UnlockCharacter(BaseCharacter character)
	{
		SetCharacterLocked(character, locked: false);
	}

	protected void SetCharacterLocked(BaseCharacter character, bool locked)
	{
		if ((Object)(object)character == (Object)null)
		{
			return;
		}
		FamilyMember familyMember = character as FamilyMember;
		if ((Object)(object)familyMember != (Object)null)
		{
			familyMember.isUncontrollable = locked;
			if (familyMember.automation && locked)
			{
				familyMember.ToggleAutomation();
			}
		}
	}

	protected bool SetCharacterPosition(BaseCharacter character, Vector3 pos)
	{
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)character != (Object)null && (Object)(object)((Component)character).transform != (Object)null)
		{
			FamilyMember familyMember = character as FamilyMember;
			if ((Object)(object)familyMember != (Object)null)
			{
				familyMember.job_queue.ForceClear();
				familyMember.ai_queue.ForceClear();
				familyMember.CancelCurrentJob(immediate: true);
				familyMember.CancelCurrentAIJob(immediate: true);
			}
			if (character.isClimbingOrWaiting)
			{
				character.StopClimbingImmediately();
			}
			character.ClearPath();
			((Component)character).transform.position = pos;
			if ((Object)(object)ShelterRoomGrid.Instance != (Object)null)
			{
				character.SetOutside(ShelterRoomGrid.Instance.IsOnSurface(pos));
			}
			return true;
		}
		return false;
	}

	protected bool QueueCharacterMove(BaseCharacter character, Vector3 pos)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)character == (Object)null)
		{
			return false;
		}
		bool flag = false;
		FamilyMember familyMember = character as FamilyMember;
		if ((Object)(object)familyMember != (Object)null)
		{
			return familyMember.AddAIJob(new Job_GoToLocation(familyMember, pos, cancellableInTransit: false));
		}
		character.ClearPath();
		character.WalkToPosition(pos);
		return true;
	}
}
