using UnityEngine;

public class MapButton : MonoBehaviour
{
	[SerializeField]
	private UI_ExpeditionMap map_screen;

	public void OnPress(bool isDown)
	{
	}
}
