using UnityEngine;

public class PlatformAtlasSwitcher : MonoBehaviour
{
	[SerializeField]
	private UIAtlas m_referenceAtlas;

	[SerializeField]
	private UIAtlas m_XboneAtlas;

	private static PlatformAtlasSwitcher m_instance;

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
			return;
		}
		if ((Object)(object)m_referenceAtlas != (Object)null)
		{
			m_referenceAtlas.replacement = null;
			if ((Object)(object)m_XboneAtlas != (Object)null)
			{
				m_referenceAtlas.replacement = m_XboneAtlas;
			}
		}
	}
}
