public interface ISaveable
{
	bool IsRelocationEnabled();

	bool IsReadyForLoad();

	bool SaveLoad(SaveData data);
}
