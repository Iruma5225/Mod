using System;
using System.Collections.Generic;
using UnityEngine;

public class LeaderboardsPanel : BasePanel
{
	public List<LeaderboardConfig> leaderboards = new List<LeaderboardConfig>();

	public AudioClip m_OpenSound;

	public AudioClip m_CloseSound;

	public GameObject m_focus_button;

	public bool m_closeOnCancelButton = true;

	private PlatformLeaderboards_Base m_platform;

	private const float kReadDelay = 0.5f;

	private const float kMinBusyTime = 0.5f;

	private LeaderboardData resultsData = new LeaderboardData();

	private int boardIndex;

	private LeaderboardFilter filter;

	private int firstRow = 1;

	private int pageNumber = 1;

	private int numPages;

	private int rowsPerPage;

	private int skipToPageWithRank;

	private bool isBusy;

	private bool readFinished;

	private bool hasError;

	private float pendingReadTimer;

	private float busyMessageShowTime;

	private GameObject lastFocusedButton;

	[SerializeField]
	private UILabel titleLabel;

	[SerializeField]
	private UILabel filterLabel;

	[SerializeField]
	private UILabel pageLabel;

	[SerializeField]
	private GameObject notificationBox;

	[SerializeField]
	private UILocalize notificationText;

	private List<UILabel> rankLabels = new List<UILabel>();

	private List<UILabel> nameLabels = new List<UILabel>();

	private List<UIButton> nameButtons = new List<UIButton>();

	private List<UILabel> scoreLabels = new List<UILabel>();

	private List<UILabel> daysLabels = new List<UILabel>();

	[SerializeField]
	private GameObject m_filterPcControls;

	[SerializeField]
	private GameObject m_leaderboardPcControls;

	[SerializeField]
	private UIButton m_pcScrollUpButton;

	[SerializeField]
	private UIButton m_pcScrollDownButton;

	private TweenAlpha m_tween;

	private bool m_inputDisabled;

	private bool m_tweeningOut;

	private int kMaxRowsToRead => (m_platform == null) ? 50 : m_platform.GetMaxRowsToRead();

	private void Awake()
	{
		m_tween = ((Component)this).GetComponent<TweenAlpha>();
		if (m_platform == null)
		{
			m_platform = new PlatformLeaderboards_GPS();
			m_platform.onReadComplete += OnLeaderboardReadComplete;
		}
		bool flag = true;
		flag &= FindRowElements<UILabel>("Grids/RanksGrid", ref rankLabels);
		flag &= FindRowElements<UILabel>("Grids/PlayerNamesGrid", ref nameLabels);
		flag &= FindRowElements<UIButton>("Grids/PlayerNamesGrid", ref nameButtons);
		flag &= FindRowElements<UILabel>("Grids/DaysGrid", ref daysLabels);
		if ((Object)(object)titleLabel == (Object)null || (Object)(object)filterLabel == (Object)null || (Object)(object)notificationBox == (Object)null || (Object)(object)notificationText == (Object)null || (Object)(object)pageLabel == (Object)null || !flag)
		{
			throw new Exception("Leaderboards screen failed to find some of its UI elements");
		}
		rowsPerPage = rankLabels.Count;
	}

	public override void Update()
	{
		if (m_platform != null)
		{
			m_platform.Update();
		}
		if (pendingReadTimer > Mathf.Epsilon)
		{
			pendingReadTimer -= RealTime.deltaTime;
			if (pendingReadTimer <= Mathf.Epsilon)
			{
				ReadLeaderboard();
				pendingReadTimer = 0f;
			}
		}
		if (readFinished && RealTime.time >= busyMessageShowTime + 0.5f)
		{
			readFinished = false;
			SetBusy(busy: false);
			if (!hasError)
			{
				PopulateLeaderboard();
			}
			else
			{
				ShowLeaderboardErrorMessage();
			}
		}
	}

	public void OnPrevLeaderboard()
	{
		if (m_inputDisabled || isBusy)
		{
			return;
		}
		int num = boardIndex;
		uint num2;
		for (num2 = 0u; num2 < leaderboards.Count; num2++)
		{
			num--;
			if (num < 0)
			{
				num = leaderboards.Count - 1;
			}
			if (IsLeaderboardValid(leaderboards[num]))
			{
				break;
			}
		}
		if (num2 < leaderboards.Count)
		{
			boardIndex = num;
			UpdateHeaders();
			notificationBox.SetActive(false);
			firstRow = 1;
			pageNumber = 1;
			skipToPageWithRank = 1;
			pendingReadTimer = 0.5f;
		}
	}

	public void OnNextLeaderboard()
	{
		if (m_inputDisabled || isBusy)
		{
			return;
		}
		int num = boardIndex;
		uint num2;
		for (num2 = 0u; num2 < leaderboards.Count; num2++)
		{
			num++;
			if (num == leaderboards.Count)
			{
				num = 0;
			}
			if (IsLeaderboardValid(leaderboards[num]))
			{
				break;
			}
		}
		if (num2 < leaderboards.Count)
		{
			boardIndex = num;
			UpdateHeaders();
			notificationBox.SetActive(false);
			firstRow = 1;
			pageNumber = 1;
			skipToPageWithRank = 1;
			pendingReadTimer = 0.5f;
		}
	}

	public void OnPrevFilter()
	{
		if (!m_inputDisabled && !isBusy)
		{
			if (filter != LeaderboardFilter.Overall)
			{
				filter--;
			}
			else if (filter == LeaderboardFilter.Overall)
			{
				filter = (LeaderboardFilter)(Enum.GetNames(typeof(LeaderboardFilter)).Length - 1);
			}
			UpdateHeaders();
			notificationBox.SetActive(false);
			firstRow = 1;
			skipToPageWithRank = 1;
			pendingReadTimer = 0.5f;
		}
	}

	public void OnNextFilter()
	{
		if (!m_inputDisabled && !isBusy)
		{
			if ((uint)filter < Enum.GetNames(typeof(LeaderboardFilter)).Length - 1)
			{
				filter++;
			}
			else if ((uint)filter == Enum.GetNames(typeof(LeaderboardFilter)).Length - 1)
			{
				filter = LeaderboardFilter.Overall;
			}
			UpdateHeaders();
			notificationBox.SetActive(false);
			firstRow = 1;
			skipToPageWithRank = 1;
			pendingReadTimer = 0.5f;
		}
	}

	public void OnPreviousPage()
	{
		if (!m_inputDisabled && !isBusy)
		{
			if (pageNumber > 1)
			{
				pageNumber--;
				PopulateLeaderboard();
				UpdateScrollArrows();
			}
			else if (filter == LeaderboardFilter.Overall && firstRow > 1)
			{
				firstRow = Mathf.Max(firstRow - kMaxRowsToRead, 1);
				skipToPageWithRank = resultsData.rows[0].rank - 1;
				ReadLeaderboard();
				pendingReadTimer = 0f;
			}
		}
	}

	public void OnNextPage()
	{
		if (!m_inputDisabled && !isBusy)
		{
			if (pageNumber < numPages)
			{
				pageNumber++;
				PopulateLeaderboard();
				UpdateScrollArrows();
			}
			else if (filter == LeaderboardFilter.Overall && resultsData.totalRows >= firstRow + numPages * rowsPerPage)
			{
				firstRow += numPages * rowsPerPage;
				skipToPageWithRank = resultsData.rows.Back().rank + 1;
				ReadLeaderboard();
				pendingReadTimer = 0f;
			}
		}
	}

	public void OnFirstPage()
	{
		if (!m_inputDisabled && !isBusy)
		{
			if (firstRow == 1)
			{
				pageNumber = 1;
				PopulateLeaderboard();
				UpdateScrollArrows();
			}
			else if (filter == LeaderboardFilter.Overall)
			{
				firstRow = 1;
				skipToPageWithRank = 1;
				ReadLeaderboard();
				pendingReadTimer = 0f;
			}
		}
	}

	public void OnLastPage()
	{
		if (m_inputDisabled || isBusy)
		{
			return;
		}
		if (firstRow > resultsData.totalRows - resultsData.rows.Count)
		{
			pageNumber = numPages;
			PopulateLeaderboard();
			UpdateScrollArrows();
		}
		else if (filter == LeaderboardFilter.Overall)
		{
			firstRow = Mathf.Max(resultsData.totalRows - kMaxRowsToRead + 1, 1);
			int num = (firstRow - 1) % rowsPerPage;
			if (num > 0)
			{
				firstRow += rowsPerPage - num;
			}
			skipToPageWithRank = int.MaxValue;
			ReadLeaderboard();
			pendingReadTimer = 0f;
		}
	}

	public void OnNameSelected(GameObject obj)
	{
		if (m_inputDisabled || isBusy)
		{
			return;
		}
		UIButton component = obj.GetComponent<UIButton>();
		if ((Object)(object)component == (Object)null)
		{
			Debug.Log((object)"Error: Can't find UIButton");
			return;
		}
		int num = -1;
		num = nameButtons.Count - 1;
		while (num >= 0 && !((Object)(object)nameButtons[num] == (Object)(object)component))
		{
			num--;
		}
		if (num >= 0)
		{
			int num2 = (pageNumber - 1) * rowsPerPage + num;
			if (num2 >= 0 && num2 < resultsData.rows.Count)
			{
				m_platform.ShowPlayerInfo(resultsData.rows[num2]);
			}
		}
	}

	private bool IsLeaderboardValid(LeaderboardConfig board)
	{
		return true;
	}

	private void ReadLeaderboard()
	{
		if (!isBusy)
		{
			ClearLeaderboard();
			if (m_platform.ReadLeaderboard(leaderboards[boardIndex], filter, firstRow, kMaxRowsToRead))
			{
				SetBusy(busy: true);
			}
		}
	}

	private void OnLeaderboardReadComplete(bool success, LeaderboardData results, bool closeMenu)
	{
		if (closeMenu && (Object)(object)UIPanelManager.instance != (Object)null)
		{
			UIPanelManager.instance.PopPanel(this);
			return;
		}
		if (success)
		{
			resultsData = results;
			UpdatePagingForResults();
		}
		hasError = !success;
		readFinished = true;
	}

	private bool FindRowElements<T>(string parentName, ref List<T> elementsList) where T : Component
	{
		if (string.IsNullOrEmpty(parentName) || elementsList == null)
		{
			return false;
		}
		elementsList.Clear();
		Transform val = ((Component)this).transform.Find(parentName);
		if ((Object)(object)val != (Object)null)
		{
			List<Transform> list = new List<Transform>();
			for (int i = 0; i < val.childCount; i++)
			{
				if ((Object)(object)((Component)val.GetChild(i)).GetComponentInChildren<T>() != (Object)null)
				{
					list.Add(val.GetChild(i));
				}
			}
			list.Sort((Transform x, Transform y) => ((Object)x).name.CompareTo(((Object)y).name));
			foreach (Transform item in list)
			{
				elementsList.Add(((Component)item).GetComponentInChildren<T>());
			}
		}
		return elementsList.Count > 0;
	}

	private void ResetResultsData()
	{
		resultsData.displayName = string.Empty;
		resultsData.totalRows = 0;
		resultsData.rows.Clear();
		pageNumber = 1;
		numPages = 1;
	}

	private void SetBusy(bool busy)
	{
		isBusy = busy;
		if (busy)
		{
			notificationBox.SetActive(false);
			notificationText.key = "Text.UI.Leaderboards.Busy";
			notificationBox.SetActive(true);
			busyMessageShowTime = RealTime.time;
			lastFocusedButton = UICamera.selectedObject;
			UICamera.selectedObject = null;
			return;
		}
		notificationText.key = string.Empty;
		notificationBox.SetActive(false);
		busyMessageShowTime = 0f;
		GameObject val = null;
		if (filter == LeaderboardFilter.MyScore)
		{
			for (int i = 0; i < resultsData.rows.Count; i++)
			{
				if (resultsData.rows[i].isMyScore)
				{
					int num = (resultsData.rows[i].rank - resultsData.rows[0].rank) % rowsPerPage;
					if (num > 0 && num < nameButtons.Count)
					{
						val = (UICamera.selectedObject = ((Component)nameButtons[num]).gameObject);
					}
					break;
				}
			}
		}
		if (!((Object)(object)val == (Object)null))
		{
			return;
		}
		for (int j = 0; j < nameButtons.Count; j++)
		{
			int num2 = (pageNumber - 1) * rowsPerPage + j;
			if (num2 < resultsData.rows.Count)
			{
				val = ((Component)nameButtons[j]).gameObject;
			}
			if ((Object)(object)((Component)nameButtons[j]).gameObject == (Object)(object)lastFocusedButton)
			{
				if (num2 < resultsData.rows.Count)
				{
					UICamera.selectedObject = ((Component)nameButtons[j]).gameObject;
				}
				else
				{
					UICamera.selectedObject = val;
				}
				break;
			}
		}
	}

	private void ClearLeaderboard()
	{
		ResetResultsData();
		foreach (UILabel rankLabel in rankLabels)
		{
			rankLabel.text = string.Empty;
		}
		foreach (UILabel nameLabel in nameLabels)
		{
			nameLabel.text = string.Empty;
		}
		foreach (UILabel scoreLabel in scoreLabels)
		{
			scoreLabel.text = string.Empty;
		}
		foreach (UILabel daysLabel in daysLabels)
		{
			daysLabel.text = string.Empty;
		}
		pageLabel.text = string.Empty;
	}

	private void UpdateHeaders()
	{
		if (boardIndex >= 0 && boardIndex < leaderboards.Count)
		{
			titleLabel.text = Localization.Get(leaderboards[boardIndex].localizeName);
			filterLabel.text = Localization.Get("Text.UI.Leaderboards.Filter." + filter);
		}
	}

	private void PopulateLeaderboard()
	{
		UpdateHeaders();
		if (resultsData.rows.Count == 0)
		{
			string key = string.Empty;
			switch (filter)
			{
			case LeaderboardFilter.Overall:
				key = "Text.UI.Leaderboards.NoScores";
				break;
			case LeaderboardFilter.MyScore:
				key = "Text.UI.Leaderboards.PlayerNotPosted";
				break;
			case LeaderboardFilter.Friends:
				key = "Text.UI.Leaderboards.FriendsNotPosted";
				break;
			}
			notificationText.key = key;
			notificationBox.SetActive(true);
			return;
		}
		if (pageNumber < 1)
		{
			pageNumber = 1;
		}
		GameObject selectedObject = null;
		for (int i = 0; i < rowsPerPage; i++)
		{
			int num = (pageNumber - 1) * rowsPerPage + i;
			if (num < resultsData.rows.Count)
			{
				rankLabels[i].text = resultsData.rows[num].rank + ".";
				nameLabels[i].alignment = NGUIText.Alignment.Left;
				nameLabels[i].text = resultsData.rows[num].name;
				daysLabels[i].text = resultsData.rows[num].days;
				if (i < scoreLabels.Count)
				{
					scoreLabels[i].text = resultsData.rows[num].score;
				}
				((Component)nameButtons[i]).gameObject.SetActive(true);
				selectedObject = ((Component)nameButtons[i]).gameObject;
				if ((Object)(object)UICamera.selectedObject == (Object)null && (Object)(object)UICamera.nextSelection == (Object)null)
				{
					UICamera.selectedObject = selectedObject;
				}
			}
			else
			{
				rankLabels[i].text = "-";
				nameLabels[i].alignment = NGUIText.Alignment.Center;
				nameLabels[i].text = "-";
				daysLabels[i].text = "-";
				if (i < scoreLabels.Count)
				{
					scoreLabels[i].text = "-";
				}
				if ((Object)(object)UICamera.selectedObject == (Object)(object)((Component)nameButtons[i]).gameObject)
				{
					UICamera.selectedObject = selectedObject;
				}
				((Component)nameButtons[i]).gameObject.SetActive(false);
			}
		}
		float num2 = (float)resultsData.totalRows / (float)rowsPerPage;
		int num3 = (int)Mathf.Ceil(num2);
		int num4 = (int)Mathf.Ceil((float)(firstRow / rowsPerPage)) + pageNumber;
		pageLabel.text = num4.ToString("D") + "/" + num3.ToString("D");
	}

	private void UpdatePagingForResults()
	{
		float num = (float)resultsData.rows.Count / (float)rowsPerPage;
		numPages = (int)Mathf.Ceil(num);
		pageNumber = 1;
		if (resultsData.rows.Count > 0)
		{
			int rank = resultsData.rows[0].rank;
			int rank2 = resultsData.rows.Back().rank;
			if (filter == LeaderboardFilter.MyScore || filter == LeaderboardFilter.Friends)
			{
				for (int i = 0; i < resultsData.rows.Count; i++)
				{
					if (resultsData.rows[i].isMyScore)
					{
						skipToPageWithRank = resultsData.rows[i].rank;
						break;
					}
				}
			}
			skipToPageWithRank = Mathf.Clamp(skipToPageWithRank, rank, rank2);
			pageNumber = (skipToPageWithRank - rank) / rowsPerPage + 1;
		}
		UpdateScrollArrows();
	}

	private void UpdateScrollArrows()
	{
		int num = resultsData.totalRows / rowsPerPage;
		if (resultsData.totalRows % rowsPerPage > 0)
		{
			num++;
		}
		int num2 = (int)Mathf.Ceil((float)(firstRow / rowsPerPage)) + pageNumber;
		if ((Object)(object)m_pcScrollUpButton != (Object)null)
		{
			((Behaviour)m_pcScrollUpButton).enabled = num2 > 1;
			m_pcScrollUpButton.SetState((num2 <= 1) ? UIButtonColor.State.Disabled : UIButtonColor.State.Normal, immediate: true);
		}
		if ((Object)(object)m_pcScrollDownButton != (Object)null)
		{
			((Behaviour)m_pcScrollDownButton).enabled = num2 < num;
			m_pcScrollDownButton.SetState((num2 >= num) ? UIButtonColor.State.Disabled : UIButtonColor.State.Normal, immediate: true);
		}
	}

	private void ShowLeaderboardErrorMessage()
	{
		string message = "Text.UI.Leaderboards.FailedGeneric";
		MessageBox.Show(MessageBoxButtons.Okay_Button, message, OnErrorMessageDismissed);
	}

	private void OnErrorMessageDismissed(int response)
	{
		if ((Object)(object)UIPanelManager.instance != (Object)null)
		{
			UIPanelManager.instance.PopPanel(this);
		}
	}

	public override void OnCancel()
	{
		if (m_inputDisabled)
		{
			Debug.Log((object)"input disabled");
			return;
		}
		base.OnCancel();
		if (m_closeOnCancelButton)
		{
			if ((Object)(object)m_tween != (Object)null)
			{
				m_inputDisabled = true;
				m_tweeningOut = true;
				m_tween.PlayReverse();
			}
			else if ((Object)(object)UIPanelManager.instance != (Object)null)
			{
				UIPanelManager.instance.PopPanel(this);
			}
		}
	}

	public override void OnSelect()
	{
	}

	public override void OnExtra1()
	{
		if (!m_inputDisabled && !isBusy)
		{
			OnNextLeaderboard();
		}
	}

	public override void OnExtra2()
	{
		if (!m_inputDisabled && !isBusy)
		{
			OnNextFilter();
		}
	}

	public override void OnTabLeft()
	{
		if (!m_inputDisabled && !isBusy)
		{
			OnPreviousPage();
		}
	}

	public override void OnTabRight()
	{
		if (!m_inputDisabled && !isBusy)
		{
			OnNextPage();
		}
	}

	public override void OnShow()
	{
		if ((Object)(object)m_tween != (Object)null)
		{
			m_inputDisabled = true;
			m_tweeningOut = false;
			m_tween.PlayForward();
		}
		else
		{
			m_inputDisabled = false;
		}
		bool active = true;
		if ((Object)(object)m_filterPcControls != (Object)null)
		{
			m_filterPcControls.SetActive(active);
		}
		if ((Object)(object)m_leaderboardPcControls != (Object)null)
		{
			m_leaderboardPcControls.SetActive(active);
		}
		if ((Object)(object)m_pcScrollUpButton != (Object)null)
		{
			((Component)m_pcScrollUpButton).gameObject.SetActive(active);
		}
		if ((Object)(object)m_pcScrollDownButton != (Object)null)
		{
			((Component)m_pcScrollDownButton).gameObject.SetActive(active);
		}
		if ((Object)(object)m_OpenSound != (Object)null)
		{
			UISound.instance.Play(m_OpenSound);
		}
		if ((Object)(object)m_focus_button != (Object)null)
		{
			UICamera.selectedObject = m_focus_button;
		}
		boardIndex = 0;
		filter = LeaderboardFilter.Overall;
		hasError = false;
		pendingReadTimer = 0.1f;
		if ((Object)(object)m_tween != (Object)null)
		{
			pendingReadTimer += m_tween.duration;
		}
		resultsData.rows = new List<RowData>();
		ClearLeaderboard();
		UpdateHeaders();
		skipToPageWithRank = 1;
		lastFocusedButton = null;
		SetBusy(busy: false);
		base.OnShow();
	}

	public override void OnClose()
	{
		if ((Object)(object)m_CloseSound != (Object)null)
		{
			UISound.instance.Play(m_CloseSound);
		}
		if (m_platform != null)
		{
			m_platform.Reset();
		}
		base.OnClose();
	}

	public void OnTweenFinished()
	{
		if (m_tweeningOut)
		{
			if ((Object)(object)UIPanelManager.instance != (Object)null)
			{
				UIPanelManager.instance.PopPanel(this);
			}
		}
		else
		{
			m_inputDisabled = false;
		}
	}

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool DestroyOnClose()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override bool PausesGameInput()
	{
		return true;
	}
}
