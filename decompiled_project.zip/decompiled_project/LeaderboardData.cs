using System.Collections.Generic;

public class LeaderboardData
{
	public string displayName;

	public int totalRows;

	public List<RowData> rows = new List<RowData>();
}
