using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Localization
{
	public static bool localizationHasBeenSet = false;

	private static string[] mLanguages = null;

	private static int mLanguageIndex = -1;

	private static string mLanguage;

	private static Hashtable hashTable = new Hashtable();

	private static List<string> mLanguageFiles = new List<string>();

	public static Hashtable hashtable
	{
		get
		{
			if (!localizationHasBeenSet)
			{
				language = PlayerPrefs.GetString("Language", "English");
			}
			return hashTable;
		}
		set
		{
			localizationHasBeenSet = value != null;
			hashtable = value;
		}
	}

	public static string[] knownLanguages
	{
		get
		{
			if (!localizationHasBeenSet)
			{
				LoadDictionary(PlayerPrefs.GetString("Language", "English"));
			}
			return mLanguages;
		}
	}

	public static string language
	{
		get
		{
			if (string.IsNullOrEmpty(mLanguage))
			{
				string[] array = knownLanguages;
				mLanguage = PlayerPrefs.GetString("Language", (array == null) ? "English" : array[0]);
				LoadAndSelect(mLanguage);
			}
			return mLanguage;
		}
		set
		{
			if (!(mLanguage != value))
			{
				return;
			}
			mLanguage = value;
			LoadAndSelect(mLanguage);
			int num = knownLanguages.Length;
			for (int i = 0; i < num; i++)
			{
				if (knownLanguages[i] == language)
				{
					mLanguageIndex = i;
				}
			}
		}
	}

	[Obsolete("Localization is now always active. You no longer need to check this property.")]
	public static bool isActive => true;

	private static bool LoadDictionary(string value)
	{
		AddLanguageFile("UI/Localization");
		AddLanguageFile("UI/TempLocalization");
		hashTable.Clear();
		int count = mLanguageFiles.Count;
		bool result = false;
		if (!localizationHasBeenSet)
		{
			for (int i = 0; i < count; i++)
			{
				Object obj = Resources.Load(mLanguageFiles[i], typeof(TextAsset));
				TextAsset val = (TextAsset)(object)((obj is TextAsset) ? obj : null);
				localizationHasBeenSet = true;
				if ((Object)(object)val != (Object)null && LoadCSV(val) && !string.IsNullOrEmpty(value))
				{
					Object obj2 = Resources.Load(value, typeof(TextAsset));
					val = (TextAsset)(object)((obj2 is TextAsset) ? obj2 : null);
					if ((Object)(object)val != (Object)null)
					{
						Load(val);
						result = true;
					}
				}
			}
		}
		return result;
	}

	private static bool LoadAndSelect(string value)
	{
		if (!string.IsNullOrEmpty(value))
		{
			if (hashTable.Count == 0 && !LoadDictionary(value))
			{
				return false;
			}
			if (SelectLanguage(value))
			{
				return true;
			}
		}
		hashTable.Clear();
		if (string.IsNullOrEmpty(value))
		{
			PlayerPrefs.DeleteKey("Language");
		}
		return false;
	}

	public static void Load(TextAsset asset)
	{
		ByteReader byteReader = new ByteReader(asset);
		Set(((Object)asset).name, byteReader.ReadDictionary());
	}

	public static bool LoadCSV(TextAsset asset)
	{
		ByteReader byteReader = new ByteReader(asset);
		BetterList<string> betterList = byteReader.ReadCSV();
		if (betterList.size < 2)
		{
			return false;
		}
		betterList[0] = "KEY";
		if (!string.Equals(betterList[0], "KEY"))
		{
			return false;
		}
		mLanguages = new string[betterList.size - 1];
		for (int i = 0; i < mLanguages.Length; i++)
		{
			mLanguages[i] = betterList[i + 1];
		}
		while (betterList != null)
		{
			AddCSV(betterList);
			betterList = byteReader.ReadCSV();
		}
		return true;
	}

	private static bool SelectLanguage(string language)
	{
		mLanguageIndex = -1;
		if (hashTable.Count == 0)
		{
			return false;
		}
		if (hashTable["KEY"] is List<List<string>> list)
		{
			for (int i = 0; i < list[0].Count; i++)
			{
				if (list[0][i] == language)
				{
					mLanguageIndex = i;
					mLanguage = language;
					PlayerPrefs.SetString("Language", mLanguage);
					UIRoot.Broadcast("OnLocalize");
					return true;
				}
			}
		}
		return false;
	}

	private static void AddCSV(BetterList<string> values)
	{
		if (values.size < 2)
		{
			return;
		}
		int num = values[0].Length - 1;
		if (num > 0)
		{
			string text = values[0];
			if (values[0].CompareTo("KEY") != 0)
			{
				text = text.ToLowerInvariant();
			}
			while (text[num] >= '0' && text[num] <= '9' && num > 0)
			{
				num--;
			}
			text = text.Substring(0, num + 1).TrimEnd(new char[1] { '.' });
			List<string> list = new List<string>();
			int size = values.size;
			for (int i = 1; i < size; i++)
			{
				list.Add(values[i]);
			}
			while (list.Count < mLanguages.Length)
			{
				list.Add(string.Empty);
			}
			list.TrimExcess();
			if (hashTable.ContainsKey(text))
			{
				List<List<string>> list2 = hashTable[text] as List<List<string>>;
				list2.TrimExcess();
				list2.Add(list);
			}
			else
			{
				List<List<string>> list3 = new List<List<string>>();
				list3.Add(list);
				list3.TrimExcess();
				hashTable.Add(text, list3);
			}
		}
	}

	public static void Set(string languageName, Dictionary<string, string> dictionary)
	{
		mLanguage = languageName;
		PlayerPrefs.SetString("Language", mLanguage);
		localizationHasBeenSet = false;
		mLanguageIndex = -1;
		mLanguages = new string[1] { languageName };
		UIRoot.Broadcast("OnLocalize");
	}

	public static string Get(string key, bool suppressWarnings = false)
	{
		if (!localizationHasBeenSet)
		{
			language = PlayerPrefs.GetString("Language", "English");
		}
		string text = key.ToLowerInvariant();
		int num = text.Length - 1;
		if (num > 0)
		{
			while (text[num] >= '0' && text[num] <= '9' && num > 0)
			{
				num--;
			}
		}
		if (num < text.Length - 1)
		{
			string text2 = text.Substring(0, num + 1);
			text2 = text2.TrimEnd(new char[1] { '.' });
			if (hashTable[text2] is List<List<string>> list)
			{
				int num2 = int.Parse(text.Substring(num + 1).Replace(".", string.Empty));
				num2--;
				if (num2 >= 0 && list.Count > num2 && list[num2].Count > mLanguageIndex)
				{
					return list[num2][mLanguageIndex];
				}
			}
		}
		else if (hashTable[text] is List<List<string>> { Count: >0 } list2 && list2[0].Count > mLanguageIndex)
		{
			string text3 = list2[0][mLanguageIndex];
			if (!string.IsNullOrEmpty(text3))
			{
				return text3;
			}
		}
		if (!suppressWarnings)
		{
		}
		return text;
	}

	[Obsolete("Use Localization.Get instead")]
	public static string Localize(string key)
	{
		return Get(key);
	}

	public static bool Exists(string key)
	{
		if (!localizationHasBeenSet)
		{
			language = PlayerPrefs.GetString("Language", "English");
		}
		return hashTable.ContainsKey(key);
	}

	public static int GetNumberOfRandomKeys(string key)
	{
		string key2 = key.ToLowerInvariant();
		List<List<string>> list = hashTable[key2] as List<List<string>>;
		return list.Count;
	}

	public static string GetRandomValueFromKey(string key)
	{
		string text = key.ToLowerInvariant();
		if (hashTable[text] is List<List<string>> list)
		{
			int index = Random.Range(0, list.Count);
			if (list[index].Count > mLanguageIndex)
			{
				return list[index][mLanguageIndex];
			}
		}
		return text;
	}

	public static List<string> GetAllLanguages(string key)
	{
		string key2 = key.ToLowerInvariant();
		if (hashTable[key2] is List<List<string>> { Count: >0 } list)
		{
			return list[0];
		}
		return null;
	}

	public static void AddLanguageFile(string path)
	{
		if (!mLanguageFiles.Contains(path))
		{
			mLanguageFiles.Add(path);
		}
	}
}
