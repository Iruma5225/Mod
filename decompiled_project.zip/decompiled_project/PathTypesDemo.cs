using System;
using System.Collections;
using System.Collections.Generic;
using Pathfinding;
using Pathfinding.Util;
using UnityEngine;

public class PathTypesDemo : MonoBehaviour
{
	public enum DemoMode
	{
		ABPath,
		MultiTargetPath,
		RandomPath,
		FleePath,
		ConstantPath,
		FloodPath,
		FloodPathTracer
	}

	public DemoMode activeDemo;

	public Transform start;

	public Transform end;

	public Vector3 pathOffset;

	public Material lineMat;

	public Material squareMat;

	public float lineWidth;

	public RichAI[] agents;

	public int searchLength = 1000;

	public int spread = 100;

	public float aimStrength;

	private Path lastPath;

	private List<GameObject> lastRender = new List<GameObject>();

	private List<Vector3> multipoints = new List<Vector3>();

	private Vector2 mouseDragStart;

	private float mouseDragStartTime;

	private FloodPath lastFlood;

	private void Update()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		Ray val = Camera.main.ScreenPointToRay(Input.mousePosition);
		Vector3 val2 = ((Ray)(ref val)).origin + ((Ray)(ref val)).direction * (((Ray)(ref val)).origin.y / (0f - ((Ray)(ref val)).direction.y));
		end.position = val2;
		if (Input.GetMouseButtonDown(0))
		{
			mouseDragStart = Vector2.op_Implicit(Input.mousePosition);
			mouseDragStartTime = Time.realtimeSinceStartup;
		}
		if (Input.GetMouseButtonUp(0))
		{
			Vector2 val3 = Vector2.op_Implicit(Input.mousePosition);
			Vector2 val4 = val3 - mouseDragStart;
			if (((Vector2)(ref val4)).sqrMagnitude > 25f && Time.realtimeSinceStartup - mouseDragStartTime > 0.3f)
			{
				Rect val5 = Rect.MinMaxRect(Mathf.Min(mouseDragStart.x, val3.x), Mathf.Min(mouseDragStart.y, val3.y), Mathf.Max(mouseDragStart.x, val3.x), Mathf.Max(mouseDragStart.y, val3.y));
				RichAI[] array = Object.FindObjectsOfType(typeof(RichAI)) as RichAI[];
				List<RichAI> list = new List<RichAI>();
				for (int i = 0; i < array.Length; i++)
				{
					Vector2 val6 = Vector2.op_Implicit(Camera.main.WorldToScreenPoint(((Component)array[i]).transform.position));
					if (((Rect)(ref val5)).Contains(val6))
					{
						list.Add(array[i]);
					}
				}
				agents = list.ToArray();
			}
			else
			{
				if (Input.GetKey((KeyCode)304))
				{
					multipoints.Add(val2);
				}
				if (Input.GetKey((KeyCode)306))
				{
					multipoints.Clear();
				}
				if (Input.mousePosition.x > 225f)
				{
					DemoPath();
				}
			}
		}
		if (Input.GetMouseButton(0) && Input.GetKey((KeyCode)308) && lastPath.IsDone())
		{
			DemoPath();
		}
	}

	public void OnGUI()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		GUILayout.BeginArea(new Rect(5f, 5f, 220f, (float)(Screen.height - 10)), string.Empty, GUIStyle.op_Implicit("Box"));
		switch (activeDemo)
		{
		case DemoMode.ABPath:
			GUILayout.Label("Basic path. Finds a path from point A to point B.", (GUILayoutOption[])(object)new GUILayoutOption[0]);
			break;
		case DemoMode.MultiTargetPath:
			GUILayout.Label("Multi Target Path. Finds a path quickly from one point to many others in a single search.", (GUILayoutOption[])(object)new GUILayoutOption[0]);
			break;
		case DemoMode.RandomPath:
			GUILayout.Label("Randomized Path. Finds a path with a specified length in a random direction or biased towards some point when using a larger aim strenggth.", (GUILayoutOption[])(object)new GUILayoutOption[0]);
			break;
		case DemoMode.FleePath:
			GUILayout.Label("Flee Path. Tries to flee from a specified point. Remember to set Flee Strength!", (GUILayoutOption[])(object)new GUILayoutOption[0]);
			break;
		case DemoMode.ConstantPath:
			GUILayout.Label("Finds all nodes which it costs less than some value to reach.", (GUILayoutOption[])(object)new GUILayoutOption[0]);
			break;
		case DemoMode.FloodPath:
			GUILayout.Label("Searches the whole graph from a specific point. FloodPathTracer can then be used to quickly find a path to that point", (GUILayoutOption[])(object)new GUILayoutOption[0]);
			break;
		case DemoMode.FloodPathTracer:
			GUILayout.Label("Traces a path to where the FloodPath started. Compare the claculation times for this path with ABPath!\nGreat for TD games", (GUILayoutOption[])(object)new GUILayoutOption[0]);
			break;
		}
		GUILayout.Space(5f);
		GUILayout.Label("Note that the paths are rendered without ANY post-processing applied, so they might look a bit edgy", (GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.Space(5f);
		GUILayout.Label("Click anywhere to recalculate the path. Hold Alt to continuously recalculate the path while the mouse is pressed.", (GUILayoutOption[])(object)new GUILayoutOption[0]);
		if (activeDemo == DemoMode.ConstantPath || activeDemo == DemoMode.RandomPath || activeDemo == DemoMode.FleePath)
		{
			GUILayout.Label("Search Distance (" + searchLength + ")", (GUILayoutOption[])(object)new GUILayoutOption[0]);
			searchLength = Mathf.RoundToInt(GUILayout.HorizontalSlider((float)searchLength, 0f, 100000f, (GUILayoutOption[])(object)new GUILayoutOption[0]));
		}
		if (activeDemo == DemoMode.RandomPath || activeDemo == DemoMode.FleePath)
		{
			GUILayout.Label("Spread (" + spread + ")", (GUILayoutOption[])(object)new GUILayoutOption[0]);
			spread = Mathf.RoundToInt(GUILayout.HorizontalSlider((float)spread, 0f, 40000f, (GUILayoutOption[])(object)new GUILayoutOption[0]));
			GUILayout.Label(((activeDemo != DemoMode.RandomPath) ? "Flee strength" : "Aim strength") + " (" + aimStrength + ")", (GUILayoutOption[])(object)new GUILayoutOption[0]);
			aimStrength = GUILayout.HorizontalSlider(aimStrength, 0f, 1f, (GUILayoutOption[])(object)new GUILayoutOption[0]);
		}
		if (activeDemo == DemoMode.MultiTargetPath)
		{
			GUILayout.Label("Hold shift and click to add new target points. Hold ctr and click to remove all target points", (GUILayoutOption[])(object)new GUILayoutOption[0]);
		}
		if (GUILayout.Button("A to B path", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			activeDemo = DemoMode.ABPath;
		}
		if (GUILayout.Button("Multi Target Path", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			activeDemo = DemoMode.MultiTargetPath;
		}
		if (GUILayout.Button("Random Path", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			activeDemo = DemoMode.RandomPath;
		}
		if (GUILayout.Button("Flee path", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			activeDemo = DemoMode.FleePath;
		}
		if (GUILayout.Button("Constant Path", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			activeDemo = DemoMode.ConstantPath;
		}
		if (GUILayout.Button("Flood Path", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			activeDemo = DemoMode.FloodPath;
		}
		if (GUILayout.Button("Flood Path Tracer", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			activeDemo = DemoMode.FloodPathTracer;
		}
		GUILayout.EndArea();
	}

	public void OnPathComplete(Path p)
	{
		//IL_04da: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e1: Expected O, but got Unknown
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Expected O, but got Unknown
		//IL_0530: Unknown result type (might be due to invalid IL or missing references)
		//IL_0536: Unknown result type (might be due to invalid IL or missing references)
		//IL_053b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_028b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_0306: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03db: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0419: Unknown result type (might be due to invalid IL or missing references)
		//IL_041e: Unknown result type (might be due to invalid IL or missing references)
		//IL_047b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0482: Expected O, but got Unknown
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		if (lastRender == null)
		{
			return;
		}
		if (p.error)
		{
			ClearPrevious();
		}
		else if ((object)p.GetType() == typeof(MultiTargetPath))
		{
			List<GameObject> list = new List<GameObject>(lastRender);
			lastRender.Clear();
			MultiTargetPath multiTargetPath = p as MultiTargetPath;
			for (int i = 0; i < multiTargetPath.vectorPaths.Length; i++)
			{
				if (multiTargetPath.vectorPaths[i] != null)
				{
					List<Vector3> list2 = multiTargetPath.vectorPaths[i];
					GameObject val = null;
					if (list.Count > i && (Object)(object)list[i].GetComponent<LineRenderer>() != (Object)null)
					{
						val = list[i];
						list.RemoveAt(i);
					}
					else
					{
						val = new GameObject("LineRenderer_" + i, new Type[1] { typeof(LineRenderer) });
					}
					LineRenderer component = val.GetComponent<LineRenderer>();
					((Renderer)component).sharedMaterial = lineMat;
					component.SetWidth(lineWidth, lineWidth);
					component.SetVertexCount(list2.Count);
					for (int j = 0; j < list2.Count; j++)
					{
						component.SetPosition(j, list2[j] + pathOffset);
					}
					lastRender.Add(val);
				}
			}
			for (int k = 0; k < list.Count; k++)
			{
				Object.Destroy((Object)(object)list[k]);
			}
		}
		else if ((object)p.GetType() == typeof(ConstantPath))
		{
			ClearPrevious();
			ConstantPath constantPath = p as ConstantPath;
			List<GraphNode> allNodes = constantPath.allNodes;
			Mesh val2 = new Mesh();
			List<Vector3> list3 = new List<Vector3>();
			bool flag = false;
			for (int num = allNodes.Count - 1; num >= 0; num--)
			{
				Vector3 val3 = (Vector3)allNodes[num].position + pathOffset;
				if (list3.Count == 65000 && !flag)
				{
					Debug.LogError((object)"Too many nodes, rendering a mesh would throw 65K vertex error. Using Debug.DrawRay instead for the rest of the nodes");
					flag = true;
				}
				if (flag)
				{
					Debug.DrawRay(val3, Vector3.up, Color.blue);
				}
				else
				{
					GridGraph gridGraph = AstarData.GetGraph(allNodes[num]) as GridGraph;
					float num2 = 1f;
					if (gridGraph != null)
					{
						num2 = gridGraph.nodeSize;
					}
					list3.Add(val3 + new Vector3(-0.5f, 0f, -0.5f) * num2);
					list3.Add(val3 + new Vector3(0.5f, 0f, -0.5f) * num2);
					list3.Add(val3 + new Vector3(-0.5f, 0f, 0.5f) * num2);
					list3.Add(val3 + new Vector3(0.5f, 0f, 0.5f) * num2);
				}
			}
			Vector3[] array = list3.ToArray();
			int[] array2 = new int[3 * array.Length / 2];
			int l = 0;
			int num3 = 0;
			for (; l < array.Length; l += 4)
			{
				array2[num3] = l;
				array2[num3 + 1] = l + 1;
				array2[num3 + 2] = l + 2;
				array2[num3 + 3] = l + 1;
				array2[num3 + 4] = l + 3;
				array2[num3 + 5] = l + 2;
				num3 += 6;
			}
			Vector2[] array3 = (Vector2[])(object)new Vector2[array.Length];
			for (int m = 0; m < array3.Length; m += 4)
			{
				ref Vector2 reference = ref array3[m];
				reference = new Vector2(0f, 0f);
				ref Vector2 reference2 = ref array3[m + 1];
				reference2 = new Vector2(1f, 0f);
				ref Vector2 reference3 = ref array3[m + 2];
				reference3 = new Vector2(0f, 1f);
				ref Vector2 reference4 = ref array3[m + 3];
				reference4 = new Vector2(1f, 1f);
			}
			val2.vertices = array;
			val2.triangles = array2;
			val2.uv = array3;
			val2.RecalculateNormals();
			GameObject val4 = new GameObject("Mesh", new Type[2]
			{
				typeof(MeshRenderer),
				typeof(MeshFilter)
			});
			MeshFilter component2 = val4.GetComponent<MeshFilter>();
			component2.mesh = val2;
			MeshRenderer component3 = val4.GetComponent<MeshRenderer>();
			((Renderer)component3).material = squareMat;
			lastRender.Add(val4);
		}
		else
		{
			ClearPrevious();
			GameObject val5 = new GameObject("LineRenderer", new Type[1] { typeof(LineRenderer) });
			LineRenderer component4 = val5.GetComponent<LineRenderer>();
			((Renderer)component4).sharedMaterial = lineMat;
			component4.SetWidth(lineWidth, lineWidth);
			component4.SetVertexCount(p.vectorPath.Count);
			for (int n = 0; n < p.vectorPath.Count; n++)
			{
				component4.SetPosition(n, p.vectorPath[n] + pathOffset);
			}
			lastRender.Add(val5);
		}
	}

	private void ClearPrevious()
	{
		for (int i = 0; i < lastRender.Count; i++)
		{
			Object.Destroy((Object)(object)lastRender[i]);
		}
		lastRender.Clear();
	}

	private void OnApplicationQuit()
	{
		ClearPrevious();
		lastRender = null;
	}

	private void DemoPath()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		Path path = null;
		if (activeDemo == DemoMode.ABPath)
		{
			path = ABPath.Construct(start.position, end.position, OnPathComplete);
			if (agents != null && agents.Length > 0)
			{
				List<Vector3> list = ListPool<Vector3>.Claim(agents.Length);
				Vector3 val = Vector3.zero;
				for (int i = 0; i < agents.Length; i++)
				{
					list.Add(((Component)agents[i]).transform.position);
					val += list[i];
				}
				val /= (float)list.Count;
				for (int j = 0; j < agents.Length; j++)
				{
					List<Vector3> list2;
					int index;
					(list2 = list)[index = j] = list2[index] - val;
				}
				PathUtilities.GetPointsAroundPoint(end.position, AstarPath.active.graphs[0] as IRaycastableGraph, list, 0f, 0.2f);
				for (int k = 0; k < agents.Length; k++)
				{
					if (!((Object)(object)agents[k] == (Object)null))
					{
						agents[k].target.position = list[k];
						agents[k].UpdatePath();
					}
				}
			}
		}
		else if (activeDemo == DemoMode.MultiTargetPath)
		{
			MultiTargetPath multiTargetPath = MultiTargetPath.Construct(multipoints.ToArray(), end.position, null, OnPathComplete);
			path = multiTargetPath;
		}
		else if (activeDemo == DemoMode.RandomPath)
		{
			RandomPath randomPath = RandomPath.Construct(start.position, searchLength, OnPathComplete);
			randomPath.spread = spread;
			randomPath.aimStrength = aimStrength;
			randomPath.aim = end.position;
			path = randomPath;
		}
		else if (activeDemo == DemoMode.FleePath)
		{
			FleePath fleePath = FleePath.Construct(start.position, end.position, searchLength, OnPathComplete);
			fleePath.aimStrength = aimStrength;
			fleePath.spread = spread;
			path = fleePath;
		}
		else if (activeDemo == DemoMode.ConstantPath)
		{
			((MonoBehaviour)this).StartCoroutine(CalculateConstantPath());
			path = null;
		}
		else if (activeDemo == DemoMode.FloodPath)
		{
			path = (lastFlood = FloodPath.Construct(end.position));
		}
		else if (activeDemo == DemoMode.FloodPathTracer && lastFlood != null)
		{
			FloodPathTracer floodPathTracer = FloodPathTracer.Construct(end.position, lastFlood, OnPathComplete);
			path = floodPathTracer;
		}
		if (path != null)
		{
			AstarPath.StartPath(path);
			lastPath = path;
		}
	}

	public IEnumerator CalculateConstantPath()
	{
		ConstantPath constPath = ConstantPath.Construct(end.position, searchLength, OnPathComplete);
		AstarPath.StartPath(constPath);
		lastPath = constPath;
		yield return constPath.WaitForPath();
	}
}
