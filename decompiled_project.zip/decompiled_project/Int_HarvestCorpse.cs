using UnityEngine;

public class Int_HarvestCorpse : Int_Base
{
	[SerializeField]
	private int trauma = 30;

	public int Trauma => trauma;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_HarvestCorpse";
	}

	public override string GetInteractionType()
	{
		return "harvest_corpse";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}
}
