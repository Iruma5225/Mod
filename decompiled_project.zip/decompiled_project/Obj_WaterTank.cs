using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class Obj_WaterTank : Obj_Base
{
	[SerializeField]
	private int m_Capacity = 100;

	[SerializeField]
	private float m_WaterGeneration;

	private float m_NextWaterGenerationTime;

	[SerializeField]
	private SpriteRenderer m_contaminationOverlay;

	[SerializeField]
	private SpriteRenderer m_tankSprite;

	public List<Sprite> m_WaterTankSprites = new List<Sprite>();

	private float posIconOffTimer;

	private float negIconOffTimer;

	public float IconOffDelay;

	[SerializeField]
	private GameObject posWaterIcon;

	[SerializeField]
	private GameObject negWaterIcon;

	public int Capacity => m_Capacity;

	public float WaterGeneration => m_WaterGeneration;

	public bool posWaterIconVisible
	{
		get
		{
			return (Object)(object)posWaterIcon != (Object)null && posWaterIcon.activeSelf;
		}
		set
		{
			if ((Object)(object)posWaterIcon != (Object)null)
			{
				posWaterIcon.SetActive(value);
			}
		}
	}

	public bool negWaterIconVisible
	{
		get
		{
			return (Object)(object)negWaterIcon != (Object)null && negWaterIcon.activeSelf;
		}
		set
		{
			if ((Object)(object)negWaterIcon != (Object)null)
			{
				negWaterIcon.SetActive(value);
			}
		}
	}

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.WaterTank;
	}

	public override void OnCheck()
	{
	}

	public override void Start()
	{
		if ((Object)(object)WaterManager.Instance != (Object)null)
		{
			WaterManager.Instance.RegisterStorage(this);
		}
		if (m_WaterGeneration > 0f)
		{
			m_NextWaterGenerationTime = Time.time + GameTime.RealSecondsPerDay / m_WaterGeneration;
		}
	}

	public void OnWaterUpdated()
	{
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)WaterManager.Instance != (Object)null))
		{
			return;
		}
		float num = ((!(WaterManager.Instance.MaxStoredWater > 0f)) ? 0f : (WaterManager.Instance.StoredWater / WaterManager.Instance.MaxStoredWater));
		float a = WaterManager.Instance.Contamination * 0.01f;
		if ((Object)(object)m_contaminationOverlay != (Object)null)
		{
			Color color = m_contaminationOverlay.color;
			color.a = a;
			m_contaminationOverlay.color = color;
		}
		if ((Object)(object)m_tankSprite != (Object)null)
		{
			int num2 = Mathf.FloorToInt(num * (float)(m_WaterTankSprites.Count - 1));
			if (num2 >= 0 && num2 < m_WaterTankSprites.Count && (Object)(object)m_WaterTankSprites[num2] != (Object)null)
			{
				m_tankSprite.sprite = m_WaterTankSprites[num2];
			}
		}
	}

	public override void Update()
	{
		base.Update();
		if (m_WaterGeneration > 0f && Time.time >= m_NextWaterGenerationTime)
		{
			WaterManager.Instance.AddWater(1f);
			m_NextWaterGenerationTime = Time.time + GameTime.RealSecondsPerDay / m_WaterGeneration;
		}
		if (Time.time >= posIconOffTimer && posIconOffTimer > 0f)
		{
			deactivatePosWaterIcon();
			posIconOffTimer = 0f;
		}
		if (Time.time >= negIconOffTimer && negIconOffTimer > 0f)
		{
			deactivateNegWaterIcon();
			negIconOffTimer = 0f;
		}
	}

	public void activatePosWaterIcon()
	{
	}

	public void activateNegWaterIcon()
	{
	}

	public void deactivatePosWaterIcon()
	{
	}

	public void deactivateNegWaterIcon()
	{
	}

	public override List<string> GetTooltipExtraInfo()
	{
		StringBuilder stringBuilder = new StringBuilder();
		List<string> list = new List<string>();
		stringBuilder.Append(Mathf.FloorToInt(WaterManager.Instance.StoredWater));
		stringBuilder.Append("/");
		stringBuilder.Append(WaterManager.Instance.MaxStoredWater);
		list.Add(Localization.Get("Item.Name.Water"));
		list.Add(stringBuilder.ToString());
		list.Add(Localization.Get("UI.Contamination"));
		list.Add(WaterManager.Instance.Contamination.ToString("0") + "%");
		return list;
	}

	public override void OnDestroy()
	{
		base.OnDestroy();
		if ((Object)(object)WaterManager.Instance != (Object)null)
		{
			WaterManager.Instance.UnRegisterStorage(this);
		}
	}

	public override bool IsReadyForLoad()
	{
		return (Object)(object)WaterManager.Instance != (Object)null && SaveManager.instance.HasBeenLoaded(WaterManager.Instance);
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		if (m_WaterGeneration > 0f)
		{
			data.SaveLoadAbsoluteTime("next_water", ref m_NextWaterGenerationTime);
		}
		data.SaveLoadAbsoluteTime("posIconOffTimer", ref posIconOffTimer);
		data.SaveLoadAbsoluteTime("negIconOffTimer", ref negIconOffTimer);
		bool value = posWaterIconVisible;
		bool value2 = negWaterIconVisible;
		data.SaveLoad("posIconVisible", ref value);
		data.SaveLoad("negIconVisible", ref value2);
		if (data.isLoading)
		{
			posWaterIconVisible = value;
			negWaterIconVisible = value2;
			OnWaterUpdated();
		}
	}
}
