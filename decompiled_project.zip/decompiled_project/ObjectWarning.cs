using System.Collections.Generic;
using UnityEngine;

public class ObjectWarning : MonoBehaviour
{
	private enum WarningType
	{
		Disabled,
		NoPower,
		LowIntegrity,
		Max
	}

	private enum WarningState
	{
		Hidden,
		FadingIn,
		Showing,
		FadingOut
	}

	private const int IntegrityThreshold = 25;

	[SerializeField]
	private SpriteRenderer m_sprite;

	[SerializeField]
	private float m_warningDuration = 2f;

	[SerializeField]
	private float m_warningFadeTime = 0.3f;

	[SerializeField]
	private List<Sprite> m_sprites = new List<Sprite>();

	private WarningType m_currentWarning = WarningType.Max;

	private WarningState m_warningState;

	private Obj_Base m_obj;

	private float m_fadeStartAlpha;

	private float m_fadeStartTime;

	private float m_fadeEndTime;

	private float m_showUntilTime;

	private float m_nextCheckTime;

	public void Awake()
	{
		SetWarningIconState(WarningState.Hidden);
		if (NextWarningSprite())
		{
			SetWarningIconState(WarningState.FadingIn);
		}
	}

	public void Initialise(Obj_Base obj, Vector3 pos)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		m_obj = obj;
		if ((Object)(object)m_obj != (Object)null)
		{
			((Component)this).transform.parent = ((Component)m_obj).transform;
			((Component)this).transform.localPosition = pos;
		}
	}

	private bool NextWarningSprite()
	{
		for (WarningType warningType = ((m_currentWarning != WarningType.Max) ? (m_currentWarning + 1) : WarningType.Disabled); warningType != m_currentWarning; warningType = ((warningType != WarningType.Max) ? (warningType + 1) : WarningType.Disabled))
		{
			if (IsWarningIconNeeded(warningType))
			{
				m_currentWarning = warningType;
				return true;
			}
		}
		if (IsWarningIconNeeded(m_currentWarning))
		{
			return true;
		}
		return false;
	}

	private bool IsWarningIconNeeded(WarningType warning)
	{
		if ((Object)(object)m_obj == (Object)null)
		{
			return false;
		}
		bool result = false;
		switch (warning)
		{
		case WarningType.Disabled:
			result = !m_obj.IsEnabled();
			break;
		case WarningType.NoPower:
			result = m_obj.CanUsePower() && !m_obj.HasEnoughPower();
			if ((Object)(object)TutorialManager.Instance != (Object)null && TutorialManager.Instance.TutorialActive && TutorialManager.Instance.currentStage < TutorialManager.TutorialStage.RefuelGenerator)
			{
				result = false;
			}
			break;
		case WarningType.LowIntegrity:
		{
			Obj_Integrity obj_Integrity = m_obj as Obj_Integrity;
			if ((Object)(object)obj_Integrity != (Object)null)
			{
				result = obj_Integrity.Integrity <= 25;
			}
			break;
		}
		}
		return result;
	}

	private void SetWarningIconState(WarningState state)
	{
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		m_warningState = state;
		switch (state)
		{
		case WarningState.Hidden:
			if ((Object)(object)m_sprite != (Object)null)
			{
				m_sprite.SetAlpha(0f);
			}
			m_nextCheckTime = Time.time + 1f;
			break;
		case WarningState.Showing:
			m_showUntilTime = Time.time + m_warningDuration;
			break;
		case WarningState.FadingIn:
		{
			Sprite val = null;
			int currentWarning = (int)m_currentWarning;
			if (currentWarning >= 0 && currentWarning < m_sprites.Count)
			{
				val = m_sprites[currentWarning];
			}
			if ((Object)(object)m_sprite != (Object)null && (Object)(object)val != (Object)null)
			{
				m_sprite.sprite = val;
			}
			m_fadeStartAlpha = ((!((Object)(object)m_sprite != (Object)null)) ? 0f : m_sprite.color.a);
			m_fadeStartTime = Time.time;
			m_fadeEndTime = m_fadeStartTime + m_warningFadeTime;
			break;
		}
		case WarningState.FadingOut:
			m_fadeStartAlpha = ((!((Object)(object)m_sprite != (Object)null)) ? 1f : m_sprite.color.a);
			m_fadeStartTime = Time.time;
			m_fadeEndTime = m_fadeStartTime + m_warningFadeTime;
			break;
		}
	}

	public void Update()
	{
		if (m_warningState != WarningState.Hidden && ((Object)(object)m_obj == (Object)null || m_obj.isBurningOrBurntOut))
		{
			SetWarningIconState(WarningState.Hidden);
		}
		switch (m_warningState)
		{
		case WarningState.Hidden:
			if (Time.time >= m_nextCheckTime)
			{
				if (NextWarningSprite())
				{
					SetWarningIconState(WarningState.FadingIn);
				}
				else
				{
					m_nextCheckTime = Time.time + 1f;
				}
			}
			break;
		case WarningState.Showing:
			if (Time.time >= m_showUntilTime)
			{
				if (NextWarningSprite())
				{
					SetWarningIconState(WarningState.FadingOut);
					break;
				}
				if (IsWarningIconNeeded(m_currentWarning))
				{
					m_showUntilTime = Time.time + m_warningDuration;
					break;
				}
				m_currentWarning = WarningType.Max;
				SetWarningIconState(WarningState.FadingOut);
			}
			break;
		case WarningState.FadingIn:
		{
			float num2 = (Time.time - m_fadeStartTime) / (m_fadeEndTime - m_fadeStartTime);
			float alpha2 = Mathf.Lerp(m_fadeStartAlpha, 1f, num2);
			if ((Object)(object)m_sprite != (Object)null)
			{
				m_sprite.SetAlpha(alpha2);
			}
			if (num2 >= 1f)
			{
				SetWarningIconState(WarningState.Showing);
			}
			break;
		}
		case WarningState.FadingOut:
		{
			float num = (Time.time - m_fadeStartTime) / (m_fadeEndTime - m_fadeStartTime);
			float alpha = Mathf.Lerp(m_fadeStartAlpha, 0f, num);
			if ((Object)(object)m_sprite != (Object)null)
			{
				m_sprite.SetAlpha(alpha);
			}
			if (num >= 1f)
			{
				if (m_currentWarning == WarningType.Max)
				{
					SetWarningIconState(WarningState.Hidden);
				}
				else
				{
					SetWarningIconState(WarningState.FadingIn);
				}
			}
			break;
		}
		}
	}
}
