using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class Obj_FoodBowl : Obj_Base
{
	[SerializeField]
	private Sprite m_emptySprite;

	[SerializeField]
	private Sprite m_fullSprite;

	[SerializeField]
	private SpriteRenderer m_renderer;

	[SerializeField]
	private AudioClip m_fill_sound;

	private AudioSource m_audio;

	private bool m_filled;

	private int m_medicine;

	private bool m_pendingDelete;

	public SpriteRenderer m_plaqueSprite;

	public bool hasFood => m_filled;

	public int medicineCount => m_medicine;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.FoodBowl;
	}

	public override void Start()
	{
		base.Start();
		if ((Object)(object)m_renderer == (Object)null)
		{
		}
		if ((Object)(object)m_emptySprite == (Object)null || (Object)(object)m_fullSprite == (Object)null)
		{
		}
		if ((Object)(object)m_renderer != (Object)null)
		{
			m_renderer.sprite = m_emptySprite;
		}
		m_audio = ((Component)this).GetComponent<AudioSource>();
	}

	public override void Update()
	{
		base.Update();
		if (m_pendingDelete && (Object)(object)SaveManager.instance != (Object)null && !SaveManager.instance.isLoading && !SaveManager.instance.isSaving && !RelocationManager.isRelocating)
		{
			if ((Object)(object)SaveManager.instance != (Object)null)
			{
				SaveManager.instance.UnregisterSaveable(this);
			}
			if ((Object)(object)ObjectManager.Instance != (Object)null)
			{
				ObjectManager.Instance.RemoveObject(this);
			}
			m_pendingDelete = false;
		}
	}

	public override void OnDestroy()
	{
	}

	public void SetPendingDelete()
	{
		m_pendingDelete = true;
	}

	public void CancelPendingDelete()
	{
		m_pendingDelete = false;
	}

	public void FillWithFood()
	{
		m_filled = true;
		m_medicine = 0;
		if ((Object)(object)m_renderer != (Object)null)
		{
			m_renderer.sprite = m_fullSprite;
		}
	}

	public void Medicate()
	{
		if (m_filled)
		{
			m_medicine++;
		}
	}

	public void ConsumeFood(out int medicineCount)
	{
		medicineCount = m_medicine;
		m_filled = false;
		m_medicine = 0;
		if ((Object)(object)m_renderer != (Object)null)
		{
			m_renderer.sprite = m_emptySprite;
		}
	}

	public void PlayFillSound()
	{
		if ((Object)(object)m_audio != (Object)null)
		{
			m_audio.PlayOneShot(m_fill_sound);
		}
	}

	public override void OnSelected()
	{
		base.OnSelected();
		if ((Object)(object)m_plaqueSprite != (Object)null)
		{
			((Renderer)m_plaqueSprite).material.EnableKeyword("OUTLINE_ON");
		}
	}

	public override void OnUnSelected()
	{
		base.OnUnSelected();
		if ((Object)(object)m_plaqueSprite != (Object)null)
		{
			((Renderer)m_plaqueSprite).material.DisableKeyword("OUTLINE_ON");
		}
	}

	public override string GetTooltipName()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append(GetName());
		stringBuilder.Append(" (");
		stringBuilder.Append((!hasFood) ? Localization.Get("Text.UI.Empty") : Localization.Get("Text.UI.Filled"));
		if (m_medicine > 0)
		{
			stringBuilder.Append(", ");
			stringBuilder.Append(m_medicine.ToString());
			stringBuilder.Append("x ");
			stringBuilder.Append(Localization.Get("Text.UI.FoodBowlMedicine"));
		}
		stringBuilder.Append(")");
		return stringBuilder.ToString();
	}

	public override List<string> GetTooltipExtraInfo()
	{
		CompanionAnimal pet = FamilyManager.Instance.GetPet();
		List<string> list = new List<string>();
		StringBuilder stringBuilder = new StringBuilder();
		list.Add(Localization.Get("customise.petname"));
		list.Add(pet.petName.ToString());
		list.Add(string.Empty);
		list.Add(string.Empty);
		stringBuilder.Append(((int)pet.health/*cast due to .constrained prefix*/).ToString());
		list.Add(Localization.Get("Text.UI.Health"));
		list.Add(stringBuilder.ToString());
		list.Add(Localization.Get("Text.UI.Status"));
		if (pet.Poisoned)
		{
			list.Add(Localization.Get("Text.UI.Poisoned"));
		}
		else if (pet.Starving)
		{
			list.Add(Localization.Get("Text.UI.Starving"));
		}
		else
		{
			list.Add(Localization.Get("Text.UI.Fine"));
		}
		if (pet.immune)
		{
			list.Add(Localization.Get("UI.RadiationImmune"));
			list.Add(string.Empty);
		}
		return list;
	}

	public override bool IsReadyForLoad()
	{
		if ((Object)(object)SaveManager.instance != (Object)null && (Object)(object)FamilyManager.Instance != (Object)null && SaveManager.instance.HasBeenLoaded(FamilyManager.Instance))
		{
			return true;
		}
		return false;
	}

	public override bool SaveLoad(SaveData data)
	{
		if (m_pendingDelete)
		{
			return true;
		}
		return base.SaveLoad(data);
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		data.SaveLoad("filled", ref m_filled);
		data.SaveLoad("medicine", ref m_medicine);
		if (data.isLoading && m_filled && (Object)(object)m_renderer != (Object)null)
		{
			m_renderer.sprite = m_fullSprite;
		}
	}
}
