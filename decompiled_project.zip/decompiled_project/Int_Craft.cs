using UnityEngine;

[AddComponentMenu("Sheltered/Interaction/Craft")]
public class Int_Craft : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_Craft";
	}

	public override string GetInteractionType()
	{
		return "craft";
	}

	public override bool IsPlayerSelectable()
	{
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}
}
