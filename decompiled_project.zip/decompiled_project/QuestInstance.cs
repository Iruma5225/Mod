using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

[Serializable]
public class QuestInstance
{
	public enum QuestState
	{
		Inactive,
		Active,
		Completed,
		Failed
	}

	private QuestState m_state;

	private QuestDefBase m_definition;

	private int m_id = -1;

	private string m_description;

	private int m_daysInactive;

	private MapRegion m_mapRegion;

	private bool m_visited;

	[NonSerialized]
	private List<QuestInstance> m_subquests = new List<QuestInstance>();

	[NonSerialized]
	private QuestInstance m_parent;

	private List<string> m_milestones = new List<string>();

	private ScenarioStage m_stage;

	private Dictionary<string, QuestManager.QuestCharacterInfo> m_characterInfo = new Dictionary<string, QuestManager.QuestCharacterInfo>();

	private int m_unansweredIntercomCount;

	private string m_visitedIcon;

	public QuestState state => m_state;

	public QuestDefBase definition => m_definition;

	public int id => m_id;

	public string descriptionKey => m_description;

	public int daysInactive => m_daysInactive;

	public MapRegion mapRegion => m_mapRegion;

	public bool visited => m_visited;

	public ReadOnlyCollection<QuestInstance> subquests => m_subquests.AsReadOnly();

	public QuestInstance parent => m_parent;

	public ReadOnlyCollection<string> milestones => m_milestones.AsReadOnly();

	public ScenarioStage stage => m_stage;

	public int unansweredIntercomCount
	{
		get
		{
			return m_unansweredIntercomCount;
		}
		set
		{
			m_unansweredIntercomCount = value;
		}
	}

	public QuestInstance()
	{
	}

	public QuestInstance(int instanceId)
	{
		m_id = instanceId;
	}

	public void Initialise(QuestDefBase def, int id, MapRegion mapRegion, QuestInstance parentInstance)
	{
		m_id = id;
		m_definition = def;
		m_parent = parentInstance;
		m_mapRegion = mapRegion;
		m_visitedIcon = def.visitedIcon;
		GetTopmostParent()?.AddCharacterPresets(def.characterSetup);
		if (def != null && def.IsQuest() && ((QuestDef)def).questType == QuestDef.QuestType.Subquest)
		{
			m_state = QuestState.Inactive;
		}
		else if (def != null && def.IsScenario())
		{
			m_state = QuestState.Inactive;
		}
		else
		{
			ActivateQuest();
		}
		if ((Object)(object)m_mapRegion != (Object)null && def.IsQuest())
		{
			m_mapRegion.SetQuestInstance(this);
		}
	}

	public void CleanUp()
	{
		if ((Object)(object)m_mapRegion != (Object)null && m_mapRegion.questInstanceId == m_id)
		{
			m_mapRegion.SetQuestInstance(null);
		}
		for (int i = 0; i < m_subquests.Count; i++)
		{
			if (m_subquests[i] != null)
			{
				m_subquests[i].CleanUp();
			}
		}
	}

	public QuestInstance GetTopmostParent()
	{
		QuestInstance questInstance = this;
		while (questInstance.m_parent != null)
		{
			questInstance = questInstance.m_parent;
		}
		return questInstance;
	}

	private void AddCharacterPresets(ReadOnlyCollection<QuestDefBase.QuestCharacter> charactersToAdd)
	{
		if (m_parent != null)
		{
			return;
		}
		for (int i = 0; i < charactersToAdd.Count; i++)
		{
			string key = charactersToAdd[i].characterId.ToLowerInvariant();
			if (!m_characterInfo.ContainsKey(key))
			{
				QuestManager.QuestCharacterInfo questCharacterInfo = new QuestManager.QuestCharacterInfo();
				questCharacterInfo.Initialize(charactersToAdd[i]);
				if (questCharacterInfo.m_preset != null)
				{
					m_characterInfo.Add(key, questCharacterInfo);
				}
			}
		}
	}

	public QuestManager.QuestCharacterInfo GetCharacterInfo(string characterId)
	{
		if (m_characterInfo == null || string.IsNullOrEmpty(characterId))
		{
			return null;
		}
		QuestInstance topmostParent = GetTopmostParent();
		if (topmostParent != this)
		{
			return topmostParent.GetCharacterInfo(characterId);
		}
		string text = characterId.ToLowerInvariant();
		QuestManager.QuestCharacterInfo value = null;
		if (!m_characterInfo.TryGetValue(text, out value))
		{
			value = QuestManager.instance.GetCharacterInfo(text);
		}
		if (value == null)
		{
		}
		return value;
	}

	public void SetDescription(string key)
	{
		if (!string.IsNullOrEmpty(key))
		{
			m_description = key;
		}
	}

	public void SetMilestone(string milestone)
	{
		if (!string.IsNullOrEmpty(milestone))
		{
			milestone = milestone.ToLower();
			if (!m_milestones.Contains(milestone))
			{
				m_milestones.Add(milestone);
			}
		}
	}

	public void ClearMilestone(string milestone)
	{
		if (string.IsNullOrEmpty(milestone))
		{
			return;
		}
		milestone = milestone.ToLower();
		if (m_milestones.Contains(milestone))
		{
			m_milestones.RemoveAll((string x) => x == milestone);
		}
	}

	public bool CheckMilestone(string milestone)
	{
		if (string.IsNullOrEmpty(milestone))
		{
			return false;
		}
		milestone = milestone.ToLower();
		return m_milestones.Contains(milestone);
	}

	public void AddSubquest(QuestInstance inst)
	{
		if (inst != null && inst.definition != null && inst.definition.IsQuest() && ((QuestDef)inst.definition).questType == QuestDef.QuestType.Subquest)
		{
			m_subquests.Add(inst);
		}
	}

	public void ActivateQuest()
	{
		if (m_state != QuestState.Inactive)
		{
			return;
		}
		m_state = QuestState.Active;
		if (m_definition.IsQuest())
		{
			if ((Object)(object)m_mapRegion != (Object)null)
			{
				m_mapRegion.SetQuestInstance(this);
				if (m_definition is QuestDef questDef && questDef.itemsToSpawn.Count > 0)
				{
					m_mapRegion.AddQuestItems(questDef.itemsToSpawn);
				}
			}
		}
		else if (!m_definition.IsScenario())
		{
		}
	}

	public void FinishQuest(bool success)
	{
		if (m_state == QuestState.Inactive || m_state == QuestState.Active)
		{
			if (m_definition.IsQuest() || m_definition.IsScenario())
			{
			}
			m_state = ((!success) ? QuestState.Failed : QuestState.Completed);
			if (success && (m_definition.id == "HelicopterCrashSite" || m_definition.id == "ConvoyCrashSite"))
			{
				m_mapRegion.ResetIcon();
			}
			CleanUp();
		}
	}

	public void SetStage(string stageId)
	{
		if (string.IsNullOrEmpty(stageId))
		{
			return;
		}
		ScenarioStage scenarioStage = null;
		if (m_definition.IsScenario() && m_definition is ScenarioDef scenarioDef)
		{
			for (int i = 0; i < scenarioDef.stages.Count; i++)
			{
				if (string.Compare(stageId, scenarioDef.stages[i].id, StringComparison.OrdinalIgnoreCase) == 0)
				{
					scenarioStage = scenarioDef.stages[i];
					break;
				}
			}
		}
		m_stage = scenarioStage;
	}

	public void SetDaysInactive(int days)
	{
		if (days >= 0)
		{
			m_daysInactive = days;
		}
	}

	public void ResetInactiveTimer()
	{
		SetDaysInactive(0);
	}

	public void SetVisited()
	{
		m_visited = true;
		if (m_visitedIcon != string.Empty)
		{
			m_mapRegion.ChangeIcon(m_visitedIcon);
		}
	}

	public bool HasBeenStarted()
	{
		return visited;
	}

	public bool AreAnySubquestsActive()
	{
		for (int i = 0; i < m_subquests.Count; i++)
		{
			if (m_subquests[i].IsActive())
			{
				return true;
			}
		}
		return false;
	}

	public bool IsActive()
	{
		return m_state == QuestState.Active;
	}

	public void SaveLoadQuestInstance(SaveData data)
	{
		data.GroupStart("QuestInstance_" + m_id);
		data.SaveLoad("id", ref m_id);
		data.SaveLoad("visited", ref m_visited);
		data.SaveLoad("daysActive", ref m_daysInactive);
		data.SaveLoad("unansweredCount", ref m_unansweredIntercomCount);
		data.SaveLoad("visitedIcon", ref m_visitedIcon);
		int value = (int)m_state;
		data.SaveLoad("state", ref value);
		if (data.isLoading)
		{
			m_state = (QuestState)value;
		}
		string value2 = ((m_definition == null) ? string.Empty : m_definition.id);
		data.SaveLoad("def", ref value2);
		if (data.isLoading && (Object)(object)QuestLibrary.instance != (Object)null)
		{
			m_definition = QuestLibrary.instance.FindDefinition(value2);
		}
		List<QuestManager.CharacterPresetInstance> list = QuestManager.instance.SaveLoadCharacterPresets(data, m_characterInfo);
		if (data.isLoading)
		{
			for (int i = 0; i < list.Count; i++)
			{
				m_characterInfo.Add(list[i].id, list[i].info);
			}
		}
		int value3 = (((Object)(object)m_mapRegion != (Object)null) ? m_mapRegion.gridReference.x : 0);
		int value4 = (((Object)(object)m_mapRegion != (Object)null) ? m_mapRegion.gridReference.y : 0);
		data.SaveLoad("mapRegionX", ref value3);
		data.SaveLoad("mapRegionY", ref value4);
		if (data.isLoading && (Object)(object)ExpeditionMap.Instance != (Object)null)
		{
			m_mapRegion = ExpeditionMap.Instance.GetRegionOnMap(new ExpeditionMap.GridRef(value3, value4));
		}
		int value5 = ((m_parent == null) ? (-1) : m_parent.id);
		data.SaveLoad("parentId", ref value5);
		if (data.isLoading && value5 > -1)
		{
			m_parent = QuestManager.instance.GetQuestInstance(value5);
		}
		data.SaveLoadList("milestones", m_milestones, delegate(int index)
		{
			string value7 = m_milestones[index];
			data.SaveLoad("milestone", ref value7);
		}, delegate
		{
			string value7 = string.Empty;
			data.SaveLoad("milestone", ref value7);
			SetMilestone(value7);
		});
		List<int> subquestIds = new List<int>();
		for (int num = 0; num < m_subquests.Count; num++)
		{
			subquestIds.Add(m_subquests[num].id);
		}
		data.SaveLoadList("subquestIds", subquestIds, delegate(int index)
		{
			int value7 = subquestIds[index];
			data.SaveLoad("id", ref value7);
		}, delegate
		{
			int value7 = -1;
			data.SaveLoad("id", ref value7);
			if (value7 > -1)
			{
				QuestInstance questInstance = QuestManager.instance.GetQuestInstance(value7);
				if (questInstance != null)
				{
					m_subquests.Add(questInstance);
				}
			}
		});
		string value6 = ((m_stage == null) ? string.Empty : m_stage.id);
		data.SaveLoad("stage", ref value6);
		if (data.isLoading)
		{
			SetStage(value6);
		}
		data.GroupEnd();
		if (m_visited)
		{
			SetVisited();
		}
	}
}
