using System;
using System.Collections.Generic;
using UnityEngine;

public class FamilySpawner : MonoBehaviour
{
	public enum PetType
	{
		Cat,
		Dog,
		Fish,
		Horse,
		Snake,
		Max
	}

	public class CharacterAttributes
	{
		public string m_firstName = string.Empty;

		public string m_lastName = string.Empty;

		public string m_meshId = string.Empty;

		public CharacterMeshOptions.CharacterMeshType m_mesh;

		public string m_headTexture = "default";

		public string m_torsoTexture = "default";

		public string m_legTexture = "default";

		public Color m_skinColor = Color.white;

		public Color m_hairColor = Color.white;

		public Color m_shirtColor = Color.white;

		public Color m_pantsColor = Color.white;

		public int m_strengthLevel;

		public int m_strengthMax = 20;

		public int m_dexterityLevel;

		public int m_dexterityMax = 20;

		public int m_charismaLevel;

		public int m_charismaMax = 20;

		public int m_perceptionLevel;

		public int m_perceptionMax = 20;

		public int m_intelligenceLevel;

		public int m_intelligenceMax = 20;

		public List<Traits.Strength> m_strengthTraits = new List<Traits.Strength>();

		public List<Traits.Weakness> m_weaknessTraits = new List<Traits.Weakness>();

		public EncounterCharacter.PersonalityType m_personality;

		public CharacterAttributes()
		{
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_004e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0053: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			m_firstName = "Sam";
			m_lastName = "Smith";
		}

		public CharacterAttributes(CharacterMeshOptions.CharacterPreset preset)
		{
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_004e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0053: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0101: Unknown result type (might be due to invalid IL or missing references)
			//IL_0108: Unknown result type (might be due to invalid IL or missing references)
			//IL_010d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0114: Unknown result type (might be due to invalid IL or missing references)
			//IL_0119: Unknown result type (might be due to invalid IL or missing references)
			//IL_0120: Unknown result type (might be due to invalid IL or missing references)
			//IL_0125: Unknown result type (might be due to invalid IL or missing references)
			m_meshId = preset.m_meshId;
			m_firstName = preset.m_firstName;
			m_lastName = preset.m_lastName;
			m_headTexture = preset.m_headTexture;
			m_torsoTexture = preset.m_torsoTexture;
			m_legTexture = preset.m_legTexture;
			m_skinColor = preset.m_skinColor;
			m_hairColor = preset.m_hairColor;
			m_shirtColor = preset.m_shirtColor;
			m_pantsColor = preset.m_pantsColor;
			RandomizeStats();
		}

		public CharacterAttributes(CharacterAttributes copy)
		{
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_004e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0053: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_0102: Unknown result type (might be due to invalid IL or missing references)
			//IL_0107: Unknown result type (might be due to invalid IL or missing references)
			//IL_010e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0113: Unknown result type (might be due to invalid IL or missing references)
			//IL_011a: Unknown result type (might be due to invalid IL or missing references)
			//IL_011f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0126: Unknown result type (might be due to invalid IL or missing references)
			//IL_012b: Unknown result type (might be due to invalid IL or missing references)
			if (copy != null)
			{
				m_firstName = copy.m_firstName;
				m_lastName = copy.m_lastName;
				m_meshId = copy.m_meshId;
				m_headTexture = copy.m_headTexture;
				m_torsoTexture = copy.m_torsoTexture;
				m_legTexture = copy.m_legTexture;
				m_skinColor = copy.m_skinColor;
				m_hairColor = copy.m_hairColor;
				m_shirtColor = copy.m_shirtColor;
				m_pantsColor = copy.m_pantsColor;
				m_strengthLevel = copy.m_strengthLevel;
				m_strengthMax = copy.m_strengthMax;
				m_dexterityLevel = copy.m_dexterityLevel;
				m_dexterityMax = copy.m_dexterityMax;
				m_charismaLevel = copy.m_charismaLevel;
				m_charismaMax = copy.m_charismaMax;
				m_perceptionLevel = copy.m_perceptionLevel;
				m_perceptionMax = copy.m_perceptionMax;
				m_intelligenceLevel = copy.m_intelligenceLevel;
				m_intelligenceMax = copy.m_intelligenceMax;
				m_strengthTraits = new List<Traits.Strength>(copy.m_strengthTraits);
				m_weaknessTraits = new List<Traits.Weakness>(copy.m_weaknessTraits);
				m_personality = copy.m_personality;
			}
		}

		public void Randomize()
		{
			bool flag = Random.Range(0, 2) == 0;
			m_firstName = NameGenerator.GetFirstName((!flag) ? NameGenerator.Gender.Female : NameGenerator.Gender.Male);
			m_lastName = NameGenerator.GetSurname();
			m_meshId = ((!flag) ? "woman" : "man");
			if ((Object)(object)CharacterMeshOptions.instance == (Object)null || CharacterMeshOptions.instance.FindCharacterMesh(m_meshId) == null)
			{
			}
			RandomizeStats();
			RandomizeTraits();
		}

		public void RandomizeStats()
		{
			m_strengthLevel = Random.Range(10, 21);
			m_dexterityLevel = Random.Range(10, 21);
			m_charismaLevel = Random.Range(10, 21);
			m_perceptionLevel = Random.Range(10, 21);
			m_intelligenceLevel = Random.Range(10, 21);
		}

		public void RandomizeTraits()
		{
			Traits.Strength item = (Traits.Strength)Random.Range(0, 8);
			Traits.Weakness item2 = (Traits.Weakness)Random.Range(0, 8);
			m_strengthTraits.Add(item);
			m_weaknessTraits.Add(item2);
		}

		public void SaveLoadAttributes(SaveData data)
		{
			data.GroupStart("CharacterAttributes");
			SaveLoadPreset_Internal(data);
			data.GroupEnd();
		}

		protected virtual void SaveLoadPreset_Internal(SaveData data)
		{
			data.SaveLoad("mesh_id", ref m_meshId);
			data.SaveLoad("first_name", ref m_firstName);
			data.SaveLoad("last_name", ref m_lastName);
			data.SaveLoad("head_tex", ref m_headTexture);
			data.SaveLoad("torso_tex", ref m_torsoTexture);
			data.SaveLoad("leg_tex", ref m_legTexture);
			data.SaveLoad("skin_color", ref m_skinColor);
			data.SaveLoad("hair_color", ref m_hairColor);
			data.SaveLoad("shirt_color", ref m_shirtColor);
			data.SaveLoad("pants_color", ref m_pantsColor);
			data.SaveLoad("strength_level", ref m_strengthLevel);
			data.SaveLoad("strength_max", ref m_strengthMax);
			data.SaveLoad("dexterity_level", ref m_dexterityLevel);
			data.SaveLoad("dexterity_max", ref m_dexterityMax);
			data.SaveLoad("charisma_level", ref m_charismaLevel);
			data.SaveLoad("charisma_max", ref m_charismaMax);
			data.SaveLoad("perception_level", ref m_perceptionLevel);
			data.SaveLoad("perception_max", ref m_perceptionMax);
			data.SaveLoad("intelligence_level", ref m_intelligenceLevel);
			data.SaveLoad("intelligence_max", ref m_intelligenceMax);
			data.SaveLoadList("strengths", m_strengthTraits, delegate(int i)
			{
				int value2 = (int)m_strengthTraits[i];
				data.SaveLoad("strength", ref value2);
			}, delegate
			{
				int value2 = 0;
				data.SaveLoad("strength", ref value2);
				m_strengthTraits.Add((Traits.Strength)value2);
			});
			data.SaveLoadList("weaknesses", m_strengthTraits, delegate(int i)
			{
				int value2 = (int)m_weaknessTraits[i];
				data.SaveLoad("weakness", ref value2);
			}, delegate
			{
				int value2 = 0;
				data.SaveLoad("weakness", ref value2);
				m_weaknessTraits.Add((Traits.Weakness)value2);
			});
			int value = (int)m_personality;
			data.SaveLoad("personality", ref value);
			if (data.isLoading)
			{
				m_personality = (EncounterCharacter.PersonalityType)value;
			}
		}
	}

	public class PetSpawnInfo
	{
		public PetType petType = PetType.Max;

		public Vector3 position = Vector3.zero;

		public GameObject prefab;

		public ObjectManager.ObjectType objectType = ObjectManager.ObjectType.Undefined;

		public int objectLevel = 1;
	}

	[Serializable]
	private class PetPrefab
	{
		public PetType pet = PetType.Max;

		public GameObject prefab;
	}

	public class PendingFamilyMember
	{
		public CharacterAttributes attributes = new CharacterAttributes();
	}

	public class PendingPet
	{
		public PetType petType = PetType.Dog;

		public string petName = "Brutus";
	}

	[SerializeField]
	private GameObject m_familyMemberPrefab;

	[SerializeField]
	private GameObject m_npcPrefab;

	[SerializeField]
	private List<Transform> m_initialSpawnPoints = new List<Transform>();

	[SerializeField]
	private Transform m_petSpawnPoint;

	private List<PetSpawnInfo> m_petSpawnInfo = new List<PetSpawnInfo>();

	[SerializeField]
	private List<PetPrefab> m_petPrefabs = new List<PetPrefab>();

	[SerializeField]
	private PetType m_forcedPet = PetType.Max;

	private static List<PendingFamilyMember> m_pendingSpawns = new List<PendingFamilyMember>();

	public static PendingPet m_pendingPet = null;

	private static FamilySpawner m_instance = null;

	public static int numPendingSpawns => m_pendingSpawns.Count;

	public static FamilySpawner instance => m_instance;

	public void Awake()
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
			return;
		}
		if ((Object)(object)m_petSpawnPoint != (Object)null)
		{
			RegisterPetSpawnInfo(PetType.Cat, m_petSpawnPoint.position, GetPrefabForPet(PetType.Cat));
			RegisterPetSpawnInfo(PetType.Dog, m_petSpawnPoint.position, GetPrefabForPet(PetType.Dog));
		}
	}

	public FamilyMember SpawnFamilyMember(CharacterAttributes attribs, Vector3 position)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		if (attribs == null)
		{
			return null;
		}
		if ((Object)(object)m_familyMemberPrefab == (Object)null)
		{
			return null;
		}
		GameObject val = Object.Instantiate<GameObject>(m_familyMemberPrefab, position, Quaternion.identity);
		if ((Object)(object)val != (Object)null)
		{
			val.transform.parent = ((Component)this).transform;
			FamilyMember component = val.GetComponent<FamilyMember>();
			if ((Object)(object)component == (Object)null)
			{
				Object.Destroy((Object)(object)val);
				return null;
			}
			if ((Object)(object)CharacterMeshOptions.instance != (Object)null)
			{
				attribs.m_mesh = CharacterMeshOptions.instance.FindCharacterMesh(attribs.m_meshId);
			}
			if (attribs.m_mesh != null && (Object)(object)attribs.m_mesh.m_meshAsset != (Object)null)
			{
				GameObject val2 = Object.Instantiate<GameObject>(attribs.m_mesh.m_meshAsset, Vector3.zero, Quaternion.identity);
				if ((Object)(object)val2 != (Object)null)
				{
					((Object)val2.gameObject).name = "mesh";
					val2.transform.parent = val.transform;
					val2.transform.localPosition = Vector2.op_Implicit(attribs.m_mesh.m_meshOffset);
					val2.transform.rotation = Quaternion.Euler(new Vector3(0f, 180f, 0f));
					val2.AddComponent<CharacterAnimEvents>();
					CharacterMesh characterMesh = val2.AddComponent<CharacterMesh>();
					if ((Object)(object)characterMesh != (Object)null)
					{
						characterMesh.SetMeshType(attribs.m_mesh, "CharacterMesh");
					}
					DayNightTransition dayNightTransition = val2.AddComponent<DayNightTransition>();
					if ((Object)(object)dayNightTransition != (Object)null)
					{
						dayNightTransition.TransitionColor1 = new Color(0.3529412f, 20f / 51f, 0.7058824f);
						dayNightTransition.checkForChild = false;
						dayNightTransition.checkRecursive = false;
						dayNightTransition.alphaTransition = false;
						dayNightTransition.particleTransition = false;
					}
					component.SetCharacterMesh(characterMesh);
				}
			}
			component.SetUpSpawn(attribs);
			return component;
		}
		return null;
	}

	public NpcVisitor SpawnNpc(CharacterAttributes attribs, Vector3 position)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		if (attribs == null)
		{
			return null;
		}
		if ((Object)(object)m_npcPrefab == (Object)null)
		{
			return null;
		}
		GameObject val = Object.Instantiate<GameObject>(m_npcPrefab, position, Quaternion.identity);
		if ((Object)(object)val != (Object)null)
		{
			val.transform.parent = ((Component)this).transform;
			NpcVisitor component = val.GetComponent<NpcVisitor>();
			if ((Object)(object)component == (Object)null)
			{
				Object.Destroy((Object)(object)val);
				return null;
			}
			if ((Object)(object)CharacterMeshOptions.instance != (Object)null)
			{
				attribs.m_mesh = CharacterMeshOptions.instance.FindCharacterMesh(attribs.m_meshId);
			}
			if (attribs.m_mesh != null && (Object)(object)attribs.m_mesh.m_meshAsset != (Object)null)
			{
				GameObject val2 = Object.Instantiate<GameObject>(attribs.m_mesh.m_meshAsset, Vector3.zero, Quaternion.identity);
				if ((Object)(object)val2 != (Object)null)
				{
					((Object)val2.gameObject).name = "mesh";
					val2.transform.parent = val.transform;
					val2.transform.localPosition = Vector2.op_Implicit(attribs.m_mesh.m_meshOffset);
					val2.transform.rotation = Quaternion.Euler(new Vector3(0f, 180f, 0f));
					val2.AddComponent<CharacterAnimEvents>();
					CharacterMesh characterMesh = val2.AddComponent<CharacterMesh>();
					if ((Object)(object)characterMesh != (Object)null)
					{
						characterMesh.SetMeshType(attribs.m_mesh, "CharacterMesh");
					}
					DayNightTransition dayNightTransition = val2.AddComponent<DayNightTransition>();
					if ((Object)(object)dayNightTransition != (Object)null)
					{
						dayNightTransition.TransitionColor1 = new Color(0.3529412f, 20f / 51f, 0.7058824f);
						dayNightTransition.checkForChild = false;
						dayNightTransition.checkRecursive = false;
						dayNightTransition.alphaTransition = false;
						dayNightTransition.particleTransition = false;
					}
					Animator component2 = val2.GetComponent<Animator>();
					if ((Object)(object)component2 != (Object)null)
					{
						component2.runtimeAnimatorController = attribs.m_mesh.m_anims;
					}
					component.SetCharacterMesh(characterMesh);
				}
			}
			component.SetUpSpawn(attribs);
			return component;
		}
		return null;
	}

	public void RegisterPetSpawnInfo(PetType petType, Vector3 position, GameObject prefab = null)
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		if (m_petSpawnInfo.FindIndex((PetSpawnInfo x) => x.petType == petType) < 0)
		{
			PetSpawnInfo petSpawnInfo = new PetSpawnInfo();
			petSpawnInfo.petType = petType;
			petSpawnInfo.position = position;
			petSpawnInfo.prefab = prefab;
			m_petSpawnInfo.Add(petSpawnInfo);
		}
	}

	public void RegisterPetSpawnInfo(PetType petType, Vector3 position, ObjectManager.ObjectType objectType, int objectLevel)
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		if (m_petSpawnInfo.FindIndex((PetSpawnInfo x) => x.petType == petType) < 0)
		{
			PetSpawnInfo petSpawnInfo = new PetSpawnInfo();
			petSpawnInfo.petType = petType;
			petSpawnInfo.position = position;
			petSpawnInfo.objectType = objectType;
			petSpawnInfo.objectLevel = objectLevel;
			m_petSpawnInfo.Add(petSpawnInfo);
		}
	}

	public GameObject GetPrefabForPet(PetType type)
	{
		return m_petPrefabs.Find((PetPrefab x) => x.pet == type)?.prefab;
	}

	public Vector3 GetDefaultPositionForPet(PetType petType)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		return m_petSpawnInfo.Find((PetSpawnInfo x) => x.petType == petType)?.position ?? Vector3.zero;
	}

	public void SpawnPet(PetType petType, string petName)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		PetSpawnInfo petSpawnInfo = m_petSpawnInfo.Find((PetSpawnInfo x) => x.petType == petType);
		if (petSpawnInfo != null)
		{
			SpawnPet(petType, petName, petSpawnInfo.position);
		}
	}

	public void SpawnPet(PetType petType, string petName, Vector3 position)
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		PetSpawnInfo petSpawnInfo = m_petSpawnInfo.Find((PetSpawnInfo x) => x.petType == petType);
		if (petSpawnInfo == null)
		{
			return;
		}
		if (petSpawnInfo.objectType != ObjectManager.ObjectType.Undefined)
		{
			Obj_Base obj_Base = ObjectManager.Instance.SpawnObject(petSpawnInfo.objectType, petSpawnInfo.objectLevel, Vector2.op_Implicit(position));
			if ((Object)(object)obj_Base == (Object)null)
			{
				return;
			}
			((Component)obj_Base).transform.parent = ((Component)this).transform;
			Obj_Pet component = ((Component)obj_Base).GetComponent<Obj_Pet>();
			if ((Object)(object)component != (Object)null)
			{
				component.petName = petName;
				component.m_type = petType;
				if ((Object)(object)FamilyManager.Instance != (Object)null)
				{
					FamilyManager.Instance.RegisterPet(component);
				}
			}
		}
		else
		{
			if (!((Object)(object)petSpawnInfo.prefab != (Object)null))
			{
				return;
			}
			GameObject val = Object.Instantiate<GameObject>(petSpawnInfo.prefab, position, Quaternion.identity);
			if ((Object)(object)val == (Object)null)
			{
				return;
			}
			val.transform.parent = ((Component)this).transform;
			CompanionAnimal component2 = val.GetComponent<CompanionAnimal>();
			if ((Object)(object)component2 != (Object)null)
			{
				component2.petName = petName;
				component2.m_type = petType;
				if ((Object)(object)FamilyManager.Instance != (Object)null)
				{
					FamilyManager.Instance.RegisterPet(component2);
				}
			}
		}
	}

	public void Update()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		if (m_pendingSpawns.Count > 0)
		{
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading)
			{
				int num = 0;
				for (int i = 0; i < m_pendingSpawns.Count; i++)
				{
					Vector3 position = Vector3.zero;
					if (num < m_initialSpawnPoints.Count)
					{
						position = m_initialSpawnPoints[num].position;
						if (num + 1 < m_initialSpawnPoints.Count)
						{
							num++;
						}
					}
					SpawnFamilyMember(m_pendingSpawns[i].attributes, position);
				}
			}
			ClearPendingFamilySpawns();
		}
		if (m_pendingPet != null)
		{
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading)
			{
				SpawnPet(m_pendingPet.petType, m_pendingPet.petName);
			}
			m_pendingPet = null;
		}
	}

	public static void SetPendingFamilySpawn(CharacterAttributes attribs)
	{
		PendingFamilyMember pendingFamilyMember = new PendingFamilyMember();
		pendingFamilyMember.attributes = attribs;
		m_pendingSpawns.Add(pendingFamilyMember);
	}

	public static void ClearPendingFamilySpawns()
	{
		m_pendingSpawns.Clear();
	}

	public static void ForceSpawnPending()
	{
		if ((Object)(object)instance != (Object)null)
		{
			instance.Update();
		}
	}
}
