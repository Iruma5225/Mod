using UnityEngine;

[ExecuteInEditMode]
public class UI_CollapseOnDisable : MonoBehaviour
{
	private int m_topYOffset;

	private int m_bottomYOffset;

	private void OnEnable()
	{
		UILabel component = ((Component)this).gameObject.GetComponent<UILabel>();
		if ((Object)(object)component != (Object)null)
		{
			if (component.topAnchor != null)
			{
				component.topAnchor.absolute -= m_topYOffset;
			}
			if (component.bottomAnchor != null)
			{
				component.bottomAnchor.absolute -= m_bottomYOffset;
			}
		}
	}

	private void OnDisable()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		UILabel component = ((Component)this).gameObject.GetComponent<UILabel>();
		if ((Object)(object)component != (Object)null)
		{
			if (component.topAnchor != null && (Object)(object)component.topAnchor.target != (Object)null)
			{
				m_topYOffset = (int)(((Component)component.topAnchor.target).transform.localPosition.y - ((Component)this).gameObject.transform.localPosition.y);
				component.topAnchor.absolute += m_topYOffset;
			}
			if (component.bottomAnchor != null && (Object)(object)component.bottomAnchor.target != (Object)null)
			{
				m_bottomYOffset = (int)(((Component)component.bottomAnchor.target).transform.localPosition.y - ((Component)this).gameObject.transform.localPosition.y);
				component.bottomAnchor.absolute += m_bottomYOffset;
			}
		}
	}
}
