using System;
using System.Diagnostics;
using System.Text;
using UnityEngine;

public static class LogUtil
{
	private const int iNumUsers = 14;

	private static bool[] userToggle = new bool[14]
	{
		true, false, false, false, false, false, false, false, false, false,
		false, false, false, true
	};

	[Conditional("UNITY_EDITOR")]
	public static void Log(string s, LogUser eUser = LogUser.Default)
	{
		if (IsValidAndActive(eUser))
		{
			Debug.Log((object)(ColourTheText(eUser, s) + GetStackTrace()));
		}
	}

	[Conditional("UNITY_EDITOR")]
	public static void Error(string s, LogUser eUser = LogUser.Essential)
	{
		if (IsValidAndActive(eUser))
		{
			Debug.LogError((object)(ColourTheText(eUser, s) + GetStackTrace()));
		}
	}

	[Conditional("UNITY_EDITOR")]
	public static void Warning(string s, LogUser eUser = LogUser.Essential)
	{
		if (IsValidAndActive(eUser))
		{
			Debug.LogWarning((object)(ColourTheText(eUser, s) + GetStackTrace()));
		}
	}

	[Conditional("UNITY_EDITOR")]
	public static void Exception(Exception e, LogUser eUser = LogUser.Essential)
	{
		if (IsValidAndActive(eUser))
		{
			Debug.LogException(e);
		}
	}

	private static string GetStackTrace()
	{
		StackTrace stackTrace = new StackTrace(2, fNeedFileInfo: true);
		StackFrame frame = stackTrace.GetFrame(0);
		string text = frame.GetFileName();
		int num = text.LastIndexOf("Assets\\");
		if (num >= 0)
		{
			text = text.Substring(num + 7);
		}
		return string.Concat("\n", text, ": <b>", frame.GetMethod(), "</b> - Line <b>", frame.GetFileLineNumber(), "</b>\n\n");
	}

	private static string ColourTheText(LogUser eUser, string message)
	{
		return eUser switch
		{
			LogUser.MapError => "<color=orange>" + message + "</Color>", 
			LogUser.Essential => "<color=#ffa0a0>" + message + "</Color>", 
			LogUser.Quests => "<color=pink>" + message + "</Color>", 
			LogUser.TMX => "<color=cyan>" + message + "</Color>", 
			_ => message, 
		};
	}

	private static bool IsValidAndActive(LogUser eUser)
	{
		switch (eUser)
		{
		case LogUser.MapError:
		case LogUser.Essential:
			return true;
		case LogUser.Default:
		case LogUser.TMX:
		case LogUser.UI:
		case LogUser.Localization:
		case LogUser.SaveGame:
		case LogUser.GameFloor:
		case LogUser.Quests:
		case LogUser.Jobs:
		case LogUser.Tutorials:
		case LogUser.AStar:
		case LogUser.TutorialLevel:
		case LogUser.GameLoading:
		case LogUser.SequentialDelegates:
		case LogUser.Exploration:
			if (userToggle[(int)eUser])
			{
				return true;
			}
			break;
		}
		return false;
	}

	public static void SetUser(LogUser eUser, bool state = true)
	{
		if (eUser >= LogUser.Default && eUser < LogUser.NumLogUsers)
		{
			userToggle[(int)eUser] = state;
		}
	}

	public static bool GetUserStatus(LogUser eUser)
	{
		bool result = false;
		if (eUser >= LogUser.Default && eUser < LogUser.NumLogUsers)
		{
			result = userToggle[(int)eUser];
		}
		return result;
	}

	public static string HexDump(byte[] bytes, int bytesPerLine = 16)
	{
		if (bytes == null)
		{
			return "<null>";
		}
		int num = bytes.Length;
		char[] array = "0123456789ABCDEF".ToCharArray();
		int num2 = 11;
		int num3 = num2 + bytesPerLine * 3 + (bytesPerLine - 1) / 8 + 2;
		int num4 = num3 + bytesPerLine + Environment.NewLine.Length;
		char[] array2 = (new string(' ', num4 - 2) + Environment.NewLine).ToCharArray();
		int num5 = (num + bytesPerLine - 1) / bytesPerLine;
		StringBuilder stringBuilder = new StringBuilder(num5 * num4);
		for (int i = 0; i < num; i += bytesPerLine)
		{
			array2[0] = array[(i >> 28) & 0xF];
			array2[1] = array[(i >> 24) & 0xF];
			array2[2] = array[(i >> 20) & 0xF];
			array2[3] = array[(i >> 16) & 0xF];
			array2[4] = array[(i >> 12) & 0xF];
			array2[5] = array[(i >> 8) & 0xF];
			array2[6] = array[(i >> 4) & 0xF];
			array2[7] = array[(i >> 0) & 0xF];
			int num6 = num2;
			int num7 = num3;
			for (int j = 0; j < bytesPerLine; j++)
			{
				if (j > 0 && (j & 7) == 0)
				{
					num6++;
				}
				if (i + j >= num)
				{
					array2[num6] = ' ';
					array2[num6 + 1] = ' ';
					array2[num7] = ' ';
				}
				else
				{
					byte b = bytes[i + j];
					array2[num6] = array[(b >> 4) & 0xF];
					array2[num6 + 1] = array[b & 0xF];
					array2[num7] = ((b >= 32) ? ((char)b) : '\ufffd');
				}
				num6 += 3;
				num7++;
			}
			stringBuilder.Append(array2);
		}
		return stringBuilder.ToString();
	}
}
