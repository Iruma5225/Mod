using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

[Serializable]
public class EventDelegateSequenced
{
	public enum EventDelegateReturn
	{
		FAILED,
		WaitAFrame,
		Continue,
		Finished
	}

	[Serializable]
	public class Parameter
	{
		public Object obj;

		public string field;

		[NonSerialized]
		public Type expectedType = typeof(void);

		[NonSerialized]
		public bool cached;

		[NonSerialized]
		public PropertyInfo propInfo;

		[NonSerialized]
		public FieldInfo fieldInfo;

		public object value
		{
			get
			{
				if (!cached)
				{
					cached = true;
					fieldInfo = null;
					propInfo = null;
					if (obj != (Object)null && !string.IsNullOrEmpty(field))
					{
						Type type = ((object)obj).GetType();
						propInfo = type.GetProperty(field);
						if ((object)propInfo == null)
						{
							fieldInfo = type.GetField(field);
						}
					}
				}
				if ((object)propInfo != null)
				{
					return propInfo.GetValue(obj, null);
				}
				if ((object)fieldInfo != null)
				{
					return fieldInfo.GetValue(obj);
				}
				return obj;
			}
		}

		public Type type
		{
			get
			{
				if (obj == (Object)null)
				{
					return typeof(void);
				}
				return ((object)obj).GetType();
			}
		}

		public Parameter()
		{
		}

		public Parameter(Object obj, string field)
		{
			this.obj = obj;
			this.field = field;
		}
	}

	public delegate EventDelegateReturn Callback();

	[SerializeField]
	private MonoBehaviour mTarget;

	[SerializeField]
	private string mMethodName;

	[SerializeField]
	private Parameter[] mParameters;

	public bool oneShot;

	[NonSerialized]
	private Callback mCachedCallback;

	[NonSerialized]
	private bool mRawDelegate;

	[NonSerialized]
	private bool mCached;

	[NonSerialized]
	private MethodInfo mMethod;

	[NonSerialized]
	private object[] mArgs;

	private static int s_Hash = "EventDelegateSequenced".GetHashCode();

	public MonoBehaviour target
	{
		get
		{
			return mTarget;
		}
		set
		{
			mTarget = value;
			mCachedCallback = null;
			mRawDelegate = false;
			mCached = false;
			mMethod = null;
			mParameters = null;
		}
	}

	public string methodName
	{
		get
		{
			return mMethodName;
		}
		set
		{
			mMethodName = value;
			mCachedCallback = null;
			mRawDelegate = false;
			mCached = false;
			mMethod = null;
			mParameters = null;
		}
	}

	public Parameter[] parameters
	{
		get
		{
			if (!mCached)
			{
				Cache();
			}
			return mParameters;
		}
	}

	public bool isValid
	{
		get
		{
			if (!mCached)
			{
				Cache();
			}
			return (mRawDelegate && mCachedCallback != null) || ((Object)(object)mTarget != (Object)null && !string.IsNullOrEmpty(mMethodName));
		}
	}

	public bool isEnabled
	{
		get
		{
			if (!mCached)
			{
				Cache();
			}
			if (mRawDelegate && mCachedCallback != null)
			{
				return true;
			}
			if ((Object)(object)mTarget == (Object)null)
			{
				return false;
			}
			MonoBehaviour val = mTarget;
			return (Object)(object)val == (Object)null || ((Behaviour)val).enabled;
		}
	}

	public EventDelegateSequenced()
	{
	}

	public EventDelegateSequenced(Callback call)
	{
		Set(call);
	}

	public EventDelegateSequenced(MonoBehaviour target, string methodName)
	{
		Set(target, methodName);
	}

	private static string GetMethodName(Callback callback)
	{
		return callback.Method.Name;
	}

	private static bool IsValid(Callback callback)
	{
		return callback != null && (object)callback.Method != null;
	}

	public override bool Equals(object obj)
	{
		if (obj == null)
		{
			return !isValid;
		}
		if (obj is Callback)
		{
			Callback callback = obj as Callback;
			if (callback.Equals(mCachedCallback))
			{
				return true;
			}
			object? obj2 = callback.Target;
			MonoBehaviour val = (MonoBehaviour)((obj2 is MonoBehaviour) ? obj2 : null);
			return (Object)(object)mTarget == (Object)(object)val && string.Equals(mMethodName, GetMethodName(callback));
		}
		if (obj is EventDelegateSequenced)
		{
			EventDelegateSequenced eventDelegateSequenced = obj as EventDelegateSequenced;
			return (Object)(object)mTarget == (Object)(object)eventDelegateSequenced.mTarget && string.Equals(mMethodName, eventDelegateSequenced.mMethodName);
		}
		return false;
	}

	public override int GetHashCode()
	{
		return s_Hash;
	}

	private void Set(Callback call)
	{
		Clear();
		if (call != null && IsValid(call))
		{
			ref MonoBehaviour reference = ref mTarget;
			object? obj = call.Target;
			reference = (MonoBehaviour)((obj is MonoBehaviour) ? obj : null);
			if ((Object)(object)mTarget == (Object)null)
			{
				mRawDelegate = true;
				mCachedCallback = call;
				mMethodName = null;
			}
			else
			{
				mMethodName = GetMethodName(call);
				mRawDelegate = false;
			}
		}
	}

	public void Set(MonoBehaviour target, string methodName)
	{
		Clear();
		mTarget = target;
		mMethodName = methodName;
	}

	private void Cache()
	{
		mCached = true;
		if (mRawDelegate || (mCachedCallback != null && !((Object)/*isinst with value type is only supported in some contexts*/ != (Object)(object)mTarget) && !(GetMethodName(mCachedCallback) != mMethodName)) || !((Object)(object)mTarget != (Object)null) || string.IsNullOrEmpty(mMethodName))
		{
			return;
		}
		Type type = ((object)mTarget).GetType();
		mMethod = null;
		while ((object)type != null)
		{
			try
			{
				mMethod = type.GetMethod(mMethodName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
				if ((object)mMethod != null)
				{
					break;
				}
			}
			catch (Exception)
			{
			}
			type = type.BaseType;
		}
		if ((object)mMethod == null)
		{
			Debug.LogError((object)("Could not find method '" + mMethodName + "' on " + ((object)mTarget).GetType()), (Object)(object)mTarget);
			return;
		}
		if ((object)mMethod.ReturnType != typeof(EventDelegateReturn))
		{
			Debug.LogError((object)string.Concat(((object)mTarget).GetType(), ".", mMethodName, " must have a 'EventDelegateReturn' return type."), (Object)(object)mTarget);
			return;
		}
		ParameterInfo[] array = mMethod.GetParameters();
		if (array.Length == 0)
		{
			mCachedCallback = (Callback)Delegate.CreateDelegate(typeof(Callback), mTarget, mMethodName);
			mArgs = null;
			mParameters = null;
			return;
		}
		mCachedCallback = null;
		if (mParameters == null || mParameters.Length != array.Length)
		{
			mParameters = new Parameter[array.Length];
			int i = 0;
			for (int num = mParameters.Length; i < num; i++)
			{
				mParameters[i] = new Parameter();
			}
		}
		int j = 0;
		for (int num2 = mParameters.Length; j < num2; j++)
		{
			mParameters[j].expectedType = array[j].ParameterType;
		}
	}

	public EventDelegateReturn Execute()
	{
		if (!mCached)
		{
			Cache();
		}
		if (mCachedCallback != null)
		{
			return mCachedCallback();
		}
		if ((object)mMethod != null)
		{
			if (mParameters == null || mParameters.Length == 0)
			{
				object obj = mMethod.Invoke(mTarget, null);
				if ((object)obj.GetType() != typeof(EventDelegateReturn))
				{
					return EventDelegateReturn.FAILED;
				}
				return (EventDelegateReturn)obj;
			}
			if (mArgs == null || mArgs.Length != mParameters.Length)
			{
				mArgs = new object[mParameters.Length];
			}
			int i = 0;
			for (int num = mParameters.Length; i < num; i++)
			{
				mArgs[i] = mParameters[i].value;
			}
			try
			{
				object obj2 = mMethod.Invoke(mTarget, mArgs);
				if ((object)obj2.GetType() != typeof(EventDelegateReturn))
				{
					return EventDelegateReturn.FAILED;
				}
				return (EventDelegateReturn)obj2;
			}
			catch (ArgumentException ex)
			{
				string text = "Error calling ";
				if ((Object)(object)mTarget == (Object)null)
				{
					text += mMethod.Name;
				}
				else
				{
					string text2 = text;
					text = string.Concat(text2, ((object)mTarget).GetType(), ".", mMethod.Name);
				}
				text = text + ": " + ex.Message;
				text += "\n  Expected: ";
				ParameterInfo[] array = mMethod.GetParameters();
				if (array.Length == 0)
				{
					text += "no arguments";
				}
				else
				{
					text += array[0];
					for (int j = 1; j < array.Length; j++)
					{
						text = text + ", " + array[j].ParameterType;
					}
				}
				text += "\n  Received: ";
				if (mParameters.Length == 0)
				{
					text += "no arguments";
				}
				else
				{
					text += mParameters[0].type;
					for (int k = 1; k < mParameters.Length; k++)
					{
						text = text + ", " + mParameters[k].type;
					}
				}
				text += "\n";
				Debug.LogError((object)text);
			}
			int l = 0;
			for (int num2 = mArgs.Length; l < num2; l++)
			{
				mArgs[l] = null;
			}
			return EventDelegateReturn.Finished;
		}
		return EventDelegateReturn.FAILED;
	}

	public void Clear()
	{
		mTarget = null;
		mMethodName = null;
		mRawDelegate = false;
		mCachedCallback = null;
		mParameters = null;
		mCached = false;
		mMethod = null;
		mArgs = null;
	}

	public override string ToString()
	{
		if ((Object)(object)mTarget != (Object)null)
		{
			string text = ((object)mTarget).GetType().ToString();
			int num = text.LastIndexOf('.');
			if (num > 0)
			{
				text = text.Substring(num + 1);
			}
			if (!string.IsNullOrEmpty(methodName))
			{
				return text + "/" + methodName;
			}
			return text + "/[delegate]";
		}
		return (!mRawDelegate) ? null : "[delegate]";
	}

	public static void Execute(List<EventDelegateSequenced> list)
	{
		if (list == null)
		{
			return;
		}
		int num = 0;
		while (num < list.Count)
		{
			EventDelegateSequenced eventDelegateSequenced = list[num];
			if (eventDelegateSequenced != null)
			{
				eventDelegateSequenced.Execute();
				if (num >= list.Count)
				{
					break;
				}
				if (list[num] != eventDelegateSequenced)
				{
					continue;
				}
				if (eventDelegateSequenced.oneShot)
				{
					list.RemoveAt(num);
					continue;
				}
			}
			num++;
		}
	}

	public static bool IsValid(List<EventDelegateSequenced> list)
	{
		if (list != null)
		{
			int i = 0;
			for (int count = list.Count; i < count; i++)
			{
				EventDelegateSequenced eventDelegateSequenced = list[i];
				if (eventDelegateSequenced != null && eventDelegateSequenced.isValid)
				{
					return true;
				}
			}
		}
		return false;
	}

	public static EventDelegateSequenced Set(List<EventDelegateSequenced> list, Callback callback)
	{
		if (list != null)
		{
			EventDelegateSequenced eventDelegateSequenced = new EventDelegateSequenced(callback);
			list.Clear();
			list.Add(eventDelegateSequenced);
			return eventDelegateSequenced;
		}
		return null;
	}

	public static void Set(List<EventDelegateSequenced> list, EventDelegateSequenced del)
	{
		if (list != null)
		{
			list.Clear();
			list.Add(del);
		}
	}

	public static EventDelegateSequenced Add(List<EventDelegateSequenced> list, Callback callback)
	{
		return Add(list, callback, oneShot: false);
	}

	public static EventDelegateSequenced Add(List<EventDelegateSequenced> list, Callback callback, bool oneShot)
	{
		if (list != null)
		{
			int i = 0;
			for (int count = list.Count; i < count; i++)
			{
				EventDelegateSequenced eventDelegateSequenced = list[i];
				if (eventDelegateSequenced != null && eventDelegateSequenced.Equals(callback))
				{
					return eventDelegateSequenced;
				}
			}
			EventDelegateSequenced eventDelegateSequenced2 = new EventDelegateSequenced(callback);
			eventDelegateSequenced2.oneShot = oneShot;
			list.Add(eventDelegateSequenced2);
			return eventDelegateSequenced2;
		}
		Debug.LogWarning((object)"Attempting to add a callback to a list that's null");
		return null;
	}

	public static void Add(List<EventDelegateSequenced> list, EventDelegateSequenced ev)
	{
		Add(list, ev, ev.oneShot);
	}

	public static void Add(List<EventDelegateSequenced> list, EventDelegateSequenced ev, bool oneShot)
	{
		if (ev.mRawDelegate || (Object)(object)ev.target == (Object)null || string.IsNullOrEmpty(ev.methodName))
		{
			Add(list, ev.mCachedCallback, oneShot);
		}
		else if (list != null)
		{
			int i = 0;
			for (int count = list.Count; i < count; i++)
			{
				EventDelegateSequenced eventDelegateSequenced = list[i];
				if (eventDelegateSequenced != null && eventDelegateSequenced.Equals(ev))
				{
					return;
				}
			}
			EventDelegateSequenced eventDelegateSequenced2 = new EventDelegateSequenced(ev.target, ev.methodName);
			eventDelegateSequenced2.oneShot = oneShot;
			if (ev.mParameters != null && ev.mParameters.Length > 0)
			{
				eventDelegateSequenced2.mParameters = new Parameter[ev.mParameters.Length];
				for (int j = 0; j < ev.mParameters.Length; j++)
				{
					eventDelegateSequenced2.mParameters[j] = ev.mParameters[j];
				}
			}
			list.Add(eventDelegateSequenced2);
		}
		else
		{
			Debug.LogWarning((object)"Attempting to add a callback to a list that's null");
		}
	}

	public static bool Remove(List<EventDelegateSequenced> list, Callback callback)
	{
		if (list != null)
		{
			int i = 0;
			for (int count = list.Count; i < count; i++)
			{
				EventDelegateSequenced eventDelegateSequenced = list[i];
				if (eventDelegateSequenced != null && eventDelegateSequenced.Equals(callback))
				{
					list.RemoveAt(i);
					return true;
				}
			}
		}
		return false;
	}

	public static bool Remove(List<EventDelegateSequenced> list, EventDelegateSequenced ev)
	{
		if (list != null)
		{
			int i = 0;
			for (int count = list.Count; i < count; i++)
			{
				EventDelegateSequenced eventDelegateSequenced = list[i];
				if (eventDelegateSequenced != null && eventDelegateSequenced.Equals(ev))
				{
					list.RemoveAt(i);
					return true;
				}
			}
		}
		return false;
	}
}
