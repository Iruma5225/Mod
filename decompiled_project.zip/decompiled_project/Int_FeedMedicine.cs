using System;
using System.Collections.Generic;
using UnityEngine;

public class Int_FeedMedicine : Int_Base
{
	private Obj_CatatonicGhost catatonic_ghost;

	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "feed_meds";
	}

	public override int GetInteractionPriority()
	{
		return 3;
	}

	public override bool HasSubMenu()
	{
		return true;
	}

	public override void Awake()
	{
		base.Awake();
		catatonic_ghost = obj as Obj_CatatonicGhost;
	}

	public override bool IsPlayerSelectable()
	{
		if (base.IsPlayerSelectable() && (Object)(object)catatonic_ghost != (Object)null && (Object)(object)catatonic_ghost.GetFamilyMember() != (Object)null)
		{
			List<MedicineManager.MedicineType> availableMedicines = MedicineManager.GetAvailableMedicines(MedicineManager.GetUsableMedicines(catatonic_ghost));
			if (availableMedicines.Count > 0)
			{
				return true;
			}
		}
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		ShowMedicationSubMenu(member);
		return true;
	}

	private void ShowMedicationSubMenu(FamilyMember member)
	{
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		List<MedicineManager.MedicineType> availableMedicines = MedicineManager.GetAvailableMedicines(MedicineManager.GetUsableMedicines(catatonic_ghost));
		for (int i = 0; i < availableMedicines.Count; i++)
		{
			ItemManager.ItemType itemType = MedicineManager.MedicineToItem(availableMedicines[i]);
			ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(itemType);
			if ((Object)(object)itemDefinition != (Object)null)
			{
				list.Add(Enum.GetName(typeof(ItemManager.ItemType), itemType));
				list2.Add(Localization.Get("Object.interaction.feed_meds.feed").Replace("%medicine%", Localization.Get(itemDefinition.NameLocalizationKey)));
			}
		}
		ContextMenuPanel interactionMenu = InteractionManager.Instance.GetInteractionMenu();
		if ((Object)(object)interactionMenu != (Object)null)
		{
			interactionMenu.PushNewLayer(string.Empty, list, list2, delegate(string selected)
			{
				OnMedicineSelected(selected, member);
			});
		}
	}

	private void OnMedicineSelected(string option, FamilyMember member)
	{
		MedicineManager.MedicineType[] array = (MedicineManager.MedicineType[])Enum.GetValues(typeof(MedicineManager.MedicineType));
		for (int i = 0; i < array.Length; i++)
		{
			ItemManager.ItemType itemType = MedicineManager.MedicineToItem(array[i]);
			string name = Enum.GetName(typeof(ItemManager.ItemType), itemType);
			if (string.IsNullOrEmpty(name) || string.Compare(option, name) != 0)
			{
				continue;
			}
			if (!((Object)(object)member != (Object)null) || !member.isDead)
			{
				Job_Feed job_Feed = new Job_Feed(member, catatonic_ghost, Job_Feed.FeedType.Medicine);
				job_Feed.SetMedicine(array[i]);
				if (!member.AddPlayerJob(job_Feed))
				{
					job_Feed.Cancel(forced: true);
				}
				if ((Object)(object)MeshSortMan.instance != (Object)null)
				{
					MeshSortMan.instance.ForceToFront(member);
				}
			}
			break;
		}
	}
}
