using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class Obj_Freezer : Obj_Integrity
{
	private int m_Meat;

	private int m_DesperateMeat;

	[SerializeField]
	private int m_TotalMeatCapacity = 10;

	private bool m_Contaminated;

	private float m_WithoutPowerTimer;

	[SerializeField]
	private float m_WithoutPowerContaminateTime = 300f;

	public AudioClip OpenFreezerSound;

	public AudioClip CloseFreezerSound;

	public int Meat => m_Meat;

	public int DesperateMeat => m_DesperateMeat;

	public int TotalMeatCapacity => m_TotalMeatCapacity;

	public override void Start()
	{
		base.Start();
		FoodManager.Instance.RegisterStorage(this);
	}

	public override void OnDestroy()
	{
		base.OnDestroy();
		FoodManager.Instance.UnRegisterStorage(this);
	}

	public override void Update()
	{
		base.Update();
		if (!HasEnoughPower() || IsBroken())
		{
			if ((m_Meat > 0 || m_DesperateMeat > 0) && m_WithoutPowerTimer <= 0f)
			{
				m_WithoutPowerTimer = Time.time + m_WithoutPowerContaminateTime;
			}
		}
		else if (m_WithoutPowerTimer > 0f)
		{
			m_WithoutPowerTimer = 0f;
		}
		if (m_WithoutPowerTimer > 0f && Time.time >= m_WithoutPowerTimer)
		{
			m_Contaminated = true;
		}
	}

	public int AddMeat(int count)
	{
		int num = Mathf.Min(count, m_TotalMeatCapacity - (m_Meat + m_DesperateMeat));
		num = Mathf.Max(0, num);
		m_Meat += num;
		if ((Object)(object)FoodManager.Instance != (Object)null && num > 0)
		{
			FoodManager.Instance.UpdateMeatTotals();
		}
		return num;
	}

	public int RemoveMeat(int count)
	{
		if (m_Meat - count >= 0)
		{
			m_Meat -= count;
			if (m_DesperateMeat + m_Meat == 0)
			{
				if (m_Contaminated)
				{
					m_Contaminated = false;
				}
				m_WithoutPowerTimer = 0f;
			}
			if ((Object)(object)FoodManager.Instance != (Object)null)
			{
				FoodManager.Instance.UpdateMeatTotals();
			}
			return count;
		}
		int meat = m_Meat;
		m_Meat = 0;
		if ((Object)(object)FoodManager.Instance != (Object)null)
		{
			FoodManager.Instance.UpdateMeatTotals();
		}
		return meat;
	}

	public int AddDesperateMeat(int count)
	{
		int num = Mathf.Min(count, m_TotalMeatCapacity - (m_Meat + m_DesperateMeat));
		num = Mathf.Max(0, num);
		m_DesperateMeat += num;
		if ((Object)(object)FoodManager.Instance != (Object)null && num > 0)
		{
			FoodManager.Instance.UpdateMeatTotals();
		}
		return num;
	}

	public int RemoveDesperateMeat(int count)
	{
		if (m_DesperateMeat - count >= 0)
		{
			m_DesperateMeat -= count;
			if (m_DesperateMeat + m_Meat == 0)
			{
				if (m_Contaminated)
				{
					m_Contaminated = false;
				}
				m_WithoutPowerTimer = 0f;
			}
			if ((Object)(object)FoodManager.Instance != (Object)null)
			{
				FoodManager.Instance.UpdateMeatTotals();
			}
			return count;
		}
		int desperateMeat = m_DesperateMeat;
		m_DesperateMeat = 0;
		if ((Object)(object)FoodManager.Instance != (Object)null)
		{
			FoodManager.Instance.UpdateMeatTotals();
		}
		return desperateMeat;
	}

	public void EmptyFridge()
	{
		m_Meat = 0;
		m_DesperateMeat = 0;
		m_Contaminated = false;
		if ((Object)(object)FoodManager.Instance != (Object)null)
		{
			FoodManager.Instance.UpdateMeatTotals();
		}
		if (HasEnoughPower())
		{
			m_WithoutPowerTimer = 0f;
		}
	}

	public void PlayOpenFreezerSound()
	{
		AudioSource component = ((Component)this).GetComponent<AudioSource>();
		if ((Object)(object)component != (Object)null && (Object)(object)OpenFreezerSound != (Object)null)
		{
			component.PlayOneShot(OpenFreezerSound);
		}
	}

	public void PlayCloseFreezerSound()
	{
		AudioSource component = ((Component)this).GetComponent<AudioSource>();
		if ((Object)(object)component != (Object)null && (Object)(object)CloseFreezerSound != (Object)null)
		{
			component.PlayOneShot(CloseFreezerSound);
		}
	}

	public int TotalSpaceAvailable()
	{
		return m_TotalMeatCapacity - (m_Meat + m_DesperateMeat);
	}

	public bool IsMeatContaminated()
	{
		return m_Contaminated;
	}

	public bool IsMeatAvailable()
	{
		return m_Meat > 0;
	}

	public bool IsDesperateMeatAvailable()
	{
		return m_DesperateMeat > 0;
	}

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.Freezer;
	}

	public override List<string> GetTooltipExtraInfo()
	{
		List<string> tooltipExtraInfo = base.GetTooltipExtraInfo();
		StringBuilder stringBuilder = new StringBuilder();
		tooltipExtraInfo.Add(Localization.Get("ui.text.rotten"));
		if (m_Contaminated)
		{
			tooltipExtraInfo.Add(Localization.Get("text.ui.yes"));
		}
		else
		{
			tooltipExtraInfo.Add(Localization.Get("text.ui.no"));
		}
		tooltipExtraInfo.Add(Localization.Get("ui.text.meat"));
		tooltipExtraInfo.Add(m_Meat.ToString());
		tooltipExtraInfo.Add(Localization.Get("ui.text.desperatemeat"));
		tooltipExtraInfo.Add(m_DesperateMeat.ToString());
		tooltipExtraInfo.Add(Localization.Get("ui.text.capacity"));
		stringBuilder.Append((m_Meat + m_DesperateMeat).ToString());
		stringBuilder.Append("/");
		stringBuilder.Append(m_TotalMeatCapacity.ToString());
		tooltipExtraInfo.Add(stringBuilder.ToString());
		return tooltipExtraInfo;
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		data.SaveLoad("meat", ref m_Meat);
		data.SaveLoad("desperateMeat", ref m_DesperateMeat);
		data.SaveLoad("contaminated", ref m_Contaminated);
		data.SaveLoadAbsoluteTime("withoutPowerTimer", ref m_WithoutPowerTimer);
	}
}
