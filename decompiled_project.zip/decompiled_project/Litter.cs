using UnityEngine;

public class Litter : MonoBehaviour
{
	private LitterManager.LitterType type;

	private SpriteRenderer spriteRenderer;

	[SerializeField]
	private GameObject flies;

	public LitterManager.LitterType Type => type;

	public void Awake()
	{
		spriteRenderer = ((Component)this).GetComponentInChildren<SpriteRenderer>();
	}

	public bool SetupLitter(LitterManager.LitterType new_type, Sprite sprite)
	{
		type = new_type;
		if ((Object)(object)spriteRenderer != (Object)null && (Object)(object)sprite != (Object)null)
		{
			spriteRenderer.sprite = sprite;
			if (new_type != LitterManager.LitterType.Craft && new_type != LitterManager.LitterType.Repair && (Object)(object)flies != (Object)null)
			{
				flies.SetActive(true);
			}
			return true;
		}
		return false;
	}
}
