using System.Collections.Generic;
using UnityEngine;

public class Obj_CatatonicGhost : Obj_Base
{
	[SerializeField]
	private float needFoodThreshold = 10f;

	[SerializeField]
	private float needWaterThreshold = 10f;

	private FamilyMember familyMember;

	private bool in_use;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.CatatonicGhost;
	}

	public FamilyMember GetFamilyMember()
	{
		return familyMember;
	}

	public void SetInUse(bool being_used)
	{
		in_use = being_used;
	}

	public bool InUse()
	{
		return in_use;
	}

	protected override bool IsInteractionAllowed(FamilyMember member, string type)
	{
		if (!base.IsInteractionAllowed(member, type))
		{
			return false;
		}
		if (in_use)
		{
			return false;
		}
		return true;
	}

	public void SetUpGhost(FamilyMember member)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)member == (Object)null)
		{
			return;
		}
		familyMember = member;
		SetName(GetLocalizedObjectName());
		if (!member.IsFacingRight())
		{
			BoxCollider2D component = ((Component)this).GetComponent<BoxCollider2D>();
			if ((Object)(object)component != (Object)null)
			{
				Vector2 offset = ((Collider2D)component).offset;
				offset.x *= -1f;
				((Collider2D)component).offset = offset;
			}
		}
	}

	public override string GetLocalizedObjectName()
	{
		string text = base.GetLocalizedObjectName();
		if ((Object)(object)familyMember != (Object)null)
		{
			text = text.Replace("$1$", familyMember.firstName);
		}
		return text;
	}

	public bool NeedsFood()
	{
		if ((Object)(object)familyMember != (Object)null)
		{
			return familyMember.stats.hunger.Value >= needFoodThreshold;
		}
		return false;
	}

	public bool NeedsWater()
	{
		if ((Object)(object)familyMember != (Object)null)
		{
			return familyMember.stats.thirst.Value >= needWaterThreshold;
		}
		return false;
	}

	public bool NeedsMeds()
	{
		List<MedicineManager.MedicineType> usableMedicines = MedicineManager.GetUsableMedicines(this);
		return usableMedicines.Count > 0;
	}

	public bool HasHazmatSuit()
	{
		if ((Object)(object)familyMember != (Object)null)
		{
			return familyMember.isWearingHazmatSuit;
		}
		return false;
	}

	public override bool IsReadyForLoad()
	{
		if (base.IsReadyForLoad() && (Object)(object)SaveManager.instance != (Object)null && (Object)(object)FamilyManager.Instance != (Object)null && SaveManager.instance.HasBeenLoaded(FamilyManager.Instance) && FamilyManager.Instance.HaveAllFamilyBeenLoaded())
		{
			return true;
		}
		return false;
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		int value = -1;
		if ((Object)(object)familyMember != (Object)null)
		{
			value = familyMember.GetId();
		}
		data.SaveLoad("familyId", ref value);
		if (data.isLoading && value > -1 && (Object)(object)FamilyManager.Instance != (Object)null)
		{
			familyMember = FamilyManager.Instance.GetFamilyMember(value);
			if ((Object)(object)familyMember != (Object)null)
			{
				SetUpGhost(familyMember);
			}
		}
	}
}
