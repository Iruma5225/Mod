using UnityEngine;

public class Job_Craft : Job
{
	protected CraftingManager.Recipe target_recipe;

	public Job_Craft()
	{
		if (!((Object)(object)SaveManager.instance == (Object)null) && SaveManager.instance.isLoading)
		{
		}
	}

	public Job_Craft(FamilyMember target_character, CraftingManager.Recipe recipe, Obj_Base target_obj)
		: base("craft", ((Component)target_obj).transform.position, target_character, target_obj)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		target_recipe = recipe;
		if ((Object)(object)target_obj != (Object)null && target_recipe != null)
		{
			Obj_GhostBase obj_GhostBase = obj as Obj_GhostBase;
			if ((Object)(object)obj_GhostBase != (Object)null)
			{
				obj_GhostBase.SetCraftRecipeID(target_recipe.ID);
			}
		}
	}

	public override string GetJobType()
	{
		return "Job_Craft";
	}

	public override bool BeginJob()
	{
		if (!base.BeginJob())
		{
			Cancel(forced: true);
			return false;
		}
		if ((Object)(object)InventoryManager.Instance == (Object)null || (Object)(object)CraftingManager.Instance == (Object)null || (Object)(object)ItemManager.Instance == (Object)null)
		{
			return false;
		}
		if (target_recipe == null)
		{
			return false;
		}
		if (obj.IsBeingUpgraded && (Object)(object)obj.characterUpgrading != (Object)(object)character)
		{
			Cancel(forced: true);
			return false;
		}
		if (!obj.IsBeingUpgraded && target_recipe.Result == ItemManager.ItemType.Upgrade)
		{
			obj.SetIsBeingUpgraded(set: true);
			obj.SetUpgradeCharacter(character);
		}
		return true;
	}

	public override void UpdateJob()
	{
		if ((Object)(object)obj != (Object)null)
		{
			if (obj.UpdateInteraction(character, GetCancelState()))
			{
				state = JobState.Finished;
				obj.InteractionFinished(character);
				if (GetCancelState() == JobCancelState.Active)
				{
					CraftingManager.FinishCraft(target_recipe, character, obj);
					character.OnCraftCompleted();
				}
				OnFinishedJob();
			}
		}
		else
		{
			state = JobState.Finished;
			OnFinishedJob();
		}
	}

	public override void Cancel(bool forced)
	{
		bool flag = GetCancelState() == JobCancelState.Active;
		if ((Object)(object)obj.characterUpgrading == (Object)(object)character && obj.IsBeingUpgraded)
		{
			obj.SetIsBeingUpgraded(set: false);
			obj.SetUpgradeCharacter(null);
		}
		base.Cancel(forced);
		if (!flag)
		{
			return;
		}
		Obj_GhostBase obj_GhostBase = null;
		if ((Object)(object)obj != (Object)null)
		{
			obj_GhostBase = obj as Obj_GhostBase;
		}
		if ((Object)(object)obj_GhostBase != (Object)null)
		{
			if (state != JobState.Pending && state != JobState.InTransit)
			{
				UpdateJob();
			}
			if (obj_GhostBase.IsPausable())
			{
				obj_GhostBase.PauseConstruction();
			}
			else
			{
				obj_GhostBase.CancelConstruction();
			}
		}
		else
		{
			CraftingManager.CancelCraft(target_recipe);
		}
	}

	public virtual CraftingManager.Recipe GetRecipe()
	{
		return target_recipe;
	}

	public override void SaveLoadJob(SaveData data)
	{
		base.SaveLoadJob(data);
		string value = ((target_recipe == null) ? string.Empty : target_recipe.ID);
		data.SaveLoad("recipe_id", ref value);
		bool value2 = target_recipe != null && target_recipe.Result == ItemManager.ItemType.Upgrade;
		data.SaveLoad("is_upgrade", ref value2);
		if (!data.isLoading || string.IsNullOrEmpty(value) || !((Object)(object)CraftingManager.Instance != (Object)null))
		{
			return;
		}
		CraftingManager.Recipe recipe = null;
		if (value2)
		{
			UpgradeObject component = ((Component)obj).GetComponent<UpgradeObject>();
			if ((Object)(object)component != (Object)null)
			{
				recipe = component.BuildRecipeForUpgrade(value);
			}
		}
		else
		{
			recipe = CraftingManager.Instance.GetRecipeByID(value);
		}
		if (recipe != null)
		{
			target_recipe = recipe;
			if ((Object)(object)obj != (Object)null)
			{
				Obj_GhostBase obj_GhostBase = obj as Obj_GhostBase;
				if ((Object)(object)obj_GhostBase != (Object)null)
				{
					obj_GhostBase.SetCraftRecipeID(target_recipe.ID);
				}
			}
		}
		else
		{
			Cancel(forced: true);
		}
	}
}
