using System.Collections.Generic;
using UnityEngine;

public class InteractionInstance_RadioScan : InteractionInstance_Base
{
	private Int_RadioScan interaction;

	private Obj_Radio radio_object;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_RadioScan;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		radio_object = ((Component)this).GetComponent<Obj_Radio>();
		if ((Object)(object)radio_object == (Object)null)
		{
			return false;
		}
		radio_object.IncreaseUsers();
		if (radio_object.broadcasting || radio_object.scanning)
		{
			return false;
		}
		radio_object.StartScanning();
		float duration = interaction.Duration;
		duration *= interaction.m_radioLevelScanLengthMultipliers[radio_object.GetRadioUpgradeLevel()];
		ResetInteractionTimer(duration);
		member.TriggerAnim("RadioListen");
		return true;
	}

	protected override bool UpdateInteractionTimer()
	{
		return base.UpdateInteractionTimer();
	}

	protected override bool OnInteractionComplete()
	{
		if ((Object)(object)radio_object != (Object)null)
		{
			radio_object.StopScanning();
		}
		if (!base.cancelled)
		{
			List<float> list = new List<float>();
			List<Int_RadioScan.RadioScanResult> list2 = new List<Int_RadioScan.RadioScanResult>();
			list.Add(interaction.discoveredNothingChance);
			list2.Add(Int_RadioScan.RadioScanResult.Nothing);
			if ((Object)(object)FactionMan.instance != (Object)null && FactionMan.instance.HasUnrevealedFactionZones())
			{
				list.Add(interaction.zoneDiscoverChance);
				list2.Add(Int_RadioScan.RadioScanResult.FactionZone);
			}
			if ((Object)(object)QuestManager.instance != (Object)null && (Object)(object)QuestLibrary.instance != (Object)null)
			{
				QuestDefBase randomAvailableQuest = QuestLibrary.instance.GetRandomAvailableQuest(discoverByRadio: true);
				if (randomAvailableQuest != null)
				{
					list.Add(interaction.questDiscoverChance);
					list2.Add(Int_RadioScan.RadioScanResult.Quest);
				}
				randomAvailableQuest = QuestLibrary.instance.FindDefinition(interaction.tradeCaravanId);
				if (randomAvailableQuest != null && (QuestLibrary.instance.IsAvailable(randomAvailableQuest, ignoreWeight: true, discoverByRadio: false) || QuestLibrary.instance.IsAvailable(randomAvailableQuest, ignoreWeight: true, discoverByRadio: true)))
				{
					list.Add(interaction.tradeCaravanDiscoverChance);
					list2.Add(Int_RadioScan.RadioScanResult.TradeCaravan);
				}
				randomAvailableQuest = QuestLibrary.instance.FindDefinition(interaction.vehicleMissingId);
				if (randomAvailableQuest != null && (QuestLibrary.instance.IsAvailable(randomAvailableQuest, ignoreWeight: true, discoverByRadio: false) || QuestLibrary.instance.IsAvailable(randomAvailableQuest, ignoreWeight: true, discoverByRadio: true)))
				{
					list.Add(interaction.vehicleDiscoverChance);
					list2.Add(Int_RadioScan.RadioScanResult.Vehicle);
				}
			}
			Int_RadioScan.RadioScanResult radioScanResult = Int_RadioScan.RadioScanResult.Nothing;
			float num = 0f;
			for (int i = 0; i < list.Count; i++)
			{
				num += list[i];
			}
			float num2 = Random.value * num;
			float num3 = 0f;
			for (int j = 0; j < list.Count; j++)
			{
				num3 += list[j];
				if (num2 <= num3)
				{
					radioScanResult = list2[j];
					break;
				}
			}
			bool flag = false;
			switch (radioScanResult)
			{
			case Int_RadioScan.RadioScanResult.Quest:
				flag = QuestManager.instance.SpawnQuestViaRadioDiscovery();
				break;
			case Int_RadioScan.RadioScanResult.FactionZone:
				flag = FactionMan.instance.RevealRandomFactionZone();
				break;
			case Int_RadioScan.RadioScanResult.TradeCaravan:
				flag = QuestManager.instance.SpawnQuestWithId(interaction.tradeCaravanId);
				break;
			case Int_RadioScan.RadioScanResult.Vehicle:
				flag = QuestManager.instance.SpawnQuestWithId(interaction.vehicleMissingId);
				break;
			}
			if (!flag)
			{
				radioScanResult = Int_RadioScan.RadioScanResult.Nothing;
			}
			string empty = string.Empty;
			empty = radioScanResult switch
			{
				Int_RadioScan.RadioScanResult.FactionZone => "text.ui.foundfaction", 
				Int_RadioScan.RadioScanResult.TradeCaravan => "text.ui.foundcaravan", 
				Int_RadioScan.RadioScanResult.Vehicle => "text.ui.foundvehicle", 
				Int_RadioScan.RadioScanResult.Quest => "text.ui.foundquest", 
				_ => "text.ui.foundnothing", 
			};
			RadioScanningResultPanel radioScanResultPanel = UI_PanelContainer.Instance.RadioScanResultPanel;
			if ((Object)(object)radioScanResultPanel != (Object)null)
			{
				radioScanResultPanel.SetResultText(Localization.Get(empty));
				UIPanelManager.instance.PushPanel(radioScanResultPanel);
			}
			return true;
		}
		return true;
	}
}
