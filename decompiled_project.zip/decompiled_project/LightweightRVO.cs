using System;
using System.Collections.Generic;
using Pathfinding.RVO;
using UnityEngine;

[RequireComponent(typeof(MeshFilter))]
public class LightweightRVO : MonoBehaviour
{
	public enum RVOExampleType
	{
		Circle,
		Line,
		Point,
		RandomStreams
	}

	public int agentCount = 100;

	public float exampleScale = 100f;

	public RVOExampleType type;

	public float radius = 3f;

	public float maxSpeed = 2f;

	public float agentTimeHorizon = 10f;

	[HideInInspector]
	public float obstacleTimeHorizon = 10f;

	public int maxNeighbours = 10;

	public float neighbourDist = 15f;

	public Vector3 renderingOffset = Vector3.up * 0.1f;

	public bool debug;

	private Mesh mesh;

	private Simulator sim;

	private List<IAgent> agents;

	private List<Vector3> goals;

	private List<Color> colors;

	private Vector3[] verts;

	private Vector2[] uv;

	private int[] tris;

	private Color[] meshColors;

	private Vector3[] interpolatedVelocities;

	public void Start()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		mesh = new Mesh();
		RVOSimulator rVOSimulator = Object.FindObjectOfType(typeof(RVOSimulator)) as RVOSimulator;
		if ((Object)(object)rVOSimulator == (Object)null)
		{
			Debug.LogError((object)"No RVOSimulator could be found in the scene. Please add a RVOSimulator component to any GameObject");
			return;
		}
		sim = rVOSimulator.GetSimulator();
		((Component)this).GetComponent<MeshFilter>().mesh = mesh;
		CreateAgents(agentCount);
	}

	public void OnGUI()
	{
		if (GUILayout.Button("2", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			CreateAgents(2);
		}
		if (GUILayout.Button("10", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			CreateAgents(10);
		}
		if (GUILayout.Button("100", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			CreateAgents(100);
		}
		if (GUILayout.Button("500", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			CreateAgents(500);
		}
		if (GUILayout.Button("1000", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			CreateAgents(1000);
		}
		if (GUILayout.Button("5000", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			CreateAgents(5000);
		}
		GUILayout.Space(5f);
		if (GUILayout.Button("Random Streams", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			type = RVOExampleType.RandomStreams;
			CreateAgents((agents == null) ? 100 : agents.Count);
		}
		if (GUILayout.Button("Line", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			type = RVOExampleType.Line;
			CreateAgents((agents == null) ? 10 : Mathf.Min(agents.Count, 100));
		}
		if (GUILayout.Button("Circle", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			type = RVOExampleType.Circle;
			CreateAgents((agents == null) ? 100 : agents.Count);
		}
		if (GUILayout.Button("Point", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			type = RVOExampleType.Point;
			CreateAgents((agents == null) ? 100 : agents.Count);
		}
	}

	private float uniformDistance(float radius)
	{
		float num = Random.value + Random.value;
		if (num > 1f)
		{
			return radius * (2f - num);
		}
		return radius * num;
	}

	public void CreateAgents(int num)
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0367: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_0379: Unknown result type (might be due to invalid IL or missing references)
		//IL_0381: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03df: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		agentCount = num;
		agents = new List<IAgent>(agentCount);
		goals = new List<Vector3>(agentCount);
		colors = new List<Color>(agentCount);
		sim.ClearAgents();
		if (type == RVOExampleType.Circle)
		{
			float num2 = Mathf.Sqrt((float)agentCount * radius * radius * 4f / (float)Math.PI) * exampleScale * 0.05f;
			for (int i = 0; i < agentCount; i++)
			{
				Vector3 val = new Vector3(Mathf.Cos((float)i * (float)Math.PI * 2f / (float)agentCount), 0f, Mathf.Sin((float)i * (float)Math.PI * 2f / (float)agentCount)) * num2;
				IAgent item = sim.AddAgent(val);
				agents.Add(item);
				goals.Add(-val);
				colors.Add(HSVToRGB((float)i * 360f / (float)agentCount, 0.8f, 0.6f));
			}
		}
		else if (type == RVOExampleType.Line)
		{
			Vector3 position = default(Vector3);
			for (int j = 0; j < agentCount; j++)
			{
				((Vector3)(ref position))._002Ector((float)((j % 2 == 0) ? 1 : (-1)) * exampleScale, 0f, (float)(j / 2) * radius * 2.5f);
				IAgent item2 = sim.AddAgent(position);
				agents.Add(item2);
				goals.Add(new Vector3(0f - position.x, position.y, position.z));
				colors.Add((j % 2 != 0) ? Color.blue : Color.red);
			}
		}
		else if (type == RVOExampleType.Point)
		{
			for (int k = 0; k < agentCount; k++)
			{
				Vector3 position2 = new Vector3(Mathf.Cos((float)k * (float)Math.PI * 2f / (float)agentCount), 0f, Mathf.Sin((float)k * (float)Math.PI * 2f / (float)agentCount)) * exampleScale;
				IAgent item3 = sim.AddAgent(position2);
				agents.Add(item3);
				goals.Add(new Vector3(0f, position2.y, 0f));
				colors.Add(HSVToRGB((float)k * 360f / (float)agentCount, 0.8f, 0.6f));
			}
		}
		else if (type == RVOExampleType.RandomStreams)
		{
			float num3 = Mathf.Sqrt((float)agentCount * radius * radius * 4f / (float)Math.PI) * exampleScale * 0.05f;
			for (int l = 0; l < agentCount; l++)
			{
				float num4 = Random.value * (float)Math.PI * 2f;
				float num5 = Random.value * (float)Math.PI * 2f;
				Vector3 position3 = new Vector3(Mathf.Cos(num4), 0f, Mathf.Sin(num4)) * uniformDistance(num3);
				IAgent item4 = sim.AddAgent(position3);
				agents.Add(item4);
				goals.Add(new Vector3(Mathf.Cos(num5), 0f, Mathf.Sin(num5)) * uniformDistance(num3));
				colors.Add(HSVToRGB(num5 * 57.29578f, 0.8f, 0.6f));
			}
		}
		for (int m = 0; m < agents.Count; m++)
		{
			IAgent agent = agents[m];
			agent.Radius = radius;
			agent.MaxSpeed = maxSpeed;
			agent.AgentTimeHorizon = agentTimeHorizon;
			agent.ObstacleTimeHorizon = obstacleTimeHorizon;
			agent.MaxNeighbours = maxNeighbours;
			agent.NeighbourDist = neighbourDist;
			agent.DebugDraw = m == 0 && debug;
		}
		verts = (Vector3[])(object)new Vector3[4 * agents.Count];
		uv = (Vector2[])(object)new Vector2[verts.Length];
		tris = new int[agents.Count * 2 * 3];
		meshColors = (Color[])(object)new Color[verts.Length];
	}

	public void Update()
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0274: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0304: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_0327: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_0346: Unknown result type (might be due to invalid IL or missing references)
		//IL_0362: Unknown result type (might be due to invalid IL or missing references)
		//IL_0367: Unknown result type (might be due to invalid IL or missing references)
		//IL_0383: Unknown result type (might be due to invalid IL or missing references)
		//IL_0388: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a9: Unknown result type (might be due to invalid IL or missing references)
		if (agents == null || (Object)(object)mesh == (Object)null)
		{
			return;
		}
		if (agents.Count != goals.Count)
		{
			Debug.LogError((object)"Agent count does not match goal count");
			return;
		}
		for (int i = 0; i < agents.Count; i++)
		{
			Vector3 interpolatedPosition = agents[i].InterpolatedPosition;
			Vector3 val = goals[i] - interpolatedPosition;
			val = Vector3.ClampMagnitude(val, 1f);
			agents[i].DesiredVelocity = val * agents[i].MaxSpeed;
		}
		if (interpolatedVelocities == null || interpolatedVelocities.Length < agents.Count)
		{
			Vector3[] array = (Vector3[])(object)new Vector3[agents.Count];
			if (interpolatedVelocities != null)
			{
				for (int j = 0; j < interpolatedVelocities.Length; j++)
				{
					ref Vector3 reference = ref array[j];
					reference = interpolatedVelocities[j];
				}
			}
			interpolatedVelocities = array;
		}
		for (int k = 0; k < agents.Count; k++)
		{
			IAgent agent = agents[k];
			ref Vector3 reference2 = ref interpolatedVelocities[k];
			Vector3 val2 = interpolatedVelocities[k];
			Vector3 velocity = agent.Velocity;
			Vector3 velocity2 = agent.Velocity;
			reference2 = Vector3.Lerp(val2, velocity, ((Vector3)(ref velocity2)).magnitude * Time.deltaTime * 4f);
			Vector3 val3 = ((Vector3)(ref interpolatedVelocities[k])).normalized * agent.Radius;
			if (val3 == Vector3.zero)
			{
				((Vector3)(ref val3))._002Ector(0f, 0f, agent.Radius);
			}
			Vector3 val4 = Vector3.Cross(Vector3.up, val3);
			Vector3 val5 = agent.InterpolatedPosition + renderingOffset;
			int num = 4 * k;
			int num2 = 6 * k;
			ref Vector3 reference3 = ref verts[num];
			reference3 = val5 + val3 - val4;
			ref Vector3 reference4 = ref verts[num + 1];
			reference4 = val5 + val3 + val4;
			ref Vector3 reference5 = ref verts[num + 2];
			reference5 = val5 - val3 + val4;
			ref Vector3 reference6 = ref verts[num + 3];
			reference6 = val5 - val3 - val4;
			ref Vector2 reference7 = ref uv[num];
			reference7 = new Vector2(0f, 1f);
			ref Vector2 reference8 = ref uv[num + 1];
			reference8 = new Vector2(1f, 1f);
			ref Vector2 reference9 = ref uv[num + 2];
			reference9 = new Vector2(1f, 0f);
			ref Vector2 reference10 = ref uv[num + 3];
			reference10 = new Vector2(0f, 0f);
			ref Color reference11 = ref meshColors[num];
			reference11 = colors[k];
			ref Color reference12 = ref meshColors[num + 1];
			reference12 = colors[k];
			ref Color reference13 = ref meshColors[num + 2];
			reference13 = colors[k];
			ref Color reference14 = ref meshColors[num + 3];
			reference14 = colors[k];
			tris[num2] = num;
			tris[num2 + 1] = num + 1;
			tris[num2 + 2] = num + 2;
			tris[num2 + 3] = num;
			tris[num2 + 4] = num + 2;
			tris[num2 + 5] = num + 3;
		}
		mesh.Clear();
		mesh.vertices = verts;
		mesh.uv = uv;
		mesh.colors = meshColors;
		mesh.triangles = tris;
		mesh.RecalculateNormals();
	}

	private static Color HSVToRGB(float h, float s, float v)
	{
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		float num2 = 0f;
		float num3 = 0f;
		float num4 = s * v;
		float num5 = h / 60f;
		float num6 = num4 * (1f - Math.Abs(num5 % 2f - 1f));
		if (num5 < 1f)
		{
			num = num4;
			num2 = num6;
		}
		else if (num5 < 2f)
		{
			num = num6;
			num2 = num4;
		}
		else if (num5 < 3f)
		{
			num2 = num4;
			num3 = num6;
		}
		else if (num5 < 4f)
		{
			num2 = num6;
			num3 = num4;
		}
		else if (num5 < 5f)
		{
			num = num6;
			num3 = num4;
		}
		else if (num5 < 6f)
		{
			num = num4;
			num3 = num6;
		}
		float num7 = v - num4;
		num += num7;
		num2 += num7;
		num3 += num7;
		return new Color(num, num2, num3);
	}
}
