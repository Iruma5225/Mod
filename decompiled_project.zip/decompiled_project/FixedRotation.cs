using UnityEngine;

public class FixedRotation : MonoBehaviour
{
	private void Update()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.rotation = Quaternion.identity;
	}
}
