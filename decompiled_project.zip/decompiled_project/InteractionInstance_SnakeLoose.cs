using UnityEngine;

public class InteractionInstance_SnakeLoose : InteractionInstance_Base
{
	private Int_SnakeLoose interaction;

	private Obj_SnakeTank tank;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_SnakeLoose;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		tank = obj_base as Obj_SnakeTank;
		if ((Object)(object)tank == (Object)null)
		{
			return false;
		}
		member.TriggerAnim("Rummage");
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled && (Object)(object)tank != (Object)null)
		{
			tank.LetOutSnake();
		}
		return true;
	}
}
