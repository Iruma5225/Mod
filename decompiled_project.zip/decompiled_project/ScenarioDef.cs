using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

[Serializable]
public class ScenarioDef : QuestDefBase
{
	[SerializeField]
	private List<ScenarioStage> m_stages = new List<ScenarioStage>();

	public ReadOnlyCollection<ScenarioStage> stages => m_stages.AsReadOnly();

	public override bool IsQuest()
	{
		return false;
	}

	public override bool IsScenario()
	{
		return true;
	}
}
