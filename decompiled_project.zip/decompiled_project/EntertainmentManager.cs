using System;
using System.Collections.Generic;
using UnityEngine;

public class EntertainmentManager : BaseManager, ISaveable
{
	[Serializable]
	public class DiminishingStressReduction
	{
		[SerializeField]
		private float m_maxReduction;

		[SerializeField]
		private float m_decay;

		[SerializeField]
		private float m_regenRate;

		private Dictionary<int, float> reductionPerCharacter = new Dictionary<int, float>();

		public void Regen(float deltaTime)
		{
			List<int> list = new List<int>(reductionPerCharacter.Keys);
			for (int i = 0; i < list.Count; i++)
			{
				reductionPerCharacter[list[i]] += m_regenRate * deltaTime;
				if (reductionPerCharacter[list[i]] > m_maxReduction)
				{
					reductionPerCharacter[list[i]] = m_maxReduction;
				}
			}
		}

		public void Decay(int id, float percentage)
		{
			float num = (float)GetReduction(id) - (m_decay - percentage * m_decay);
			num = Mathf.Max(num, 0f);
			reductionPerCharacter[id] = num;
		}

		public int GetReduction(int id)
		{
			float value = 0f;
			if (!reductionPerCharacter.TryGetValue(id, out value))
			{
				reductionPerCharacter.Add(id, m_maxReduction);
				value = m_maxReduction;
			}
			return Mathf.FloorToInt(value);
		}

		public void SaveLoad(SaveData data, string listName)
		{
			if (data.isLoading)
			{
				reductionPerCharacter.Clear();
			}
			try
			{
				List<int> members = new List<int>(reductionPerCharacter.Keys);
				data.SaveLoadList(listName, members, delegate(int i)
				{
					int value = members[i];
					float value2 = reductionPerCharacter[members[i]];
					data.SaveLoad("memberId", ref value);
					data.SaveLoad("relief", ref value2);
				}, delegate
				{
					int value = -1;
					float value2 = 0f;
					data.SaveLoad("memberId", ref value);
					data.SaveLoad("relief", ref value2);
					if (value > -1)
					{
						reductionPerCharacter.Add(value, value2);
					}
				});
			}
			catch
			{
			}
		}
	}

	[SerializeField]
	private DiminishingStressReduction booksStressReduction = new DiminishingStressReduction();

	[SerializeField]
	private int m_MaxBooks;

	[SerializeField]
	private int m_Books;

	private List<Obj_BookShelf> m_Bookshelves = new List<Obj_BookShelf>();

	[SerializeField]
	private DiminishingStressReduction toysStressReduction = new DiminishingStressReduction();

	[SerializeField]
	private int m_MaxToys;

	[SerializeField]
	private int m_Toys;

	private List<Obj_Toybox> m_Toyboxes = new List<Obj_Toybox>();

	[SerializeField]
	private DiminishingStressReduction recordsStressReduction = new DiminishingStressReduction();

	[SerializeField]
	private int m_MaxRecords;

	[SerializeField]
	private int m_Records;

	private List<Obj_Musicbox> m_Musicboxes = new List<Obj_Musicbox>();

	[SerializeField]
	private List<Sprite> m_paintingSprites = new List<Sprite>();

	[SerializeField]
	private float m_StressReductionPerPainting;

	[SerializeField]
	private float m_PaintStressReductionDelay = 1f;

	private float paintStressTimer;

	private int m_paintingIndex;

	[SerializeField]
	private List<ObjectManager.ObjectType> m_Sculptures = new List<ObjectManager.ObjectType>();

	[SerializeField]
	private float m_StressReductionPerSculpture;

	[SerializeField]
	private float m_SculptureStressReductionDelay = 1f;

	private float sculptureStressTimer;

	private int m_sculptureIndex;

	private static EntertainmentManager m_theInstance;

	public int MaxBooks => m_MaxBooks;

	public int Books => m_Books;

	public int MaxToys => m_MaxToys;

	public int Toys => m_Toys;

	public int MaxRecords => m_MaxRecords;

	public int Records => m_Records;

	public static EntertainmentManager Instance => m_theInstance;

	private void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
		}
		else
		{
			Debug.Log((object)"Duplicate Entertainment Manager created!");
		}
	}

	public override void StartManager()
	{
		m_paintingIndex = Random.Range(0, m_paintingSprites.Count);
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
	}

	public override void UpdateManager()
	{
		booksStressReduction.Regen(Time.deltaTime);
		paintStressTimer -= Time.deltaTime;
		if (paintStressTimer <= 0f)
		{
			ReduceStressFromPaintings();
			paintStressTimer = m_PaintStressReductionDelay;
		}
		sculptureStressTimer -= Time.deltaTime;
		if (sculptureStressTimer <= 0f)
		{
			ReduceStressFromSculptures();
			sculptureStressTimer = m_SculptureStressReductionDelay;
		}
	}

	public bool AddItem(ItemManager.ItemType itemType)
	{
		int num = 0;
		switch (itemType)
		{
		case ItemManager.ItemType.Book:
			num = AddBooks(1);
			break;
		case ItemManager.ItemType.Toy:
			num = AddToys(1);
			break;
		case ItemManager.ItemType.Record:
			num = AddRecords(1);
			break;
		}
		return num > 0;
	}

	public int OnBookRead(FamilyMember member)
	{
		if ((Object)(object)member == (Object)null)
		{
			return 0;
		}
		return booksStressReduction.GetReduction(member.GetId());
	}

	public int AddBooks(int count)
	{
		int books = m_Books;
		m_Books = Mathf.Min(m_Books + count, m_MaxBooks);
		for (int i = 0; i < m_Bookshelves.Count; i++)
		{
			m_Bookshelves[i].UpdateSprite();
		}
		return m_Books - books;
	}

	public void RemoveBooks(int count)
	{
		if (count > 0)
		{
			m_Books = Mathf.Max(m_Books - count, 0);
			for (int i = 0; i < m_Bookshelves.Count; i++)
			{
				m_Bookshelves[i].UpdateSprite();
			}
		}
	}

	public void RegisterStorage(Obj_BookShelf bookshelf)
	{
		if (!m_Bookshelves.Contains(bookshelf))
		{
			m_Bookshelves.Add(bookshelf);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_MaxBooks += bookshelf.BookCapacity;
			}
			for (int i = 0; i < m_Bookshelves.Count; i++)
			{
				m_Bookshelves[i].UpdateSprite();
			}
		}
	}

	public void UnRegisterStorage(Obj_BookShelf bookshelf)
	{
		if (m_Bookshelves.Contains(bookshelf))
		{
			m_Bookshelves.Remove(bookshelf);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_MaxBooks -= bookshelf.BookCapacity;
			}
			int num = m_Books - Mathf.Min(m_Books, m_MaxToys);
			if (num > 0 && (Object)(object)InventoryManager.Instance != (Object)null)
			{
				InventoryManager.Instance.AddNewItems(ItemManager.ItemType.Book, num);
			}
			m_Books -= num;
			for (int i = 0; i < m_Bookshelves.Count; i++)
			{
				m_Bookshelves[i].UpdateSprite();
			}
		}
	}

	public int OnToyUsed(FamilyMember member)
	{
		if ((Object)(object)member == (Object)null)
		{
			return 0;
		}
		return toysStressReduction.GetReduction(member.GetId());
	}

	public int AddToys(int count)
	{
		int toys = m_Toys;
		m_Toys = Mathf.Min(m_Toys + count, m_MaxToys);
		return m_Toys - toys;
	}

	public void RemoveToys(int count)
	{
		if (count > 0)
		{
			m_Toys = Mathf.Max(m_Toys - count, 0);
		}
	}

	public void RegisterStorage(Obj_Toybox toybox)
	{
		if (!m_Toyboxes.Contains(toybox))
		{
			m_Toyboxes.Add(toybox);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_MaxToys += toybox.ToyCapacity;
			}
		}
	}

	public void UnRegisterStorage(Obj_Toybox toybox)
	{
		if (m_Toyboxes.Contains(toybox))
		{
			m_Toyboxes.Remove(toybox);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_MaxToys -= toybox.ToyCapacity;
			}
			int num = m_Toys - Mathf.Min(m_Toys, m_MaxToys);
			if (num > 0 && (Object)(object)InventoryManager.Instance != (Object)null)
			{
				InventoryManager.Instance.AddNewItems(ItemManager.ItemType.Toy, num);
			}
			m_Toys -= num;
		}
	}

	public int OnRecordUsed()
	{
		return recordsStressReduction.GetReduction(0);
	}

	public int AddRecords(int count)
	{
		int toys = m_Toys;
		m_Records = Mathf.Min(m_Records + count, m_MaxRecords);
		return m_Records - toys;
	}

	public void RemoveRecords(int count)
	{
		if (count > 0)
		{
			m_Records = Mathf.Max(m_Records - count, 0);
		}
	}

	public void RegisterStorage(Obj_Musicbox musicbox)
	{
		if (!m_Musicboxes.Contains(musicbox))
		{
			m_Musicboxes.Add(musicbox);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_MaxRecords += musicbox.RecordCapacity;
			}
		}
	}

	public void UnRegisterStorage(Obj_Musicbox musicbox)
	{
		if (m_Musicboxes.Contains(musicbox))
		{
			m_Musicboxes.Remove(musicbox);
			if ((Object)(object)SaveManager.instance == (Object)null || !SaveManager.instance.isLoading || SaveManager.instance.isRelocating)
			{
				m_MaxRecords -= musicbox.RecordCapacity;
			}
			int num = m_Records - Mathf.Min(m_Records, m_MaxRecords);
			if (num > 0 && (Object)(object)InventoryManager.Instance != (Object)null)
			{
				InventoryManager.Instance.AddNewItems(ItemManager.ItemType.Record, num);
			}
			m_Records -= num;
		}
	}

	public void GetNextPaintingSprite(out Sprite sprite, out int spriteIndex)
	{
		sprite = null;
		spriteIndex = -1;
		if (m_paintingIndex >= 0 && m_paintingIndex < m_paintingSprites.Count)
		{
			sprite = m_paintingSprites[m_paintingIndex];
			spriteIndex = m_paintingIndex;
			m_paintingIndex++;
			if (m_paintingIndex >= m_paintingSprites.Count)
			{
				m_paintingIndex = 0;
			}
		}
	}

	public Sprite GetPaintingSpriteByIndex(int spriteIndex)
	{
		if (spriteIndex < 0 || spriteIndex >= m_paintingSprites.Count)
		{
			return null;
		}
		return m_paintingSprites[spriteIndex];
	}

	public ObjectManager.ObjectType GetNextSculptureType()
	{
		ObjectManager.ObjectType result = ObjectManager.ObjectType.Undefined;
		if (m_sculptureIndex >= 0 && m_sculptureIndex < m_Sculptures.Count)
		{
			result = m_Sculptures[m_sculptureIndex];
			m_sculptureIndex++;
			if (m_sculptureIndex >= m_Sculptures.Count)
			{
				m_sculptureIndex = 0;
			}
		}
		return result;
	}

	public void ReduceStressFromPaintings()
	{
		List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Painting);
		float num = m_StressReductionPerPainting * (float)Mathf.Clamp(objectsOfType.Count, 0, 10);
		List<FamilyMember> shelteredFamilyMembers = FamilyManager.Instance.GetShelteredFamilyMembers(onlyIndoorMembers: true);
		if (shelteredFamilyMembers != null && shelteredFamilyMembers.Count > 0)
		{
			for (int i = 0; i < shelteredFamilyMembers.Count; i++)
			{
				shelteredFamilyMembers[i].stats.stress.Modify(0f - num);
			}
		}
	}

	public void ReduceStressFromSculptures()
	{
		int num = 0;
		for (int i = 0; i < m_Sculptures.Count; i++)
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(m_Sculptures[i]);
			if (objectsOfType.Count > 0)
			{
				num++;
			}
		}
		float num2 = m_StressReductionPerSculpture * (float)num;
		List<FamilyMember> shelteredFamilyMembers = FamilyManager.Instance.GetShelteredFamilyMembers(onlyIndoorMembers: true);
		if (shelteredFamilyMembers != null && shelteredFamilyMembers.Count > 0)
		{
			for (int j = 0; j < shelteredFamilyMembers.Count; j++)
			{
				shelteredFamilyMembers[j].stats.stress.Modify(0f - num2);
			}
		}
	}

	public bool IsRelocationEnabled()
	{
		return false;
	}

	public bool IsReadyForLoad()
	{
		return (Object)(object)FamilyManager.Instance != (Object)null && (Object)(object)SaveManager.instance != (Object)null && SaveManager.instance.HasBeenLoaded(FamilyManager.Instance);
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("EntertainmentManager");
		if (!data.isLoading || !data.isRelocating)
		{
			data.SaveLoad("books", ref m_Books);
			data.SaveLoad("maxBooks", ref m_MaxBooks);
			data.SaveLoad("toys", ref m_Toys);
			data.SaveLoad("maxToys", ref m_MaxToys);
			data.SaveLoad("records", ref m_Records);
			data.SaveLoad("maxRecords", ref m_MaxRecords);
			toysStressReduction.SaveLoad(data, "toyMemberRelief");
			booksStressReduction.SaveLoad(data, "bookMemberRelief");
			recordsStressReduction.SaveLoad(data, "recordMemberRelief");
		}
		data.SaveLoad("paintSpriteIndex", ref m_paintingIndex);
		data.SaveLoad("sculptureIndex", ref m_sculptureIndex);
		if (data.isLoading)
		{
			for (int i = 0; i < m_Bookshelves.Count; i++)
			{
				m_Bookshelves[i].UpdateSprite();
			}
		}
		data.GroupEnd();
		return true;
	}
}
