using System;
using System.Collections.Generic;
using UnityEngine;

public class MedicineManager : BaseManagerNoUpdate
{
	public enum MedicineType
	{
		Undefined = 0,
		FirstAid = 1,
		Bandages = 2,
		AntiRadiation = 3,
		AntiBiotics = 4,
		Valium = 5,
		HomemadeAntiBiotics = 20,
		HomemadeAntiemetics = 21,
		HomemadeAntiRadiation = 22,
		HomemadeAntiDepressant = 23
	}

	public override void StartManager()
	{
	}

	public static ItemManager.ItemType MedicineToItem(MedicineType meds)
	{
		ItemManager.ItemType result = ItemManager.ItemType.Undefined;
		switch (meds)
		{
		case MedicineType.FirstAid:
			result = ItemManager.ItemType.FirstAid;
			break;
		case MedicineType.AntiRadiation:
			result = ItemManager.ItemType.AntiRadMedicine;
			break;
		case MedicineType.AntiBiotics:
			result = ItemManager.ItemType.Antibiotics;
			break;
		case MedicineType.Valium:
			result = ItemManager.ItemType.Valium;
			break;
		case MedicineType.Bandages:
			result = ItemManager.ItemType.Bandages;
			break;
		case MedicineType.HomemadeAntiBiotics:
			result = ItemManager.ItemType.HomemadeAntibiotics;
			break;
		case MedicineType.HomemadeAntiemetics:
			result = ItemManager.ItemType.HomemadeAntiemetics;
			break;
		case MedicineType.HomemadeAntiRadiation:
			result = ItemManager.ItemType.HomemadeAntiRad;
			break;
		case MedicineType.HomemadeAntiDepressant:
			result = ItemManager.ItemType.HomemadeAntidepressant;
			break;
		}
		return result;
	}

	public static MedicineType ItemToMedicine(ItemManager.ItemType meds)
	{
		MedicineType result = MedicineType.Undefined;
		switch (meds)
		{
		case ItemManager.ItemType.FirstAid:
			result = MedicineType.FirstAid;
			break;
		case ItemManager.ItemType.AntiRadMedicine:
			result = MedicineType.AntiRadiation;
			break;
		case ItemManager.ItemType.Antibiotics:
			result = MedicineType.AntiBiotics;
			break;
		case ItemManager.ItemType.Valium:
			result = MedicineType.Valium;
			break;
		case ItemManager.ItemType.Bandages:
			result = MedicineType.Bandages;
			break;
		case ItemManager.ItemType.HomemadeAntibiotics:
			result = MedicineType.HomemadeAntiBiotics;
			break;
		case ItemManager.ItemType.HomemadeAntiemetics:
			result = MedicineType.HomemadeAntiemetics;
			break;
		case ItemManager.ItemType.HomemadeAntiRad:
			result = MedicineType.HomemadeAntiRadiation;
			break;
		case ItemManager.ItemType.HomemadeAntidepressant:
			result = MedicineType.HomemadeAntiDepressant;
			break;
		}
		return result;
	}

	public static bool IsMedicineNeeded(FamilyMember member, MedicineType medicine)
	{
		return medicine switch
		{
			MedicineType.FirstAid => member.health < member.maxHealth || member.illness.bleeding.isActive, 
			MedicineType.Bandages => member.illness.bleeding.isActive, 
			MedicineType.AntiRadiation => member.illness.radiation.isActive, 
			MedicineType.HomemadeAntiRadiation => member.illness.radiation.isActive, 
			MedicineType.AntiBiotics => member.illness.infection.isActive, 
			MedicineType.HomemadeAntiBiotics => member.illness.infection.isActive, 
			MedicineType.HomemadeAntiemetics => member.illness.foodPoisoning.isActive, 
			MedicineType.Valium => member.stats.stress.NormalizedValue > 0f || member.stats.trauma.NormalizedValue > 0f, 
			MedicineType.HomemadeAntiDepressant => member.stats.stress.NormalizedValue > 0f || member.stats.trauma.NormalizedValue > 0f, 
			_ => false, 
		};
	}

	public static List<MedicineType> GetUsableMedicines(FamilyMember member)
	{
		List<MedicineType> list = new List<MedicineType>();
		if ((Object)(object)member != (Object)null)
		{
			MedicineType[] array = (MedicineType[])Enum.GetValues(typeof(MedicineType));
			for (int i = 0; i < array.Length; i++)
			{
				if (IsMedicineNeeded(member, array[i]))
				{
					list.Add(array[i]);
				}
			}
		}
		return list;
	}

	public static List<MedicineType> GetUsableMedicines(Obj_CatatonicGhost catatonic)
	{
		List<MedicineType> list = new List<MedicineType>();
		if ((Object)(object)catatonic != (Object)null)
		{
			FamilyMember familyMember = catatonic.GetFamilyMember();
			if ((Object)(object)familyMember != (Object)null)
			{
				if (IsMedicineNeeded(familyMember, MedicineType.FirstAid))
				{
					list.Add(MedicineType.FirstAid);
				}
				if (IsMedicineNeeded(familyMember, MedicineType.Bandages))
				{
					list.Add(MedicineType.Bandages);
				}
				if (IsMedicineNeeded(familyMember, MedicineType.AntiRadiation))
				{
					list.Add(MedicineType.AntiRadiation);
				}
				if (IsMedicineNeeded(familyMember, MedicineType.HomemadeAntiRadiation))
				{
					list.Add(MedicineType.HomemadeAntiRadiation);
				}
			}
		}
		return list;
	}

	public static List<MedicineType> GetAvailableMedicines(List<MedicineType> input_meds)
	{
		List<MedicineType> list = new List<MedicineType>();
		for (int i = 0; i < input_meds.Count; i++)
		{
			if (InventoryManager.Instance.GetNumItemsOfType(MedicineToItem(input_meds[i])) > 0)
			{
				list.Add(input_meds[i]);
			}
		}
		return list;
	}

	public static List<MedicineType> GetAvailableMedicines()
	{
		List<MedicineType> list = new List<MedicineType>();
		MedicineType[] array = (MedicineType[])Enum.GetValues(typeof(MedicineType));
		for (int i = 0; i < array.Length; i++)
		{
			if (InventoryManager.Instance.GetNumItemsOfType(MedicineToItem(array[i])) > 0)
			{
				list.Add(array[i]);
			}
		}
		return list;
	}

	public static List<ItemManager.ItemType> GetAvailableMedicineItems()
	{
		List<ItemManager.ItemType> list = new List<ItemManager.ItemType>();
		MedicineType[] array = (MedicineType[])Enum.GetValues(typeof(MedicineType));
		for (int i = 0; i < array.Length; i++)
		{
			ItemManager.ItemType item = MedicineToItem(array[i]);
			if (InventoryManager.Instance.GetNumItemsOfType(item) > 0)
			{
				list.Add(item);
			}
		}
		return list;
	}

	public static float GetCureSuccessChance(MedicineType medicine)
	{
		if (medicine == MedicineType.HomemadeAntiBiotics || medicine == MedicineType.HomemadeAntiDepressant || medicine == MedicineType.HomemadeAntiemetics || medicine == MedicineType.HomemadeAntiRadiation)
		{
			return 0.75f;
		}
		return 1f;
	}

	public static void Cure(FamilyMember member, MedicineType medicine)
	{
		switch (medicine)
		{
		case MedicineType.FirstAid:
			member.illness.bleeding.SetActive(active: false);
			member.Heal(50);
			break;
		case MedicineType.Bandages:
			member.illness.bleeding.SetActive(active: false);
			break;
		case MedicineType.AntiRadiation:
			member.illness.radiation.OnAntiRadiationMedicine();
			break;
		case MedicineType.HomemadeAntiRadiation:
			member.illness.radiation.OnAntiRadiationMedicine();
			break;
		case MedicineType.AntiBiotics:
			member.illness.infection.OnAntibioticsTaken();
			break;
		case MedicineType.HomemadeAntiBiotics:
			member.illness.infection.OnAntibioticsTaken();
			break;
		case MedicineType.HomemadeAntiemetics:
			member.illness.foodPoisoning.SetActive(active: false);
			break;
		case MedicineType.Valium:
			member.stats.stress.Modify(0f - member.stats.stress.MaxValue);
			member.stats.trauma.Reset();
			break;
		case MedicineType.HomemadeAntiDepressant:
			member.stats.stress.Modify(0f - member.stats.stress.MaxValue);
			member.stats.trauma.Reset();
			break;
		}
	}
}
