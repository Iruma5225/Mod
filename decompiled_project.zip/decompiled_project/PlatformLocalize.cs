using System.Collections.Generic;
using UnityEngine;

public class PlatformLocalize : MonoBehaviour
{
	[SerializeField]
	private string pcKey = string.Empty;

	[SerializeField]
	private UILabel text;

	private string key = string.Empty;

	private Dictionary<string, string> replacements = new Dictionary<string, string>();

	private void OnInputChanged()
	{
		key = pcKey;
		OnEnable();
	}

	private void OnLocalize()
	{
		OnEnable();
	}

	private void OnEnable()
	{
		if (pcKey != null)
		{
			key = pcKey;
		}
		if ((Object)(object)text != (Object)null)
		{
			SetText_Internal(key);
		}
	}

	private void SetText_Internal(string new_text, bool localized = false)
	{
		string text = (localized ? new_text : Localization.Get(new_text));
		foreach (KeyValuePair<string, string> replacement in replacements)
		{
			text = text.Replace(replacement.Key, replacement.Value);
		}
		if ((Object)(object)this.text != (Object)null)
		{
			this.text.text = text;
		}
	}

	public void SetReplacement(string token, string replace)
	{
		string value = string.Empty;
		if (!replacements.TryGetValue(token, out value))
		{
			replacements.Add(token, replace);
		}
		replacements[token] = replace;
		if ((Object)(object)text != (Object)null)
		{
			text.text = text.text.Replace(token, replace);
		}
	}
}
