namespace GooglePlayGames.BasicApi.Nearby;

public enum InitializationStatus
{
	Success,
	VersionUpdateRequired,
	InternalError
}
