using System.Collections.Generic;
using AnimationOrTween;
using UnityEngine;

public class GameModeSelectionPanel : BasePanel
{
	[SerializeField]
	private TweenAlpha m_tween;

	[SerializeField]
	private BasePanel m_slotSelectionPanel;

	[SerializeField]
	private BasePanel m_scenarioSelectionPanel;

	[SerializeField]
	private List<UIButton> m_modeButtons = new List<UIButton>();

	[SerializeField]
	private UILabel m_modeDescLabel;

	private bool m_scenarioModeChosen;

	private bool m_goingBack;

	private bool m_inputEnabled;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return false;
	}

	public void Start()
	{
	}

	public void OnDestroy()
	{
	}

	public override void OnShow()
	{
		base.OnShow();
		m_goingBack = false;
		m_inputEnabled = false;
		if ((Object)(object)m_tween != (Object)null)
		{
			m_tween.PlayForward();
		}
		else
		{
			m_inputEnabled = true;
		}
	}

	public override void OnResume()
	{
		base.OnResume();
		if ((Object)(object)m_tween != (Object)null)
		{
			m_tween.PlayForward();
		}
		else
		{
			m_inputEnabled = true;
		}
	}

	public override void OnCancel()
	{
		if (m_inputEnabled)
		{
			base.OnCancel();
			m_goingBack = true;
			m_inputEnabled = false;
			if ((Object)(object)m_tween != (Object)null)
			{
				m_tween.PlayReverse();
				m_tween.ResetToBeginning();
			}
			if ((Object)(object)UIPanelManager.instance != (Object)null)
			{
				UIPanelManager.instance.PopPanel(this);
			}
		}
	}

	public override void Update()
	{
		if (m_modeButtons[0].state == UIButtonColor.State.Hover || m_modeButtons[0].state == UIButtonColor.State.Pressed)
		{
			OnSurvivalSelected();
		}
		else if (m_modeButtons[1].state == UIButtonColor.State.Hover || m_modeButtons[1].state == UIButtonColor.State.Pressed)
		{
			OnScenarioSelected();
		}
		else
		{
			m_modeDescLabel.text = string.Empty;
		}
	}

	public void OnSurvivalSelected()
	{
		if ((Object)(object)m_modeDescLabel != (Object)null)
		{
			m_modeDescLabel.text = Localization.Get("ui.gamemode.survivaldesc");
		}
	}

	public void OnScenarioSelected()
	{
		if ((Object)(object)m_modeDescLabel != (Object)null)
		{
			m_modeDescLabel.text = Localization.Get("ui.gamemode.scenariodesc");
		}
	}

	public void OnSurvivalModeChosen()
	{
		if (m_inputEnabled)
		{
			if ((Object)(object)m_tween != (Object)null)
			{
				m_tween.PlayReverse();
			}
			m_scenarioModeChosen = false;
		}
	}

	public void OnScenarioModeChosen()
	{
		if (m_inputEnabled)
		{
			if ((Object)(object)m_tween != (Object)null)
			{
				m_tween.PlayReverse();
			}
			m_scenarioModeChosen = true;
		}
	}

	private void ShowSaveSlotScreen()
	{
		if (!((Object)(object)m_tween != (Object)null))
		{
			return;
		}
		if (m_tween.direction == Direction.Reverse)
		{
			m_inputEnabled = false;
			if ((Object)(object)m_slotSelectionPanel != (Object)null && (Object)(object)UIPanelManager.instance != (Object)null)
			{
				UIPanelManager.Instance().PushPanel(m_slotSelectionPanel);
			}
		}
		else
		{
			m_inputEnabled = true;
		}
	}

	private void ShowScenarioSelectionScreen()
	{
		if (!((Object)(object)m_tween != (Object)null))
		{
			return;
		}
		if (m_tween.direction == Direction.Reverse)
		{
			m_inputEnabled = false;
			if ((Object)(object)m_slotSelectionPanel != (Object)null && (Object)(object)UIPanelManager.instance != (Object)null)
			{
				UIPanelManager.Instance().PushPanel(m_scenarioSelectionPanel);
			}
		}
		else
		{
			m_inputEnabled = true;
		}
	}

	public void OnTweenFinished()
	{
		if ((Object)(object)m_tween != (Object)null && m_tween.direction == Direction.Reverse)
		{
			if (!m_goingBack)
			{
				if (!m_scenarioModeChosen)
				{
					ShowSaveSlotScreen();
				}
				else
				{
					ShowScenarioSelectionScreen();
				}
			}
			else if ((Object)(object)UIPanelManager.instance != (Object)null)
			{
				UIPanelManager.instance.PopPanel(this);
			}
		}
		else
		{
			m_inputEnabled = true;
		}
	}
}
