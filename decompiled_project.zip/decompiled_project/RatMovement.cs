using UnityEngine;

public class RatMovement : MonoBehaviour
{
	[SerializeField]
	private float m_WalkSpeed = 1f;

	private float m_walkSpeedMultiplier = 1f;

	[SerializeField]
	private float m_IdleChance = 0.33f;

	[SerializeField]
	private float m_LeaveChance = 0.33f;

	[SerializeField]
	private float m_MinWantToIdleTime;

	[SerializeField]
	private float m_MaxWantToIdleTime = 1f;

	public bool m_MoveLeft;

	private bool m_isWaiting;

	private bool m_WantToLeave;

	private float m_NextIdleTime;

	private Animator m_animator;

	private void Awake()
	{
		m_animator = ((Component)this).GetComponentInChildren<Animator>();
		m_NextIdleTime = Time.time + Random.Range(m_MinWantToIdleTime, m_MaxWantToIdleTime);
		if (Random.value > 0.5f)
		{
			SetMoveDirection(left: true);
		}
	}

	private void Update()
	{
		if (Time.time >= m_NextIdleTime)
		{
			if (Random.value < m_IdleChance)
			{
				if (!IsIdle())
				{
					SetIdle(idle: true);
				}
			}
			else if (IsIdle())
			{
				SetIdle(idle: false);
			}
			if (Random.value < m_LeaveChance)
			{
				m_WantToLeave = true;
			}
			m_NextIdleTime = Time.time + Random.Range(m_MinWantToIdleTime, m_MaxWantToIdleTime);
		}
		MovePest();
	}

	public void SetMoveDirection(bool left)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		if (m_MoveLeft != left)
		{
			((Component)this).transform.localScale = Vector3.Scale(((Component)this).transform.localScale, new Vector3(-1f, 1f, 1f));
			m_MoveLeft = left;
		}
	}

	public bool IsIdle()
	{
		return m_isWaiting;
	}

	public void SetIdle(bool idle)
	{
		if (m_isWaiting != idle)
		{
			m_isWaiting = idle;
			if (idle)
			{
				m_animator.SetTrigger("Idle");
			}
			else
			{
				m_animator.SetTrigger("Walk");
			}
		}
	}

	private void OnTriggerEnter2D(Collider2D coll)
	{
		if (((Component)coll).tag == "Vent" && m_WantToLeave)
		{
			ShelterVent component = ((Component)coll).GetComponent<ShelterVent>();
			if ((Object)(object)component != (Object)null)
			{
				component.PlayPestAnim();
			}
			Kill();
		}
		if (((Component)coll).tag == "Wall" || ((Component)coll).tag == "Door")
		{
			SetMoveDirection(!m_MoveLeft);
		}
	}

	public void MovePest()
	{
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		if (!m_isWaiting)
		{
			if (m_walkSpeedMultiplier > 1f)
			{
				m_walkSpeedMultiplier = Mathf.Max(1f, m_walkSpeedMultiplier - Time.deltaTime);
			}
			if (m_MoveLeft)
			{
				((Component)this).transform.Translate(new Vector3(-1f * (m_WalkSpeed * m_walkSpeedMultiplier * Time.deltaTime), 0f, 0f));
			}
			else
			{
				((Component)this).transform.Translate(new Vector3(m_WalkSpeed * m_walkSpeedMultiplier * Time.deltaTime, 0f, 0f));
			}
		}
	}

	public void Kill()
	{
		PestManager.Instance.UnregisterPest(this);
		Object.Destroy((Object)(object)((Component)this).gameObject);
	}

	public void FleeFromPosition(Vector3 position)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		m_walkSpeedMultiplier = 2.5f;
		m_isWaiting = false;
		if ((((Component)this).transform.position.x > position.x && m_MoveLeft) || (((Component)this).transform.position.x < position.x && !m_MoveLeft))
		{
			SetMoveDirection(!m_MoveLeft);
		}
	}
}
