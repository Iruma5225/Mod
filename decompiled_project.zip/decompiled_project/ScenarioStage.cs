using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

[Serializable]
public class ScenarioStage
{
	[SerializeField]
	private string m_id = string.Empty;

	[SerializeField]
	private List<string> m_characterIds = new List<string>();

	[SerializeField]
	private List<QuestEncounterStage> m_intercomStages = new List<QuestEncounterStage>();

	[SerializeField]
	private string m_unansweredNextStage = string.Empty;

	[SerializeField]
	private int m_unansweredNextDays = 1;

	[SerializeField]
	private bool m_punishOnUnanswered;

	public string id => m_id;

	public ReadOnlyCollection<string> characterIds => m_characterIds.AsReadOnly();

	public ReadOnlyCollection<QuestEncounterStage> intercomStages => m_intercomStages.AsReadOnly();

	public string unansweredNextStage => m_unansweredNextStage;

	public int unansweredNextDays => m_unansweredNextDays;

	public bool punishOnUnanswered => m_punishOnUnanswered;
}
