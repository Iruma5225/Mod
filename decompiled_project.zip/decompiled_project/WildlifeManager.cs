using System.Collections.Generic;
using UnityEngine;

public class WildlifeManager : BaseManager
{
	[SerializeField]
	private GameObject[] m_wildLifePrefab;

	[SerializeField]
	private Transform[] SpawnLocations;

	[SerializeField]
	private int m_MaxWildLifeCount = 1;

	[SerializeField]
	private float minSpawnDelay;

	[SerializeField]
	private float maxSpawnDelay = 1f;

	private float m_NextSpawnTime;

	private List<WildlifeMovement> m_Wildlife = new List<WildlifeMovement>();

	private static WildlifeManager m_instance;

	public static WildlifeManager Instance => m_instance;

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
			return;
		}
		m_NextSpawnTime = Time.time + Random.Range(minSpawnDelay, maxSpawnDelay);
	}

	public override void StartManager()
	{
	}

	public override void UpdateManager()
	{
		if (SpawnLocations != null && m_wildLifePrefab != null && Time.time >= m_NextSpawnTime)
		{
			if (Random.value > 0.5f && m_Wildlife.Count < m_MaxWildLifeCount)
			{
				SpawnRandomWildlife();
			}
			m_NextSpawnTime = Time.time + Random.Range(minSpawnDelay, maxSpawnDelay);
		}
	}

	private void SpawnRandomWildlife()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		Transform val = SpawnLocations[Random.Range(0, SpawnLocations.Length)];
		GameObject val2 = m_wildLifePrefab[Random.Range(0, m_wildLifePrefab.Length)];
		GameObject val3 = Object.Instantiate<GameObject>(val2, val.position, Quaternion.identity);
		if ((Object)(object)val3 == (Object)null)
		{
			return;
		}
		val3.transform.parent = ((Component)this).transform;
		WildlifeMovement component = val3.GetComponent<WildlifeMovement>();
		if ((Object)(object)component == (Object)null)
		{
			Object.Destroy((Object)(object)val3);
			return;
		}
		RegisterWildlife(component);
		if (val.position.x > 0f)
		{
			component.SetMoveDirection(left: true);
		}
	}

	public void RegisterWildlife(WildlifeMovement wildlife)
	{
		if (!m_Wildlife.Contains(wildlife))
		{
			m_Wildlife.Add(wildlife);
		}
	}

	public void UnregisterWildlife(WildlifeMovement wildlife)
	{
		if (m_Wildlife.Contains(wildlife))
		{
			m_Wildlife.Remove(wildlife);
		}
	}
}
