using System.Collections.Generic;
using UnityEngine;

public class VehiclePanel : BasePanel
{
	[SerializeField]
	private Obj_CamperVan vehicle;

	[SerializeField]
	private List<VehiclePartSlot> partSlots_Inspector = new List<VehiclePartSlot>();

	private Dictionary<ItemManager.ItemType, List<VehiclePartSlot>> partSlots = new Dictionary<ItemManager.ItemType, List<VehiclePartSlot>>();

	public AudioClip closeSound;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public void Awake()
	{
		for (int i = 0; i < partSlots_Inspector.Count; i++)
		{
			if (!partSlots.TryGetValue(partSlots_Inspector[i].Part, out var _))
			{
				partSlots.Add(partSlots_Inspector[i].Part, new List<VehiclePartSlot>());
			}
			partSlots[partSlots_Inspector[i].Part].Add(partSlots_Inspector[i]);
		}
	}

	public override void OnClose()
	{
		base.OnClose();
		AudioManager.Instance.PlayUI(closeSound);
	}

	public override void OnCancel()
	{
		base.OnCancel();
		UIPanelManager.Instance().PopPanel(this);
	}

	public override void OnShow()
	{
		base.OnShow();
		if ((Object)(object)vehicle == (Object)null)
		{
			return;
		}
		List<ItemManager.ItemType> listOfRequiredParts = vehicle.GetListOfRequiredParts();
		for (int i = 0; i < listOfRequiredParts.Count; i++)
		{
			int num = vehicle.GetRequiredNumberOfParts(listOfRequiredParts[i]) - vehicle.GetRemainingRequiredPart(listOfRequiredParts[i]);
			if (!partSlots.TryGetValue(listOfRequiredParts[i], out var value))
			{
				continue;
			}
			for (int j = 0; j < value.Count; j++)
			{
				value[j].UpdateSprite();
				if (j < num)
				{
					value[j].ShowPart();
				}
				else
				{
					value[j].HidePart();
				}
			}
		}
		UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.VehiclePanel);
	}
}
