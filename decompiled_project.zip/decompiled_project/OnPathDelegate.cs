using Pathfinding;

public delegate void OnPathDelegate(Path p);
