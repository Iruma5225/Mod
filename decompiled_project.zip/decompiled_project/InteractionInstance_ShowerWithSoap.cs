using UnityEngine;

public class InteractionInstance_ShowerWithSoap : InteractionInstance_Base
{
	private Int_ShowerWithSoap interaction;

	private Obj_Shower shower_object;

	private float duration;

	private float water_needed;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_ShowerWithSoap;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		shower_object = ((Component)this).GetComponent<Obj_Shower>();
		if ((Object)(object)shower_object == (Object)null)
		{
			return false;
		}
		if (WaterManager.Instance.StoredWater <= 0f)
		{
			shower_object.NoWaterIconVisible = true;
			shower_object.setNoWaterIconOffTimer();
			if (!member.isSpeaking)
			{
				member.Say(Localization.Get("Speech.NoWater"));
			}
			return false;
		}
		duration = member.stats.dirtiness.Value / interaction.StatReductionPerSecond;
		water_needed = duration * interaction.WaterUsedPerSecond;
		if (water_needed > WaterManager.Instance.StoredWater)
		{
			water_needed = WaterManager.Instance.StoredWater;
			duration = water_needed / interaction.WaterUsedPerSecond + Time.deltaTime;
		}
		ResetInteractionTimer(duration);
		member.SetSpriteVisibility(visible: false);
		if ((Object)(object)objectAnimator != (Object)null)
		{
			objectAnimator.SetTrigger("Close");
		}
		interaction.StartSoundEffect();
		interaction.StartLoopSoundEffect();
		member.SetMeshDepth(BaseCharacter.MeshDepth.Ladder);
		if ((Object)(object)shower_object.m_meshMask != (Object)null)
		{
			shower_object.m_meshMask.SetActive(true);
		}
		shower_object.SetInUse(being_used: true);
		InventoryManager.Instance.RemoveItemOfType(ItemManager.ItemType.Soap);
		return true;
	}

	protected override void OnInteractionUpdated()
	{
		interaction = base_interaction as Int_ShowerWithSoap;
		if (!WaterManager.Instance.UseWater(interaction.WaterUsedPerSecond * Time.deltaTime))
		{
			WaterManager.Instance.UseWater(WaterManager.Instance.StoredWater);
		}
		member.stats.dirtiness.Modify((0f - interaction.StatReductionPerSecond) * Time.deltaTime);
		member.stats.trauma.Modify((0f - interaction.TraumaReductionPerSecond) * Time.deltaTime);
	}

	protected override bool OnInteractionComplete()
	{
		shower_object.SetInUse(being_used: false);
		member.SetMeshDepth(BaseCharacter.MeshDepth.Normal);
		if ((Object)(object)shower_object.m_meshMask != (Object)null)
		{
			shower_object.m_meshMask.SetActive(false);
		}
		if (base.cancelled)
		{
			duration = cancelled_duration;
		}
		shower_object.Degrade(Mathf.FloorToInt(duration * interaction.IntegrityLostPerSecond));
		member.SetSpriteVisibility(visible: true);
		if ((Object)(object)objectAnimator != (Object)null)
		{
			objectAnimator.SetTrigger("Open");
		}
		interaction.StopLoopSoundEffect();
		interaction.FinishedSoundEffect();
		if (WaterManager.Instance.StoredWater <= 0f)
		{
			shower_object.NoWaterIconVisible = true;
			shower_object.setNoWaterIconOffTimer();
		}
		return true;
	}
}
