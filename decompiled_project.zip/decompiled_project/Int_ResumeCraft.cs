using UnityEngine;

public class Int_ResumeCraft : Int_Base
{
	private Obj_GhostBase obj_ghost;

	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "resume_craft";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		return base.IsPlayerSelectable() && (Object)(object)obj_ghost != (Object)null && obj_ghost.IsPaused();
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override void Awake()
	{
		base.Awake();
		obj_ghost = obj as Obj_GhostBase;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		if ((Object)(object)obj_ghost != (Object)null)
		{
			obj_ghost.ResumeConstruction(member);
			return true;
		}
		return false;
	}
}
