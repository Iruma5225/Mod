using System.Collections.Generic;
using UnityEngine;

public class Job_Murder : Job
{
	private enum MurderStage
	{
		GoToCharacter,
		Kill
	}

	private MurderStage m_stage;

	private readonly ItemManager.ItemType[] m_possibleWeapons = new ItemManager.ItemType[3]
	{
		ItemManager.ItemType.Weapon_Knife,
		ItemManager.ItemType.Weapon_Hatchet,
		ItemManager.ItemType.Weapon_Rock
	};

	private ItemManager.ItemType m_weapon = ItemManager.ItemType.Weapon_Fists;

	private FamilyMember m_target;

	private int m_killsLeft;

	private const float m_targetPositionError = 0.6f;

	private const float m_targetUpdateInterval = 0.2f;

	private float m_targetUpdateTimer;

	private float m_killTimer;

	private float m_attackTimer;

	public Job_Murder()
	{
		if (!((Object)(object)SaveManager.instance == (Object)null) && SaveManager.instance.isLoading)
		{
		}
	}

	public Job_Murder(FamilyMember character, int killCount)
		: base("murder", Vector3.zero, character, null)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		m_killsLeft = killCount;
	}

	public override string GetJobType()
	{
		return "Job_Murder";
	}

	public override void Activate()
	{
		m_weapon = ItemManager.ItemType.Weapon_Fists;
		if (m_possibleWeapons.Length > 0)
		{
			m_weapon = m_possibleWeapons[Random.Range(0, m_possibleWeapons.Length)];
		}
		m_target = GetNearestCharacterToExit();
		BeginStage();
	}

	public override bool BeginJob()
	{
		state = JobState.Started;
		return true;
	}

	public override void UpdateJob()
	{
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		if (m_stage == MurderStage.GoToCharacter)
		{
			m_targetUpdateTimer -= Time.deltaTime;
			if (m_targetUpdateTimer <= 0f)
			{
				FamilyMember target = m_target;
				m_target = GetNearestCharacterToExit();
				if ((Object)(object)m_target != (Object)(object)target)
				{
					m_stage = MurderStage.GoToCharacter;
					BeginStage();
				}
				else
				{
					UpdatePathing();
				}
				m_targetUpdateTimer = 0.2f;
			}
			if ((Object)(object)m_target == (Object)null)
			{
				Cancel(forced: true);
				BeginStage();
			}
		}
		if (m_stage == MurderStage.GoToCharacter && (Object)(object)m_target != (Object)null && Vector3.Distance(((Component)character).transform.position, ((Component)m_target).transform.position) < 0.6f && !m_target.isClimbing)
		{
			m_stage = MurderStage.Kill;
			BeginStage();
		}
		if (m_stage == MurderStage.Kill)
		{
			m_killTimer -= Time.deltaTime;
			if (m_killTimer <= 0f && (Object)(object)m_target != (Object)null && !m_target.isDead)
			{
				m_target.Kill(BaseCharacter.DamageType.Murder, string.Empty);
				m_killsLeft--;
			}
			m_attackTimer -= Time.deltaTime;
			if (m_attackTimer <= 0f)
			{
				m_target = GetNearestCharacterToExit();
				m_stage = MurderStage.GoToCharacter;
				BeginStage();
			}
		}
	}

	public static List<FamilyMember> GetValidTargets(FamilyMember murderer)
	{
		List<FamilyMember> shelteredFamilyMembers = FamilyManager.Instance.GetShelteredFamilyMembers(onlyIndoorMembers: true);
		shelteredFamilyMembers.RemoveAll((FamilyMember x) => (Object)(object)x == (Object)(object)murderer);
		shelteredFamilyMembers.RemoveAll(delegate(FamilyMember x)
		{
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			ShelterRoomGrid.GridCell cell = ShelterRoomGrid.Instance.GetCell(((Component)x).transform.position);
			return (cell == null || (cell.type != ShelterRoomGrid.CellType.Room && cell.type != ShelterRoomGrid.CellType.RoomTop)) ? true : false;
		});
		return shelteredFamilyMembers;
	}

	private FamilyMember GetNearestCharacterToExit()
	{
		List<FamilyMember> validTargets = GetValidTargets(character);
		if (validTargets.Count > 0)
		{
			validTargets.Sort(delegate(FamilyMember x, FamilyMember y)
			{
				//IL_0006: Unknown result type (might be due to invalid IL or missing references)
				//IL_000b: Unknown result type (might be due to invalid IL or missing references)
				//IL_0012: Unknown result type (might be due to invalid IL or missing references)
				//IL_0017: Unknown result type (might be due to invalid IL or missing references)
				Vector3 position = ((Component)x).transform.position;
				Vector3 position2 = ((Component)y).transform.position;
				return (position.y == position2.y) ? position.x.CompareTo(position2.x) : position2.y.CompareTo(position.y);
			});
			return validTargets[0];
		}
		return null;
	}

	private void UpdatePathing()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		character.ClearPath();
		if (!m_target.isClimbing)
		{
			location = ((!((Object)(object)m_target != (Object)null)) ? ((Component)character).transform.position : ((Component)m_target).transform.position);
			character.WalkToPosition(location);
		}
	}

	private void BeginStage()
	{
		character.TriggerAnim("Idle");
		character.SetAnimationLayer(0);
		character.ClearPath();
		if (m_killsLeft <= 0 || GetCancelState() != JobCancelState.Active)
		{
			state = JobState.Finished;
			OnFinishedJob();
			return;
		}
		switch (m_stage)
		{
		case MurderStage.GoToCharacter:
			if ((Object)(object)m_target != (Object)null)
			{
				UpdatePathing();
			}
			state = JobState.Started;
			break;
		case MurderStage.Kill:
		{
			ItemDefinition_Combat combatDefinition = ItemManager.Instance.GetCombatDefinition(m_weapon);
			if ((Object)(object)combatDefinition != (Object)null)
			{
				ItemDefinition_Combat.AnimInfo animInfo = combatDefinition.GetAnimInfo(ItemDefinition_Combat.WeaponAnimEnum.Melee);
				if (animInfo != null)
				{
					character.SetAnimationLayer(combatDefinition.AnimationLayer);
					character.TriggerAnim(animInfo.TriggerName);
					m_killTimer = animInfo.ImpactTime;
					m_attackTimer = animInfo.Length;
				}
			}
			state = JobState.Started;
			break;
		}
		default:
			state = JobState.Finished;
			OnFinishedJob();
			break;
		}
	}

	public override void OnFinishedJob()
	{
		base.OnFinishedJob();
		if (cancelState != JobCancelState.Active)
		{
			character.OnMurderCancelled();
		}
		else
		{
			character.OnFinishedMurdering();
		}
	}

	public override void SaveLoadJob(SaveData data)
	{
		base.SaveLoadJob(data);
		int value = ((!((Object)(object)m_target != (Object)null)) ? (-1) : m_target.GetId());
		int value2 = (int)m_stage;
		data.SaveLoad("targetId", ref value);
		data.SaveLoad("murderStage", ref value2);
		data.SaveLoad("killsLeft", ref m_killsLeft);
		data.SaveLoad("targetUpdateTimer", ref m_targetUpdateTimer);
		data.SaveLoad("killTimer", ref m_killTimer);
		data.SaveLoad("endTimer", ref m_attackTimer);
		if (data.isLoading)
		{
			if ((Object)(object)FamilyManager.Instance != (Object)null && value > -1)
			{
				m_target = FamilyManager.Instance.GetFamilyMember(value);
			}
			m_stage = (MurderStage)value2;
		}
	}
}
