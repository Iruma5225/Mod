using UnityEngine;

public class GameTime : MonoBehaviour, ISaveable
{
	public delegate void GameTimeEvent();

	[SerializeField]
	private float day_length_in_seconds = 600f;

	private static float day_seconds;

	private static float real_to_game_seconds_multiplier;

	private static float game_to_real_seconds_multiplier;

	private static float game_time = 21600f;

	private static int current_minute;

	private static int current_hour;

	private static int current_day = 1;

	private static int current_week = 1;

	private static GameTime m_instance;

	public static int Minute => current_minute;

	public static int Hour => current_hour;

	public static int Day => current_day;

	public static int Week => current_week;

	public static float DayProgress => game_time / 86400f;

	public static float RealSecondsPerDay => day_seconds;

	public static event GameTimeEvent newDay;

	public static event GameTimeEvent newWeek;

	public static float RealSecondsToGameSeconds(float real_seconds)
	{
		return real_seconds * real_to_game_seconds_multiplier;
	}

	public static float GameSecondsToRealSeconds(float game_seconds)
	{
		return game_seconds * game_to_real_seconds_multiplier;
	}

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
			return;
		}
		day_seconds = day_length_in_seconds;
		game_to_real_seconds_multiplier = day_length_in_seconds / 86400f;
		real_to_game_seconds_multiplier = 1f / game_to_real_seconds_multiplier;
		current_minute = 0;
		current_hour = 0;
		current_day = 1;
		current_week = 1;
		game_time = 21600f;
		SendCurrentDayStat();
		SetInShelterPresence();
		GameTime.newDay = null;
		GameTime.newWeek = null;
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
	}

	public void Update()
	{
		if (Time.timeScale == 0f)
		{
			return;
		}
		if ((Object)(object)TutorialManager.Instance != (Object)null && TutorialManager.Instance.TutorialActive)
		{
			current_minute = 0;
			current_hour = 0;
			current_day = 1;
			return;
		}
		float num = game_time;
		game_time += Time.deltaTime * real_to_game_seconds_multiplier;
		if (num < 21600f && game_time >= 21600f)
		{
			if (current_day++ % 7 == 0)
			{
				current_week++;
				if (GameTime.newWeek != null)
				{
					GameTime.newWeek();
				}
			}
			if (GameTime.newDay != null)
			{
				GameTime.newDay();
			}
			if ((Object)(object)SaveManager.instance != (Object)null && !RelocationManager.isRelocating)
			{
				SaveManager.instance.SaveToCurrentSlot(alsoSaveGlobalDataOnPs4: false);
			}
			if ((Object)(object)AchievementManager.instance != (Object)null)
			{
				AchievementManager.instance.OnNewDay(current_day);
			}
			SendCurrentDayStat();
		}
		if (game_time >= 86400f)
		{
			game_time -= 86400f;
		}
		int num2 = (int)game_time % 86400;
		current_hour = num2 / 3600;
		current_minute = (num2 - current_hour * 3600) / 60;
	}

	public static bool HasBeenLoaded()
	{
		if ((Object)(object)m_instance != (Object)null && (Object)(object)SaveManager.instance != (Object)null && SaveManager.instance.HasBeenLoaded(m_instance))
		{
			return true;
		}
		return false;
	}

	public bool IsRelocationEnabled()
	{
		return true;
	}

	public bool IsReadyForLoad()
	{
		return true;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("GameTime");
		data.SaveLoad("gameTime", ref game_time);
		data.SaveLoad("current_min", ref current_minute);
		data.SaveLoad("current_hour", ref current_hour);
		data.SaveLoad("current_day", ref current_day);
		data.SaveLoad("current_week", ref current_week);
		if (data.isLoading)
		{
			SendCurrentDayStat();
			SetInShelterPresence();
		}
		data.GroupEnd();
		return true;
	}

	private void SendCurrentDayStat()
	{
	}

	private void SetInShelterPresence()
	{
	}
}
