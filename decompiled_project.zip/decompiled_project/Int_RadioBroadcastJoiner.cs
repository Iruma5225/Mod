public class Int_RadioBroadcastJoiner : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_RadioBroadcastJoiner";
	}

	public override string GetInteractionType()
	{
		return "radio_broadcast_joiner";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		return false;
	}
}
