public static class GPGSIds
{
	public const string achievement_green_fingers = "CgkIo6rz9toeEAIQEA";

	public const string achievement_fat_of_the_land = "CgkIo6rz9toeEAIQDw";

	public const string leaderboard_high_score_hardcore = "CgkIo6rz9toeEAIQGg";

	public const string leaderboard_monthly = "CgkIo6rz9toeEAIQFw";

	public const string achievement_tinkerer = "CgkIo6rz9toeEAIQCw";

	public const string achievement_tko = "CgkIo6rz9toeEAIQCQ";

	public const string achievement_hunter_gatherer = "CgkIo6rz9toeEAIQDg";

	public const string leaderboard_high_scores = "CgkIo6rz9toeEAIQFg";

	public const string leaderboard_monthly_hardcore = "CgkIo6rz9toeEAIQGw";

	public const string achievement_correct_code = "CgkIo6rz9toeEAIQFQ";

	public const string achievement_grease_monkey = "CgkIo6rz9toeEAIQEg";

	public const string achievement_gunslinger = "CgkIo6rz9toeEAIQCg";

	public const string achievement_tooled_up = "CgkIo6rz9toeEAIQCA";

	public const string achievement_push_it_to_the_limit = "CgkIo6rz9toeEAIQDA";

	public const string achievement_handyman = "CgkIo6rz9toeEAIQBw";

	public const string achievement_day_tripper = "CgkIo6rz9toeEAIQAw";

	public const string achievement_true_survivor = "CgkIo6rz9toeEAIQAg";

	public const string achievement_nice_try = "CgkIo6rz9toeEAIQFA";

	public const string leaderboard_monthly_hard = "CgkIo6rz9toeEAIQGQ";

	public const string achievement_helping_hand = "CgkIo6rz9toeEAIQEw";

	public const string achievement_getting_comfy = "CgkIo6rz9toeEAIQAQ";

	public const string achievement_well_travelled = "CgkIo6rz9toeEAIQBA";

	public const string achievement_im_giving_you_all_shes_got = "CgkIo6rz9toeEAIQDQ";

	public const string achievement_botanist = "CgkIo6rz9toeEAIQEQ";

	public const string achievement_globetrotter = "CgkIo6rz9toeEAIQBQ";

	public const string leaderboard_high_scores_hard = "CgkIo6rz9toeEAIQGA";

	public const string achievement_relic_hunter = "CgkIo6rz9toeEAIQBg";
}
