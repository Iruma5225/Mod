using System.Collections.Generic;
using UnityEngine;

public abstract class InteractionInstance_Base : MonoBehaviour
{
	public enum InteractionState
	{
		Pending,
		Started,
		Finished,
		Cancelled
	}

	private bool m_InProgress;

	private float m_progress;

	private float start_time;

	private float end_time;

	protected float cancelled_duration;

	private InteractionState state;

	protected bool m_cancelled;

	private bool m_forceCancelled;

	private float m_FatigueAccumulator;

	protected float m_fatigueRateMultiplier = 1f;

	protected Int_Base base_interaction;

	protected Obj_Base obj_base;

	protected PoweredObject obj_power;

	protected FamilyMember member;

	protected Animator objectAnimator;

	public string type = string.Empty;

	public bool InProgress => m_InProgress;

	public float Progress => m_progress;

	public bool cancelled => m_cancelled;

	public bool forceCancelled => m_forceCancelled;

	public InteractionState GetState()
	{
		return state;
	}

	protected abstract bool OnInteractionStarted();

	protected virtual void OnInteractionUpdated()
	{
	}

	protected abstract bool OnInteractionComplete();

	public bool Initialize(Int_Base base_interaction, FamilyMember family_member)
	{
		this.base_interaction = base_interaction;
		member = family_member;
		type = base_interaction.GetInteractionType();
		obj_base = ((Component)this).GetComponent<Obj_Base>();
		obj_power = ((Component)this).GetComponent<PoweredObject>();
		objectAnimator = ((Component)this).GetComponentInChildren<Animator>();
		if ((Object)(object)base_interaction == (Object)null)
		{
			return false;
		}
		if ((Object)(object)member == (Object)null)
		{
			return false;
		}
		ResetInteractionTimer(base_interaction.Duration);
		if (state == InteractionState.Pending)
		{
			if (OnInteractionStarted())
			{
				state = InteractionState.Started;
				if ((Object)(object)obj_power != (Object)null && base_interaction.PowerUse > 0 && (Object)(object)PowerManager.Instance != (Object)null)
				{
					obj_power.RequiredPower += base_interaction.PowerUse;
					PowerManager.Instance.UpdatePowerFlow();
				}
				if (base_interaction.IsAvailable())
				{
					return true;
				}
			}
			Cancel(force: true);
			if (cancelled)
			{
				state = InteractionState.Cancelled;
			}
			if (!cancelled)
			{
				if (OnInteractionComplete() || m_forceCancelled)
				{
					FinishInteraction();
				}
			}
			else
			{
				FinishInteraction();
			}
		}
		return false;
	}

	private void FinishInteraction()
	{
		SetProgress(member, 0f);
		m_InProgress = false;
		if (!cancelled)
		{
			state = InteractionState.Finished;
		}
		if ((Object)(object)obj_power != (Object)null && (Object)(object)PowerManager.Instance != (Object)null)
		{
			obj_power.RequiredPower -= base_interaction.PowerUse;
			PowerManager.Instance.UpdatePowerFlow();
		}
		if (!((Object)(object)base_interaction != (Object)null) || cancelled)
		{
			return;
		}
		int num = base_interaction.ExpAward;
		int num2 = 0;
		List<BaseStats.StatType> statsToAwardExp = base_interaction.StatsToAwardExp;
		for (int i = 0; i < statsToAwardExp.Count; i++)
		{
			if (i == statsToAwardExp.Count - 1)
			{
				member.BaseStats.GetStatByEnum(statsToAwardExp[i]).IncreaseExp(num);
				break;
			}
			num2 = Random.Range(0, num);
			member.BaseStats.GetStatByEnum(statsToAwardExp[i]).IncreaseExp(num2);
			num -= num2;
		}
	}

	protected void ResetInteractionTimer(float duration)
	{
		start_time = Time.time;
		end_time = start_time + duration;
		m_InProgress = true;
		SetProgress(member, 0f);
	}

	protected void ModifyInteractionDuration(float duration)
	{
		float time = Time.time;
		end_time = time + (1f - Progress) * duration;
		start_time = time - Progress * duration;
		m_InProgress = true;
		SetProgress(member, (time - start_time) / (end_time - start_time));
	}

	protected virtual bool UpdateInteractionTimer()
	{
		float time = Time.time;
		SetProgress(member, (time - start_time) / (end_time - start_time));
		if (time >= end_time)
		{
			return true;
		}
		return false;
	}

	public bool UpdateInteraction()
	{
		if ((Object)(object)base_interaction != (Object)null && (Object)(object)obj_base != (Object)null && !base_interaction.IsAvailable())
		{
			if (member.job_queue.GetCurrent() != null && (Object)(object)member.job_queue.GetCurrent().obj == (Object)(object)obj_base)
			{
				member.job_queue.GetCurrent().Cancel(forced: true);
			}
			else if (member.ai_queue.GetCurrent() != null && (Object)(object)member.ai_queue.GetCurrent().obj == (Object)(object)obj_base)
			{
				member.ai_queue.GetCurrent().Cancel(forced: true);
			}
		}
		if ((Object)(object)base_interaction != (Object)null && base_interaction.FatigueRate != 0f)
		{
			m_FatigueAccumulator += base_interaction.FatigueRate * m_fatigueRateMultiplier * Time.deltaTime;
			if (m_FatigueAccumulator >= 1f)
			{
				int num = Mathf.FloorToInt(m_FatigueAccumulator);
				m_FatigueAccumulator -= num;
				member.stats.fatigue.Modify(num);
			}
			else if (m_FatigueAccumulator <= -1f)
			{
				int num2 = Mathf.CeilToInt(m_FatigueAccumulator);
				m_FatigueAccumulator -= num2;
				member.stats.fatigue.Modify(num2);
			}
		}
		if (!UpdateInteractionTimer() && !m_forceCancelled && (!cancelled || !CanCancelImmediately()))
		{
			OnInteractionUpdated();
			return false;
		}
		if (cancelled)
		{
			state = InteractionState.Cancelled;
		}
		if (OnInteractionComplete() || m_forceCancelled)
		{
			FinishInteraction();
			return true;
		}
		state = InteractionState.Started;
		return false;
	}

	public void SetProgress(FamilyMember member, float progress)
	{
		if (m_InProgress)
		{
			m_progress = Mathf.Clamp(progress, 0f, 1f);
			if ((Object)(object)InteractionManager.Instance != (Object)null)
			{
				InteractionManager.Instance.SetInteractionProgress(member, progress);
			}
		}
	}

	public void Cancel(bool force)
	{
		m_cancelled = true;
		m_forceCancelled = force;
		if (force)
		{
			SetProgress(member, 0f);
		}
		float time = Time.time;
		if (state == InteractionState.Started && time >= start_time && time < end_time)
		{
			cancelled_duration = time - start_time;
		}
	}

	protected virtual bool CanCancelImmediately()
	{
		return true;
	}
}
