using UnityEngine;

public class NavmeshController : MonoBehaviour
{
}
