using UnityEngine;

public class InteractionInstance_BrewCoffee : InteractionInstance_Base
{
	private Int_BrewCoffee interaction;

	private float m_waterRequiredForCoffee = 5f;

	private int m_beansRequiredForCoffee = 1;

	protected override bool CanCancelImmediately()
	{
		return false;
	}

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_BrewCoffee;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		Obj_CoffeeMachine obj_CoffeeMachine = obj_base as Obj_CoffeeMachine;
		if (!obj_CoffeeMachine.HasEnoughPower() || !obj_CoffeeMachine.IsEnabled())
		{
			return false;
		}
		if (((Object)(object)WaterManager.Instance != (Object)null && WaterManager.Instance.StoredWater < m_waterRequiredForCoffee) || ((Object)(object)InventoryManager.Instance != (Object)null && InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.CoffeeBeans) < m_beansRequiredForCoffee))
		{
			return false;
		}
		WaterManager.Instance.UseWater(m_waterRequiredForCoffee);
		InventoryManager.Instance.RemoveItemOfType(ItemManager.ItemType.CoffeeBeans);
		member.TriggerAnim("Rummage");
		interaction.BrewSoundEffect();
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled)
		{
			Obj_CoffeeMachine obj_CoffeeMachine = obj_base as Obj_CoffeeMachine;
			if (!((Object)(object)obj_CoffeeMachine != (Object)null))
			{
				return false;
			}
			obj_CoffeeMachine.StartBrewing();
		}
		return true;
	}
}
