using System;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMeshOptions : MonoBehaviour
{
	[Serializable]
	public class CharacterTexture
	{
		public string m_id = string.Empty;

		public Texture2D m_texture;

		public Sprite m_avatar;

		public bool m_availableForCustomization = true;
	}

	[Serializable]
	public class OverlayTexture
	{
		public string m_id = string.Empty;

		public Texture2D m_texture;
	}

	[Serializable]
	public class CharacterMeshType
	{
		public string m_id = string.Empty;

		public bool m_male = true;

		public bool m_adult = true;

		public RuntimeAnimatorController m_anims;

		public GameObject m_meshAsset;

		public Vector2 m_meshOffset = Vector2.zero;

		public Vector2 m_uiOffset = new Vector2(0f, 2f);

		public Vector2 m_collisionBoxOffset = new Vector2(0f, 0.9f);

		public Vector2 m_collisionBoxDimensions = new Vector2(1.2f, 2f);

		public List<CharacterTexture> m_headTextures = new List<CharacterTexture>();

		public List<CharacterTexture> m_torsoTextures = new List<CharacterTexture>();

		public List<CharacterTexture> m_legTextures = new List<CharacterTexture>();

		public List<OverlayTexture> m_torsoOverlayTextures = new List<OverlayTexture>();

		public string GetRandomTexture(CharacterMesh.TextureType texType)
		{
			List<CharacterTexture> list = null;
			switch (texType)
			{
			case CharacterMesh.TextureType.Head:
				list = m_headTextures;
				break;
			case CharacterMesh.TextureType.Torso:
				list = m_torsoTextures;
				break;
			case CharacterMesh.TextureType.Legs:
				list = m_legTextures;
				break;
			}
			if (list == null || list.Count == 0)
			{
				return "default";
			}
			List<string> list2 = new List<string>();
			for (int i = 0; i < list.Count; i++)
			{
				if (list[i] != null)
				{
					string text = list[i].m_id.ToLowerInvariant();
					if (text != "gasmask" && text != "hazmat" && list[i].m_availableForCustomization)
					{
						list2.Add(list[i].m_id);
					}
				}
			}
			if (list2.Count > 0)
			{
				return list2[Random.Range(0, list2.Count)];
			}
			return "default";
		}
	}

	[Serializable]
	public class CharacterPreset
	{
		public string m_id = string.Empty;

		public string m_meshId = string.Empty;

		public string m_firstName = string.Empty;

		public string m_lastName = string.Empty;

		public string m_headTexture = "default";

		public string m_torsoTexture = "default";

		public string m_legTexture = "default";

		public string m_torsoOverlay = "none";

		public Color m_skinColor = Color.white;

		public Color m_hairColor = Color.white;

		public Color m_shirtColor = Color.white;

		public Color m_pantsColor = Color.white;

		public bool m_randomizeMesh;

		public bool m_randomizeName;

		public bool m_randomizeClothes;

		public CharacterPreset()
		{
		}//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)


		public CharacterPreset(CharacterPreset other)
		{
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0074: Unknown result type (might be due to invalid IL or missing references)
			//IL_007a: Unknown result type (might be due to invalid IL or missing references)
			//IL_007f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0104: Unknown result type (might be due to invalid IL or missing references)
			//IL_0109: Unknown result type (might be due to invalid IL or missing references)
			//IL_0110: Unknown result type (might be due to invalid IL or missing references)
			//IL_0115: Unknown result type (might be due to invalid IL or missing references)
			m_id = other.m_id;
			m_meshId = other.m_meshId;
			m_firstName = other.m_firstName;
			m_lastName = other.m_lastName;
			m_headTexture = other.m_headTexture;
			m_torsoTexture = other.m_torsoTexture;
			m_legTexture = other.m_legTexture;
			m_torsoOverlay = other.m_torsoOverlay;
			m_skinColor = other.m_skinColor;
			m_hairColor = other.m_hairColor;
			m_shirtColor = other.m_shirtColor;
			m_pantsColor = other.m_pantsColor;
			m_randomizeMesh = other.m_randomizeMesh;
			m_randomizeName = other.m_randomizeName;
			m_randomizeClothes = other.m_randomizeClothes;
		}

		public virtual void Randomize_DontCallThisOutsideOfCharacterMeshOptions()
		{
			//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0109: Unknown result type (might be due to invalid IL or missing references)
			//IL_010e: Unknown result type (might be due to invalid IL or missing references)
			//IL_011a: Unknown result type (might be due to invalid IL or missing references)
			//IL_011f: Unknown result type (might be due to invalid IL or missing references)
			if (m_randomizeMesh)
			{
				m_meshId = ((Random.Range(0, 2) != 0) ? "woman" : "man");
			}
			CharacterMeshType characterMeshType = null;
			if (!string.IsNullOrEmpty(m_meshId) && (Object)(object)instance != (Object)null)
			{
				characterMeshType = instance.FindCharacterMesh(m_meshId);
			}
			if (m_randomizeName && characterMeshType != null)
			{
				m_firstName = NameGenerator.GetFirstName((!characterMeshType.m_male) ? NameGenerator.Gender.Female : NameGenerator.Gender.Male);
				m_lastName = NameGenerator.GetSurname();
			}
			if (m_randomizeClothes)
			{
				if (characterMeshType != null)
				{
					m_headTexture = characterMeshType.GetRandomTexture(CharacterMesh.TextureType.Head);
					m_torsoTexture = characterMeshType.GetRandomTexture(CharacterMesh.TextureType.Torso);
					m_legTexture = characterMeshType.GetRandomTexture(CharacterMesh.TextureType.Legs);
				}
				if ((Object)(object)NpcVisitManager.Instance != (Object)null)
				{
					m_hairColor = NpcVisitManager.Instance.GetRandomNpcColor(CharacterMesh.ColorCustomization.HairColor);
					m_skinColor = NpcVisitManager.Instance.GetRandomNpcColor(CharacterMesh.ColorCustomization.SkinColor);
					m_shirtColor = NpcVisitManager.Instance.GetRandomNpcColor(CharacterMesh.ColorCustomization.ShirtColor);
					m_pantsColor = NpcVisitManager.Instance.GetRandomNpcColor(CharacterMesh.ColorCustomization.PantsColor);
				}
			}
		}

		public void SaveLoadPreset(SaveData data)
		{
			data.GroupStart("CharacterPreset");
			SaveLoadPreset_Internal(data);
			data.GroupEnd();
		}

		protected virtual void SaveLoadPreset_Internal(SaveData data)
		{
			data.SaveLoad("preset_id", ref m_id);
			data.SaveLoad("mesh_id", ref m_meshId);
			data.SaveLoad("first_name", ref m_firstName);
			data.SaveLoad("last_name", ref m_lastName);
			data.SaveLoad("head_tex", ref m_headTexture);
			data.SaveLoad("torso_tex", ref m_torsoTexture);
			data.SaveLoad("leg_tex", ref m_legTexture);
			data.SaveLoad("overlay_torso", ref m_torsoOverlay);
			data.SaveLoad("skin_color", ref m_skinColor);
			data.SaveLoad("hair_color", ref m_hairColor);
			data.SaveLoad("shirt_color", ref m_shirtColor);
			data.SaveLoad("pants_color", ref m_pantsColor);
		}
	}

	[Serializable]
	public class QuestCharacterPreset : CharacterPreset
	{
		public bool m_useFamilyName;

		public QuestCharacterPreset()
		{
		}

		public QuestCharacterPreset(QuestCharacterPreset other)
			: base(other)
		{
			m_useFamilyName = other.m_useFamilyName;
		}

		public override void Randomize_DontCallThisOutsideOfCharacterMeshOptions()
		{
			base.Randomize_DontCallThisOutsideOfCharacterMeshOptions();
			if (m_useFamilyName)
			{
				m_lastName = NameGenerator.familySurname;
			}
		}

		protected override void SaveLoadPreset_Internal(SaveData data)
		{
			base.SaveLoadPreset_Internal(data);
		}
	}

	[SerializeField]
	private List<CharacterMeshType> m_characterMeshes = new List<CharacterMeshType>();

	[SerializeField]
	private List<CharacterPreset> m_kickstarterPresets = new List<CharacterPreset>();

	private int m_nextKickstarterPreset;

	[SerializeField]
	private List<QuestCharacterPreset> m_questCharacterPresets = new List<QuestCharacterPreset>();

	private static CharacterMeshOptions m_instance;

	public static CharacterMeshOptions instance => m_instance;

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
			Object.DontDestroyOnLoad((Object)(object)this);
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
			return;
		}
		CheckForErrors();
		m_kickstarterPresets.Shuffle();
	}

	public List<string> GetCharacterMeshIds()
	{
		List<string> list = new List<string>();
		for (int i = 0; i < m_characterMeshes.Count; i++)
		{
			list.Add(m_characterMeshes[i].m_id);
		}
		return list;
	}

	public CharacterMeshType FindCharacterMesh(string id)
	{
		for (int i = 0; i < m_characterMeshes.Count; i++)
		{
			if (string.Compare(m_characterMeshes[i].m_id, id, ignoreCase: true) == 0)
			{
				return m_characterMeshes[i];
			}
		}
		return null;
	}

	public CharacterPreset FindKickstarterPreset(string id)
	{
		for (int i = 0; i < m_kickstarterPresets.Count; i++)
		{
			if (string.Compare(m_kickstarterPresets[i].m_id, id, ignoreCase: true) == 0)
			{
				return new CharacterPreset(m_kickstarterPresets[i]);
			}
		}
		return null;
	}

	public QuestCharacterPreset FindQuestCharacterPreset(string id)
	{
		for (int i = 0; i < m_questCharacterPresets.Count; i++)
		{
			if (string.Compare(m_questCharacterPresets[i].m_id, id, ignoreCase: true) == 0)
			{
				QuestCharacterPreset questCharacterPreset = new QuestCharacterPreset(m_questCharacterPresets[i]);
				questCharacterPreset.Randomize_DontCallThisOutsideOfCharacterMeshOptions();
				return questCharacterPreset;
			}
		}
		return null;
	}

	public CharacterMesh InstantiateNewCharacterMesh(string meshId, Transform parent, string meshLayer, float animSpeed)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		if (string.IsNullOrEmpty(meshId))
		{
			return null;
		}
		CharacterMeshType characterMeshType = FindCharacterMesh(meshId);
		if (characterMeshType == null || (Object)(object)characterMeshType.m_meshAsset == (Object)null)
		{
			return null;
		}
		Animator val = null;
		GameObject val2 = Object.Instantiate<GameObject>(characterMeshType.m_meshAsset, Vector3.zero, Quaternion.identity);
		if ((Object)(object)val2 != (Object)null)
		{
			((Object)val2.gameObject).name = "mesh";
			val2.transform.parent = parent;
			val2.transform.localPosition = Vector2.op_Implicit(characterMeshType.m_meshOffset);
			val2.transform.localScale = Vector3.one;
			val2.transform.rotation = Quaternion.Euler(new Vector3(0f, 180f, 0f));
			val = val2.GetComponent<Animator>();
			if ((Object)(object)val != (Object)null)
			{
				val.runtimeAnimatorController = characterMeshType.m_anims;
				val.updateMode = (AnimatorUpdateMode)2;
				val.speed = animSpeed;
			}
			CharacterMesh characterMesh = val2.AddComponent<CharacterMesh>();
			if ((Object)(object)characterMesh != (Object)null)
			{
				characterMesh.SetMeshType(characterMeshType, meshLayer);
			}
			return characterMesh;
		}
		return null;
	}

	public CharacterPreset GetNextKickstarterCharacterPreset()
	{
		int num = m_nextKickstarterPreset++;
		if (m_nextKickstarterPreset >= m_kickstarterPresets.Count)
		{
			m_nextKickstarterPreset = 0;
		}
		if (m_kickstarterPresets.Count > 0 && num < m_kickstarterPresets.Count)
		{
			return new CharacterPreset(m_kickstarterPresets[num]);
		}
		return null;
	}

	private void CheckForErrors()
	{
		for (int i = 0; i < m_characterMeshes.Count; i++)
		{
			string id = m_characterMeshes[i].m_id;
			if (string.IsNullOrEmpty(id))
			{
				continue;
			}
			for (int j = i + 1; j < m_characterMeshes.Count; j++)
			{
				if (string.Compare(id, m_characterMeshes[j].m_id.ToLower(), ignoreCase: true) == 0)
				{
				}
			}
		}
		for (int k = 0; k < m_characterMeshes.Count; k++)
		{
			List<string> list = new List<string>();
			CharacterMeshType characterMeshType = m_characterMeshes[k];
			CharacterTexture characterTexture = null;
			for (int l = 0; l < characterMeshType.m_headTextures.Count; l++)
			{
				characterTexture = characterMeshType.m_headTextures[l];
				if (characterTexture != null && !((Object)(object)characterTexture.m_texture == (Object)null) && !string.IsNullOrEmpty(characterTexture.m_id) && !list.Contains(characterTexture.m_id))
				{
					list.Add(characterTexture.m_id);
				}
			}
		}
	}
}
