using UnityEngine;

public class ShadowAnimEvents : MonoBehaviour
{
	public void OnHatchAnimStarted()
	{
	}

	public void OnHatchAnimFinished()
	{
	}
}
