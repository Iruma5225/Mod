using System.Collections.Generic;
using UnityEngine;

public class Obj_CoffeeMachine : Obj_Integrity
{
	private int m_cupsOfCoffee;

	private int m_prevCups;

	private bool m_brewing;

	[SerializeField]
	private float m_brewingTime = 30f;

	private float m_brewingTimer;

	[SerializeField]
	private int m_cupsPerBrew = 10;

	private float m_brewingSpriteSwitchTimer;

	private float m_brewingSpriteSwitchTime = 0.5f;

	[SerializeField]
	private SpriteRenderer m_brewingSprite;

	[SerializeField]
	private List<SpriteRenderer> m_coffeeLevelSprites = new List<SpriteRenderer>();

	public int cupsOfCoffee => m_cupsOfCoffee;

	public bool brewing => m_brewing;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.CoffeeMachine;
	}

	public override void OnCheck()
	{
	}

	public override void Update()
	{
		base.Update();
		if (!m_brewing || !HasEnoughPower() || !IsEnabled())
		{
			return;
		}
		if (m_brewingTimer <= 0f)
		{
			m_prevCups = m_cupsOfCoffee;
			m_cupsOfCoffee++;
			UpdateCoffeeLevel();
			if (m_cupsOfCoffee >= m_cupsPerBrew)
			{
				m_brewing = false;
				((Renderer)m_brewingSprite).enabled = false;
				m_brewingSpriteSwitchTimer = 0f;
			}
			else
			{
				m_brewingTimer = m_brewingTime / (float)m_cupsPerBrew;
			}
		}
		m_brewingTimer -= Time.deltaTime;
		if (m_brewing && m_brewingSpriteSwitchTimer <= 0f)
		{
			if ((Object)(object)m_brewingSprite != (Object)null)
			{
				((Renderer)m_brewingSprite).enabled = !((Renderer)m_brewingSprite).enabled;
			}
			m_brewingSpriteSwitchTimer = m_brewingSpriteSwitchTime;
		}
		m_brewingSpriteSwitchTimer -= Time.deltaTime;
	}

	public void StartBrewing()
	{
		m_brewing = true;
		m_brewingTimer = m_brewingTime / (float)m_cupsPerBrew;
	}

	public bool DrinkCoffee()
	{
		if (m_cupsOfCoffee > 0)
		{
			m_prevCups = m_cupsOfCoffee;
			m_cupsOfCoffee--;
			UpdateCoffeeLevel();
			return true;
		}
		return false;
	}

	public void UpdateCoffeeLevel()
	{
		int num = 0;
		int num2 = 0;
		num = Mathf.FloorToInt((float)m_prevCups * ((float)m_coffeeLevelSprites.Count / (float)m_cupsPerBrew));
		num2 = Mathf.FloorToInt((float)m_cupsOfCoffee * ((float)m_coffeeLevelSprites.Count / (float)m_cupsPerBrew));
		if (num > 0)
		{
			((Renderer)m_coffeeLevelSprites[num - 1]).enabled = false;
		}
		if (num2 > 0)
		{
			((Renderer)m_coffeeLevelSprites[num2 - 1]).enabled = true;
		}
	}

	public override List<string> GetTooltipExtraInfo()
	{
		List<string> list = new List<string>();
		list = base.GetTooltipExtraInfo();
		list.Add(Localization.Get("ui.tooltip.coffee"));
		list.Add(m_cupsOfCoffee.ToString());
		list.Add(Localization.Get("ui.tooltip.coffeebrewing"));
		if (m_brewing)
		{
			list.Add(Localization.Get("text.ui.yes"));
		}
		else
		{
			list.Add(Localization.Get("text.ui.no"));
		}
		return list;
	}

	public override void OnDestroy()
	{
		base.OnDestroy();
	}

	protected override void SaveLoadObject(SaveData data)
	{
		base.SaveLoadObject(data);
		data.SaveLoad("cupsOfCoffee", ref m_cupsOfCoffee);
		data.SaveLoad("brewing", ref m_brewing);
		data.SaveLoad("brewingTimer", ref m_brewingTimer);
		data.SaveLoad("brewingSpriteSwitchTimer", ref m_brewingSpriteSwitchTimer);
		data.SaveLoad("prevCups", ref m_prevCups);
		if (data.isLoading)
		{
			UpdateCoffeeLevel();
		}
	}
}
