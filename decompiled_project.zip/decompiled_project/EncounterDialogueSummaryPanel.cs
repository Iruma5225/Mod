using System.Collections.Generic;
using UnityEngine;

public class EncounterDialogueSummaryPanel : BasePanel
{
	[SerializeField]
	private UILabel m_title;

	[SerializeField]
	private UIGrid member_grid;

	[SerializeField]
	private AudioClip open_sound;

	private EncounterManager.EncounterType summaryType;

	private List<EncounterSummaryCharacter> characterSummaries = new List<EncounterSummaryCharacter>();

	private void Awake()
	{
		EncounterSummaryCharacter[] componentsInChildren = ((Component)member_grid).GetComponentsInChildren<EncounterSummaryCharacter>();
		if (componentsInChildren != null && componentsInChildren.Length > 0)
		{
			characterSummaries.AddRange(componentsInChildren);
		}
	}

	public override void OnShow()
	{
		base.OnShow();
		BaseStats.StatType stat1_type = BaseStats.StatType.Max;
		if (summaryType == EncounterManager.EncounterType.Trade)
		{
			stat1_type = BaseStats.StatType.Charisma;
		}
		else if (summaryType == EncounterManager.EncounterType.Recruit)
		{
			stat1_type = BaseStats.StatType.Intelligence;
		}
		List<EncounterCharacter> list = new List<EncounterCharacter>(EncounterManager.Instance.GetPlayerCharacters());
		list.RemoveAll((EncounterCharacter x) => !x.isPlayerControlled);
		for (int num = 0; num < characterSummaries.Count; num++)
		{
			if (num >= list.Count)
			{
				((Component)characterSummaries[num]).gameObject.SetActive(false);
				continue;
			}
			characterSummaries[num].ShowCharacter(list[num], stat1_type);
			((Component)characterSummaries[num]).gameObject.SetActive(true);
		}
		if ((Object)(object)member_grid != (Object)null)
		{
			member_grid.Reposition();
		}
		if ((Object)(object)m_title != (Object)null)
		{
			if (summaryType == EncounterManager.EncounterType.Trade)
			{
				m_title.text = Localization.Get("Text.UI.EncounterSummaryHeading.Trade");
			}
			else if (summaryType == EncounterManager.EncounterType.Recruit)
			{
				m_title.text = Localization.Get("Text.UI.EncounterSummaryHeading.Recruit");
			}
		}
		AudioManager.Instance.PlayUI(open_sound);
	}

	public void SetEncounterType(EncounterManager.EncounterType type)
	{
		summaryType = type;
	}

	public override void OnCancel()
	{
		base.OnCancel();
		UIPanelManager.Instance().PopPanel(this);
		EncounterManager.Instance.OnSummaryClosed();
	}

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}
}
