using UnityEngine;

public class ObjectiveTarget : MonoBehaviour
{
	[SerializeField]
	private SpriteRenderer arrowSprite;

	[SerializeField]
	private SpriteAlphaPulse arrowPulse;

	private Camera mainCamera;

	private Camera uiCamera;

	private Transform m_target;

	private BasicCamera gameCamera;

	private float normalCameraScale;

	private bool m_updateArrow;

	private void Awake()
	{
		mainCamera = Camera.main;
		uiCamera = UICamera.mainCamera;
		if ((Object)(object)mainCamera != (Object)null)
		{
			gameCamera = ((Component)mainCamera).GetComponent<BasicCamera>();
		}
		if ((Object)(object)gameCamera != (Object)null)
		{
			normalCameraScale = gameCamera.preZoomSize;
		}
		UpdateArrow();
	}

	public void SetTarget(Transform target)
	{
		m_target = target;
	}

	public void UpdateArrow()
	{
		m_updateArrow = true;
	}

	public void LateUpdate()
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		if (!m_updateArrow)
		{
			return;
		}
		m_updateArrow = false;
		if ((Object)(object)m_target != (Object)null)
		{
			Vector3 val = mainCamera.WorldToViewportPoint(m_target.position);
			bool flag = val.x >= 0.15f && val.x <= 0.85f && val.y >= 0.15f && val.y <= 0.85f;
			if (gameCamera.isZoomed)
			{
				flag = val.x >= 0f && val.x <= 1f && val.y >= 0f && val.y <= 1f;
			}
			if (flag)
			{
				ShowArrow(show: true);
				((Component)this).transform.position = uiCamera.ViewportToWorldPoint(val);
				((Component)this).transform.localScale = Vector3.one * (normalCameraScale / mainCamera.orthographicSize);
			}
			else
			{
				ShowArrow(show: false);
			}
		}
	}

	private void ShowArrow(bool show)
	{
		if ((Object)(object)arrowSprite != (Object)null)
		{
			((Renderer)arrowSprite).enabled = show;
		}
		if ((Object)(object)arrowPulse != (Object)null)
		{
			((Behaviour)arrowPulse).enabled = show;
		}
	}
}
