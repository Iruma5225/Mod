using UnityEngine;

public class Int_TakeRecycling : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "take_recycling";
	}

	public override bool IsPlayerSelectable()
	{
		if (!base.IsPlayerSelectable())
		{
			return false;
		}
		Obj_RecyclingPlant obj_RecyclingPlant = null;
		if ((Object)(object)obj != (Object)null)
		{
			obj_RecyclingPlant = obj as Obj_RecyclingPlant;
		}
		if ((Object)(object)obj_RecyclingPlant != (Object)null && obj_RecyclingPlant.outputReady)
		{
			return true;
		}
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		if ((Object)(object)UI_PanelContainer.Instance.RecycleOutputPanel != (Object)null)
		{
			UI_PanelContainer.Instance.RecycleOutputPanel.SetRecyclingPlant(obj as Obj_RecyclingPlant);
			UIPanelManager.Instance().PushPanel(UI_PanelContainer.Instance.RecycleOutputPanel);
			return true;
		}
		return false;
	}
}
