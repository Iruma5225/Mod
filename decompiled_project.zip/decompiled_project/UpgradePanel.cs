using System.Collections.Generic;
using UnityEngine;

public class UpgradePanel : BasePanel
{
	[SerializeField]
	private UILabel m_headerLabel;

	[SerializeField]
	private GameObject m_descriptionBoxPC;

	[SerializeField]
	private UILabel m_upgradeNameLabelPC;

	[SerializeField]
	private UILabel m_upgradeDescriptionLabelPC;

	[SerializeField]
	private GameObject m_descriptionBoxConsole;

	[SerializeField]
	private UILabel m_upgradeNameLabelConsole;

	[SerializeField]
	private UILabel m_upgradeDescriptionLabelConsole;

	[SerializeField]
	private ItemButtonBase[] m_requiredItems = new ItemButtonBase[5];

	[SerializeField]
	private UpgradeGrid[] m_upgradeGrids = new UpgradeGrid[0];

	[SerializeField]
	private UIButton m_craftButton;

	[SerializeField]
	private LegendContainer m_legend;

	private UpgradeGrid m_selectedGrid;

	private int m_selectedLevel = -1;

	private int m_selectedSlot = -1;

	private bool m_upgradingAvailable;

	private Obj_Base obj_base;

	private UpgradeObject obj_upgrade;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public void SetUpgradeObject(Obj_Base obj)
	{
		obj_base = obj;
		if ((Object)(object)obj_base != (Object)null)
		{
			obj_upgrade = ((Component)obj_base).GetComponent<UpgradeObject>();
		}
		else
		{
			obj_base = null;
		}
	}

	public override void OnShow()
	{
		base.OnShow();
		m_upgradingAvailable = false;
		for (int i = 0; i < m_upgradeGrids.Length; i++)
		{
			m_upgradeGrids[i].Initialize(OnUpgradeSelected, OnUpgradeDeselected, OnUpgradeClicked);
		}
		UpdateGrids();
		UpdateSelection();
		m_headerLabel.text = Localization.Get("Text.UI.Upgrade.Header").Replace("%obj_name%", obj_base.GetName());
		UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.UpgradePanel);
	}

	public override void OnSelect()
	{
		base.OnSelect();
		CraftSelectedUpgrade();
	}

	public override void OnCancel()
	{
		base.OnCancel();
		if ((Object)(object)UIPanelManager.Instance() != (Object)null)
		{
			UIPanelManager.Instance().PopPanel(this);
		}
	}

	private void UpdateGrids()
	{
		for (int i = 0; i < m_upgradeGrids.Length; i++)
		{
			m_upgradeGrids[i].ClearUpgrades();
		}
		if ((Object)(object)obj_upgrade == (Object)null)
		{
			return;
		}
		List<UpgradeObject.PathEnum> paths = obj_upgrade.GetPaths();
		List<UpgradeGrid> list = new List<UpgradeGrid>(m_upgradeGrids);
		List<UpgradeGrid> list2 = new List<UpgradeGrid>();
		for (int j = 0; j < paths.Count; j++)
		{
			if (list.Count <= 0)
			{
				break;
			}
			int num = -1;
			for (int k = 0; k < list.Count; k++)
			{
				if (list[k].IsPathAllowed(paths[j]))
				{
					num = k;
					break;
				}
			}
			if (num >= 0)
			{
				UpgradeGrid upgradeGrid = list[num];
				UpgradeObject.UpgradePath pathForType = obj_upgrade.GetPathForType(paths[j]);
				((Component)upgradeGrid).gameObject.SetActive(true);
				upgradeGrid.SetPath(pathForType);
				list2.Add(upgradeGrid);
				list.RemoveAt(num);
			}
		}
		for (int l = 0; l < list.Count; l++)
		{
			((Component)list[l]).gameObject.SetActive(false);
		}
		if (list2.Count > 0)
		{
			list2[0].SelectFirstButton();
		}
	}

	private void UpdateSelection()
	{
		if ((Object)(object)m_selectedGrid != (Object)null && m_selectedLevel > 0 && m_selectedSlot > -1 && m_selectedSlot < m_selectedGrid.numSlots)
		{
			bool flag = true;
			UpgradeObject.LevelInfo levelInfo = obj_upgrade.GetLevelInfo(m_selectedGrid.path_type, m_selectedLevel);
			if (levelInfo == null)
			{
				return;
			}
			List<CraftingManager.Recipe.Ingredient> items = levelInfo.items;
			for (int i = 0; i < m_requiredItems.Length; i++)
			{
				if (!((Object)(object)m_requiredItems[i] == (Object)null))
				{
					if (i < items.Count && (Object)(object)InventoryManager.Instance != (Object)null)
					{
						ItemManager.ItemType item = items[i].Item;
						int numItemsOfType = InventoryManager.Instance.GetNumItemsOfType(item);
						int quantity = items[i].Quantity;
						m_requiredItems[i].SetItem(item, numItemsOfType, quantity);
						flag = flag && numItemsOfType >= quantity;
					}
					else
					{
						m_requiredItems[i].SetItem(ItemManager.ItemType.Undefined, 0, 0);
					}
				}
			}
			bool flag2 = false;
			if (m_selectedLevel == obj_upgrade.GetUpgradeLevel(m_selectedGrid.path_type) + 1)
			{
				flag2 = true;
			}
			m_upgradingAvailable = flag && flag2;
			UpdateLabels(levelInfo);
		}
		else
		{
			for (int j = 0; j < m_requiredItems.Length; j++)
			{
				m_requiredItems[j].SetItem(ItemManager.ItemType.Undefined, 0, 0);
			}
			m_upgradingAvailable = false;
			UpdateLabels(null);
		}
		if ((Object)(object)m_craftButton != (Object)null)
		{
			m_craftButton.isEnabled = m_upgradingAvailable;
		}
		if ((Object)(object)m_legend != (Object)null)
		{
			m_legend.SetButtonEnabled(LegendContainer.ButtonEnum.AButton, m_upgradingAvailable);
		}
	}

	private void UpdateLabels(UpgradeObject.LevelInfo info)
	{
		string text = string.Empty;
		string text2 = string.Empty;
		if (info != null && (Object)(object)ItemManager.Instance != (Object)null && (Object)(object)InventoryManager.Instance != (Object)null)
		{
			string name = info.name;
			if (name.Length > 0)
			{
				string text3 = Localization.Get(name);
				if (text3 != name)
				{
					text = text3;
				}
			}
			name = info.description;
			if (name.Length > 0)
			{
				string text4 = Localization.Get(name);
				if (text4 != name)
				{
					text2 = text4;
				}
			}
		}
		if ((Object)(object)ItemHelpButton.instance != (Object)null && info != null)
		{
			ItemHelpButton.instance.EnableButton();
		}
		else if ((Object)(object)ItemHelpButton.instance != (Object)null)
		{
			ItemHelpButton.instance.DisableButton();
		}
		if ((Object)(object)m_upgradeNameLabelPC != (Object)null)
		{
			m_upgradeNameLabelPC.text = text;
		}
		if ((Object)(object)m_upgradeDescriptionLabelPC != (Object)null)
		{
			m_upgradeDescriptionLabelPC.text = text2;
		}
		if ((Object)(object)m_upgradeNameLabelConsole != (Object)null)
		{
			m_upgradeNameLabelConsole.text = text;
		}
		if ((Object)(object)m_upgradeDescriptionLabelConsole != (Object)null)
		{
			m_upgradeDescriptionLabelConsole.text = text2;
		}
		helpName = text;
		helpDescription = text2;
	}

	public void CraftSelectedUpgrade()
	{
		FamilyMember familyMember = null;
		if ((Object)(object)InteractionManager.Instance != (Object)null)
		{
			familyMember = InteractionManager.Instance.GetSelectedFamilyMember();
		}
		if ((Object)(object)familyMember == (Object)null || (Object)(object)obj_upgrade == (Object)null)
		{
			m_upgradingAvailable = false;
		}
		if ((Object)(object)m_selectedGrid == (Object)null || m_selectedLevel < 1 || m_selectedSlot < 0 || m_selectedSlot >= m_selectedGrid.numSlots)
		{
			m_upgradingAvailable = false;
		}
		if (m_upgradingAvailable)
		{
			if (obj_base.IsBeingUpgraded)
			{
				return;
			}
			CraftingManager.Recipe recipe = obj_upgrade.BuildRecipeForUpgrade(m_selectedGrid.path_type, m_selectedLevel);
			if (recipe == null)
			{
				m_upgradingAvailable = false;
				return;
			}
			if (!CraftingManager.CanCraftRecipe(recipe))
			{
				m_upgradingAvailable = false;
				return;
			}
			if (CraftingManager.StartCraft(recipe, familyMember, obj_base))
			{
				UIPanelManager.Instance().PopPanel(this);
			}
		}
		UpdateSelection();
	}

	private void OnUpgradeSelected(UpgradeGrid grid, int level, int slotIndex)
	{
		m_selectedGrid = grid;
		m_selectedLevel = level;
		m_selectedSlot = slotIndex;
		UpdateSelection();
	}

	private void OnUpgradeDeselected(UpgradeGrid grid)
	{
		if ((Object)(object)m_selectedGrid == (Object)(object)grid)
		{
			m_selectedGrid = null;
			m_selectedLevel = -1;
			m_selectedSlot = -1;
		}
	}

	public void OnUpgradeClicked(UpgradeGrid grid, int level, int slotIndex, bool rightClick)
	{
		if (!rightClick)
		{
			OnSelect();
		}
	}

	public void ShowItemDescriptionPanel()
	{
		ItemHelpPanel.CreateItemHelpPanel(null, helpName, helpQuantity, helpDescription);
	}
}
