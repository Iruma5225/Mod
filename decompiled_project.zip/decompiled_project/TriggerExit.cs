using System.Collections.Generic;
using UnityEngine;

public class TriggerExit : MonoBehaviour
{
	private List<ITriggerDisabled2D> m_CollidedWith = new List<ITriggerDisabled2D>();

	private Collider2D m_collider;

	private TriggerExit[] m_child_scripts;

	private void Awake()
	{
		m_collider = ((Component)this).GetComponent<Collider2D>();
		m_child_scripts = ((Component)this).GetComponentsInChildren<TriggerExit>();
	}

	private void OnTriggerEnter2D(Collider2D col)
	{
		ITriggerDisabled2D[] components = ((Component)col).GetComponents<ITriggerDisabled2D>();
		for (int i = 0; i < components.Length; i++)
		{
			m_CollidedWith.Add(components[i]);
		}
	}

	private void OnTriggerExit2D(Collider2D col)
	{
		ITriggerDisabled2D[] components = ((Component)col).GetComponents<ITriggerDisabled2D>();
		for (int i = 0; i < components.Length; i++)
		{
			m_CollidedWith.Remove(components[i]);
		}
	}

	public void ForceTriggerExit()
	{
		if (m_child_scripts != null && m_child_scripts.Length > 0)
		{
			for (int i = 0; i < m_child_scripts.Length; i++)
			{
				if (!((Object)(object)m_child_scripts[i] == (Object)(object)this))
				{
					m_child_scripts[i].ForceTriggerExit();
				}
			}
		}
		if ((Object)(object)m_collider != (Object)null)
		{
			for (int j = 0; j < m_CollidedWith.Count; j++)
			{
				m_CollidedWith[j].OnTriggerDisabled2D(m_collider);
			}
			m_CollidedWith.Clear();
		}
	}

	private void OnDisable()
	{
		ForceTriggerExit();
	}
}
