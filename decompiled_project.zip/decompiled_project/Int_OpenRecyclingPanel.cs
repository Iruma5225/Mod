using UnityEngine;

public class Int_OpenRecyclingPanel : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "open_recycling_panel";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		if (!base.IsPlayerSelectable())
		{
			return false;
		}
		Obj_RecyclingPlant obj_RecyclingPlant = obj as Obj_RecyclingPlant;
		if ((Object)(object)obj_RecyclingPlant != (Object)null && !obj_RecyclingPlant.inUse && !obj_RecyclingPlant.outputReady)
		{
			return true;
		}
		return false;
	}

	public override bool IsPlayerSelectableWithoutValidMember()
	{
		return IsPlayerSelectable();
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		if ((Object)(object)UI_PanelContainer.Instance.RecyclePanel != (Object)null)
		{
			UI_PanelContainer.Instance.RecyclePanel.SetRecyclingPlant(obj as Obj_RecyclingPlant);
			UIPanelManager.Instance().PushPanel(UI_PanelContainer.Instance.RecyclePanel);
			return true;
		}
		return false;
	}
}
