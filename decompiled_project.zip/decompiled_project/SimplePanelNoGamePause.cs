using UnityEngine;

public class SimplePanelNoGamePause : BasePanel
{
	public AudioClip m_OpenSound;

	public AudioClip m_CloseSound;

	public GameObject m_focus_button;

	public bool m_closeOnCancelButton = true;

	public override void OnCancel()
	{
		base.OnCancel();
		if (m_closeOnCancelButton)
		{
			UIPanelManager.Instance().PopPanel(this);
		}
	}

	public override void OnShow()
	{
		if ((Object)(object)m_OpenSound != (Object)null)
		{
			UISound.instance.Play(m_OpenSound);
		}
		if ((Object)(object)m_focus_button != (Object)null)
		{
			UICamera.selectedObject = m_focus_button;
		}
		base.OnShow();
	}

	public override void OnClose()
	{
		if ((Object)(object)m_CloseSound != (Object)null)
		{
			UISound.instance.Play(m_CloseSound);
		}
		base.OnClose();
	}

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool DestroyOnClose()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return true;
	}
}
