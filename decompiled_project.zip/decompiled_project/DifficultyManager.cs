using System.Collections.Generic;
using UnityEngine;

public class DifficultyManager : BaseManagerNoUpdate, ISaveable
{
	[SerializeField]
	[Range(0f, 3f)]
	[Header("Rain Difficulty Settings")]
	private static int m_rainChanceSetting;

	[SerializeField]
	private List<int> m_rainMaxDaysDifficultySettings = new List<int>();

	[SerializeField]
	private List<int> m_rainMinDaysDifficultySettings = new List<int>();

	[SerializeField]
	private List<int> m_rainBiasDifficultySettings = new List<int>();

	[Header("Map Resources Difficulty Settings")]
	[Range(0f, 3f)]
	[SerializeField]
	private static int m_mapResourcesSetting;

	[Range(0f, 1.5f)]
	[SerializeField]
	private List<float> m_regionItemsModifierPerDifficulty = new List<float>();

	[SerializeField]
	[Range(0f, 1f)]
	private List<float> m_cumulativeRestockModifiersPerDifficulty = new List<float>();

	[SerializeField]
	[Header("Breach Frequency Difficulty Settings")]
	[Range(0f, 3f)]
	private static int m_breachFrequencySetting;

	[SerializeField]
	[Range(0f, 2f)]
	private List<float> m_breachIntervalModifiersPerDifficulty = new List<float>();

	[Range(0f, 3f)]
	[Header("Faction Density Difficulty Settings")]
	[SerializeField]
	private static int m_factionDensitySetting;

	[SerializeField]
	private List<int> m_factionSpawnDayReductionPerDifficulty = new List<int>();

	[SerializeField]
	private List<int> m_factionZoneIncreasePerDifficulty = new List<int>();

	[Range(0f, 3f)]
	[SerializeField]
	[Header("Populace Mood Difficulty Settings")]
	private static int m_populaceMoodSetting;

	[Range(0.5f, 2f)]
	[SerializeField]
	private List<float> m_intimidateChanceModifiersPerDifficulty = new List<float>();

	[Range(0.1f, 1.5f)]
	[SerializeField]
	private List<float> m_tradeRecruitChanceModifiersPerDifficulty = new List<float>();

	[SerializeField]
	[Header("Fog of War Difficulty Settings")]
	private static bool m_fogOfWarSetting;

	[SerializeField]
	private List<float> m_fogApertureScaleModifiersPerMapSize = new List<float>();

	[Range(0f, 2f)]
	[SerializeField]
	[Header("Map Size Difficulty Settings")]
	private static int m_mapSizeSetting;

	[Range(1f, 2f)]
	[SerializeField]
	private List<float> m_mapSizeModifierPerDifficulty = new List<float>();

	[SerializeField]
	[Range(0.1f, 1f)]
	private List<float> m_worldUnitsModifierPerDifficulty = new List<float>();

	[Range(0f, 2f)]
	[SerializeField]
	private List<float> m_cameraZoomMaxModifierPerDifficulty = new List<float>();

	[SerializeField]
	[Range(0.1f, 2f)]
	private List<float> m_cameraZoomMinModifierPerDifficulty = new List<float>();

	[SerializeField]
	private List<Vector3> m_mapPartySymbolScale = new List<Vector3>();

	[Range(0.1f, 1f)]
	[SerializeField]
	private List<float> m_mapCursorSpeedModifierPerDifficulty = new List<float>();

	private static int m_chosenRain;

	private static int m_chosenResources;

	private static int m_chosenBreach;

	private static int m_chosenFaction;

	private static int m_chosenMood;

	private static int m_chosenMap;

	private static bool m_chosenFog;

	private bool m_initialised;

	private static DifficultyManager m_theInstance;

	public static int RainChanceSetting => m_rainChanceSetting;

	public static int MapResourcesSetting => m_mapResourcesSetting;

	public static int BreachFrequencySetting => m_breachFrequencySetting;

	public static int FactionDensitySetting => m_factionDensitySetting;

	public static int PopulaceMoodSetting => m_populaceMoodSetting;

	public static bool FogOfWarSetting => m_fogOfWarSetting;

	public static int MapSizeSetting => m_mapSizeSetting;

	public static DifficultyManager instance => m_theInstance;

	private void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
		}
		else
		{
			Debug.Log((object)"Duplicate DifficultyMan created!");
		}
		m_rainChanceSetting = m_chosenRain;
		m_mapResourcesSetting = m_chosenResources;
		m_breachFrequencySetting = m_chosenBreach;
		m_factionDensitySetting = m_chosenFaction;
		m_populaceMoodSetting = m_chosenMood;
		m_mapSizeSetting = m_chosenMap;
		m_fogOfWarSetting = m_chosenFog;
		m_initialised = true;
	}

	public override void StartManager()
	{
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
	}

	public float GetCumulativeRestockModifier()
	{
		if (m_cumulativeRestockModifiersPerDifficulty.Count > 0 && m_mapResourcesSetting < m_cumulativeRestockModifiersPerDifficulty.Count)
		{
			return m_cumulativeRestockModifiersPerDifficulty[m_mapResourcesSetting];
		}
		return 0.05f;
	}

	public float GetRegionItemsModifier()
	{
		if (m_regionItemsModifierPerDifficulty.Count > 0 && m_mapResourcesSetting < m_regionItemsModifierPerDifficulty.Count)
		{
			return m_regionItemsModifierPerDifficulty[m_mapResourcesSetting];
		}
		return 1f;
	}

	public float GetBreachIntervalModifier()
	{
		if (m_breachIntervalModifiersPerDifficulty.Count > 0 && m_breachFrequencySetting < m_breachIntervalModifiersPerDifficulty.Count)
		{
			return m_breachIntervalModifiersPerDifficulty[m_breachFrequencySetting];
		}
		return 1f;
	}

	public int GetRainMaxDays()
	{
		if (m_rainMaxDaysDifficultySettings.Count > 0 && m_rainChanceSetting < m_rainMaxDaysDifficultySettings.Count)
		{
			return m_rainMaxDaysDifficultySettings[m_rainChanceSetting];
		}
		return 4;
	}

	public int GetRainMinDays()
	{
		if (m_rainMinDaysDifficultySettings.Count > 0 && m_rainChanceSetting < m_rainMinDaysDifficultySettings.Count)
		{
			return m_rainMinDaysDifficultySettings[m_rainChanceSetting];
		}
		return 0;
	}

	public int GetRainBias()
	{
		if (m_rainBiasDifficultySettings.Count > 0 && m_rainChanceSetting < m_rainBiasDifficultySettings.Count)
		{
			return m_rainBiasDifficultySettings[m_rainChanceSetting];
		}
		return 5;
	}

	public int GetFactionSpawnDayReduction()
	{
		if (m_factionSpawnDayReductionPerDifficulty.Count > 0 && m_factionDensitySetting < m_factionSpawnDayReductionPerDifficulty.Count)
		{
			return m_factionSpawnDayReductionPerDifficulty[m_factionDensitySetting];
		}
		return 0;
	}

	public int GetFactionZoneIncrease()
	{
		if (m_factionZoneIncreasePerDifficulty.Count > 0 && m_factionDensitySetting < m_factionZoneIncreasePerDifficulty.Count)
		{
			return m_factionZoneIncreasePerDifficulty[m_factionDensitySetting];
		}
		return 0;
	}

	public float GetIntimidateChanceModifier()
	{
		if (m_intimidateChanceModifiersPerDifficulty.Count > 0 && m_populaceMoodSetting < m_intimidateChanceModifiersPerDifficulty.Count)
		{
			return m_intimidateChanceModifiersPerDifficulty[m_populaceMoodSetting];
		}
		return 1f;
	}

	public float GetTradeRecruitChanceModifier()
	{
		if (m_tradeRecruitChanceModifiersPerDifficulty.Count > 0 && m_populaceMoodSetting < m_tradeRecruitChanceModifiersPerDifficulty.Count)
		{
			return m_tradeRecruitChanceModifiersPerDifficulty[m_populaceMoodSetting];
		}
		return 1f;
	}

	public float GetMapSizeModifier()
	{
		if (m_mapSizeModifierPerDifficulty.Count > 0 && m_mapSizeSetting < m_mapSizeModifierPerDifficulty.Count)
		{
			return m_mapSizeModifierPerDifficulty[m_mapSizeSetting];
		}
		return 1f;
	}

	public float GetWorldUnitsModifier()
	{
		if (m_worldUnitsModifierPerDifficulty.Count > 0 && m_mapSizeSetting < m_worldUnitsModifierPerDifficulty.Count)
		{
			return m_worldUnitsModifierPerDifficulty[m_mapSizeSetting];
		}
		return 1f;
	}

	public float GetCameraMinModifier()
	{
		if (m_cameraZoomMinModifierPerDifficulty.Count > 0 && m_mapSizeSetting < m_cameraZoomMinModifierPerDifficulty.Count)
		{
			return m_cameraZoomMinModifierPerDifficulty[m_mapSizeSetting];
		}
		return 1f;
	}

	public float GetCameraMaxModifier()
	{
		if (m_cameraZoomMaxModifierPerDifficulty.Count > 0 && m_mapSizeSetting < m_cameraZoomMaxModifierPerDifficulty.Count)
		{
			return m_cameraZoomMaxModifierPerDifficulty[m_mapSizeSetting];
		}
		return 1f;
	}

	public float GetMapCursorModifier()
	{
		if (m_mapCursorSpeedModifierPerDifficulty.Count > 0 && m_mapSizeSetting < m_mapCursorSpeedModifierPerDifficulty.Count)
		{
			return m_mapCursorSpeedModifierPerDifficulty[m_mapSizeSetting];
		}
		return 1f;
	}

	public Vector3 GetPartyMapSymbolScale()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		if (m_mapPartySymbolScale.Count > 0 && m_mapSizeSetting < m_mapPartySymbolScale.Count)
		{
			return m_mapPartySymbolScale[m_mapSizeSetting];
		}
		return Vector3.one;
	}

	public float GetFogApertureScaleModifier()
	{
		if (m_fogApertureScaleModifiersPerMapSize.Count > 0 && m_mapSizeSetting < m_fogApertureScaleModifiersPerMapSize.Count)
		{
			return m_fogApertureScaleModifiersPerMapSize[m_mapSizeSetting];
		}
		return 3f;
	}

	public static void StoreMenuDifficultySettings(int rain, int resources, int breach, int faction, int mood, int map, bool fog)
	{
		m_chosenRain = rain;
		m_chosenResources = resources;
		m_chosenBreach = breach;
		m_chosenFaction = faction;
		m_chosenMood = mood;
		m_chosenMap = map;
		m_chosenFog = fog;
	}

	public static int GetDifficultySetting()
	{
		if (m_rainChanceSetting == 0 && m_mapResourcesSetting == 0 && m_breachFrequencySetting == 0 && m_factionDensitySetting == 0 && m_populaceMoodSetting == 0 && !m_fogOfWarSetting && m_mapSizeSetting == 0)
		{
			return 0;
		}
		if (m_rainChanceSetting == 1 && m_mapResourcesSetting == 1 && m_breachFrequencySetting == 1 && m_factionDensitySetting == 1 && m_populaceMoodSetting == 1 && !m_fogOfWarSetting && m_mapSizeSetting == 0)
		{
			return 1;
		}
		if (m_rainChanceSetting == 2 && m_mapResourcesSetting == 2 && m_breachFrequencySetting == 2 && m_factionDensitySetting == 2 && m_populaceMoodSetting == 2 && m_fogOfWarSetting && m_mapSizeSetting == 1)
		{
			return 2;
		}
		if (m_rainChanceSetting == 3 && m_mapResourcesSetting == 3 && m_breachFrequencySetting == 3 && m_factionDensitySetting == 3 && m_populaceMoodSetting == 3 && m_fogOfWarSetting && m_mapSizeSetting == 2)
		{
			return 3;
		}
		return 4;
	}

	public bool IsRelocationEnabled()
	{
		return true;
	}

	public bool IsReadyForLoad()
	{
		return m_initialised;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("DifficultyManager");
		data.SaveLoad("rainChance", ref m_rainChanceSetting);
		data.SaveLoad("mapResources", ref m_mapResourcesSetting);
		data.SaveLoad("breachFrequency", ref m_breachFrequencySetting);
		data.SaveLoad("factionDensity", ref m_factionDensitySetting);
		data.SaveLoad("populaceMood", ref m_populaceMoodSetting);
		data.SaveLoad("fogOfWar", ref m_fogOfWarSetting);
		data.SaveLoad("mapSize", ref m_mapSizeSetting);
		data.GroupEnd();
		return true;
	}
}
