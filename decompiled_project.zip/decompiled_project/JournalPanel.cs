using System.Collections.Generic;
using UnityEngine;

public class JournalPanel : BasePanel
{
	public AudioClip m_openSound;

	public AudioClip m_closeSound;

	public AudioClip m_newTabSound;

	[SerializeField]
	private List<GameObject> tabs = new List<GameObject>();

	[SerializeField]
	private List<UISprite> tab_sprites = new List<UISprite>();

	[SerializeField]
	private int tabs_max_depth = 5;

	private int current_tab_index;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override void OnShow()
	{
		base.OnShow();
		SetTab(current_tab_index);
		AudioManager.Instance.PlayUI(m_openSound);
	}

	public override void OnClose()
	{
		base.OnClose();
		AudioManager.Instance.PlayUI(m_closeSound);
	}

	public override void OnCancel()
	{
		UIPanelManager.Instance().PopPanel(this);
	}

	public void SetTab(int new_tab)
	{
		if (new_tab >= 0 && new_tab < tab_sprites.Count)
		{
			if ((Object)(object)m_newTabSound != (Object)null && new_tab != current_tab_index)
			{
				AudioManager.Instance.PlayUI(m_newTabSound);
			}
			current_tab_index = new_tab;
			for (int i = 0; i < tabs.Count; i++)
			{
				tabs[i].SetActive(i == current_tab_index);
			}
			int num = tabs_max_depth;
			SetTabSpriteDepth(current_tab_index, num);
			for (int num2 = current_tab_index - 1; num2 >= 0; num2--)
			{
				num -= 2;
				SetTabSpriteDepth(num2, num);
			}
			for (int j = current_tab_index + 1; j < tab_sprites.Count; j++)
			{
				num -= 2;
				SetTabSpriteDepth(j, num);
			}
		}
	}

	private void SetTabSpriteDepth(int index, int depth)
	{
		if (index >= 0 && index < tab_sprites.Count)
		{
			tab_sprites[index].depth = depth;
			UILabel componentInChildren = ((Component)tab_sprites[index]).GetComponentInChildren<UILabel>();
			if ((Object)(object)componentInChildren != (Object)null)
			{
				componentInChildren.depth = depth + 1;
			}
		}
	}

	public override void OnTabRight()
	{
		if (current_tab_index < tab_sprites.Count - 1)
		{
			SetTab(current_tab_index + 1);
		}
	}

	public override void OnTabLeft()
	{
		if (current_tab_index > 0)
		{
			SetTab(current_tab_index - 1);
		}
	}

	public void GoToJournalTab()
	{
		SetTab(0);
	}

	public void GoToQuestTab()
	{
		SetTab(1);
	}
}
