using UnityEngine;

[AddComponentMenu("Sheltered/Interaction/Check")]
public class Int_Check : Int_Base
{
	public AudioClip CheckSound;

	public AudioClip FinishedSound;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_Check";
	}

	public override string GetInteractionType()
	{
		return "check";
	}

	public void PlayCheckSound()
	{
		if ((Object)(object)CheckSound != (Object)null)
		{
			((Component)this).GetComponent<AudioSource>().PlayOneShot(CheckSound);
		}
	}

	public void PlayFinishedSound()
	{
		if ((Object)(object)FinishedSound != (Object)null)
		{
			((Component)this).GetComponent<AudioSource>().PlayOneShot(FinishedSound);
		}
	}
}
