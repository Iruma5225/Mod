public class Int_BuryCorpse : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_BuryCorpse";
	}

	public override string GetInteractionType()
	{
		return "bury_corpse";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}
}
