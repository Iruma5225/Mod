using UnityEngine;

public class TutorialStage_ExplainCommands : BaseTutorial
{
	[SerializeField]
	private float m_duration = 10f;

	private float m_endTime;

	public override TutorialManager.TutorialStage GetTutorialStage()
	{
		return TutorialManager.TutorialStage.ExplainCommands;
	}

	public override void OnEnterStage(bool showPanel)
	{
		base.OnEnterStage(showPanel);
		m_endTime = PausableTime.time + Mathf.Max(0f, m_duration);
	}

	public override bool IsStageComplete()
	{
		return PausableTime.time >= m_endTime;
	}
}
