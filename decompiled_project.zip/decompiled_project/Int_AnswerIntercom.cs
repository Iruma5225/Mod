using UnityEngine;

public class Int_AnswerIntercom : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "answer_intercom";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		if (base.IsPlayerSelectable() && (Object)(object)IntercomManager.Instance != (Object)null && IntercomManager.Instance.isNpcWaiting)
		{
			return true;
		}
		return false;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		if ((Object)(object)IntercomManager.Instance != (Object)null)
		{
			IntercomManager.Instance.AnswerIntercom();
			return true;
		}
		return false;
	}
}
