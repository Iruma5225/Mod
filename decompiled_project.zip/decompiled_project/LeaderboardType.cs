public enum LeaderboardType
{
	AllTime_DaysSurvived,
	AllTime_DaysSurvived_Hard,
	AllTime_DaysSurvived_Hardcore,
	Monthly_DaysSurvived,
	Monthly_DaysSurvived_Hard,
	Monthly_DaysSurvived_Hardcore
}
