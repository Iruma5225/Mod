using System;

[Serializable]
public class InterruptionState
{
	public Interruption_Poop poop = new Interruption_Poop();

	public Interruption_Vomit vomit = new Interruption_Vomit();

	public Interruption_Sleep sleep = new Interruption_Sleep();

	public void Initialize(FamilyMember member)
	{
		poop.Initialize(member);
		vomit.Initialize(member);
	}

	public void UpdateInterruptions()
	{
		poop.UpdateInterruption();
		vomit.UpdateInterruption();
	}

	public bool AreInterruptionsActive()
	{
		return poop.isActive || vomit.isActive || sleep.isActive;
	}

	public void SaveLoadInterruptions(SaveData data)
	{
		data.GroupStart("Interruptions");
		try
		{
			poop.SaveLoadInterruption(data);
			vomit.SaveLoadInterruption(data);
			sleep.SaveLoadInterruption(data);
		}
		catch (SaveData.MissingGroupException)
		{
		}
		data.GroupEnd();
	}
}
