using System;
using System.Collections.Generic;
using UnityEngine;

public class ActivityLog : BaseManager, ISaveable
{
	[Serializable]
	public class ActivityEntry
	{
		public string m_text = string.Empty;

		public Activity m_type;

		public ActivityEntry()
		{
			m_text = string.Empty;
			m_type = Activity.None;
		}

		public ActivityEntry(string text, Activity type)
		{
			m_text = text;
			m_type = type;
		}
	}

	public delegate void ActivityDelegate(string activityText, Activity activityType);

	public enum Activity
	{
		None,
		TestActivity,
		CharacterDeath,
		CharacterCatatonic,
		FixedObject,
		ObjectBroken,
		ContractIllness_Radiation,
		ContractIllness_Malnourishment,
		ContractIllness_FoodPoisoning,
		ContractIllness_Infection,
		CureIllness_Radiation,
		CureIllness_Malnourishment,
		CureIllness_FoodPoisoning,
		CureIllness_Infection,
		Weather_Rain,
		Weather_BlackRain,
		Weather_LightDust,
		Weather_MediumDust,
		Weather_HeavyDust,
		NpcBuzzedIntercom,
		IncomingRadioTransmission,
		CharacterStrengthTurnWeak,
		CharacterWeakTurnStrength,
		ContractIllness_Dehydration,
		CureIllness_Dehydration,
		CharacterLevelUp,
		CharacterMaxLevel,
		Object_CatastrophicFailure,
		StorageFull,
		WaterTankFull,
		PantryFull,
		PlantsReady,
		PlantsDead,
		CharacterDeath_Hunger,
		CharacterDeath_Thirst,
		CharacterDeath_Malnourishment,
		CharacterDeath_Radiation,
		CharacterDeath_Mercy,
		CharacterDeath_Weapon,
		CharacterDeath_Bleeding,
		CharacterDeath_Wasteland,
		CharacterDeath_Murder,
		CharacterDeath_Pet,
		CharacterLeft_Normal,
		CharacterLeft_Steal,
		CharacterLeft_Damage,
		CharacterLeft_Deupgrade,
		CharacterLeft_Defecate,
		CharacterDeath_Suffocation,
		LostCharacterReturn,
		LostCharactersReturn
	}

	public class ExtraInfoString
	{
		public string m_text = string.Empty;

		public bool m_isLocalizationKey;

		public ExtraInfoString(string text, bool isLocalizationKey)
		{
			m_text = text;
			m_isLocalizationKey = isLocalizationKey;
		}
	}

	[SerializeField]
	private int m_maxMessages = 12;

	[SerializeField]
	private float m_transformValidInterval = 20f;

	private List<ActivityEntry> m_entries = new List<ActivityEntry>();

	private Transform m_transform;

	private float m_validTransformUntil;

	private static ActivityLog m_instance;

	public int maxMessages => m_maxMessages;

	public int numMessages => m_entries.Count;

	public bool validTransform => (Object)(object)m_transform != (Object)null;

	public static ActivityLog Instance => m_instance;

	public event ActivityDelegate onNewActivity;

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
		}
	}

	public override void StartManager()
	{
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
	}

	public override void UpdateManager()
	{
		if (m_validTransformUntil > 0f && Time.time >= m_validTransformUntil)
		{
			m_validTransformUntil = 0f;
			m_transform = null;
		}
	}

	public void GoToActivity()
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		if (!(m_validTransformUntil > 0f))
		{
			return;
		}
		m_validTransformUntil = 0f;
		if ((Object)(object)Camera.main != (Object)null)
		{
			BasicCamera component = ((Component)Camera.main).GetComponent<BasicCamera>();
			if ((Object)(object)component != (Object)null && (Object)(object)m_transform != (Object)null)
			{
				component.SnapToPosition(Vector2.op_Implicit(m_transform.position));
			}
		}
		m_transform = null;
	}

	public void Add(Activity type, ExtraInfoString extra1 = null, ExtraInfoString extra2 = null)
	{
		string text = BuildLocalizedString(type, extra1, extra2);
		if (text.Length > 0)
		{
			m_entries.Add(new ActivityEntry(text, type));
			if (m_entries.Count > m_maxMessages)
			{
				m_entries.RemoveAt(0);
			}
			if (this.onNewActivity != null)
			{
				this.onNewActivity(text, type);
			}
		}
	}

	public void Add(Activity type, Transform transform, ExtraInfoString extra1 = null, ExtraInfoString extra2 = null)
	{
		if ((Object)(object)transform != (Object)null)
		{
			m_transform = transform;
			m_validTransformUntil = Time.time + m_transformValidInterval;
		}
		Add(type, extra1, extra2);
	}

	private string BuildLocalizedString(Activity type, ExtraInfoString extra1, ExtraInfoString extra2)
	{
		string empty = string.Empty;
		switch (type)
		{
		case Activity.TestActivity:
			empty = "Test Activity " + Random.Range(1, 101);
			break;
		case Activity.CharacterDeath:
			empty = Localization.Get("Activity.CharacterDied");
			break;
		case Activity.CharacterCatatonic:
			empty = Localization.Get("Activity.CharacterCatatonic");
			break;
		case Activity.ContractIllness_Radiation:
			empty = Localization.Get("Activity.ContractIllness.Radiation");
			break;
		case Activity.ContractIllness_Malnourishment:
			empty = Localization.Get("Activity.ContractIllness.Malnourishment");
			break;
		case Activity.ContractIllness_FoodPoisoning:
			empty = Localization.Get("Activity.ContractIllness.FoodPoisoning");
			break;
		case Activity.ContractIllness_Dehydration:
			empty = Localization.Get("Activity.ContractIllness.Dehydration");
			break;
		case Activity.CureIllness_Radiation:
			empty = Localization.Get("Activity.CuredIllness.Radiation");
			break;
		case Activity.CureIllness_Malnourishment:
			empty = Localization.Get("Activity.CuredIllness.Malnourishment");
			break;
		case Activity.CureIllness_FoodPoisoning:
			empty = Localization.Get("Activity.CuredIllness.FoodPoisoning");
			break;
		case Activity.CureIllness_Dehydration:
			empty = Localization.Get("Activity.CuredIllness.Dehydration");
			break;
		case Activity.FixedObject:
			empty = Localization.Get("Activity.ObjectFixed");
			break;
		case Activity.ObjectBroken:
			empty = Localization.Get("Activity.ObjectBroken");
			break;
		case Activity.Weather_Rain:
			empty = Localization.Get("Activity.Weather.Rain");
			break;
		case Activity.Weather_BlackRain:
			empty = Localization.Get("Activity.Weather.BlackRain");
			break;
		case Activity.Weather_LightDust:
			empty = Localization.Get("Activity.Weather.LightSand");
			break;
		case Activity.Weather_MediumDust:
			empty = Localization.Get("Activity.Weather.MediumSand");
			break;
		case Activity.Weather_HeavyDust:
			empty = Localization.Get("Activity.Weather.HeavySand");
			break;
		case Activity.NpcBuzzedIntercom:
			empty = Localization.Get("Activity.NpcBuzzedIntercom");
			break;
		case Activity.IncomingRadioTransmission:
			empty = Localization.Get("Activity.IncomingRadioTransmission");
			break;
		case Activity.PantryFull:
			empty = Localization.Get("Activity.PantryFull");
			break;
		case Activity.WaterTankFull:
			empty = Localization.Get("Activity.WaterTankFull");
			break;
		case Activity.StorageFull:
			empty = Localization.Get("Activity.StorageFull");
			break;
		case Activity.CharacterLevelUp:
			empty = Localization.Get("Activity.LevelUp");
			break;
		case Activity.CharacterMaxLevel:
			empty = Localization.Get("Activity.MaxLevel");
			break;
		case Activity.Object_CatastrophicFailure:
			empty = Localization.Get("Activity.ObjectCatastrophic");
			break;
		case Activity.CharacterStrengthTurnWeak:
			empty = Localization.Get("Activity.StrengthTurnWeak");
			break;
		case Activity.CharacterWeakTurnStrength:
			empty = Localization.Get("Activity.WeakTurnStrength");
			break;
		case Activity.PlantsDead:
			empty = Localization.Get("Activity.Planter.Wilted");
			break;
		case Activity.PlantsReady:
			empty = Localization.Get("Activity.Planter.ReadyToHarvest");
			break;
		case Activity.CharacterDeath_Hunger:
			empty = Localization.Get("Activity.CharacterDied.Hunger");
			break;
		case Activity.CharacterDeath_Thirst:
			empty = Localization.Get("Activity.CharacterDied.Thirst");
			break;
		case Activity.CharacterDeath_Malnourishment:
			empty = Localization.Get("Activity.CharacterDied.Malnourishment");
			break;
		case Activity.CharacterDeath_Radiation:
			empty = Localization.Get("Activity.CharacterDied.Radiation");
			break;
		case Activity.CharacterDeath_Mercy:
			empty = Localization.Get("Activity.CharacterDied.Mercy");
			break;
		case Activity.CharacterDeath_Weapon:
			empty = Localization.Get("Activity.CharacterDied.Weapon");
			break;
		case Activity.CharacterDeath_Bleeding:
			empty = Localization.Get("Activity.CharacterDied.Bleeding");
			break;
		case Activity.CharacterDeath_Wasteland:
			empty = Localization.Get("Activity.CharacterDied.Wasteland");
			break;
		case Activity.CharacterDeath_Murder:
			empty = Localization.Get("Activity.CharacterDied.Murder");
			break;
		case Activity.CharacterDeath_Pet:
			empty = Localization.Get("Activity.CharacterDied.Pet");
			break;
		case Activity.CharacterDeath_Suffocation:
			empty = Localization.Get("Activity.CharacterDied.Suffocation");
			break;
		case Activity.CharacterLeft_Normal:
			empty = Localization.Get("Activity.CharacterLeft.Normal");
			break;
		case Activity.CharacterLeft_Steal:
			empty = Localization.Get("Activity.CharacterLeft.Steal");
			break;
		case Activity.CharacterLeft_Damage:
			empty = Localization.Get("Activity.CharacterLeft.Damage");
			break;
		case Activity.CharacterLeft_Defecate:
			empty = Localization.Get("Activity.CharacterLeft.Defecate");
			break;
		case Activity.CharacterLeft_Deupgrade:
			empty = Localization.Get("Activity.CharacterLeft.Deupgrade");
			break;
		case Activity.LostCharacterReturn:
			empty = Localization.Get("Activity.LostCharacterReturn");
			break;
		case Activity.LostCharactersReturn:
			empty = Localization.Get("Activity.LostCharactersReturn");
			break;
		case Activity.None:
			return string.Empty;
		default:
			return string.Empty;
		}
		if (extra1 != null && !string.IsNullOrEmpty(extra1.m_text))
		{
			string text = ((!extra1.m_isLocalizationKey) ? extra1.m_text : Localization.Get(extra1.m_text));
			if (text.Length > 0)
			{
				empty = empty.Replace("$1$", text);
			}
		}
		if (extra2 != null && !string.IsNullOrEmpty(extra2.m_text))
		{
			string text2 = ((!extra2.m_isLocalizationKey) ? extra2.m_text : Localization.Get(extra2.m_text));
			if (text2.Length > 0)
			{
				empty = empty.Replace("$2$", text2);
			}
		}
		return empty;
	}

	public bool IsRelocationEnabled()
	{
		return false;
	}

	public bool IsReadyForLoad()
	{
		return (Object)(object)UI_InputListener.Instance != (Object)null;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("ActivityLog");
		try
		{
			data.SaveLoadList("entries", m_entries, delegate(int i)
			{
				ActivityEntry activityEntry = ((m_entries[i] == null) ? new ActivityEntry() : m_entries[i]);
				data.SaveLoad("text", ref activityEntry.m_text);
				int value2 = (int)activityEntry.m_type;
				data.SaveLoad("type", ref value2);
			}, delegate
			{
				ActivityEntry activityEntry = new ActivityEntry();
				if (activityEntry != null)
				{
					int value2 = 0;
					data.SaveLoad("text", ref activityEntry.m_text);
					data.SaveLoad("type", ref value2);
					activityEntry.m_type = (Activity)value2;
					if (activityEntry.m_type != Activity.None)
					{
						m_entries.Add(activityEntry);
					}
				}
			});
		}
		catch (SaveData.MissingGroupException)
		{
		}
		bool value = false;
		if ((Object)(object)UI_InputListener.Instance != (Object)null)
		{
			value = Object.op_Implicit((Object)(object)UI_PanelContainer.Instance.InfoPanelNotification);
		}
		data.SaveLoad("notification", ref value);
		if (!data.isLoading || !value || (Object)(object)UI_PanelContainer.Instance.InfoPanelNotification != (Object)null)
		{
		}
		data.GroupEnd();
		return true;
	}
}
