using System.Collections.Generic;
using UnityEngine;

[AddComponentMenu("NGUI/Interaction/Table")]
public class UITable : UIWidgetContainer
{
	public delegate void OnReposition();

	public enum Direction
	{
		Down,
		Up
	}

	public enum Sorting
	{
		None,
		Alphabetic,
		Horizontal,
		Vertical,
		Custom
	}

	public int columns;

	public Direction direction;

	public Sorting sorting;

	public bool hideInactive = true;

	public bool keepWithinPanel;

	public Vector2 padding = Vector2.zero;

	public OnReposition onReposition;

	protected UIPanel mPanel;

	protected bool mInitDone;

	protected bool mReposition;

	protected List<Transform> mChildren = new List<Transform>();

	[SerializeField]
	[HideInInspector]
	private bool sorted;

	public bool repositionNow
	{
		set
		{
			if (value)
			{
				mReposition = true;
				((Behaviour)this).enabled = true;
			}
		}
	}

	public List<Transform> children
	{
		get
		{
			if (mChildren.Count == 0)
			{
				Transform transform = ((Component)this).transform;
				mChildren.Clear();
				for (int i = 0; i < transform.childCount; i++)
				{
					Transform child = transform.GetChild(i);
					if (Object.op_Implicit((Object)(object)child) && Object.op_Implicit((Object)(object)((Component)child).gameObject) && (!hideInactive || NGUITools.GetActive(((Component)child).gameObject)))
					{
						mChildren.Add(child);
					}
				}
				if (sorting != Sorting.None || sorted)
				{
					if (sorting == Sorting.Alphabetic)
					{
						mChildren.Sort(UIGrid.SortByName);
					}
					else if (sorting == Sorting.Horizontal)
					{
						mChildren.Sort(UIGrid.SortHorizontal);
					}
					else if (sorting == Sorting.Vertical)
					{
						mChildren.Sort(UIGrid.SortVertical);
					}
					else
					{
						Sort(mChildren);
					}
				}
			}
			return mChildren;
		}
	}

	protected virtual void Sort(List<Transform> list)
	{
		list.Sort(UIGrid.SortByName);
	}

	protected void RepositionVariableSize(List<Transform> children)
	{
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_0387: Unknown result type (might be due to invalid IL or missing references)
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		float num2 = 0f;
		int num3 = ((columns <= 0) ? 1 : (children.Count / columns + 1));
		int num4 = ((columns <= 0) ? children.Count : columns);
		Bounds[,] array = new Bounds[num3, num4];
		Bounds[] array2 = (Bounds[])(object)new Bounds[num4];
		Bounds[] array3 = (Bounds[])(object)new Bounds[num3];
		int num5 = 0;
		int num6 = 0;
		int i = 0;
		for (int count = children.Count; i < count; i++)
		{
			Transform val = children[i];
			Bounds val2 = NGUIMath.CalculateRelativeWidgetBounds(val, !hideInactive);
			Vector3 localScale = val.localScale;
			((Bounds)(ref val2)).min = Vector3.Scale(((Bounds)(ref val2)).min, localScale);
			((Bounds)(ref val2)).max = Vector3.Scale(((Bounds)(ref val2)).max, localScale);
			array[num6, num5] = val2;
			((Bounds)(ref array2[num5])).Encapsulate(val2);
			((Bounds)(ref array3[num6])).Encapsulate(val2);
			if (++num5 >= columns && columns > 0)
			{
				num5 = 0;
				num6++;
			}
		}
		num5 = 0;
		num6 = 0;
		int j = 0;
		for (int count2 = children.Count; j < count2; j++)
		{
			Transform val3 = children[j];
			Bounds val4 = array[num6, num5];
			Bounds val5 = array2[num5];
			Bounds val6 = array3[num6];
			Vector3 localPosition = val3.localPosition;
			localPosition.x = num + ((Bounds)(ref val4)).extents.x - ((Bounds)(ref val4)).center.x;
			localPosition.x += ((Bounds)(ref val4)).min.x - ((Bounds)(ref val5)).min.x + padding.x;
			if (direction == Direction.Down)
			{
				localPosition.y = 0f - num2 - ((Bounds)(ref val4)).extents.y - ((Bounds)(ref val4)).center.y;
				localPosition.y += (((Bounds)(ref val4)).max.y - ((Bounds)(ref val4)).min.y - ((Bounds)(ref val6)).max.y + ((Bounds)(ref val6)).min.y) * 0.5f - padding.y;
			}
			else
			{
				localPosition.y = num2 + (((Bounds)(ref val4)).extents.y - ((Bounds)(ref val4)).center.y);
				localPosition.y -= (((Bounds)(ref val4)).max.y - ((Bounds)(ref val4)).min.y - ((Bounds)(ref val6)).max.y + ((Bounds)(ref val6)).min.y) * 0.5f - padding.y;
			}
			num += ((Bounds)(ref val5)).max.x - ((Bounds)(ref val5)).min.x + padding.x * 2f;
			val3.localPosition = localPosition;
			if (++num5 >= columns && columns > 0)
			{
				num5 = 0;
				num6++;
				num = 0f;
				num2 += ((Bounds)(ref val6)).size.y + padding.y * 2f;
			}
		}
	}

	[ContextMenu("Execute")]
	public virtual void Reposition()
	{
		if (Application.isPlaying && !mInitDone && NGUITools.GetActive((Behaviour)(object)this))
		{
			mReposition = true;
			return;
		}
		if (!mInitDone)
		{
			Init();
		}
		mReposition = false;
		Transform transform = ((Component)this).transform;
		mChildren.Clear();
		List<Transform> list = children;
		if (list.Count > 0)
		{
			RepositionVariableSize(list);
		}
		if (keepWithinPanel && (Object)(object)mPanel != (Object)null)
		{
			mPanel.ConstrainTargetToBounds(transform, immediate: true);
			UIScrollView component = ((Component)mPanel).GetComponent<UIScrollView>();
			if ((Object)(object)component != (Object)null)
			{
				component.UpdateScrollbars(recalculateBounds: true);
			}
		}
		if (onReposition != null)
		{
			onReposition();
		}
	}

	protected virtual void Start()
	{
		Init();
		Reposition();
		((Behaviour)this).enabled = false;
	}

	protected virtual void Init()
	{
		mInitDone = true;
		mPanel = NGUITools.FindInParents<UIPanel>(((Component)this).gameObject);
	}

	protected virtual void LateUpdate()
	{
		if (mReposition)
		{
			Reposition();
		}
		((Behaviour)this).enabled = false;
	}
}
