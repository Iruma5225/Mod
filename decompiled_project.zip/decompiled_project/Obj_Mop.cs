using UnityEngine;

public class Obj_Mop : Obj_Base
{
	[SerializeField]
	private Sprite mopSprite;

	[SerializeField]
	private Sprite noMopSprite;

	private SpriteRenderer spriteRenderer;

	private bool in_use;

	private bool has_mop = true;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.Mop;
	}

	public bool InUse()
	{
		return in_use;
	}

	public void SetInUse(bool use)
	{
		in_use = use;
	}

	public bool HasMop()
	{
		return has_mop;
	}

	public override void Awake()
	{
		base.Awake();
		spriteRenderer = ((Component)this).GetComponentInChildren<SpriteRenderer>();
		UpdateMop();
	}

	public bool TakeMop()
	{
		has_mop = false;
		UpdateMop();
		return true;
	}

	public bool ReplaceMop()
	{
		has_mop = true;
		UpdateMop();
		return true;
	}

	public void UpdateMop()
	{
		if (!((Object)(object)spriteRenderer == (Object)null))
		{
			if (!has_mop)
			{
				spriteRenderer.sprite = noMopSprite;
				base.selectable = false;
			}
			else
			{
				spriteRenderer.sprite = mopSprite;
				base.selectable = true;
			}
		}
	}
}
