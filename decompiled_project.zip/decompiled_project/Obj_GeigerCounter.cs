public class Obj_GeigerCounter : Obj_Base
{
	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.GeigerCounter;
	}
}
