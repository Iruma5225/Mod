using System.Collections.Generic;
using UnityEngine;

public class CityScapeCreator : MonoBehaviour
{
	public List<GameObject> CityscapePrefabs;

	public GameObject CranePrefab;

	public float maxSpacingValue;

	private void Start()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		float x = Random.Range(5f, 7.5f);
		CityscapePrefabs.Shuffle();
		Vector3 position = ((Component)this).transform.position;
		position.x = x;
		int num = Random.Range(3, CityscapePrefabs.Count + 1);
		if (CityscapePrefabs != null && CityscapePrefabs.Count > 0)
		{
			for (int i = 0; i < num; i++)
			{
				GameObject val = Object.Instantiate<GameObject>(CityscapePrefabs[i], position, Quaternion.identity);
				if ((Object)(object)val != (Object)null)
				{
					val.transform.parent = ((Component)this).transform;
				}
				position.x += Random.Range(1f, maxSpacingValue);
			}
		}
		int num2 = ((num % 2 == 0) ? (num / 2) : ((int)Mathf.Floor((float)num / 2f)));
		Vector3 position2 = ((Component)this).transform.position;
		position2.x = x;
		Vector3 localScale = default(Vector3);
		for (int j = 0; j < num2; j++)
		{
			int num3 = Random.Range(0, 2);
			if (!((Object)(object)CranePrefab != (Object)null))
			{
				continue;
			}
			GameObject val2 = Object.Instantiate<GameObject>(CranePrefab, position2, Quaternion.identity);
			if ((Object)(object)val2 != (Object)null)
			{
				val2.transform.parent = ((Component)this).transform;
				if (num3 == 1)
				{
					((Vector3)(ref localScale))._002Ector(-1f, 1f, 1f);
					val2.transform.localScale = localScale;
				}
			}
			position2.x += 1f + Random.Range(0f, maxSpacingValue);
		}
	}
}
