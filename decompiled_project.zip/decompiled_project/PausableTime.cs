using UnityEngine;

public class PausableTime : MonoBehaviour
{
	private static PausableTime m_instance;

	private static float m_time;

	private static float m_deltaTime;

	private static bool m_isPaused;

	public static float time => m_time;

	public static float deltaTime => m_deltaTime;

	public static bool isPause => m_isPaused;

	private void Awake()
	{
		if ((Object)(object)m_instance != (Object)null && (Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
			return;
		}
		m_instance = this;
		m_time = RealTime.time;
		m_deltaTime = 0f;
		m_isPaused = false;
		PauseManager.OnPause -= OnGamePaused;
		PauseManager.OnPause += OnGamePaused;
		PauseManager.OnResume -= OnGameResumed;
		PauseManager.OnResume += OnGameResumed;
	}

	private void Update()
	{
		if (!m_isPaused)
		{
			m_time += RealTime.deltaTime;
			m_deltaTime = RealTime.deltaTime;
		}
		else
		{
			m_deltaTime = 0f;
		}
	}

	private void OnGamePaused()
	{
		m_isPaused = true;
	}

	private void OnGameResumed(float timePaused)
	{
		m_isPaused = false;
	}
}
