using UnityEngine;

public class UI_SpeechBubble : MonoBehaviour
{
	private UI_Character ui_character;

	private UILabel label;

	private TweenAlpha tween;

	public void Awake()
	{
		if ((Object)(object)((Component)this).transform.parent != (Object)null)
		{
			ui_character = ((Component)((Component)this).transform.parent).GetComponent<UI_Character>();
			if ((Object)(object)ui_character == (Object)null && (Object)(object)((Component)this).transform.parent.parent != (Object)null)
			{
				ui_character = ((Component)((Component)this).transform.parent.parent).GetComponent<UI_Character>();
			}
		}
		if ((Object)(object)ui_character == (Object)null)
		{
			Object.Destroy((Object)(object)this);
		}
		label = ((Component)this).GetComponentInChildren<UILabel>();
		tween = ((Component)this).GetComponent<TweenAlpha>();
	}

	public void Start()
	{
		if ((Object)(object)ui_character != (Object)null && (Object)(object)ui_character.baseCharacter != (Object)null)
		{
			ui_character.baseCharacter.SetUISpeechBubble(this);
		}
		((Component)this).gameObject.SetActive(false);
	}

	public void ShowText(string text)
	{
		if ((Object)(object)label != (Object)null)
		{
			label.text = text;
		}
		((Component)this).gameObject.SetActive(true);
		if ((Object)(object)tween != (Object)null)
		{
			tween.PlayForward();
		}
	}

	public void OnTweenOver()
	{
		((Component)this).gameObject.SetActive(true);
		if ((Object)(object)tween != (Object)null)
		{
			tween.ResetToBeginning();
		}
	}

	public bool IsShowingText()
	{
		if ((Object)(object)tween != (Object)null)
		{
			return ((Behaviour)tween).isActiveAndEnabled;
		}
		return false;
	}
}
