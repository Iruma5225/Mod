using UnityEngine;

public class Int_OpenStoragePanel : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return string.Empty;
	}

	public override string GetInteractionType()
	{
		return "open_storage_panel";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		return !obj.isBurningOrBurntOut && base.InteractionEnabled;
	}

	public override bool IsPlayerSelectableWithoutValidMember()
	{
		return IsPlayerSelectable();
	}

	public override bool IsAvailable()
	{
		return true;
	}

	public override bool OnInteractionSelected(FamilyMember member)
	{
		if ((Object)(object)UI_PanelContainer.Instance.StoragePanel != (Object)null)
		{
			UIPanelManager.Instance().PushPanel(UI_PanelContainer.Instance.StoragePanel);
			return true;
		}
		return false;
	}
}
