using UnityEngine;

public class Job_Clean : Job
{
	private const float clean_object_duration = 3f;

	private float clean_object_time;

	private Litter target_litter;

	private Obj_Mop mop;

	public Job_Clean()
	{
		if (!((Object)(object)SaveManager.instance == (Object)null) && SaveManager.instance.isLoading)
		{
		}
	}

	public Job_Clean(FamilyMember target_character, Obj_Mop bucket)
		: base("clean_job", ((Component)bucket).transform.position, target_character, bucket)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		mop = bucket;
	}

	public override string GetJobType()
	{
		return "Job_Clean";
	}

	public override void Activate()
	{
		base.Activate();
	}

	public override bool BeginJob()
	{
		if ((Object)(object)obj != (Object)null && obj.GetObjectType() == ObjectManager.ObjectType.Mop)
		{
			type = "take_mop";
			if (obj.BeginInteraction(character, type))
			{
				state = JobState.Started;
				return true;
			}
			Cancel(forced: true);
			return false;
		}
		character.TriggerAnim("Mop");
		character.PlaySound(BaseCharacter.AnimSounds.Mop, loop: true);
		clean_object_time = Time.time + 3f;
		state = JobState.Started;
		return true;
	}

	public override void UpdateJob()
	{
		if ((Object)(object)obj != (Object)null && obj.GetObjectType() == ObjectManager.ObjectType.Mop)
		{
			if (obj.UpdateInteraction(character, GetCancelState()))
			{
				obj.InteractionFinished(character);
				if (GetCancelState() != JobCancelState.Active)
				{
					state = JobState.Finished;
					OnFinishedJob();
				}
				else
				{
					obj = null;
					type = "clean_job";
					BeginNextCleanup();
				}
			}
		}
		else if (GetCancelState() != JobCancelState.Active)
		{
			state = JobState.Finished;
			OnFinishedJob();
		}
		else if (Time.time >= clean_object_time)
		{
			LitterManager.Instance.CleanupLitter(target_litter);
			BeginNextCleanup();
		}
	}

	private void BeginNextCleanup()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		target_litter = LitterManager.Instance.GetClosestLitterToPoint(((Component)character).transform.position);
		if ((Object)(object)target_litter == (Object)null)
		{
			mop.ReplaceMop();
			character.StopSound();
			state = JobState.Finished;
			OnFinishedJob();
		}
		else
		{
			location = ((Component)target_litter).transform.position;
			character.WalkToPosition(location);
			state = JobState.InTransit;
		}
	}

	public override void OnFinishedJob()
	{
		base.OnFinishedJob();
		character.StopSound();
	}

	public override void Cancel(bool forced)
	{
		base.Cancel(forced);
		mop.ReplaceMop();
	}

	public Vector3 GetTargetPosition()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return location;
	}

	public override void SaveLoadJob(SaveData data)
	{
		base.SaveLoadJob(data);
		int value = ((!((Object)(object)mop != (Object)null)) ? (-1) : mop.objectId);
		data.SaveLoad("mopObjectId", ref value);
		if (data.isLoading)
		{
			mop = null;
			if (value > -1 && (Object)(object)ObjectManager.Instance != (Object)null)
			{
				mop = ObjectManager.Instance.GetObjectWithId(value) as Obj_Mop;
			}
		}
	}
}
