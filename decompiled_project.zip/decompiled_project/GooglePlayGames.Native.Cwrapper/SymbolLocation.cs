namespace GooglePlayGames.Native.Cwrapper;

internal static class SymbolLocation
{
	internal const string NativeSymbolLocation = "gpg";
}
