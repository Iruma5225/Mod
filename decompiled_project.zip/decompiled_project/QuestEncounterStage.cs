using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

[Serializable]
public class QuestEncounterStage
{
	public enum EncounterStageType
	{
		Standard,
		Choice,
		CheckItems,
		CheckSubquestCompletion,
		CheckMilestone,
		Randomizer,
		EndEncounter,
		EnterCode,
		RecruitCharacters
	}

	public enum QuestEncounterCharacter
	{
		Player,
		LeadNpc,
		Npc2,
		Npc3,
		Npc4
	}

	[Serializable]
	public class DialogueString
	{
		[SerializeField]
		private QuestEncounterCharacter m_character;

		[SerializeField]
		private string m_textKey = string.Empty;

		public QuestEncounterCharacter character => m_character;

		public string textKey => m_textKey;
	}

	[Serializable]
	public class DialogueOption
	{
		[SerializeField]
		private string m_textKey = string.Empty;

		[SerializeField]
		private string m_nextId = string.Empty;

		public string textKey => m_textKey;

		public string nextId => m_nextId;
	}

	public enum EncounterEndType
	{
		NothingHappens,
		EnterCombat,
		EnterTrade,
		EnterRecruit,
		PlayerLeaves,
		NpcLeaves,
		RewardItems,
		BreakFilter
	}

	public enum QuestCombatResult
	{
		Nothing,
		CompleteQuestOnWin,
		CompleteParentScenarioOnWin
	}

	[Serializable]
	public class FloatingQuestTrigger
	{
		[SerializeField]
		private string m_id = string.Empty;

		[SerializeField]
		private float m_activationDelayDays = 2f;

		[SerializeField]
		private float m_durationDays = 5f;

		public string id => m_id;

		public float activationDelayDays => m_activationDelayDays;

		public float durationDays => m_durationDays;
	}

	[Serializable]
	public class ScenarioTrigger
	{
		[SerializeField]
		private string m_id = string.Empty;

		[SerializeField]
		[Range(0f, 100f)]
		private float m_spawnChance = 100f;

		[SerializeField]
		private int m_delayDays = 1;

		public string id => m_id;

		public float spawnChance => m_spawnChance;

		public int delayDays => m_delayDays;
	}

	[Serializable]
	public class EndEncounterOptions
	{
		[SerializeField]
		private EncounterEndType m_type;

		[SerializeField]
		private QuestCombatResult m_combatResult;

		[SerializeField]
		private string m_combatWinMilestone = string.Empty;

		[SerializeField]
		private string m_combatLossMilestone = string.Empty;

		[SerializeField]
		private bool m_addVehicle;

		[SerializeField]
		private List<ItemStack> m_rewardItems = new List<ItemStack>();

		[SerializeField]
		private bool m_overrideTradeItems;

		[SerializeField]
		private List<ItemStack> m_tradeItems = new List<ItemStack>();

		[SerializeField]
		private int m_minRandomTradeItems;

		[SerializeField]
		private int m_maxRandomTradeItems;

		[SerializeField]
		private List<FloatingQuestTrigger> m_triggerFloatingQuests = new List<FloatingQuestTrigger>();

		[SerializeField]
		private List<ScenarioTrigger> m_spawnScenarios = new List<ScenarioTrigger>();

		[SerializeField]
		private bool m_completeQuest;

		[SerializeField]
		private bool m_completeParentScenario;

		public EncounterEndType type => m_type;

		public QuestCombatResult combatResult => m_combatResult;

		public string combatWinMilestone => m_combatWinMilestone;

		public string combatLossMilestone => m_combatLossMilestone;

		public bool addVehicle => m_addVehicle;

		public List<ItemStack> rewardItems
		{
			get
			{
				List<ItemStack> list = new List<ItemStack>();
				for (int i = 0; i < m_rewardItems.Count; i++)
				{
					list.Add(new ItemStack(m_rewardItems[i]));
				}
				return list;
			}
		}

		public bool overrideTradeItems => m_overrideTradeItems;

		public List<ItemStack> tradeItems
		{
			get
			{
				List<ItemStack> list = new List<ItemStack>();
				for (int i = 0; i < m_tradeItems.Count; i++)
				{
					list.Add(new ItemStack(m_tradeItems[i]));
				}
				return list;
			}
		}

		public int minRandomTradeItems => m_minRandomTradeItems;

		public int maxRandomTradeItems => m_maxRandomTradeItems;

		public ReadOnlyCollection<FloatingQuestTrigger> triggerFloatingQuests => m_triggerFloatingQuests.AsReadOnly();

		public ReadOnlyCollection<ScenarioTrigger> spawnScenarios => m_spawnScenarios.AsReadOnly();

		public bool completeQuest => m_completeQuest;

		public bool completeParentScenario => m_completeParentScenario;
	}

	public enum MilestoneAction
	{
		SetMilestone,
		ClearMilestone
	}

	public enum MilestoneScope
	{
		ParentQuest,
		Global
	}

	[Serializable]
	public class QuestMilestone
	{
		[SerializeField]
		private string m_name = string.Empty;

		[SerializeField]
		private MilestoneScope m_scope;

		[SerializeField]
		private MilestoneAction m_action;

		public string name => m_name;

		public MilestoneScope scope => m_scope;

		public MilestoneAction action => m_action;
	}

	[Serializable]
	public class QuestMilestoneCheck
	{
		[SerializeField]
		private string m_name = string.Empty;

		[SerializeField]
		private MilestoneScope m_scope;

		public string name => m_name;

		public MilestoneScope scope => m_scope;
	}

	public enum SubquestCheckOp
	{
		AnyAreSuccessful,
		AnyAreCompleted,
		AllAreSuccessful,
		AllAreCompleted
	}

	[Serializable]
	public class SubquestCheck
	{
		[SerializeField]
		private SubquestCheckOp m_check = SubquestCheckOp.AllAreSuccessful;

		[SerializeField]
		private List<string> m_subquests = new List<string>();

		public SubquestCheckOp check => m_check;

		public ReadOnlyCollection<string> subquests => m_subquests.AsReadOnly();
	}

	[Serializable]
	public class ScenarioStageChange
	{
		[SerializeField]
		private string m_id = string.Empty;

		[SerializeField]
		private int m_delay;

		public string id => m_id;

		public int delay => m_delay;
	}

	[Serializable]
	public class DescriptionOverride
	{
		[SerializeField]
		private string m_key = string.Empty;

		public string key => m_key;
	}

	[SerializeField]
	private string m_id = string.Empty;

	[SerializeField]
	private EncounterStageType m_type;

	[SerializeField]
	private string m_nextId = string.Empty;

	[SerializeField]
	private string m_alternateNextId = string.Empty;

	[SerializeField]
	private List<DialogueString> m_dialogue = new List<DialogueString>();

	[SerializeField]
	private List<DialogueOption> m_options = new List<DialogueOption>();

	[SerializeField]
	private List<string> m_randomizedNextIds = new List<string>();

	[SerializeField]
	private List<ItemStack> m_items = new List<ItemStack>();

	[SerializeField]
	private List<ItemStack> m_itemsToRemove = new List<ItemStack>();

	[SerializeField]
	private EndEncounterOptions m_endOptions = new EndEncounterOptions();

	[SerializeField]
	private List<string> m_subquestsToActivate = new List<string>();

	[SerializeField]
	private SubquestCheck m_subquestCheck = new SubquestCheck();

	[SerializeField]
	private List<QuestMilestone> m_setMilestones = new List<QuestMilestone>();

	[SerializeField]
	private List<QuestMilestoneCheck> m_checkMilestones = new List<QuestMilestoneCheck>();

	[SerializeField]
	private ScenarioStageChange m_stageChange = new ScenarioStageChange();

	[SerializeField]
	private DescriptionOverride m_stageDescriptionKey = new DescriptionOverride();

	[SerializeField]
	private List<string> m_characterIds = new List<string>();

	[SerializeField]
	private bool m_recruitAsFamily;

	public string id => m_id;

	public EncounterStageType type => m_type;

	public string nextId => m_nextId;

	public string alternateNextId => m_alternateNextId;

	public ReadOnlyCollection<DialogueString> dialogue => m_dialogue.AsReadOnly();

	public ReadOnlyCollection<DialogueOption> options => m_options.AsReadOnly();

	public ReadOnlyCollection<string> randomizedNextIds => m_randomizedNextIds.AsReadOnly();

	public List<ItemStack> items
	{
		get
		{
			Dictionary<ItemManager.ItemType, int> dictionary = new Dictionary<ItemManager.ItemType, int>();
			for (int i = 0; i < m_items.Count; i++)
			{
				if (dictionary.ContainsKey(m_items[i].m_type))
				{
					dictionary[m_items[i].m_type] += m_items[i].m_count;
				}
				else
				{
					dictionary.Add(m_items[i].m_type, m_items[i].m_count);
				}
			}
			List<ItemStack> list = new List<ItemStack>();
			foreach (KeyValuePair<ItemManager.ItemType, int> item in dictionary)
			{
				list.Add(new ItemStack(item.Key, item.Value));
			}
			return list;
		}
	}

	public List<ItemStack> itemsToRemove
	{
		get
		{
			List<ItemStack> list = new List<ItemStack>();
			for (int i = 0; i < m_itemsToRemove.Count; i++)
			{
				list.Add(new ItemStack(m_itemsToRemove[i]));
			}
			return list;
		}
	}

	public EndEncounterOptions endOptions => m_endOptions;

	public ReadOnlyCollection<string> subquestsToActivate => m_subquestsToActivate.AsReadOnly();

	public SubquestCheck subquestCheck => m_subquestCheck;

	public ReadOnlyCollection<QuestMilestone> setMilestones => m_setMilestones.AsReadOnly();

	public ReadOnlyCollection<QuestMilestoneCheck> checkMilestones => m_checkMilestones.AsReadOnly();

	public ScenarioStageChange stageChange => m_stageChange;

	public DescriptionOverride stageDescription => m_stageDescriptionKey;

	public ReadOnlyCollection<string> characterIdsToRecruit => m_characterIds.AsReadOnly();

	public bool recruitAsFamily => m_recruitAsFamily;
}
