using System.Collections.Generic;
using UnityEngine;

public class Obj_HidingSpot : Obj_Base
{
	[SerializeField]
	private Animator m_animator;

	[SerializeField]
	private int m_maxHidden = 1;

	private List<FamilyMember> m_hidden = new List<FamilyMember>();

	private AudioSource m_audio;

	[SerializeField]
	private AudioClip m_openSound;

	public int numHidden => m_hidden.Count;

	public int maxHidden => m_maxHidden;

	public override ObjectManager.ObjectType GetObjectType()
	{
		return ObjectManager.ObjectType.HidingSpot;
	}

	public override void OnDestroy()
	{
		base.OnDestroy();
		ExpelHidden();
	}

	public void AddHidden(FamilyMember member)
	{
		if (m_maxHidden > 0)
		{
			if (m_hidden.Count >= m_maxHidden)
			{
				m_hidden[0].LeaveHidingSpot();
				m_hidden.RemoveAt(0);
			}
			if (m_hidden.Count < m_maxHidden)
			{
				m_hidden.Add(member);
				member.EnterHidingSpot(this);
			}
			PlayOpenAnim();
		}
	}

	public void ExpelHidden()
	{
		if (m_hidden.Count <= 0)
		{
			return;
		}
		for (int i = 0; i < m_hidden.Count; i++)
		{
			if ((Object)(object)m_hidden[i] != (Object)null)
			{
				m_hidden[i].LeaveHidingSpot();
			}
		}
		m_hidden.Clear();
		PlayOpenAnim();
	}

	private void PlayOpenAnim()
	{
		if ((Object)(object)m_animator != (Object)null)
		{
			m_animator.SetTrigger("Open");
			if ((Object)(object)m_audio == (Object)null)
			{
				m_audio = ((Component)this).GetComponent<AudioSource>();
			}
			if ((Object)(object)m_audio != (Object)null && (Object)(object)m_openSound != (Object)null)
			{
				m_audio.PlayOneShot(m_openSound);
			}
		}
	}

	public override List<string> GetTooltipExtraInfo()
	{
		List<string> list = new List<string>();
		list.Add(Localization.Get("text.ui.numhidden"));
		list.Add(m_hidden.Count + " / " + m_maxHidden);
		return list;
	}
}
