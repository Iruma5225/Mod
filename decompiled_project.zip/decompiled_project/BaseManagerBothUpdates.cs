public abstract class BaseManagerBothUpdates : BaseManagerNoUpdate
{
	private void FixedUpdate()
	{
		if (LoadingManager.IsLoadingFinished())
		{
			FixedUpdateManager();
		}
	}

	public abstract void FixedUpdateManager();

	private void Update()
	{
		if (LoadingManager.IsLoadingFinished())
		{
			UpdateManager();
		}
	}

	public abstract void UpdateManager();
}
