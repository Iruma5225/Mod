using UnityEngine;

public class Int_Medicate : Int_Base
{
	public MedicineManager.MedicineType medicine = MedicineManager.MedicineType.FirstAid;

	public AudioClip m_RummageSFX;

	public AudioClip m_FinishedSFX;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_Medicate";
	}

	public override string GetInteractionType()
	{
		string result = string.Empty;
		switch (medicine)
		{
		case MedicineManager.MedicineType.FirstAid:
			result = "medicate_firstaid";
			break;
		case MedicineManager.MedicineType.AntiRadiation:
			result = "medicate_antirad";
			break;
		case MedicineManager.MedicineType.AntiBiotics:
			result = "medicate_antibio";
			break;
		case MedicineManager.MedicineType.Valium:
			result = "medicate_valium";
			break;
		case MedicineManager.MedicineType.Bandages:
			result = "medicate_bandages";
			break;
		case MedicineManager.MedicineType.HomemadeAntiBiotics:
			result = "medicate_homemade_antibiotics";
			break;
		case MedicineManager.MedicineType.HomemadeAntiemetics:
			result = "medicate_homemade_antiemetic";
			break;
		case MedicineManager.MedicineType.HomemadeAntiRadiation:
			result = "medicate_homemade_antirad";
			break;
		case MedicineManager.MedicineType.HomemadeAntiDepressant:
			result = "medicate_homemade_antidepressant";
			break;
		}
		return result;
	}

	public override int GetInteractionPriority()
	{
		return (int)medicine;
	}

	public void RummageSoundEffect()
	{
		if ((Object)(object)m_RummageSFX != (Object)null)
		{
			((Component)this).GetComponent<AudioSource>().PlayOneShot(m_RummageSFX);
		}
	}

	public void FinishedSoundEffect()
	{
		if ((Object)(object)m_RummageSFX != (Object)null)
		{
			((Component)this).GetComponent<AudioSource>().PlayOneShot(m_FinishedSFX);
		}
	}

	public override bool IsPlayerSelectable()
	{
		if (base.IsPlayerSelectable())
		{
			ItemManager.ItemType item = MedicineManager.MedicineToItem(medicine);
			if ((Object)(object)InventoryManager.Instance != (Object)null && InventoryManager.Instance.GetNumItemsOfType(item) > 0)
			{
				return true;
			}
		}
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}
}
