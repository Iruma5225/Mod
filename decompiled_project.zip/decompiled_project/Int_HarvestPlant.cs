public class Int_HarvestPlant : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_HarvestPlant";
	}

	public override string GetInteractionType()
	{
		return "harvest_plant";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		Obj_Planter obj_Planter = obj as Obj_Planter;
		if (base.IsPlayerSelectable() && obj_Planter.ReadyToHarvest() && !obj_Planter.beingHarvested)
		{
			return true;
		}
		return false;
	}
}
