using UnityEngine;

public class InteractionInstance_Enable : InteractionInstance_Base
{
	protected override bool OnInteractionStarted()
	{
		if ((Object)(object)obj_base == (Object)null || obj_base.IsEnabled())
		{
			return false;
		}
		if ((Object)(object)member != (Object)null)
		{
			member.TriggerAnim("Rummage");
		}
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled)
		{
			if ((Object)(object)obj_base != (Object)null)
			{
				obj_base.EnableObject();
			}
			Int_Enable int_Enable = base_interaction as Int_Enable;
			if ((Object)(object)int_Enable != (Object)null)
			{
				int_Enable.PlayEnableSound();
			}
		}
		return true;
	}
}
