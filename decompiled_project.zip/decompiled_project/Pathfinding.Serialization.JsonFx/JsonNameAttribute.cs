using System;

namespace Pathfinding.Serialization.JsonFx;

public class JsonNameAttribute : Attribute
{
	public JsonNameAttribute(string s)
	{
	}
}
