using System;

namespace Pathfinding.Serialization.JsonFx;

public class JsonOptInAttribute : Attribute
{
}
