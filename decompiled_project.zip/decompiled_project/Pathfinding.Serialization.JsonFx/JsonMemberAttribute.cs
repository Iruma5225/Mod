using System;

namespace Pathfinding.Serialization.JsonFx;

public class JsonMemberAttribute : Attribute
{
}
