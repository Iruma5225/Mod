using System.Collections.Generic;
using UnityEngine;

public class InteractionInstance_Deconstruct : InteractionInstance_Base
{
	private Int_Deconstruct interaction;

	private CraftingManager.Recipe recipe;

	private Sprite originalSprite;

	private SpriteRenderer spriteRenderer;

	private Sprite[] constructionSprites;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_Deconstruct;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		if ((Object)(object)CraftingManager.Instance == (Object)null || (Object)(object)ItemManager.Instance == (Object)null)
		{
			return false;
		}
		ItemManager.ItemType item = ItemManager.Instance.FindItemForObject(obj_base.GetObjectType(), obj_base.objectLevel);
		if (interaction.OverrideItems.Length > 0)
		{
			recipe = new CraftingManager.Recipe(ItemManager.ItemType.Undefined, interaction.OverrideItems);
		}
		if (recipe == null && !string.IsNullOrEmpty(obj_base.recipeId))
		{
			recipe = CraftingManager.Instance.GetRecipeByID(obj_base.recipeId);
		}
		if (recipe == null)
		{
			List<CraftingManager.Recipe> recipesForItem = CraftingManager.Instance.GetRecipesForItem(item);
			if (recipesForItem != null && recipesForItem.Count > 0)
			{
				recipe = recipesForItem[0];
			}
		}
		if (recipe == null)
		{
			return false;
		}
		ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(item);
		if ((Object)(object)itemDefinition != (Object)null)
		{
			float duration = CraftingManager.CalculateCraftTime(itemDefinition.BaseCraftTime);
			ResetInteractionTimer(duration);
		}
		obj_base.selectable = false;
		if (Random.value >= 0.5f)
		{
			member.TriggerAnim("Fix");
			member.PlaySound(BaseCharacter.AnimSounds.Blowtorch, loop: true);
		}
		else
		{
			member.TriggerAnim("Hammer");
			member.PlaySound(BaseCharacter.AnimSounds.Hammer, loop: true);
		}
		if (obj_base.GetObjectType() != ObjectManager.ObjectType.BurntGhost)
		{
			spriteRenderer = ((Component)obj_base).GetComponentInChildren<SpriteRenderer>();
			constructionSprites = obj_base.constructionSprites;
			if ((Object)(object)spriteRenderer != (Object)null && constructionSprites != null && constructionSprites.Length > 0)
			{
				originalSprite = spriteRenderer.sprite;
				spriteRenderer.sprite = constructionSprites[constructionSprites.Length - 1];
			}
		}
		return true;
	}

	protected override void OnInteractionUpdated()
	{
		base.OnInteractionUpdated();
		if ((Object)(object)spriteRenderer != (Object)null && constructionSprites != null && constructionSprites.Length > 0)
		{
			int num = Mathf.FloorToInt((1f - base.Progress) * (float)constructionSprites.Length);
			num = Mathf.Clamp(num, 0, constructionSprites.Length - 1);
			if ((Object)(object)spriteRenderer.sprite != (Object)(object)constructionSprites[num])
			{
				spriteRenderer.sprite = constructionSprites[num];
			}
		}
	}

	protected override bool OnInteractionComplete()
	{
		member.StopSound();
		if (base.cancelled)
		{
			obj_base.selectable = true;
			if ((Object)(object)spriteRenderer != (Object)null && (Object)(object)originalSprite != (Object)null)
			{
				spriteRenderer.sprite = originalSprite;
			}
			return true;
		}
		if (recipe == null)
		{
			return true;
		}
		CraftingManager.Recipe.Ingredient[] input = recipe.Input;
		if (input == null)
		{
			return false;
		}
		List<ItemManager.ItemType> list = new List<ItemManager.ItemType>();
		for (int i = 0; i < input.Length; i++)
		{
			for (int j = 0; j < input[i].Quantity; j++)
			{
				ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(input[i].Item);
				if (itemDefinition.CanBeRecovered)
				{
					list.Add(input[i].Item);
				}
			}
		}
		float num = interaction.ReturnChance;
		if (member.traits.HasStrength(Traits.Strength.Resourceful))
		{
			num = interaction.ReturnChance_Resourceful;
		}
		else if (member.traits.HasWeakness(Traits.Weakness.Wasteful))
		{
			num = interaction.ReturnChance_Wasteful;
		}
		for (int k = 0; k < list.Count; k++)
		{
			if (Random.value > num)
			{
				list.RemoveAt(k);
			}
		}
		for (int l = 0; l < list.Count; l++)
		{
			InventoryManager.Instance.AddNewItem(list[l]);
		}
		if (obj_base.GetObjectType() == ObjectManager.ObjectType.Freezer)
		{
			Obj_Freezer obj_Freezer = obj_base as Obj_Freezer;
			if ((Object)(object)obj_Freezer != (Object)null && !obj_Freezer.IsMeatContaminated())
			{
				FoodManager.Instance.AddMeat(obj_Freezer.Meat);
				FoodManager.Instance.AddDesperateMeat(obj_Freezer.DesperateMeat);
			}
		}
		if ((Object)(object)UIPanelManager.Instance() != (Object)null && (Object)(object)UI_PanelContainer.Instance.DeconstructionPanel != (Object)null)
		{
			UI_PanelContainer.Instance.DeconstructionPanel.Setup(obj_base.GetName(), list);
			UIPanelManager.Instance().PushPanel(UI_PanelContainer.Instance.DeconstructionPanel);
		}
		member.OnDeconstructCompleted();
		if (obj_base.GetObjectType() == ObjectManager.ObjectType.BurntGhost)
		{
			Obj_BurntGhost obj_BurntGhost = obj_base as Obj_BurntGhost;
			if ((Object)(object)obj_BurntGhost != (Object)null)
			{
				obj_BurntGhost.OnObjectDeconstructed();
			}
		}
		ObjectManager.Instance.RemoveObject(obj_base);
		return true;
	}
}
