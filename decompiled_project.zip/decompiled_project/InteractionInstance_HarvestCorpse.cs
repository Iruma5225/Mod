using System.Collections.Generic;
using UnityEngine;

public class InteractionInstance_HarvestCorpse : InteractionInstance_Base
{
	private Int_HarvestCorpse interaction;

	private Obj_Freezer freezer_object;

	private Obj_Corpse corpse;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_HarvestCorpse;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		freezer_object = ((Component)this).GetComponent<Obj_Freezer>();
		if ((Object)(object)freezer_object == (Object)null)
		{
			return false;
		}
		if (!member.isCarryingCorpse)
		{
			return false;
		}
		corpse = member.StopCarryingCorpse();
		if ((Object)(object)corpse == (Object)null)
		{
			return false;
		}
		member.SetAnimBool("Crouch", truth: true);
		member.TriggerAnim("Rummage");
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		member.SetAnimBool("Crouch", truth: false);
		if (!base.cancelled && (Object)(object)freezer_object != (Object)null)
		{
			if ((Object)(object)corpse != (Object)null)
			{
				if (corpse.HazmatSuit != null)
				{
					Obj_HazmatSuit.HazmatSuit suit = corpse.RemoveHazmatSuit();
					List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.HazmatSuits);
					if (objectsOfType != null && objectsOfType.Count > 0)
					{
						Obj_HazmatSuit obj_HazmatSuit = null;
						for (int i = 0; i < objectsOfType.Count; i++)
						{
							obj_HazmatSuit = objectsOfType[i] as Obj_HazmatSuit;
							if ((Object)(object)obj_HazmatSuit != (Object)null && !obj_HazmatSuit.IsFullOfSuits())
							{
								obj_HazmatSuit.ReturnSuit(suit);
								break;
							}
						}
					}
				}
				if (corpse.isPet)
				{
					freezer_object.AddMeat(corpse.RationValue);
				}
				else
				{
					freezer_object.AddDesperateMeat(corpse.RationValue);
				}
				ObjectManager.Instance.RemoveObject(corpse);
			}
			FamilyManager.Instance.CharacterHasHarvestedCorpse(member, interaction.Trauma);
			if ((Object)(object)JournalManager.Instance != (Object)null)
			{
				JournalManager.Instance.RecordEvent(JournalEvents.Event.BodyHarvested, new ActivityLog.ExtraInfoString(corpse.FirstName, isLocalizationKey: false));
				if (corpse.loyalty >= 1f)
				{
					JournalManager.Instance.CreateJournalEntry(JournalManager.JournalEntryType.Death);
				}
			}
		}
		return true;
	}
}
