using System.Collections.Generic;
using UnityEngine;

public class MapLegendFactions : MonoBehaviour
{
	[SerializeField]
	private GameObject m_legendEntryPrefab;

	[SerializeField]
	private GameObject m_header;

	private List<GameObject> m_spawned = new List<GameObject>();

	public void OnEnable()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		DestroyEntries();
		if ((Object)(object)m_legendEntryPrefab == (Object)null || (Object)(object)FactionMan.instance == (Object)null)
		{
			return;
		}
		List<FactionMan.ActiveFactionInfo> activeFactionInfo = FactionMan.instance.GetActiveFactionInfo();
		if ((Object)(object)m_header != (Object)null)
		{
			m_header.SetActive(activeFactionInfo.Count > 0);
		}
		for (int i = 0; i < activeFactionInfo.Count; i++)
		{
			GameObject val = Object.Instantiate<GameObject>(m_legendEntryPrefab, Vector3.zero, Quaternion.identity);
			if ((Object)(object)val != (Object)null)
			{
				MapLegendFactionEntry component = val.GetComponent<MapLegendFactionEntry>();
				if ((Object)(object)component != (Object)null)
				{
					((Component)component).transform.parent = ((Component)this).transform;
					((Component)component).transform.localScale = Vector3.one;
					((Component)component).transform.localPosition = Vector3.zero;
					m_spawned.Add(((Component)component).gameObject);
					component.SetFactionInfo(activeFactionInfo[i].m_name, activeFactionInfo[i].m_color);
				}
			}
		}
		UIGrid component2 = ((Component)this).GetComponent<UIGrid>();
		if ((Object)(object)component2 != (Object)null)
		{
			component2.repositionNow = true;
		}
	}

	public void OnDisable()
	{
		DestroyEntries();
	}

	private void DestroyEntries()
	{
		for (int num = m_spawned.Count - 1; num >= 0; num--)
		{
			Object.Destroy((Object)(object)m_spawned[num]);
		}
		m_spawned.Clear();
	}
}
