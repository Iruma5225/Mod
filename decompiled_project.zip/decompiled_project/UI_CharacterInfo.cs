using System.Collections.Generic;
using UnityEngine;

public class UI_CharacterInfo : MonoBehaviour
{
	private enum WarningState
	{
		Hidden,
		FadingIn,
		Showing,
		FadingOut
	}

	public enum PopupType
	{
		Trauma,
		Xp,
		LevelUp,
		Loyalty,
		TrapHit,
		TrapMiss,
		Max
	}

	private class PopupInfo
	{
		public PopupType m_type = PopupType.Max;

		public float m_value;

		public BaseStats.StatType m_stat = BaseStats.StatType.Max;
	}

	[SerializeField]
	private UISprite m_sprite;

	[SerializeField]
	private UILabel m_floatingText;

	[SerializeField]
	private AudioClip m_levelUpSound;

	[SerializeField]
	private AudioClip m_xpSound;

	[SerializeField]
	private AudioClip m_traumaSound;

	[SerializeField]
	private AudioClip m_loyaltySound;

	private TweenAlpha m_textAlphaTween;

	private TweenPosition m_textPosTween;

	[SerializeField]
	private float m_catatonicDuration = 10f;

	[SerializeField]
	private float m_warningDuration = 2f;

	[SerializeField]
	private float m_warningFadeTime = 0.3f;

	[SerializeField]
	private float m_popupDuration = 3f;

	[SerializeField]
	private float m_popupFadeTime = 1f;

	private FamilyMember m_member;

	private BehaviourStat.BehaviourStatType m_currentWarning;

	private float m_fadeStartAlpha;

	private float m_fadeStartTime;

	private float m_fadeEndTime;

	private float m_showUntilTime;

	private float m_nextCheckTime;

	[SerializeField]
	private bool m_testPopup;

	private bool m_showingPopup;

	private bool m_showingCatatonic;

	private WarningState m_warningState;

	private List<PopupInfo> m_popupQueue = new List<PopupInfo>();

	public void Awake()
	{
		if ((Object)(object)m_floatingText != (Object)null)
		{
			m_textAlphaTween = ((Component)m_floatingText).GetComponent<TweenAlpha>();
			m_textPosTween = ((Component)m_floatingText).GetComponent<TweenPosition>();
		}
		if (NextWarningSprite())
		{
			SetWarningIconState(WarningState.FadingIn);
		}
	}

	private bool NextWarningSprite()
	{
		if ((Object)(object)m_member != (Object)null)
		{
			if ((m_member.isCatatonic || m_member.isCatatonicLeaving) && !m_showingCatatonic)
			{
				m_showingCatatonic = true;
				return true;
			}
			if (m_showingCatatonic)
			{
				m_showingCatatonic = false;
			}
		}
		for (BehaviourStat.BehaviourStatType behaviourStatType = ((m_currentWarning != BehaviourStat.BehaviourStatType.Max) ? (m_currentWarning + 1) : BehaviourStat.BehaviourStatType.Fatigue); behaviourStatType != m_currentWarning; behaviourStatType = ((behaviourStatType != BehaviourStat.BehaviourStatType.Max) ? (behaviourStatType + 1) : BehaviourStat.BehaviourStatType.Fatigue))
		{
			if (IsWarningIconNeeded(behaviourStatType))
			{
				m_currentWarning = behaviourStatType;
				return true;
			}
		}
		if (IsWarningIconNeeded(m_currentWarning))
		{
			return true;
		}
		if ((Object)(object)m_member != (Object)null && (m_member.isCatatonic || m_member.isCatatonicLeaving) && !m_showingCatatonic)
		{
			m_showingCatatonic = true;
			return true;
		}
		return false;
	}

	private bool IsWarningIconNeeded(BehaviourStat.BehaviourStatType stat)
	{
		if ((Object)(object)m_member == (Object)null)
		{
			return false;
		}
		if (m_showingCatatonic)
		{
			return true;
		}
		if ((Object)(object)m_member != (Object)null && (m_member.isCatatonic || m_member.isCatatonicLeaving) && stat != BehaviourStat.BehaviourStatType.Hunger && stat != BehaviourStat.BehaviourStatType.Thirst)
		{
			return false;
		}
		BehaviourStat behaviourStat = null;
		switch (stat)
		{
		case BehaviourStat.BehaviourStatType.Dirtiness:
			behaviourStat = m_member.stats.dirtiness;
			break;
		case BehaviourStat.BehaviourStatType.Fatigue:
			behaviourStat = m_member.stats.fatigue;
			break;
		case BehaviourStat.BehaviourStatType.Hunger:
			behaviourStat = m_member.stats.hunger;
			break;
		case BehaviourStat.BehaviourStatType.Thirst:
			behaviourStat = m_member.stats.thirst;
			break;
		case BehaviourStat.BehaviourStatType.Toilet:
			behaviourStat = m_member.stats.toilet;
			break;
		case BehaviourStat.BehaviourStatType.Stress:
			behaviourStat = m_member.stats.stress;
			break;
		default:
			return false;
		}
		if (behaviourStat != null && behaviourStat.Value >= behaviourStat.stressIncreaseThreshold)
		{
			return true;
		}
		return false;
	}

	private void SetWarningIconState(WarningState state)
	{
		m_warningState = state;
		switch (state)
		{
		case WarningState.Hidden:
			if ((Object)(object)m_sprite != (Object)null)
			{
				m_sprite.alpha = 0f;
			}
			m_nextCheckTime = Time.time + 1f;
			break;
		case WarningState.Showing:
			m_showUntilTime = Time.time + ((!m_showingCatatonic) ? m_warningDuration : m_catatonicDuration);
			break;
		case WarningState.FadingIn:
		{
			string text = string.Empty;
			if (m_showingCatatonic)
			{
				text = "TraumaSustained";
			}
			else
			{
				switch (m_currentWarning)
				{
				case BehaviourStat.BehaviourStatType.Dirtiness:
					text = "AlertHygiene";
					break;
				case BehaviourStat.BehaviourStatType.Fatigue:
					text = "AlertTiredness";
					break;
				case BehaviourStat.BehaviourStatType.Hunger:
					text = "AlertHunger";
					break;
				case BehaviourStat.BehaviourStatType.Stress:
					text = "AlertStress";
					break;
				case BehaviourStat.BehaviourStatType.Thirst:
					text = "AlertThirst";
					break;
				case BehaviourStat.BehaviourStatType.Toilet:
					text = "AlertToilet";
					break;
				}
			}
			if ((Object)(object)m_sprite != (Object)null && text.Length > 0)
			{
				m_sprite.spriteName = text;
			}
			m_fadeStartAlpha = ((!((Object)(object)m_sprite != (Object)null)) ? 0f : m_sprite.alpha);
			m_fadeStartTime = Time.time;
			m_fadeEndTime = m_fadeStartTime + m_warningFadeTime;
			break;
		}
		case WarningState.FadingOut:
			m_fadeStartAlpha = ((!((Object)(object)m_sprite != (Object)null)) ? 1f : m_sprite.alpha);
			m_fadeStartTime = Time.time;
			m_fadeEndTime = m_fadeStartTime + m_warningFadeTime;
			break;
		}
	}

	public void AddPopup(PopupType type, BaseStats.StatType stat, float value)
	{
		if (m_showingCatatonic)
		{
			return;
		}
		switch (type)
		{
		case PopupType.Xp:
		case PopupType.LevelUp:
			if (stat == BaseStats.StatType.Max)
			{
				return;
			}
			break;
		case PopupType.Max:
			return;
		}
		PopupInfo popupInfo = new PopupInfo();
		popupInfo.m_type = type;
		popupInfo.m_stat = stat;
		popupInfo.m_value = value;
		m_popupQueue.Add(popupInfo);
	}

	public void Update()
	{
		if ((Object)(object)m_member == (Object)null && (Object)(object)((Component)this).transform.parent != (Object)null)
		{
			UI_Character component = ((Component)((Component)this).transform.parent).GetComponent<UI_Character>();
			if ((Object)(object)component == (Object)null && (Object)(object)((Component)this).transform.parent.parent != (Object)null)
			{
				component = ((Component)((Component)this).transform.parent.parent).GetComponent<UI_Character>();
			}
			if ((Object)(object)component != (Object)null)
			{
				m_member = component.familyMember;
				m_member.SetCharacterInfoUI(this);
			}
		}
		if (m_popupQueue.Count > 0 || m_showingPopup)
		{
			UpdatePopupIcon();
		}
		else
		{
			UpdateWarningIcon();
		}
		if (m_testPopup)
		{
			m_testPopup = false;
			PopupInfo popupInfo = new PopupInfo();
			popupInfo.m_stat = (BaseStats.StatType)Random.Range(0, 5);
			popupInfo.m_type = (PopupType)Random.Range(0, 6);
			popupInfo.m_value = Random.value * 20f;
			m_popupQueue.Add(popupInfo);
		}
	}

	private void UpdatePopupIcon()
	{
		if (!m_showingPopup)
		{
			SetWarningIconState(WarningState.Hidden);
			m_showingPopup = true;
			m_showUntilTime = Time.time + m_popupDuration;
			m_fadeStartTime = m_showUntilTime;
			m_fadeEndTime = m_showUntilTime + m_popupFadeTime;
			m_fadeStartAlpha = 1f;
			string spriteName = string.Empty;
			PopupInfo popupInfo = m_popupQueue[0];
			if (popupInfo.m_type == PopupType.Trauma)
			{
				spriteName = "TraumaSustained";
			}
			else if (popupInfo.m_type == PopupType.Loyalty)
			{
				spriteName = "LoyaltyIcon_Large";
			}
			else
			{
				switch (popupInfo.m_stat)
				{
				case BaseStats.StatType.Charisma:
					spriteName = "LevelUpChar";
					break;
				case BaseStats.StatType.Dexterity:
					spriteName = "LevelUpDex";
					break;
				case BaseStats.StatType.Intelligence:
					spriteName = "LevelUpInt";
					break;
				case BaseStats.StatType.Perception:
					spriteName = "LevelUpPer";
					break;
				case BaseStats.StatType.Strength:
					spriteName = "LevelUpStrength";
					break;
				}
			}
			if ((Object)(object)m_sprite != (Object)null)
			{
				m_sprite.alpha = 1f;
				m_sprite.spriteName = spriteName;
			}
			if ((Object)(object)UISound.instance != (Object)null)
			{
				if (popupInfo.m_type == PopupType.LevelUp && (Object)(object)m_levelUpSound != (Object)null)
				{
					UISound.instance.Play(m_levelUpSound);
				}
				if (popupInfo.m_type == PopupType.Xp && (Object)(object)m_xpSound != (Object)null)
				{
					UISound.instance.Play(m_xpSound);
				}
				if (popupInfo.m_type == PopupType.Trauma && (Object)(object)m_traumaSound != (Object)null)
				{
					UISound.instance.Play(m_traumaSound);
				}
				if (popupInfo.m_type == PopupType.Loyalty && (Object)(object)m_loyaltySound != (Object)null)
				{
					UISound.instance.Play(m_loyaltySound);
				}
			}
			if ((Object)(object)m_floatingText != (Object)null && (Object)(object)m_textPosTween != (Object)null && (Object)(object)m_textAlphaTween != (Object)null)
			{
				switch (popupInfo.m_type)
				{
				case PopupType.LevelUp:
					m_floatingText.text = Localization.Get("UI.LevelUp");
					break;
				case PopupType.Xp:
					m_floatingText.text = "+" + Mathf.FloorToInt(popupInfo.m_value) + " " + Localization.Get("UI.XP");
					break;
				case PopupType.Trauma:
					m_floatingText.text = "+" + Mathf.FloorToInt(popupInfo.m_value) + " " + Localization.Get("UI.Trauma");
					break;
				case PopupType.Loyalty:
					m_floatingText.text = Localization.Get("UI.Loyalty");
					break;
				case PopupType.TrapHit:
					m_floatingText.text = Localization.Get("Text.Combat.Hit");
					break;
				case PopupType.TrapMiss:
					m_floatingText.text = Localization.Get("Text.Combat.Miss");
					break;
				}
				m_floatingText.alpha = 1f;
				m_textPosTween.duration = m_popupDuration + m_popupFadeTime;
				m_textPosTween.ResetToBeginning();
				m_textPosTween.PlayForward();
				m_textAlphaTween.duration = m_popupDuration + m_popupFadeTime;
				m_textAlphaTween.ResetToBeginning();
				m_textAlphaTween.PlayForward();
			}
			m_popupQueue.RemoveAt(0);
		}
		if (Time.time >= m_fadeStartTime)
		{
			float num = (Time.time - m_fadeStartTime) / (m_fadeEndTime - m_fadeStartTime);
			float alpha = Mathf.Lerp(m_fadeStartAlpha, 0f, num);
			if ((Object)(object)m_sprite != (Object)null)
			{
				m_sprite.alpha = alpha;
			}
			if (num >= 1f)
			{
				m_showingPopup = false;
			}
		}
	}

	private void UpdateWarningIcon()
	{
		if ((Object)(object)m_member != (Object)null && m_member.isHiding && m_warningState != WarningState.Hidden)
		{
			SetWarningIconState(WarningState.Hidden);
		}
		switch (m_warningState)
		{
		case WarningState.Hidden:
			if (Time.time >= m_nextCheckTime)
			{
				if (NextWarningSprite() && (Object)(object)m_member != (Object)null && !m_member.isHiding)
				{
					SetWarningIconState(WarningState.FadingIn);
				}
				else
				{
					m_nextCheckTime = Time.time + 1f;
				}
			}
			break;
		case WarningState.Showing:
		{
			bool flag = false;
			if ((Object)(object)m_member != (Object)null && (m_member.isCatatonic || m_member.isCatatonicLeaving) && !m_showingCatatonic)
			{
				flag = true;
			}
			if ((Object)(object)m_member != (Object)null && !m_member.isCatatonic && !m_member.isCatatonicLeaving && m_showingCatatonic)
			{
				flag = true;
			}
			if (Time.time >= m_showUntilTime || flag)
			{
				if (NextWarningSprite())
				{
					SetWarningIconState(WarningState.FadingOut);
					break;
				}
				if (IsWarningIconNeeded(m_currentWarning))
				{
					m_showUntilTime = Time.time + m_warningDuration;
					break;
				}
				m_currentWarning = BehaviourStat.BehaviourStatType.Max;
				SetWarningIconState(WarningState.FadingOut);
			}
			break;
		}
		case WarningState.FadingIn:
		{
			float num2 = (Time.time - m_fadeStartTime) / (m_fadeEndTime - m_fadeStartTime);
			float alpha2 = Mathf.Lerp(m_fadeStartAlpha, 1f, num2);
			if ((Object)(object)m_sprite != (Object)null)
			{
				m_sprite.alpha = alpha2;
			}
			if (num2 >= 1f)
			{
				SetWarningIconState(WarningState.Showing);
			}
			break;
		}
		case WarningState.FadingOut:
		{
			float num = (Time.time - m_fadeStartTime) / (m_fadeEndTime - m_fadeStartTime);
			float alpha = Mathf.Lerp(m_fadeStartAlpha, 0f, num);
			if ((Object)(object)m_sprite != (Object)null)
			{
				m_sprite.alpha = alpha;
			}
			if (num >= 1f)
			{
				if (m_currentWarning == BehaviourStat.BehaviourStatType.Max && !m_showingCatatonic)
				{
					SetWarningIconState(WarningState.Hidden);
				}
				else
				{
					SetWarningIconState(WarningState.FadingIn);
				}
			}
			break;
		}
		}
	}
}
