using UnityEngine;

public class Int_TrainOnPunchBag : Int_Base
{
	public float punchBagAnimationLength;

	[SerializeField]
	private int m_integrityLossPerUse;

	public int integrityLossPerUse => m_integrityLossPerUse;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_TrainOnPunchBag";
	}

	public override string GetInteractionType()
	{
		return "train_on_punch_bag";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override bool IsPlayerSelectable()
	{
		Obj_PunchBag obj_PunchBag = obj as Obj_PunchBag;
		if (base.IsPlayerSelectable() && !obj_PunchBag.beingUsed)
		{
			return true;
		}
		return false;
	}
}
