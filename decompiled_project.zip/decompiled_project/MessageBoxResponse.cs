public delegate void MessageBoxResponse(int response);
