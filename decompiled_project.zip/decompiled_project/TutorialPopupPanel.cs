using UnityEngine;

public class TutorialPopupPanel : BasePanel
{
	[SerializeField]
	private float min_lifetime = 0.5f;

	private float m_timeToDie;

	[SerializeField]
	private AudioClip closeSound;

	private bool m_shown;

	public bool HasBeenShown()
	{
		return m_shown;
	}

	public override void OnShow()
	{
		base.OnShow();
		m_timeToDie = min_lifetime;
		m_shown = true;
	}

	public override void Update()
	{
		if (m_timeToDie > 0f)
		{
			m_timeToDie -= RealTime.deltaTime;
		}
	}

	public override void OnCancel()
	{
		if (!(m_timeToDie > 0f))
		{
			base.OnCancel();
			UISound.instance.PlayPreset(UISound.PresetSound.TutorialPopupDismiss);
			if ((Object)(object)UIPanelManager.Instance() != (Object)null)
			{
				UIPanelManager.Instance().PopPanel(this);
			}
		}
	}

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool DestroyOnClose()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override bool PausesGameInput()
	{
		return true;
	}

	public override bool Popup()
	{
		return true;
	}
}
