using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

[AddComponentMenu("NGUI/UI/Input Field")]
public class UIInput : MonoBehaviour
{
	public enum InputType
	{
		Standard,
		AutoCorrect,
		Password
	}

	public enum Validation
	{
		None,
		Integer,
		Float,
		Alphanumeric,
		Username,
		Name
	}

	public enum KeyboardType
	{
		Default,
		ASCIICapable,
		NumbersAndPunctuation,
		URL,
		NumberPad,
		PhonePad,
		NamePhonePad,
		EmailAddress
	}

	public enum OnReturnKey
	{
		Default,
		Submit,
		NewLine
	}

	public delegate char OnValidate(string text, int charIndex, char addedChar);

	public static UIInput current;

	public static UIInput selection;

	public UILabel label;

	public InputType inputType;

	public OnReturnKey onReturnKey;

	public KeyboardType keyboardType;

	public bool hideInput;

	public Validation validation;

	public int characterLimit;

	public string savedAs;

	public GameObject selectOnTab;

	public Color activeTextColor = Color.white;

	public Color caretColor = new Color(1f, 1f, 1f, 0.8f);

	public Color selectionColor = new Color(1f, 0.8745098f, 47f / 85f, 0.5f);

	public List<EventDelegate> onSubmit = new List<EventDelegate>();

	public List<EventDelegate> onChange = new List<EventDelegate>();

	public OnValidate onValidate;

	public string virtualKeyboardTitleTextKey;

	public string virtualKeyboardDescTextKey;

	[SerializeField]
	[HideInInspector]
	protected string mValue;

	[NonSerialized]
	protected string mDefaultText = string.Empty;

	[NonSerialized]
	protected Color mDefaultColor = Color.white;

	[NonSerialized]
	protected float mPosition;

	[NonSerialized]
	protected bool mDoInit = true;

	[NonSerialized]
	protected UIWidget.Pivot mPivot;

	[NonSerialized]
	protected bool mLoadSavedValue = true;

	[NonSerialized]
	protected string mOSKTitleText = string.Empty;

	[NonSerialized]
	protected string mOSKDescText = string.Empty;

	protected static int mDrawStart;

	protected static string mLastIME = string.Empty;

	protected static TouchScreenKeyboard mKeyboard;

	[NonSerialized]
	protected int mSelectionStart;

	[NonSerialized]
	protected int mSelectionEnd;

	[NonSerialized]
	protected UITexture mHighlight;

	[NonSerialized]
	protected UITexture mCaret;

	[NonSerialized]
	protected Texture2D mBlankTex;

	[NonSerialized]
	protected float mNextBlink;

	[NonSerialized]
	protected float mLastAlpha;

	[NonSerialized]
	protected string mCached = string.Empty;

	[NonSerialized]
	protected int mSelectMe = -1;

	public string defaultText
	{
		get
		{
			return mDefaultText;
		}
		set
		{
			if (mDoInit)
			{
				Init();
			}
			mDefaultText = value;
			UpdateLabel();
		}
	}

	public bool inputShouldBeHidden => hideInput && (Object)(object)label != (Object)null && !label.multiLine && inputType != InputType.Password;

	[Obsolete("Use UIInput.value instead")]
	public string text
	{
		get
		{
			return value;
		}
		set
		{
			this.value = value;
		}
	}

	public string value
	{
		get
		{
			if (mDoInit)
			{
				Init();
			}
			return mValue;
		}
		set
		{
			if (mDoInit)
			{
				Init();
			}
			mDrawStart = 0;
			value = value.Replace("\\b", "\b");
			value = Validate(value);
			if (isSelected && mKeyboard != null && mCached != value)
			{
				mKeyboard.text = value;
				mCached = value;
			}
			if (!(mValue != value))
			{
				return;
			}
			mValue = value;
			mLoadSavedValue = false;
			if (isSelected)
			{
				if (string.IsNullOrEmpty(value))
				{
					mSelectionStart = 0;
					mSelectionEnd = 0;
				}
				else
				{
					mSelectionStart = value.Length;
					mSelectionEnd = mSelectionStart;
				}
			}
			else
			{
				SaveToPlayerPrefs(value);
			}
			UpdateLabel();
			ExecuteOnChange();
		}
	}

	[Obsolete("Use UIInput.isSelected instead")]
	public bool selected
	{
		get
		{
			return isSelected;
		}
		set
		{
			isSelected = value;
		}
	}

	public bool isSelected
	{
		get
		{
			return (Object)(object)selection == (Object)(object)this;
		}
		set
		{
			if (!value)
			{
				if (isSelected)
				{
					UICamera.selectedObject = null;
				}
			}
			else
			{
				UICamera.selectedObject = ((Component)this).gameObject;
			}
		}
	}

	public int cursorPosition
	{
		get
		{
			if (mKeyboard != null && !inputShouldBeHidden)
			{
				return value.Length;
			}
			return (!isSelected) ? value.Length : mSelectionEnd;
		}
		set
		{
			if (isSelected && (mKeyboard == null || inputShouldBeHidden))
			{
				mSelectionEnd = value;
				UpdateLabel();
			}
		}
	}

	public int selectionStart
	{
		get
		{
			if (mKeyboard != null && !inputShouldBeHidden)
			{
				return 0;
			}
			return (!isSelected) ? value.Length : mSelectionStart;
		}
		set
		{
			if (isSelected && (mKeyboard == null || inputShouldBeHidden))
			{
				mSelectionStart = value;
				UpdateLabel();
			}
		}
	}

	public int selectionEnd
	{
		get
		{
			if (mKeyboard != null && !inputShouldBeHidden)
			{
				return value.Length;
			}
			return (!isSelected) ? value.Length : mSelectionEnd;
		}
		set
		{
			if (isSelected && (mKeyboard == null || inputShouldBeHidden))
			{
				mSelectionEnd = value;
				UpdateLabel();
			}
		}
	}

	public UITexture caret => mCaret;

	public string Validate(string val)
	{
		if (string.IsNullOrEmpty(val))
		{
			return string.Empty;
		}
		StringBuilder stringBuilder = new StringBuilder(val.Length);
		for (int i = 0; i < val.Length; i++)
		{
			char c = val[i];
			if (onValidate != null)
			{
				c = onValidate(stringBuilder.ToString(), stringBuilder.Length, c);
			}
			else if (validation != Validation.None)
			{
				c = Validate(stringBuilder.ToString(), stringBuilder.Length, c);
			}
			if (c != 0)
			{
				stringBuilder.Append(c);
			}
		}
		if (characterLimit > 0 && stringBuilder.Length > characterLimit)
		{
			return stringBuilder.ToString(0, characterLimit);
		}
		return stringBuilder.ToString();
	}

	private void Start()
	{
		if (mLoadSavedValue && !string.IsNullOrEmpty(savedAs))
		{
			LoadValue();
		}
		else
		{
			value = mValue.Replace("\\n", "\n");
		}
	}

	protected void Init()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		if (mDoInit && (Object)(object)label != (Object)null)
		{
			mDoInit = false;
			mDefaultText = label.text;
			mDefaultColor = label.color;
			label.supportEncoding = false;
			if (label.alignment == NGUIText.Alignment.Justified)
			{
				label.alignment = NGUIText.Alignment.Left;
				Debug.LogWarning((object)"Input fields using labels with justified alignment are not supported at this time", (Object)(object)this);
			}
			if (!string.IsNullOrEmpty(virtualKeyboardTitleTextKey))
			{
				mOSKTitleText = Localization.Get(virtualKeyboardTitleTextKey);
			}
			if (!string.IsNullOrEmpty(virtualKeyboardDescTextKey))
			{
				mOSKDescText = Localization.Get(virtualKeyboardDescTextKey);
			}
			mPivot = label.pivot;
			mPosition = label.cachedTransform.localPosition.x;
			UpdateLabel();
		}
	}

	protected void SaveToPlayerPrefs(string val)
	{
		if (!string.IsNullOrEmpty(savedAs))
		{
			if (string.IsNullOrEmpty(val))
			{
				PlayerPrefs.DeleteKey(savedAs);
			}
			else
			{
				PlayerPrefs.SetString(savedAs, val);
			}
		}
	}

	protected virtual void OnSelect(bool isSelected)
	{
		if (isSelected)
		{
			OnSelectEvent();
		}
		else
		{
			OnDeselectEvent();
		}
	}

	protected void OnSelectEvent()
	{
		selection = this;
		if (mDoInit)
		{
			Init();
		}
		if ((Object)(object)label != (Object)null && NGUITools.GetActive((Behaviour)(object)this))
		{
			mSelectMe = Time.frameCount;
		}
	}

	protected void OnDeselectEvent()
	{
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		if (mDoInit)
		{
			Init();
		}
		if ((Object)(object)label != (Object)null && NGUITools.GetActive((Behaviour)(object)this))
		{
			mValue = value;
			if (mKeyboard != null)
			{
				mKeyboard.active = false;
				mKeyboard = null;
			}
			if (string.IsNullOrEmpty(mValue))
			{
				label.text = mDefaultText;
				label.color = mDefaultColor;
			}
			else
			{
				label.text = mValue;
			}
			Input.imeCompositionMode = (IMECompositionMode)0;
			RestoreLabelPivot();
		}
		selection = null;
		UpdateLabel();
	}

	private void Update()
	{
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Invalid comparison between Unknown and I4
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		if (!isSelected)
		{
			return;
		}
		if (mDoInit)
		{
			Init();
		}
		if (mSelectMe != -1 && mSelectMe != Time.frameCount)
		{
			mSelectMe = -1;
			mSelectionStart = 0;
			mSelectionEnd = ((!string.IsNullOrEmpty(mValue)) ? mValue.Length : 0);
			mDrawStart = 0;
			label.color = activeTextColor;
			if ((int)Application.platform == 8 || (int)Application.platform == 11)
			{
				TouchScreenKeyboardType val;
				if (inputShouldBeHidden)
				{
					TouchScreenKeyboard.hideInput = true;
					val = (TouchScreenKeyboardType)keyboardType;
					string text = "|";
				}
				else if (inputType == InputType.Password)
				{
					TouchScreenKeyboard.hideInput = false;
					val = (TouchScreenKeyboardType)0;
					string text = mValue;
					mSelectionStart = mSelectionEnd;
				}
				else
				{
					TouchScreenKeyboard.hideInput = false;
					val = (TouchScreenKeyboardType)keyboardType;
					string text = mValue;
					mSelectionStart = mSelectionEnd;
				}
				mKeyboard = ((inputType != InputType.Password) ? TouchScreenKeyboard.Open(string.Empty, val, !inputShouldBeHidden && inputType == InputType.AutoCorrect, label.multiLine && !hideInput, false, false, defaultText) : TouchScreenKeyboard.Open(string.Empty, val, false, false, true));
			}
			else
			{
				Vector2 compositionCursorPos = Vector2.op_Implicit((!((Object)(object)UICamera.current != (Object)null) || !((Object)(object)UICamera.current.cachedCamera != (Object)null)) ? label.worldCorners[0] : UICamera.current.cachedCamera.WorldToScreenPoint(label.worldCorners[0]));
				compositionCursorPos.y = (float)Screen.height - compositionCursorPos.y;
				Input.imeCompositionMode = (IMECompositionMode)1;
				Input.compositionCursorPos = compositionCursorPos;
			}
			UpdateLabel();
			return;
		}
		if (mKeyboard != null)
		{
			string text2 = mKeyboard.text;
			if (inputShouldBeHidden)
			{
				if (text2 != "|")
				{
					if (!string.IsNullOrEmpty(text2))
					{
						Insert(text2.Substring(1));
					}
					else
					{
						DoBackspace();
					}
					mKeyboard.text = "|";
				}
			}
			else if (mCached != text2)
			{
				mCached = text2;
				value = text2;
			}
			if (mKeyboard.done || !mKeyboard.active)
			{
				if (!mKeyboard.wasCanceled)
				{
					Submit();
				}
				mKeyboard = null;
				isSelected = false;
				mCached = string.Empty;
			}
		}
		else
		{
			if ((Object)(object)selectOnTab != (Object)null && Input.GetKeyDown((KeyCode)9))
			{
				UICamera.selectedObject = selectOnTab;
				return;
			}
			string compositionString = Input.compositionString;
			if (string.IsNullOrEmpty(compositionString) && !string.IsNullOrEmpty(Input.inputString))
			{
				string inputString = Input.inputString;
				for (int i = 0; i < inputString.Length; i++)
				{
					char c = inputString[i];
					if (c >= ' ' && c != '\uf700' && c != '\uf701' && c != '\uf702' && c != '\uf703')
					{
						Insert(c.ToString());
					}
				}
			}
			if (mLastIME != compositionString)
			{
				mSelectionEnd = ((!string.IsNullOrEmpty(compositionString)) ? (mValue.Length + compositionString.Length) : mSelectionStart);
				mLastIME = compositionString;
				UpdateLabel();
				ExecuteOnChange();
			}
		}
		if ((Object)(object)mCaret != (Object)null && mNextBlink < RealTime.time)
		{
			mNextBlink = RealTime.time + 0.5f;
			((Behaviour)mCaret).enabled = !((Behaviour)mCaret).enabled;
		}
		if (isSelected && mLastAlpha != label.finalAlpha)
		{
			UpdateLabel();
		}
	}

	protected void DoBackspace()
	{
		if (string.IsNullOrEmpty(mValue))
		{
			return;
		}
		if (mSelectionStart == mSelectionEnd)
		{
			if (mSelectionStart < 1)
			{
				return;
			}
			mSelectionEnd--;
		}
		Insert(string.Empty);
	}

	protected virtual bool ProcessEvent(Event ev)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Invalid comparison between Unknown and I4
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Invalid comparison between Unknown and I4
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Invalid comparison between Unknown and I4
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Invalid comparison between Unknown and I4
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Invalid comparison between Unknown and I4
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Expected I4, but got Unknown
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Expected I4, but got Unknown
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Expected I4, but got Unknown
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Invalid comparison between Unknown and I4
		//IL_052a: Unknown result type (might be due to invalid IL or missing references)
		//IL_052f: Unknown result type (might be due to invalid IL or missing references)
		//IL_054a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Invalid comparison between Unknown and I4
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Invalid comparison between Unknown and I4
		if ((Object)(object)label == (Object)null)
		{
			return false;
		}
		RuntimePlatform platform = Application.platform;
		bool flag = (((int)platform != 0 && (int)platform != 1 && (int)platform != 3) ? ((ev.modifiers & 2) != 0) : ((ev.modifiers & 8) != 0));
		bool flag2 = (ev.modifiers & 1) != 0;
		KeyCode keyCode = ev.keyCode;
		switch (keyCode - 271)
		{
		default:
			switch (keyCode - 97)
			{
			case 0:
				if (flag)
				{
					ev.Use();
					mSelectionStart = 0;
					mSelectionEnd = mValue.Length;
					UpdateLabel();
				}
				return true;
			case 2:
				if (flag)
				{
					ev.Use();
					NGUITools.clipboard = GetSelection();
				}
				return true;
			}
			switch (keyCode - 118)
			{
			case 0:
				if (flag)
				{
					ev.Use();
					Insert(NGUITools.clipboard);
				}
				return true;
			case 2:
				if (flag)
				{
					ev.Use();
					NGUITools.clipboard = GetSelection();
					Insert(string.Empty);
				}
				return true;
			}
			if ((int)keyCode != 8)
			{
				if ((int)keyCode != 13)
				{
					if ((int)keyCode == 127)
					{
						ev.Use();
						if (!string.IsNullOrEmpty(mValue))
						{
							if (mSelectionStart == mSelectionEnd)
							{
								if (mSelectionStart >= mValue.Length)
								{
									return true;
								}
								mSelectionEnd++;
							}
							Insert(string.Empty);
						}
						return true;
					}
					return false;
				}
				goto case 0;
			}
			ev.Use();
			DoBackspace();
			return true;
		case 5:
			ev.Use();
			if (!string.IsNullOrEmpty(mValue))
			{
				mSelectionEnd = Mathf.Max(mSelectionEnd - 1, 0);
				if (!flag2)
				{
					mSelectionStart = mSelectionEnd;
				}
				UpdateLabel();
			}
			return true;
		case 4:
			ev.Use();
			if (!string.IsNullOrEmpty(mValue))
			{
				mSelectionEnd = Mathf.Min(mSelectionEnd + 1, mValue.Length);
				if (!flag2)
				{
					mSelectionStart = mSelectionEnd;
				}
				UpdateLabel();
			}
			return true;
		case 9:
			ev.Use();
			if (!string.IsNullOrEmpty(mValue))
			{
				mSelectionEnd = 0;
				if (!flag2)
				{
					mSelectionStart = mSelectionEnd;
				}
				UpdateLabel();
			}
			return true;
		case 10:
			ev.Use();
			if (!string.IsNullOrEmpty(mValue))
			{
				mSelectionEnd = mValue.Length;
				if (!flag2)
				{
					mSelectionStart = mSelectionEnd;
				}
				UpdateLabel();
			}
			return true;
		case 7:
			ev.Use();
			if (!string.IsNullOrEmpty(mValue))
			{
				if (label.multiLine)
				{
					mSelectionEnd = label.GetCharacterIndex(mSelectionEnd, (KeyCode)278);
				}
				else
				{
					mSelectionEnd = 0;
				}
				if (!flag2)
				{
					mSelectionStart = mSelectionEnd;
				}
				UpdateLabel();
			}
			return true;
		case 8:
			ev.Use();
			if (!string.IsNullOrEmpty(mValue))
			{
				if (label.multiLine)
				{
					mSelectionEnd = label.GetCharacterIndex(mSelectionEnd, (KeyCode)279);
				}
				else
				{
					mSelectionEnd = mValue.Length;
				}
				if (!flag2)
				{
					mSelectionStart = mSelectionEnd;
				}
				UpdateLabel();
			}
			return true;
		case 2:
			ev.Use();
			if (!string.IsNullOrEmpty(mValue))
			{
				mSelectionEnd = label.GetCharacterIndex(mSelectionEnd, (KeyCode)273);
				if (mSelectionEnd != 0)
				{
					mSelectionEnd += mDrawStart;
				}
				if (!flag2)
				{
					mSelectionStart = mSelectionEnd;
				}
				UpdateLabel();
			}
			return true;
		case 3:
			ev.Use();
			if (!string.IsNullOrEmpty(mValue))
			{
				mSelectionEnd = label.GetCharacterIndex(mSelectionEnd, (KeyCode)274);
				if (mSelectionEnd != label.processedText.Length)
				{
					mSelectionEnd += mDrawStart;
				}
				else
				{
					mSelectionEnd = mValue.Length;
				}
				if (!flag2)
				{
					mSelectionStart = mSelectionEnd;
				}
				UpdateLabel();
			}
			return true;
		case 0:
			ev.Use();
			if (onReturnKey == OnReturnKey.NewLine || (onReturnKey == OnReturnKey.Default && label.multiLine && !flag && label.overflowMethod != UILabel.Overflow.ClampContent && validation == Validation.None))
			{
				Insert("\n");
			}
			else
			{
				UICamera.currentScheme = UICamera.ControlScheme.Controller;
				UICamera.currentKey = ((object)ev.keyCode/*cast due to .constrained prefix*/).ToString();
				Submit();
				UICamera.currentKey = ((object)(KeyCode)0/*cast due to .constrained prefix*/).ToString();
			}
			return true;
		}
	}

	protected virtual void Insert(string text)
	{
		string leftText = GetLeftText();
		string rightText = GetRightText();
		int length = rightText.Length;
		StringBuilder stringBuilder = new StringBuilder(leftText.Length + rightText.Length + text.Length);
		stringBuilder.Append(leftText);
		int i = 0;
		for (int length2 = text.Length; i < length2; i++)
		{
			if (characterLimit > 0 && stringBuilder.Length + length >= characterLimit)
			{
				break;
			}
			char c = text[i];
			if (onValidate != null)
			{
				c = onValidate(stringBuilder.ToString(), stringBuilder.Length, c);
			}
			else if (validation != Validation.None)
			{
				c = Validate(stringBuilder.ToString(), stringBuilder.Length, c);
			}
			if (c != 0)
			{
				stringBuilder.Append(c);
			}
		}
		mSelectionStart = stringBuilder.Length;
		mSelectionEnd = mSelectionStart;
		int j = 0;
		for (int length3 = rightText.Length; j < length3; j++)
		{
			char c2 = rightText[j];
			if (onValidate != null)
			{
				c2 = onValidate(stringBuilder.ToString(), stringBuilder.Length, c2);
			}
			else if (validation != Validation.None)
			{
				c2 = Validate(stringBuilder.ToString(), stringBuilder.Length, c2);
			}
			if (c2 != 0)
			{
				stringBuilder.Append(c2);
			}
		}
		mValue = stringBuilder.ToString();
		UpdateLabel();
		ExecuteOnChange();
	}

	protected string GetLeftText()
	{
		int num = Mathf.Min(mSelectionStart, mSelectionEnd);
		return (!string.IsNullOrEmpty(mValue) && num >= 0) ? mValue.Substring(0, num) : string.Empty;
	}

	protected string GetRightText()
	{
		int num = Mathf.Max(mSelectionStart, mSelectionEnd);
		return (!string.IsNullOrEmpty(mValue) && num < mValue.Length) ? mValue.Substring(num) : string.Empty;
	}

	protected string GetSelection()
	{
		if (string.IsNullOrEmpty(mValue) || mSelectionStart == mSelectionEnd)
		{
			return string.Empty;
		}
		int num = Mathf.Min(mSelectionStart, mSelectionEnd);
		int num2 = Mathf.Max(mSelectionStart, mSelectionEnd);
		return mValue.Substring(num, num2 - num);
	}

	protected int GetCharUnderMouse()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		Vector3[] worldCorners = label.worldCorners;
		Ray currentRay = UICamera.currentRay;
		Plane val = default(Plane);
		((Plane)(ref val))._002Ector(worldCorners[0], worldCorners[1], worldCorners[2]);
		float num = default(float);
		return ((Plane)(ref val)).Raycast(currentRay, ref num) ? (mDrawStart + label.GetCharacterIndexAtPosition(((Ray)(ref currentRay)).GetPoint(num))) : 0;
	}

	protected virtual void OnPress(bool isPressed)
	{
		if (isPressed && isSelected && (Object)(object)label != (Object)null && (UICamera.currentScheme == UICamera.ControlScheme.Mouse || UICamera.currentScheme == UICamera.ControlScheme.Touch))
		{
			selectionEnd = GetCharUnderMouse();
			if (!Input.GetKey((KeyCode)304) && !Input.GetKey((KeyCode)303))
			{
				selectionStart = mSelectionEnd;
			}
		}
	}

	protected virtual void OnDrag(Vector2 delta)
	{
		if ((Object)(object)label != (Object)null && (UICamera.currentScheme == UICamera.ControlScheme.Mouse || UICamera.currentScheme == UICamera.ControlScheme.Touch))
		{
			selectionEnd = GetCharUnderMouse();
		}
	}

	private void OnDisable()
	{
		Cleanup();
	}

	protected virtual void Cleanup()
	{
		if (Object.op_Implicit((Object)(object)mHighlight))
		{
			((Behaviour)mHighlight).enabled = false;
		}
		if (Object.op_Implicit((Object)(object)mCaret))
		{
			((Behaviour)mCaret).enabled = false;
		}
		if (Object.op_Implicit((Object)(object)mBlankTex))
		{
			NGUITools.Destroy((Object)(object)mBlankTex);
			mBlankTex = null;
		}
	}

	public void Submit()
	{
		if (NGUITools.GetActive((Behaviour)(object)this))
		{
			mValue = value;
			if ((Object)(object)current == (Object)null)
			{
				current = this;
				EventDelegate.Execute(onSubmit);
				current = null;
			}
			SaveToPlayerPrefs(mValue);
		}
	}

	public void UpdateLabel()
	{
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Expected O, but got Unknown
		//IL_0520: Unknown result type (might be due to invalid IL or missing references)
		//IL_0526: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)label != (Object)null))
		{
			return;
		}
		if (mDoInit)
		{
			Init();
		}
		bool flag = isSelected;
		string text = value;
		bool flag2 = string.IsNullOrEmpty(text) && string.IsNullOrEmpty(Input.compositionString);
		label.color = ((!flag2 || flag) ? activeTextColor : mDefaultColor);
		string text2;
		if (flag2)
		{
			text2 = ((!flag) ? mDefaultText : string.Empty);
			RestoreLabelPivot();
		}
		else
		{
			if (inputType == InputType.Password)
			{
				text2 = string.Empty;
				string text3 = "*";
				if ((Object)(object)label.bitmapFont != (Object)null && label.bitmapFont.bmFont != null && label.bitmapFont.bmFont.GetGlyph(42) == null)
				{
					text3 = "x";
				}
				int i = 0;
				for (int length = text.Length; i < length; i++)
				{
					text2 += text3;
				}
			}
			else
			{
				text2 = text;
			}
			int num = (flag ? Mathf.Min(text2.Length, cursorPosition) : 0);
			string text4 = text2.Substring(0, num);
			if (flag)
			{
				text4 += Input.compositionString;
			}
			text2 = text4 + text2.Substring(num, text2.Length - num);
			if (flag && label.overflowMethod == UILabel.Overflow.ClampContent && label.maxLineCount == 1)
			{
				int num2 = label.CalculateOffsetToFit(text2);
				if (num2 == 0)
				{
					mDrawStart = 0;
					RestoreLabelPivot();
				}
				else if (num < mDrawStart)
				{
					mDrawStart = num;
					SetPivotToLeft();
				}
				else if (num2 < mDrawStart)
				{
					mDrawStart = num2;
					SetPivotToLeft();
				}
				else
				{
					num2 = label.CalculateOffsetToFit(text2.Substring(0, num));
					if (num2 > mDrawStart)
					{
						mDrawStart = num2;
						SetPivotToRight();
					}
				}
				if (mDrawStart != 0)
				{
					text2 = text2.Substring(mDrawStart, text2.Length - mDrawStart);
				}
			}
			else
			{
				mDrawStart = 0;
				RestoreLabelPivot();
			}
		}
		label.text = text2;
		if (flag && (mKeyboard == null || inputShouldBeHidden))
		{
			int num3 = mSelectionStart - mDrawStart;
			int num4 = mSelectionEnd - mDrawStart;
			if ((Object)(object)mBlankTex == (Object)null)
			{
				mBlankTex = new Texture2D(2, 2, (TextureFormat)5, false);
				for (int j = 0; j < 2; j++)
				{
					for (int k = 0; k < 2; k++)
					{
						mBlankTex.SetPixel(k, j, Color.white);
					}
				}
				mBlankTex.Apply();
			}
			if (num3 != num4)
			{
				if ((Object)(object)mHighlight == (Object)null)
				{
					mHighlight = NGUITools.AddWidget<UITexture>(label.cachedGameObject);
					((Object)mHighlight).name = "Input Highlight";
					mHighlight.mainTexture = (Texture)(object)mBlankTex;
					mHighlight.fillGeometry = false;
					mHighlight.pivot = label.pivot;
					mHighlight.SetAnchor(label.cachedTransform);
				}
				else
				{
					mHighlight.pivot = label.pivot;
					mHighlight.mainTexture = (Texture)(object)mBlankTex;
					mHighlight.MarkAsChanged();
					((Behaviour)mHighlight).enabled = true;
				}
			}
			if ((Object)(object)mCaret == (Object)null)
			{
				mCaret = NGUITools.AddWidget<UITexture>(label.cachedGameObject);
				((Object)mCaret).name = "Input Caret";
				mCaret.mainTexture = (Texture)(object)mBlankTex;
				mCaret.fillGeometry = false;
				mCaret.pivot = label.pivot;
				mCaret.SetAnchor(label.cachedTransform);
			}
			else
			{
				mCaret.pivot = label.pivot;
				mCaret.mainTexture = (Texture)(object)mBlankTex;
				mCaret.MarkAsChanged();
				((Behaviour)mCaret).enabled = true;
			}
			if (num3 != num4)
			{
				label.PrintOverlay(num3, num4, mCaret.geometry, mHighlight.geometry, caretColor, selectionColor);
				((Behaviour)mHighlight).enabled = mHighlight.geometry.hasVertices;
			}
			else
			{
				label.PrintOverlay(num3, num4, mCaret.geometry, null, caretColor, selectionColor);
				if ((Object)(object)mHighlight != (Object)null)
				{
					((Behaviour)mHighlight).enabled = false;
				}
			}
			mNextBlink = RealTime.time + 0.5f;
			mLastAlpha = label.finalAlpha;
		}
		else
		{
			Cleanup();
		}
	}

	protected void SetPivotToLeft()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		Vector2 pivotOffset = NGUIMath.GetPivotOffset(mPivot);
		pivotOffset.x = 0f;
		label.pivot = NGUIMath.GetPivot(pivotOffset);
	}

	protected void SetPivotToRight()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		Vector2 pivotOffset = NGUIMath.GetPivotOffset(mPivot);
		pivotOffset.x = 1f;
		label.pivot = NGUIMath.GetPivot(pivotOffset);
	}

	protected void RestoreLabelPivot()
	{
		if ((Object)(object)label != (Object)null && label.pivot != mPivot)
		{
			label.pivot = mPivot;
		}
	}

	protected char Validate(string text, int pos, char ch)
	{
		if (validation == Validation.None || !((Behaviour)this).enabled)
		{
			return ch;
		}
		if (validation == Validation.Integer)
		{
			if (ch >= '0' && ch <= '9')
			{
				return ch;
			}
			if (ch == '-' && pos == 0 && !text.Contains("-"))
			{
				return ch;
			}
		}
		else if (validation == Validation.Float)
		{
			if (ch >= '0' && ch <= '9')
			{
				return ch;
			}
			if (ch == '-' && pos == 0 && !text.Contains("-"))
			{
				return ch;
			}
			if (ch == '.' && !text.Contains("."))
			{
				return ch;
			}
		}
		else if (validation == Validation.Alphanumeric)
		{
			if (ch >= 'A' && ch <= 'Z')
			{
				return ch;
			}
			if (ch >= 'a' && ch <= 'z')
			{
				return ch;
			}
			if (ch >= '0' && ch <= '9')
			{
				return ch;
			}
		}
		else if (validation == Validation.Username)
		{
			if (ch >= 'A' && ch <= 'Z')
			{
				return (char)(ch - 65 + 97);
			}
			if (ch >= 'a' && ch <= 'z')
			{
				return ch;
			}
			if (ch >= '0' && ch <= '9')
			{
				return ch;
			}
		}
		else if (validation == Validation.Name)
		{
			char c = ((text.Length <= 0) ? ' ' : text[Mathf.Clamp(pos, 0, text.Length - 1)]);
			if (char.IsLetter(ch))
			{
				return ch;
			}
			if (ch == ' ')
			{
				if (c == ' ')
				{
					return '\0';
				}
				return ch;
			}
		}
		return '\0';
	}

	protected void ExecuteOnChange()
	{
		if ((Object)(object)current == (Object)null && EventDelegate.IsValid(onChange))
		{
			current = this;
			EventDelegate.Execute(onChange);
			current = null;
		}
	}

	public void RemoveFocus()
	{
		isSelected = false;
	}

	public void SaveValue()
	{
		SaveToPlayerPrefs(mValue);
	}

	public void LoadValue()
	{
		if (!string.IsNullOrEmpty(savedAs))
		{
			string text = mValue.Replace("\\n", "\n");
			mValue = string.Empty;
			value = ((!PlayerPrefs.HasKey(savedAs)) ? text : PlayerPrefs.GetString(savedAs));
		}
	}
}
