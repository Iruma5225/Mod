using System;
using UnityEngine;

namespace GooglePlayGames.OurUtils;

public static class PlatformUtils
{
	public static bool Supported
	{
		get
		{
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			AndroidJavaClass val = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
			AndroidJavaObject val2 = ((AndroidJavaObject)val).GetStatic<AndroidJavaObject>("currentActivity");
			AndroidJavaObject val3 = val2.Call<AndroidJavaObject>("getPackageManager", new object[0]);
			AndroidJavaObject val4 = null;
			try
			{
				val4 = val3.Call<AndroidJavaObject>("getLaunchIntentForPackage", new object[1] { "com.google.android.play.games" });
			}
			catch (Exception)
			{
				return false;
			}
			return val4 != null;
		}
	}
}
