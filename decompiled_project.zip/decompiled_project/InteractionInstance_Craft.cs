using UnityEngine;

public class InteractionInstance_Craft : InteractionInstance_Base
{
	private Int_Craft interaction;

	private Obj_GhostBase ghost;

	private float craftTimeLight;

	private float craftTimeDark;

	private bool previouslyLit;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_Craft;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		Obj_Laboratory obj_Laboratory = obj_base as Obj_Laboratory;
		if ((Object)(object)obj_Laboratory != (Object)null && member.BaseStats.Intelligence.Level < 10)
		{
			member.Say(Localization.Get("text.speech.lowint"));
			return false;
		}
		ghost = ((Component)this).GetComponent<Obj_GhostBase>();
		if ((Object)(object)ghost != (Object)null)
		{
			SetProgress(member, ghost.CraftedPercentage);
		}
		float num = 1f;
		if (member.traits.HasStrength(Traits.Strength.HandsOn))
		{
			num = 0.75f;
		}
		else if (member.traits.HasWeakness(Traits.Weakness.HandsOff))
		{
			num = 1.25f;
		}
		if ((Object)(object)ghost != (Object)null)
		{
			member.TriggerAnim(ghost.craftAnimation);
			switch (ghost.craftAnimation)
			{
			case "Hammer":
				member.PlaySound(BaseCharacter.AnimSounds.Hammer, loop: true);
				break;
			case "Fix":
				member.PlaySound(BaseCharacter.AnimSounds.Blowtorch, loop: true);
				break;
			case "PickWall":
				member.PlaySound(BaseCharacter.AnimSounds.Pickaxe_Wall, loop: true);
				break;
			case "PickFloor":
				member.PlaySound(BaseCharacter.AnimSounds.Pickaxe_Floor, loop: true);
				break;
			}
		}
		else if ((Object)(object)obj_Laboratory != (Object)null)
		{
			member.TriggerAnim("Lab");
		}
		else
		{
			member.TriggerAnim("Hammer");
			member.PlaySound(BaseCharacter.AnimSounds.Hammer, loop: true);
		}
		Job current = member.job_queue.GetCurrent();
		if (current != null && current is Job_Craft job_Craft)
		{
			CraftingManager.Recipe recipe = job_Craft.GetRecipe();
			if (recipe != null)
			{
				float num2 = 0f;
				UpgradeObject component = ((Component)obj_base).GetComponent<UpgradeObject>();
				if ((Object)(object)component != (Object)null && recipe.Result == ItemManager.ItemType.Upgrade)
				{
					num2 = CraftingManager.CalculateCraftTime(component.upgradeCraftTime) * num;
				}
				else
				{
					ItemDefinition itemDefinition = ItemManager.Instance.GetItemDefinition(recipe.Result);
					if ((Object)(object)itemDefinition != (Object)null)
					{
						num2 = CraftingManager.CalculateCraftTime(itemDefinition.BaseCraftTime) * num;
					}
				}
				craftTimeLight = num2;
				craftTimeDark = num2 * 2f;
				if (member.IsInDarkness())
				{
					num2 = craftTimeDark;
					previouslyLit = false;
				}
				else
				{
					previouslyLit = true;
				}
				ModifyInteractionDuration(num2);
			}
		}
		return true;
	}

	protected override void OnInteractionUpdated()
	{
		base.OnInteractionUpdated();
		if (member.IsInDarkness() && previouslyLit)
		{
			ModifyInteractionDuration(craftTimeDark);
			previouslyLit = false;
		}
		else if (!member.IsInDarkness() && !previouslyLit)
		{
			ModifyInteractionDuration(craftTimeLight);
			previouslyLit = true;
		}
		if ((Object)(object)ghost != (Object)null)
		{
			ghost.SetConstructionPercentage(base.Progress);
		}
	}

	protected override bool OnInteractionComplete()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		member.StopSound();
		if (!base.cancelled && (Object)(object)LitterManager.Instance != (Object)null && !member.isOutside && Random.value > 0.5f)
		{
			LitterManager.Instance.DropLitter(((Component)member).transform.position, LitterManager.LitterType.Craft);
		}
		return true;
	}
}
