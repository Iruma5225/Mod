using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Pathfinding;
using Pathfinding.Util;
using UnityEngine;

[AddComponentMenu("Pathfinding/Pathfinder")]
public class AstarPath : MonoBehaviour
{
	public enum AstarDistribution
	{
		WebsiteDownload,
		AssetStore
	}

	private enum GraphUpdateOrder
	{
		GraphUpdate,
		FloodFill
	}

	private struct GUOSingle
	{
		public GraphUpdateOrder order;

		public IUpdatableGraph graph;

		public GraphUpdateObject obj;
	}

	public struct AstarWorkItem
	{
		public Action init;

		public Func<bool, bool> update;

		public AstarWorkItem(Func<bool, bool> update)
		{
			init = null;
			this.update = update;
		}

		public AstarWorkItem(Action init, Func<bool, bool> update)
		{
			this.init = init;
			this.update = update;
		}
	}

	public static readonly AstarDistribution Distribution = AstarDistribution.WebsiteDownload;

	public static readonly string Branch = "master_Pro";

	public static readonly bool HasPro = true;

	public AstarData astarData;

	public static AstarPath active = null;

	public bool showNavGraphs = true;

	public bool showUnwalkableNodes = true;

	public GraphDebugMode debugMode;

	public float debugFloor;

	public float debugRoof = 20000f;

	public bool manualDebugFloorRoof;

	public bool showSearchTree;

	public float unwalkableNodeDebugSize = 0.3f;

	public PathLog logPathResults = PathLog.Normal;

	public float maxNearestNodeDistance = 100f;

	public bool scanOnStartup = true;

	public bool fullGetNearestSearch;

	public bool prioritizeGraphs;

	public float prioritizeGraphsLimit = 1f;

	public AstarColor colorSettings;

	[SerializeField]
	protected string[] tagNames;

	public Heuristic heuristic = Heuristic.Euclidean;

	public float heuristicScale = 1f;

	public ThreadCount threadCount;

	public float maxFrameTime = 1f;

	public int minAreaSize;

	public bool limitGraphUpdates = true;

	public float maxGraphUpdateFreq = 0.2f;

	public static int PathsCompleted = 0;

	[NonSerialized]
	public float lastScanTime;

	[NonSerialized]
	public Path debugPath;

	[NonSerialized]
	public string inGameDebugPath;

	private bool graphUpdateRoutineRunning;

	private bool isRegisteredForUpdate;

	private bool workItemsQueued;

	private bool queuedWorkItemFloodFill;

	public static Action OnAwakeSettings;

	public static OnGraphDelegate OnGraphPreScan;

	public static OnGraphDelegate OnGraphPostScan;

	public static OnPathDelegate OnPathPreSearch;

	public static OnPathDelegate OnPathPostSearch;

	public static OnScanDelegate OnPreScan;

	public static OnScanDelegate OnPostScan;

	public static OnScanDelegate OnLatePostScan;

	public static OnScanDelegate OnGraphsUpdated;

	public static Action On65KOverflow;

	private static Action OnThreadSafeCallback;

	public Action OnDrawGizmosCallback;

	[Obsolete]
	public Action OnGraphsWillBeUpdated;

	[Obsolete]
	public Action OnGraphsWillBeUpdated2;

	private Queue<GraphUpdateObject> graphUpdateQueue;

	private Stack<GraphNode> floodStack;

	private ThreadControlQueue pathQueue = new ThreadControlQueue(0);

	private static Thread[] threads;

	private Thread graphUpdateThread;

	private static PathThreadInfo[] threadInfos = new PathThreadInfo[0];

	private static IEnumerator threadEnumerator;

	private static LockFreeStack pathReturnStack = new LockFreeStack();

	public EuclideanEmbedding euclideanEmbedding = new EuclideanEmbedding();

	private int nextNodeIndex = 1;

	private Stack<int> nodeIndexPool = new Stack<int>();

	private Path pathReturnPop;

	private Queue<GUOSingle> graphUpdateQueueAsync = new Queue<GUOSingle>();

	private Queue<GUOSingle> graphUpdateQueueRegular = new Queue<GUOSingle>();

	public bool showGraphs;

	public static bool isEditor = true;

	public uint lastUniqueAreaIndex;

	private static readonly object safeUpdateLock = new object();

	private AutoResetEvent graphUpdateAsyncEvent = new AutoResetEvent(initialState: false);

	private ManualResetEvent processingGraphUpdatesAsync = new ManualResetEvent(initialState: true);

	private float lastGraphUpdate = -9999f;

	private ushort nextFreePathID = 1;

	private Queue<AstarWorkItem> workItems = new Queue<AstarWorkItem>();

	private bool processingWorkItems;

	private static int waitForPathDepth = 0;

	public static Version Version => new Version(3, 7, 4);

	[Obsolete]
	public Type[] graphTypes => astarData.graphTypes;

	public NavGraph[] graphs
	{
		get
		{
			if (astarData == null)
			{
				astarData = new AstarData();
			}
			return astarData.graphs;
		}
		set
		{
			if (astarData == null)
			{
				astarData = new AstarData();
			}
			astarData.graphs = value;
		}
	}

	public float maxNearestNodeDistanceSqr => maxNearestNodeDistance * maxNearestNodeDistance;

	public PathHandler debugPathData
	{
		get
		{
			if (debugPath == null)
			{
				return null;
			}
			return debugPath.pathHandler;
		}
	}

	public bool isScanning { get; private set; }

	public static int NumParallelThreads => (threadInfos != null) ? threadInfos.Length : 0;

	public static bool IsUsingMultithreading
	{
		get
		{
			if (threads != null && threads.Length > 0)
			{
				return true;
			}
			if (threads != null && threads.Length == 0 && threadEnumerator != null)
			{
				return false;
			}
			if (Application.isPlaying)
			{
				throw new Exception("Not 'using threading' and not 'not using threading'... Are you sure pathfinding is set up correctly?\nIf scripts are reloaded in unity editor during play this could happen.\n" + ((threads == null) ? "NULL" : (string.Empty + threads.Length)) + " " + (threadEnumerator != null));
			}
			return false;
		}
	}

	public bool IsAnyGraphUpdatesQueued => graphUpdateQueue != null && graphUpdateQueue.Count > 0;

	public string[] GetTagNames()
	{
		if (tagNames == null || tagNames.Length != 32)
		{
			tagNames = new string[32];
			for (int i = 0; i < tagNames.Length; i++)
			{
				tagNames[i] = string.Empty + i;
			}
			tagNames[0] = "Basic Ground";
		}
		return tagNames;
	}

	public static string[] FindTagNames()
	{
		if ((Object)(object)active != (Object)null)
		{
			return active.GetTagNames();
		}
		AstarPath astarPath = Object.FindObjectOfType(typeof(AstarPath)) as AstarPath;
		if ((Object)(object)astarPath != (Object)null)
		{
			active = astarPath;
			return astarPath.GetTagNames();
		}
		return new string[1] { "There is no AstarPath component in the scene" };
	}

	public ushort GetNextPathID()
	{
		if (nextFreePathID == 0)
		{
			nextFreePathID++;
			Debug.Log((object)"65K cleanup");
			if (On65KOverflow != null)
			{
				Action on65KOverflow = On65KOverflow;
				On65KOverflow = null;
				on65KOverflow();
			}
		}
		return nextFreePathID++;
	}

	private void OnDrawGizmos()
	{
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)active == (Object)null)
		{
			active = this;
		}
		else if ((Object)(object)active != (Object)(object)this)
		{
			return;
		}
		if (graphs == null || (pathQueue != null && pathQueue.AllReceiversBlocked && workItems.Count > 0))
		{
			return;
		}
		if (showNavGraphs && !manualDebugFloorRoof)
		{
			debugFloor = float.PositiveInfinity;
			debugRoof = float.NegativeInfinity;
			for (int i = 0; i < graphs.Length; i++)
			{
				if (graphs[i] == null || !graphs[i].drawGizmos)
				{
					continue;
				}
				graphs[i].GetNodes(delegate(GraphNode node)
				{
					if (!active.showSearchTree || debugPathData == null || NavGraph.InSearchTree(node, debugPath))
					{
						Pathfinding.PathNode pathNode = ((debugPathData == null) ? null : debugPathData.GetPathNode(node));
						if (pathNode != null || debugMode == GraphDebugMode.Penalty)
						{
							switch (debugMode)
							{
							case GraphDebugMode.F:
								debugFloor = Mathf.Min(debugFloor, (float)pathNode.F);
								debugRoof = Mathf.Max(debugRoof, (float)pathNode.F);
								break;
							case GraphDebugMode.G:
								debugFloor = Mathf.Min(debugFloor, (float)pathNode.G);
								debugRoof = Mathf.Max(debugRoof, (float)pathNode.G);
								break;
							case GraphDebugMode.H:
								debugFloor = Mathf.Min(debugFloor, (float)pathNode.H);
								debugRoof = Mathf.Max(debugRoof, (float)pathNode.H);
								break;
							case GraphDebugMode.Penalty:
								debugFloor = Mathf.Min(debugFloor, (float)node.Penalty);
								debugRoof = Mathf.Max(debugRoof, (float)node.Penalty);
								break;
							}
						}
					}
					return true;
				});
			}
			if (float.IsInfinity(debugFloor))
			{
				debugFloor = 0f;
				debugRoof = 1f;
			}
			if (debugRoof - debugFloor < 1f)
			{
				debugRoof += 1f;
			}
		}
		for (int num = 0; num < graphs.Length; num++)
		{
			if (graphs[num] != null && graphs[num].drawGizmos)
			{
				graphs[num].OnDrawGizmos(showNavGraphs);
			}
		}
		if (showNavGraphs)
		{
			euclideanEmbedding.OnDrawGizmos();
		}
		if (showUnwalkableNodes && showNavGraphs)
		{
			Gizmos.color = AstarColor.UnwalkableNode;
			GraphNodeDelegateCancelable del = DrawUnwalkableNode;
			for (int num2 = 0; num2 < graphs.Length; num2++)
			{
				if (graphs[num2] != null && graphs[num2].drawGizmos)
				{
					graphs[num2].GetNodes(del);
				}
			}
		}
		if (OnDrawGizmosCallback != null)
		{
			OnDrawGizmosCallback();
		}
	}

	private bool DrawUnwalkableNode(GraphNode node)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		if (!node.Walkable)
		{
			Gizmos.DrawCube((Vector3)node.position, Vector3.one * unwalkableNodeDebugSize);
		}
		return true;
	}

	private void OnGUI()
	{
	}

	private static void AstarLog(string s)
	{
		if (object.ReferenceEquals(active, null))
		{
			Debug.Log((object)("No AstarPath object was found : " + s));
		}
		else if (active.logPathResults != PathLog.None && active.logPathResults != PathLog.OnlyErrors)
		{
			Debug.Log((object)s);
		}
	}

	private static void AstarLogError(string s)
	{
		if ((Object)(object)active == (Object)null)
		{
			Debug.Log((object)("No AstarPath object was found : " + s));
		}
		else if (active.logPathResults != PathLog.None)
		{
			Debug.LogError((object)s);
		}
	}

	private void LogPathResults(Path p)
	{
		if (logPathResults != PathLog.None && (logPathResults != PathLog.OnlyErrors || p.error))
		{
			string text = p.DebugString(logPathResults);
			if (logPathResults == PathLog.InGame)
			{
				inGameDebugPath = text;
			}
			else
			{
				Debug.Log((object)text);
			}
		}
	}

	private void Update()
	{
		PerformBlockingActions();
		if (threadEnumerator != null)
		{
			try
			{
				threadEnumerator.MoveNext();
			}
			catch (Exception ex)
			{
				threadEnumerator = null;
				if (!(ex is ThreadControlQueue.QueueTerminationException))
				{
					Debug.LogException(ex);
					Debug.LogError((object)"Unhandled exception during pathfinding. Terminating.");
					pathQueue.TerminateReceivers();
					try
					{
						pathQueue.PopNoBlock(blockedBefore: false);
					}
					catch
					{
					}
				}
			}
		}
		ReturnPaths(timeSlice: true);
	}

	private void PerformBlockingActions(bool force = false, bool unblockOnComplete = true)
	{
		if (!pathQueue.AllReceiversBlocked)
		{
			return;
		}
		ReturnPaths(timeSlice: false);
		if (OnThreadSafeCallback != null)
		{
			Action onThreadSafeCallback = OnThreadSafeCallback;
			OnThreadSafeCallback = null;
			onThreadSafeCallback();
		}
		if (ProcessWorkItems(force) != 2)
		{
			return;
		}
		workItemsQueued = false;
		if (unblockOnComplete)
		{
			if (euclideanEmbedding.dirty)
			{
				euclideanEmbedding.RecalculateCosts();
			}
			pathQueue.Unblock();
		}
	}

	public void QueueWorkItemFloodFill()
	{
		if (!pathQueue.AllReceiversBlocked)
		{
			throw new Exception("You are calling QueueWorkItemFloodFill from outside a WorkItem. This might cause unexpected behaviour.");
		}
		queuedWorkItemFloodFill = true;
	}

	public void EnsureValidFloodFill()
	{
		if (queuedWorkItemFloodFill)
		{
			FloodFill();
		}
	}

	public void AddWorkItem(AstarWorkItem itm)
	{
		workItems.Enqueue(itm);
		if (!workItemsQueued)
		{
			workItemsQueued = true;
			if (!isScanning)
			{
				InterruptPathfinding();
			}
		}
	}

	private int ProcessWorkItems(bool force)
	{
		if (pathQueue.AllReceiversBlocked)
		{
			if (processingWorkItems)
			{
				throw new Exception("Processing work items recursively. Please do not wait for other work items to be completed inside work items. If you think this is not caused by any of your scripts, this might be a bug.");
			}
			processingWorkItems = true;
			while (workItems.Count > 0)
			{
				AstarWorkItem astarWorkItem = workItems.Peek();
				if (astarWorkItem.init != null)
				{
					astarWorkItem.init();
					astarWorkItem.init = null;
				}
				bool flag;
				try
				{
					flag = astarWorkItem.update == null || astarWorkItem.update(force);
				}
				catch
				{
					workItems.Dequeue();
					processingWorkItems = false;
					throw;
				}
				if (!flag)
				{
					if (force)
					{
						Debug.LogError((object)"Misbehaving WorkItem. 'force'=true but the work item did not complete.\nIf force=true is passed to a WorkItem it should always return true.");
					}
					processingWorkItems = false;
					return 1;
				}
				workItems.Dequeue();
			}
			EnsureValidFloodFill();
			processingWorkItems = false;
			return 2;
		}
		return 0;
	}

	public void QueueGraphUpdates()
	{
		if (!isRegisteredForUpdate)
		{
			isRegisteredForUpdate = true;
			AddWorkItem(new AstarWorkItem
			{
				init = QueueGraphUpdatesInternal,
				update = ProcessGraphUpdates
			});
		}
	}

	private IEnumerator DelayedGraphUpdate()
	{
		graphUpdateRoutineRunning = true;
		yield return (object)new WaitForSeconds(maxGraphUpdateFreq - (Time.time - lastGraphUpdate));
		QueueGraphUpdates();
		graphUpdateRoutineRunning = false;
	}

	public void UpdateGraphs(Bounds bounds, float t)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		UpdateGraphs(new GraphUpdateObject(bounds), t);
	}

	public void UpdateGraphs(GraphUpdateObject ob, float t)
	{
		((MonoBehaviour)this).StartCoroutine(UpdateGraphsInteral(ob, t));
	}

	private IEnumerator UpdateGraphsInteral(GraphUpdateObject ob, float t)
	{
		yield return (object)new WaitForSeconds(t);
		UpdateGraphs(ob);
	}

	public void UpdateGraphs(Bounds bounds)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		UpdateGraphs(new GraphUpdateObject(bounds));
	}

	public void UpdateGraphs(GraphUpdateObject ob)
	{
		if (graphUpdateQueue == null)
		{
			graphUpdateQueue = new Queue<GraphUpdateObject>();
		}
		graphUpdateQueue.Enqueue(ob);
		if (limitGraphUpdates && Time.time - lastGraphUpdate < maxGraphUpdateFreq)
		{
			if (!graphUpdateRoutineRunning)
			{
				((MonoBehaviour)this).StartCoroutine(DelayedGraphUpdate());
			}
		}
		else
		{
			QueueGraphUpdates();
		}
	}

	public void FlushGraphUpdates()
	{
		if (IsAnyGraphUpdatesQueued)
		{
			QueueGraphUpdates();
			FlushWorkItems(unblockOnComplete: true, block: true);
		}
	}

	public void FlushWorkItems(bool unblockOnComplete = true, bool block = false)
	{
		BlockUntilPathQueueBlocked();
		PerformBlockingActions(block, unblockOnComplete);
	}

	private void QueueGraphUpdatesInternal()
	{
		isRegisteredForUpdate = false;
		bool flag = false;
		while (graphUpdateQueue.Count > 0)
		{
			GraphUpdateObject graphUpdateObject = graphUpdateQueue.Dequeue();
			if (graphUpdateObject.requiresFloodFill)
			{
				flag = true;
			}
			foreach (IUpdatableGraph updateableGraph in astarData.GetUpdateableGraphs())
			{
				NavGraph graph = updateableGraph as NavGraph;
				if (graphUpdateObject.nnConstraint == null || graphUpdateObject.nnConstraint.SuitableGraph(active.astarData.GetGraphIndex(graph), graph))
				{
					GUOSingle item = new GUOSingle
					{
						order = GraphUpdateOrder.GraphUpdate,
						obj = graphUpdateObject,
						graph = updateableGraph
					};
					graphUpdateQueueRegular.Enqueue(item);
				}
			}
		}
		if (flag)
		{
			GUOSingle item2 = new GUOSingle
			{
				order = GraphUpdateOrder.FloodFill
			};
			graphUpdateQueueRegular.Enqueue(item2);
		}
		debugPath = null;
		GraphModifier.TriggerEvent(GraphModifier.EventType.PreUpdate);
	}

	private bool ProcessGraphUpdates(bool force)
	{
		if (force)
		{
			processingGraphUpdatesAsync.WaitOne();
		}
		else if (!processingGraphUpdatesAsync.WaitOne(0))
		{
			return false;
		}
		if (graphUpdateQueueAsync.Count != 0)
		{
			throw new Exception("Queue should be empty at this stage");
		}
		while (graphUpdateQueueRegular.Count > 0)
		{
			GUOSingle item = graphUpdateQueueRegular.Peek();
			GraphUpdateThreading graphUpdateThreading = ((item.order == GraphUpdateOrder.FloodFill) ? GraphUpdateThreading.SeparateThread : item.graph.CanUpdateAsync(item.obj));
			bool flag = force;
			if (!Application.isPlaying || graphUpdateThread == null || !graphUpdateThread.IsAlive)
			{
				flag = true;
			}
			if (!flag && graphUpdateThreading == GraphUpdateThreading.SeparateAndUnityInit)
			{
				if (graphUpdateQueueAsync.Count > 0)
				{
					processingGraphUpdatesAsync.Reset();
					graphUpdateAsyncEvent.Set();
					return false;
				}
				item.graph.UpdateAreaInit(item.obj);
				graphUpdateQueueRegular.Dequeue();
				graphUpdateQueueAsync.Enqueue(item);
				processingGraphUpdatesAsync.Reset();
				graphUpdateAsyncEvent.Set();
				return false;
			}
			if (!flag && graphUpdateThreading == GraphUpdateThreading.SeparateThread)
			{
				graphUpdateQueueRegular.Dequeue();
				graphUpdateQueueAsync.Enqueue(item);
				continue;
			}
			if (graphUpdateQueueAsync.Count > 0)
			{
				if (force)
				{
					throw new Exception("This should not happen");
				}
				processingGraphUpdatesAsync.Reset();
				graphUpdateAsyncEvent.Set();
				return false;
			}
			graphUpdateQueueRegular.Dequeue();
			if (item.order == GraphUpdateOrder.FloodFill)
			{
				FloodFill();
				continue;
			}
			if (graphUpdateThreading == GraphUpdateThreading.SeparateAndUnityInit)
			{
				try
				{
					item.graph.UpdateAreaInit(item.obj);
				}
				catch (Exception ex)
				{
					Debug.LogError((object)("Error while initializing GraphUpdates\n" + ex));
				}
			}
			try
			{
				item.graph.UpdateArea(item.obj);
			}
			catch (Exception ex2)
			{
				Debug.LogError((object)("Error while updating graphs\n" + ex2));
			}
		}
		if (graphUpdateQueueAsync.Count > 0)
		{
			processingGraphUpdatesAsync.Reset();
			graphUpdateAsyncEvent.Set();
			return false;
		}
		GraphModifier.TriggerEvent(GraphModifier.EventType.PostUpdate);
		if (OnGraphsUpdated != null)
		{
			OnGraphsUpdated(this);
		}
		return true;
	}

	private void ProcessGraphUpdatesAsync(object _astar)
	{
		AstarPath astarPath = _astar as AstarPath;
		if (object.ReferenceEquals(astarPath, null))
		{
			Debug.LogError((object)"ProcessGraphUpdatesAsync started with invalid parameter _astar (was no AstarPath object)");
			return;
		}
		while (!astarPath.pathQueue.IsTerminating)
		{
			graphUpdateAsyncEvent.WaitOne();
			if (astarPath.pathQueue.IsTerminating)
			{
				graphUpdateQueueAsync.Clear();
				processingGraphUpdatesAsync.Set();
				break;
			}
			while (graphUpdateQueueAsync.Count > 0)
			{
				GUOSingle gUOSingle = graphUpdateQueueAsync.Dequeue();
				try
				{
					if (gUOSingle.order == GraphUpdateOrder.GraphUpdate)
					{
						gUOSingle.graph.UpdateArea(gUOSingle.obj);
						continue;
					}
					if (gUOSingle.order == GraphUpdateOrder.FloodFill)
					{
						astarPath.FloodFill();
						continue;
					}
					throw new NotSupportedException(string.Empty + gUOSingle.order);
				}
				catch (Exception ex)
				{
					Debug.LogError((object)("Exception while updating graphs:\n" + ex));
				}
			}
			processingGraphUpdatesAsync.Set();
		}
	}

	public void FlushThreadSafeCallbacks()
	{
		if (OnThreadSafeCallback != null)
		{
			BlockUntilPathQueueBlocked();
			PerformBlockingActions();
		}
	}

	[ContextMenu("Log Profiler")]
	public void LogProfiler()
	{
	}

	[ContextMenu("Reset Profiler")]
	public void ResetProfiler()
	{
	}

	public static int CalculateThreadCount(ThreadCount count)
	{
		if (count == ThreadCount.AutomaticLowLoad || count == ThreadCount.AutomaticHighLoad)
		{
			int num = Mathf.Max(1, SystemInfo.processorCount);
			int num2 = SystemInfo.systemMemorySize;
			if (num2 <= 0)
			{
				Debug.LogError((object)"Machine reporting that is has <= 0 bytes of RAM. This is definitely not true, assuming 1 GiB");
				num2 = 1024;
			}
			if (num <= 1)
			{
				return 0;
			}
			if (num2 <= 512)
			{
				return 0;
			}
			if (count == ThreadCount.AutomaticHighLoad)
			{
				if (num2 <= 1024)
				{
					num = Math.Min(num, 2);
				}
			}
			else
			{
				num /= 2;
				num = Mathf.Max(1, num);
				if (num2 <= 1024)
				{
					num = Math.Min(num, 2);
				}
				num = Math.Min(num, 6);
			}
			return num;
		}
		return (int)count;
	}

	private void Awake()
	{
		if ((Object)(object)active == (Object)null)
		{
			active = this;
		}
		else if ((Object)(object)active != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
			return;
		}
		((MonoBehaviour)this).useGUILayout = false;
		isEditor = Application.isEditor;
		if (OnAwakeSettings != null)
		{
			OnAwakeSettings();
		}
		int num = CalculateThreadCount(threadCount);
		threads = new Thread[num];
		threadInfos = new PathThreadInfo[Math.Max(num, 1)];
		pathQueue = new ThreadControlQueue(threadInfos.Length);
		for (int i = 0; i < threadInfos.Length; i++)
		{
			ref PathThreadInfo reference = ref threadInfos[i];
			reference = new PathThreadInfo(i, this, new PathHandler(i, threadInfos.Length));
		}
		if (num == 0)
		{
			threadEnumerator = CalculatePaths(threadInfos[0]);
		}
		else
		{
			threadEnumerator = null;
		}
		for (int j = 0; j < threads.Length; j++)
		{
			threads[j] = new Thread(CalculatePathsThreaded);
			threads[j].Name = "Pathfinding Thread " + j;
			threads[j].IsBackground = true;
		}
		for (int k = 0; k < threads.Length; k++)
		{
			if (logPathResults == PathLog.Heavy)
			{
				Debug.Log((object)("Starting pathfinding thread " + k));
			}
			threads[k].Start(threadInfos[k]);
		}
		if (num != 0)
		{
			graphUpdateThread = new Thread(ProcessGraphUpdatesAsync);
			graphUpdateThread.IsBackground = true;
			graphUpdateThread.Priority = ThreadPriority.Lowest;
			graphUpdateThread.Start(this);
		}
		Initialize();
		FlushWorkItems();
		euclideanEmbedding.dirty = true;
		if (scanOnStartup && (!astarData.cacheStartup || (Object)(object)astarData.file_cachedStartup == (Object)null))
		{
			Scan();
		}
	}

	internal void VerifyIntegrity()
	{
		if ((Object)(object)active != (Object)(object)this)
		{
			throw new Exception("Singleton pattern broken. Make sure you only have one AstarPath object in the scene");
		}
		if (astarData == null)
		{
			throw new NullReferenceException("AstarData is null... Astar not set up correctly?");
		}
		if (astarData.graphs == null)
		{
			astarData.graphs = new NavGraph[0];
		}
		if (pathQueue == null && !Application.isPlaying)
		{
			pathQueue = new ThreadControlQueue(0);
		}
		if (threadInfos == null && !Application.isPlaying)
		{
			threadInfos = new PathThreadInfo[0];
		}
		if (!IsUsingMultithreading)
		{
		}
	}

	public void SetUpReferences()
	{
		active = this;
		if (astarData == null)
		{
			astarData = new AstarData();
		}
		if (colorSettings == null)
		{
			colorSettings = new AstarColor();
		}
		colorSettings.OnEnable();
	}

	private void Initialize()
	{
		SetUpReferences();
		astarData.FindGraphTypes();
		astarData.Awake();
		astarData.UpdateShortcuts();
		for (int i = 0; i < astarData.graphs.Length; i++)
		{
			if (astarData.graphs[i] != null)
			{
				astarData.graphs[i].Awake();
			}
		}
	}

	private void OnDestroy()
	{
		if (logPathResults == PathLog.Heavy)
		{
			Debug.Log((object)"+++ AstarPath Component Destroyed - Cleaning Up Pathfinding Data +++");
		}
		if ((Object)(object)active != (Object)(object)this)
		{
			return;
		}
		BlockUntilPathQueueBlocked();
		euclideanEmbedding.dirty = false;
		FlushWorkItems(unblockOnComplete: false, block: true);
		pathQueue.TerminateReceivers();
		if (logPathResults == PathLog.Heavy)
		{
			Debug.Log((object)"Processing Eventual Work Items");
		}
		graphUpdateAsyncEvent.Set();
		if (threads != null)
		{
			for (int i = 0; i < threads.Length; i++)
			{
				if (!threads[i].Join(50))
				{
					Debug.LogError((object)("Could not terminate pathfinding thread[" + i + "] in 50ms, trying Thread.Abort"));
					threads[i].Abort();
				}
			}
		}
		if (logPathResults == PathLog.Heavy)
		{
			Debug.Log((object)"Returning Paths");
		}
		ReturnPaths(timeSlice: false);
		pathReturnStack.PopAll();
		if (logPathResults == PathLog.Heavy)
		{
			Debug.Log((object)"Destroying Graphs");
		}
		astarData.OnDestroy();
		if (logPathResults == PathLog.Heavy)
		{
			Debug.Log((object)"Cleaning up variables");
		}
		floodStack = null;
		graphUpdateQueue = null;
		OnDrawGizmosCallback = null;
		OnAwakeSettings = null;
		OnGraphPreScan = null;
		OnGraphPostScan = null;
		OnPathPreSearch = null;
		OnPathPostSearch = null;
		OnPreScan = null;
		OnPostScan = null;
		OnLatePostScan = null;
		On65KOverflow = null;
		OnGraphsUpdated = null;
		OnThreadSafeCallback = null;
		threads = null;
		threadInfos = null;
		PathsCompleted = 0;
		active = null;
	}

	public void FloodFill(GraphNode seed)
	{
		FloodFill(seed, lastUniqueAreaIndex + 1);
		lastUniqueAreaIndex++;
	}

	public void FloodFill(GraphNode seed, uint area)
	{
		if (area > 131071)
		{
			Debug.LogError((object)("Too high area index - The maximum area index is " + 131071u));
			return;
		}
		if (area < 0)
		{
			Debug.LogError((object)"Too low area index - The minimum area index is 0");
			return;
		}
		if (floodStack == null)
		{
			floodStack = new Stack<GraphNode>(1024);
		}
		Stack<GraphNode> stack = floodStack;
		stack.Clear();
		stack.Push(seed);
		seed.Area = area;
		while (stack.Count > 0)
		{
			stack.Pop().FloodFill(stack, area);
		}
	}

	[ContextMenu("Flood Fill Graphs")]
	public void FloodFill()
	{
		queuedWorkItemFloodFill = false;
		if (astarData.graphs == null)
		{
			return;
		}
		uint area = 0u;
		lastUniqueAreaIndex = 0u;
		if (floodStack == null)
		{
			floodStack = new Stack<GraphNode>(1024);
		}
		Stack<GraphNode> stack = floodStack;
		for (int i = 0; i < graphs.Length; i++)
		{
			graphs[i]?.GetNodes(delegate(GraphNode node)
			{
				node.Area = 0u;
				return true;
			});
		}
		int smallAreasDetected = 0;
		bool warnAboutAreas = false;
		List<GraphNode> smallAreaList = ListPool<GraphNode>.Claim();
		for (int num = 0; num < graphs.Length; num++)
		{
			NavGraph navGraph = graphs[num];
			if (navGraph == null)
			{
				continue;
			}
			GraphNodeDelegateCancelable del = delegate(GraphNode node)
			{
				if (node.Walkable && node.Area == 0)
				{
					area++;
					uint num2 = area;
					if (area > 131071)
					{
						if (smallAreaList.Count > 0)
						{
							GraphNode graphNode = smallAreaList[smallAreaList.Count - 1];
							num2 = graphNode.Area;
							smallAreaList.RemoveAt(smallAreaList.Count - 1);
							stack.Clear();
							stack.Push(graphNode);
							graphNode.Area = 131071u;
							while (stack.Count > 0)
							{
								stack.Pop().FloodFill(stack, 131071u);
							}
							smallAreasDetected++;
						}
						else
						{
							area--;
							num2 = area;
							warnAboutAreas = true;
						}
					}
					stack.Clear();
					stack.Push(node);
					int num3 = 1;
					node.Area = num2;
					while (stack.Count > 0)
					{
						num3++;
						stack.Pop().FloodFill(stack, num2);
					}
					if (num3 < minAreaSize)
					{
						smallAreaList.Add(node);
					}
				}
				return true;
			};
			navGraph.GetNodes(del);
		}
		lastUniqueAreaIndex = area;
		if (warnAboutAreas)
		{
			Debug.LogError((object)("Too many areas - The maximum number of areas is " + 131071u + ". Try raising the A* Inspector -> Settings -> Min Area Size value. Enable the optimization ASTAR_MORE_AREAS under the Optimizations tab."));
		}
		if (smallAreasDetected > 0)
		{
			AstarLog(smallAreasDetected + " small areas were detected (fewer than " + minAreaSize + " nodes),these might have the same IDs as other areas, but it shouldn't affect pathfinding in any significant way (you might get All Nodes Searched as a reason for path failure).\nWhich areas are defined as 'small' is controlled by the 'Min Area Size' variable, it can be changed in the A* inspector-->Settings-->Min Area Size\nThe small areas will use the area id " + 131071u);
		}
		ListPool<GraphNode>.Release(smallAreaList);
	}

	public int GetNewNodeIndex()
	{
		if (nodeIndexPool.Count > 0)
		{
			return nodeIndexPool.Pop();
		}
		return nextNodeIndex++;
	}

	public void InitializeNode(GraphNode node)
	{
		if (!pathQueue.AllReceiversBlocked)
		{
			throw new Exception("Trying to initialize a node when it is not safe to initialize any nodes. Must be done during a graph update");
		}
		if (threadInfos == null)
		{
			threadInfos = new PathThreadInfo[0];
		}
		for (int i = 0; i < threadInfos.Length; i++)
		{
			threadInfos[i].runData.InitializeNode(node);
		}
	}

	public void DestroyNode(GraphNode node)
	{
		if (node.NodeIndex != -1)
		{
			nodeIndexPool.Push(node.NodeIndex);
			if (threadInfos == null)
			{
				threadInfos = new PathThreadInfo[0];
			}
			for (int i = 0; i < threadInfos.Length; i++)
			{
				threadInfos[i].runData.DestroyNode(node);
			}
		}
	}

	public void BlockUntilPathQueueBlocked()
	{
		if (pathQueue == null)
		{
			return;
		}
		pathQueue.Block();
		while (!pathQueue.AllReceiversBlocked)
		{
			if (IsUsingMultithreading)
			{
				Thread.Sleep(1);
			}
			else
			{
				threadEnumerator.MoveNext();
			}
		}
	}

	public void Scan()
	{
		ScanLoop(null);
	}

	public void ScanLoop(OnScanStatus statusCallback)
	{
		if (graphs == null)
		{
			return;
		}
		isScanning = true;
		euclideanEmbedding.dirty = false;
		VerifyIntegrity();
		BlockUntilPathQueueBlocked();
		if (!Application.isPlaying)
		{
			GraphModifier.FindAllModifiers();
			RelevantGraphSurface.FindAllGraphSurfaces();
		}
		RelevantGraphSurface.UpdateAllPositions();
		astarData.UpdateShortcuts();
		if (statusCallback != null)
		{
			statusCallback(new Progress(0.05f, "Pre processing graphs"));
		}
		if (OnPreScan != null)
		{
			OnPreScan(this);
		}
		GraphModifier.TriggerEvent(GraphModifier.EventType.PreScan);
		DateTime utcNow = DateTime.UtcNow;
		for (int i = 0; i < graphs.Length; i++)
		{
			if (graphs[i] != null)
			{
				graphs[i].GetNodes(delegate(GraphNode node)
				{
					node.Destroy();
					return true;
				});
			}
		}
		for (int i2 = 0; i2 < graphs.Length; i2++)
		{
			NavGraph navGraph = graphs[i2];
			if (navGraph == null)
			{
				if (statusCallback != null)
				{
					statusCallback(new Progress(AstarMath.MapTo(0.05f, 0.7f, ((float)i2 + 0.5f) / (float)(graphs.Length + 1)), "Skipping graph " + (i2 + 1) + " of " + graphs.Length + " because it is null"));
				}
				continue;
			}
			if (OnGraphPreScan != null)
			{
				if (statusCallback != null)
				{
					statusCallback(new Progress(AstarMath.MapToRange(0.1f, 0.7f, (float)i2 / (float)graphs.Length), "Scanning graph " + (i2 + 1) + " of " + graphs.Length + " - Pre processing"));
				}
				OnGraphPreScan(navGraph);
			}
			float minp = AstarMath.MapToRange(0.1f, 0.7f, (float)i2 / (float)graphs.Length);
			float maxp = AstarMath.MapToRange(0.1f, 0.7f, ((float)i2 + 0.95f) / (float)graphs.Length);
			if (statusCallback != null)
			{
				statusCallback(new Progress(minp, "Scanning graph " + (i2 + 1) + " of " + graphs.Length));
			}
			OnScanStatus statusCallback2 = null;
			if (statusCallback != null)
			{
				statusCallback2 = delegate(Progress p)
				{
					p.progress = AstarMath.MapToRange(minp, maxp, p.progress);
					statusCallback(p);
				};
			}
			navGraph.ScanInternal(statusCallback2);
			navGraph.GetNodes(delegate(GraphNode node)
			{
				node.GraphIndex = (uint)i2;
				return true;
			});
			if (OnGraphPostScan != null)
			{
				if (statusCallback != null)
				{
					statusCallback(new Progress(AstarMath.MapToRange(0.1f, 0.7f, ((float)i2 + 0.95f) / (float)graphs.Length), "Scanning graph " + (i2 + 1) + " of " + graphs.Length + " - Post processing"));
				}
				OnGraphPostScan(navGraph);
			}
		}
		if (statusCallback != null)
		{
			statusCallback(new Progress(0.8f, "Post processing graphs"));
		}
		if (OnPostScan != null)
		{
			OnPostScan(this);
		}
		GraphModifier.TriggerEvent(GraphModifier.EventType.PostScan);
		try
		{
			FlushWorkItems(unblockOnComplete: false, block: true);
		}
		catch (Exception ex)
		{
			Debug.LogException(ex);
		}
		isScanning = false;
		if (statusCallback != null)
		{
			statusCallback(new Progress(0.9f, "Computing areas"));
		}
		FloodFill();
		VerifyIntegrity();
		if (statusCallback != null)
		{
			statusCallback(new Progress(0.95f, "Late post processing"));
		}
		if (OnLatePostScan != null)
		{
			OnLatePostScan(this);
		}
		GraphModifier.TriggerEvent(GraphModifier.EventType.LatePostScan);
		euclideanEmbedding.dirty = true;
		euclideanEmbedding.RecalculatePivots();
		PerformBlockingActions(force: true);
		lastScanTime = (float)(DateTime.UtcNow - utcNow).TotalSeconds;
		GC.Collect();
		AstarLog("Scanning - Process took " + (lastScanTime * 1000f).ToString("0") + " ms to complete");
	}

	public static void WaitForPath(Path p)
	{
		if ((Object)(object)active == (Object)null)
		{
			throw new Exception("Pathfinding is not correctly initialized in this scene (yet?). AstarPath.active is null.\nDo not call this function in Awake");
		}
		if (p == null)
		{
			throw new ArgumentNullException("Path must not be null");
		}
		if (active.pathQueue.IsTerminating)
		{
			return;
		}
		if (p.GetState() == PathState.Created)
		{
			throw new Exception("The specified path has not been started yet.");
		}
		waitForPathDepth++;
		if (waitForPathDepth == 5)
		{
			Debug.LogError((object)"You are calling the WaitForPath function recursively (maybe from a path callback). Please don't do this.");
		}
		if (p.GetState() < PathState.ReturnQueue)
		{
			if (IsUsingMultithreading)
			{
				while (p.GetState() < PathState.ReturnQueue)
				{
					if (active.pathQueue.IsTerminating)
					{
						waitForPathDepth--;
						throw new Exception("Pathfinding Threads seems to have crashed.");
					}
					Thread.Sleep(1);
					active.PerformBlockingActions();
				}
			}
			else
			{
				while (p.GetState() < PathState.ReturnQueue)
				{
					if (active.pathQueue.IsEmpty && p.GetState() != PathState.Processing)
					{
						waitForPathDepth--;
						throw new Exception(string.Concat("Critical error. Path Queue is empty but the path state is '", p.GetState(), "'"));
					}
					threadEnumerator.MoveNext();
					active.PerformBlockingActions();
				}
			}
		}
		active.ReturnPaths(timeSlice: false);
		waitForPathDepth--;
	}

	[Obsolete("The threadSafe parameter has been deprecated")]
	public static void RegisterSafeUpdate(Action callback, bool threadSafe)
	{
		RegisterSafeUpdate(callback);
	}

	public static void RegisterSafeUpdate(Action callback)
	{
		if (callback == null || !Application.isPlaying)
		{
			return;
		}
		if (active.pathQueue.AllReceiversBlocked)
		{
			active.pathQueue.Lock();
			try
			{
				if (active.pathQueue.AllReceiversBlocked)
				{
					callback();
					return;
				}
			}
			finally
			{
				active.pathQueue.Unlock();
			}
		}
		lock (safeUpdateLock)
		{
			OnThreadSafeCallback = (Action)Delegate.Combine(OnThreadSafeCallback, callback);
		}
		active.pathQueue.Block();
	}

	private void InterruptPathfinding()
	{
		pathQueue.Block();
	}

	public static void StartPath(Path p, bool pushToFront = false)
	{
		if (object.ReferenceEquals(active, null))
		{
			Debug.LogError((object)"There is no AstarPath object in the scene");
			return;
		}
		if (p.GetState() != PathState.Created)
		{
			throw new Exception(string.Concat("The path has an invalid state. Expected ", PathState.Created, " found ", p.GetState(), "\nMake sure you are not requesting the same path twice"));
		}
		if (active.pathQueue.IsTerminating)
		{
			p.Error();
			return;
		}
		if (active.graphs == null || active.graphs.Length == 0)
		{
			Debug.LogError((object)"There are no graphs in the scene");
			p.Error();
			Debug.LogError((object)p.errorLog);
			return;
		}
		p.Claim(active);
		p.AdvanceState(PathState.PathQueue);
		if (pushToFront)
		{
			active.pathQueue.PushFront(p);
		}
		else
		{
			active.pathQueue.Push(p);
		}
	}

	public void OnApplicationQuit()
	{
		if (logPathResults == PathLog.Heavy)
		{
			Debug.Log((object)"+++ Application Quitting - Cleaning Up +++");
		}
		OnDestroy();
		if (threads == null)
		{
			return;
		}
		for (int i = 0; i < threads.Length; i++)
		{
			if (threads[i] != null && threads[i].IsAlive)
			{
				threads[i].Abort();
			}
		}
	}

	public void ReturnPaths(bool timeSlice)
	{
		Path next = pathReturnStack.PopAll();
		if (pathReturnPop == null)
		{
			pathReturnPop = next;
		}
		else
		{
			Path next2 = pathReturnPop;
			while (next2.next != null)
			{
				next2 = next2.next;
			}
			next2.next = next;
		}
		long num = ((!timeSlice) ? 0 : (DateTime.UtcNow.Ticks + 10000));
		int num2 = 0;
		while (pathReturnPop != null)
		{
			Path path = pathReturnPop;
			pathReturnPop = pathReturnPop.next;
			path.next = null;
			path.ReturnPath();
			path.AdvanceState(PathState.Returned);
			path.ReleaseSilent(this);
			num2++;
			if (num2 > 5 && timeSlice)
			{
				num2 = 0;
				if (DateTime.UtcNow.Ticks >= num)
				{
					break;
				}
			}
		}
	}

	private static void CalculatePathsThreaded(object _threadInfo)
	{
		PathThreadInfo pathThreadInfo;
		try
		{
			pathThreadInfo = (PathThreadInfo)_threadInfo;
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("Arguments to pathfinding threads must be of type ThreadStartInfo\n" + ex));
			throw new ArgumentException("Argument must be of type ThreadStartInfo", ex);
		}
		AstarPath astar = pathThreadInfo.astar;
		try
		{
			PathHandler runData = pathThreadInfo.runData;
			if (runData.nodes == null)
			{
				throw new NullReferenceException("NodeRuns must be assigned to the threadInfo.runData.nodes field before threads are started\nthreadInfo is an argument to the thread functions");
			}
			long num = (long)(astar.maxFrameTime * 10000f);
			long num2 = DateTime.UtcNow.Ticks + num;
			while (true)
			{
				Path path = astar.pathQueue.Pop();
				num = (long)(astar.maxFrameTime * 10000f);
				path.PrepareBase(runData);
				path.AdvanceState(PathState.Processing);
				if (OnPathPreSearch != null)
				{
					OnPathPreSearch(path);
				}
				long ticks = DateTime.UtcNow.Ticks;
				long num3 = 0L;
				path.Prepare();
				if (!path.IsDone())
				{
					astar.debugPath = path;
					path.Initialize();
					while (!path.IsDone())
					{
						path.CalculateStep(num2);
						path.searchIterations++;
						if (path.IsDone())
						{
							break;
						}
						num3 += DateTime.UtcNow.Ticks - ticks;
						Thread.Sleep(0);
						ticks = DateTime.UtcNow.Ticks;
						num2 = ticks + num;
						if (astar.pathQueue.IsTerminating)
						{
							path.Error();
						}
					}
					num3 += DateTime.UtcNow.Ticks - ticks;
					path.duration = (float)num3 * 0.0001f;
				}
				path.Cleanup();
				astar.LogPathResults(path);
				if (path.immediateCallback != null)
				{
					path.immediateCallback(path);
				}
				if (OnPathPostSearch != null)
				{
					OnPathPostSearch(path);
				}
				pathReturnStack.Push(path);
				path.AdvanceState(PathState.ReturnQueue);
				if (DateTime.UtcNow.Ticks > num2)
				{
					Thread.Sleep(1);
					num2 = DateTime.UtcNow.Ticks + num;
				}
			}
		}
		catch (Exception ex2)
		{
			if (ex2 is ThreadAbortException || ex2 is ThreadControlQueue.QueueTerminationException)
			{
				if (astar.logPathResults == PathLog.Heavy)
				{
					Debug.LogWarning((object)("Shutting down pathfinding thread #" + pathThreadInfo.threadIndex));
				}
				return;
			}
			Debug.LogException(ex2);
			Debug.LogError((object)"Unhandled exception during pathfinding. Terminating.");
			astar.pathQueue.TerminateReceivers();
		}
		Debug.LogError((object)"Error : This part should never be reached.");
		astar.pathQueue.ReceiverTerminated();
	}

	private static IEnumerator CalculatePaths(object _threadInfo)
	{
		PathThreadInfo threadInfo;
		try
		{
			threadInfo = (PathThreadInfo)_threadInfo;
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("Arguments to pathfinding threads must be of type ThreadStartInfo\n" + ex));
			throw new ArgumentException("Argument must be of type ThreadStartInfo", ex);
		}
		int numPaths = 0;
		PathHandler runData = threadInfo.runData;
		AstarPath astar = threadInfo.astar;
		if (runData.nodes == null)
		{
			throw new NullReferenceException("NodeRuns must be assigned to the threadInfo.runData.nodes field before threads are started\nthreadInfo is an argument to the thread functions");
		}
		long maxTicks = (long)(active.maxFrameTime * 10000f);
		long targetTick = DateTime.UtcNow.Ticks + maxTicks;
		while (true)
		{
			Path p = null;
			bool blockedBefore = false;
			while (p == null)
			{
				try
				{
					p = astar.pathQueue.PopNoBlock(blockedBefore);
					if (p == null)
					{
						blockedBefore = true;
					}
				}
				catch (ThreadControlQueue.QueueTerminationException)
				{
					yield break;
				}
				if (p == null)
				{
					yield return null;
				}
			}
			maxTicks = (long)(active.maxFrameTime * 10000f);
			p.PrepareBase(runData);
			p.AdvanceState(PathState.Processing);
			OnPathPreSearch?.Invoke(p);
			numPaths++;
			long startTicks = DateTime.UtcNow.Ticks;
			long totalTicks = 0L;
			p.Prepare();
			if (!p.IsDone())
			{
				active.debugPath = p;
				p.Initialize();
				while (!p.IsDone())
				{
					p.CalculateStep(targetTick);
					p.searchIterations++;
					if (p.IsDone())
					{
						break;
					}
					totalTicks += DateTime.UtcNow.Ticks - startTicks;
					yield return null;
					startTicks = DateTime.UtcNow.Ticks;
					if (astar.pathQueue.IsTerminating)
					{
						p.Error();
					}
					targetTick = DateTime.UtcNow.Ticks + maxTicks;
				}
				totalTicks += DateTime.UtcNow.Ticks - startTicks;
				p.duration = (float)totalTicks * 0.0001f;
			}
			p.Cleanup();
			active.LogPathResults(p);
			p.immediateCallback?.Invoke(p);
			OnPathPostSearch?.Invoke(p);
			pathReturnStack.Push(p);
			p.AdvanceState(PathState.ReturnQueue);
			if (DateTime.UtcNow.Ticks > targetTick)
			{
				yield return null;
				targetTick = DateTime.UtcNow.Ticks + maxTicks;
				numPaths = 0;
			}
		}
	}

	public NNInfo GetNearest(Vector3 position)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return GetNearest(position, NNConstraint.None);
	}

	public NNInfo GetNearest(Vector3 position, NNConstraint constraint)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return GetNearest(position, constraint, null);
	}

	public NNInfo GetNearest(Vector3 position, NNConstraint constraint, GraphNode hint)
	{
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		if (graphs == null)
		{
			return default(NNInfo);
		}
		float num = float.PositiveInfinity;
		NNInfo result = default(NNInfo);
		int num2 = -1;
		for (int i = 0; i < graphs.Length; i++)
		{
			NavGraph navGraph = graphs[i];
			if (navGraph == null || !constraint.SuitableGraph(i, navGraph))
			{
				continue;
			}
			NNInfo nNInfo = ((!fullGetNearestSearch) ? navGraph.GetNearest(position, constraint) : navGraph.GetNearestForce(position, constraint));
			GraphNode node = nNInfo.node;
			if (node != null)
			{
				Vector3 val = nNInfo.clampedPosition - position;
				float magnitude = ((Vector3)(ref val)).magnitude;
				if (prioritizeGraphs && magnitude < prioritizeGraphsLimit)
				{
					num = magnitude;
					result = nNInfo;
					num2 = i;
					break;
				}
				if (magnitude < num)
				{
					num = magnitude;
					result = nNInfo;
					num2 = i;
				}
			}
		}
		if (num2 == -1)
		{
			return result;
		}
		if (result.constrainedNode != null)
		{
			result.node = result.constrainedNode;
			result.clampedPosition = result.constClampedPosition;
		}
		if (!fullGetNearestSearch && result.node != null && !constraint.Suitable(result.node))
		{
			NNInfo nearestForce = graphs[num2].GetNearestForce(position, constraint);
			if (nearestForce.node != null)
			{
				result = nearestForce;
			}
		}
		if (constraint.Suitable(result.node))
		{
			if (constraint.constrainDistance)
			{
				Vector3 val2 = result.clampedPosition - position;
				if (((Vector3)(ref val2)).sqrMagnitude > maxNearestNodeDistanceSqr)
				{
					goto IL_01af;
				}
			}
			return result;
		}
		goto IL_01af;
		IL_01af:
		return default(NNInfo);
	}

	public GraphNode GetNearest(Ray ray)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		if (graphs == null)
		{
			return null;
		}
		float minDist = float.PositiveInfinity;
		GraphNode nearestNode = null;
		Vector3 lineDirection = ((Ray)(ref ray)).direction;
		Vector3 lineOrigin = ((Ray)(ref ray)).origin;
		for (int i = 0; i < graphs.Length; i++)
		{
			NavGraph navGraph = graphs[i];
			navGraph.GetNodes(delegate(GraphNode node)
			{
				//IL_0006: Unknown result type (might be due to invalid IL or missing references)
				//IL_000b: Unknown result type (might be due to invalid IL or missing references)
				//IL_000d: Unknown result type (might be due to invalid IL or missing references)
				//IL_0012: Unknown result type (might be due to invalid IL or missing references)
				//IL_0014: Unknown result type (might be due to invalid IL or missing references)
				//IL_0019: Unknown result type (might be due to invalid IL or missing references)
				//IL_001f: Unknown result type (might be due to invalid IL or missing references)
				//IL_002a: Unknown result type (might be due to invalid IL or missing references)
				//IL_002f: Unknown result type (might be due to invalid IL or missing references)
				//IL_0034: Unknown result type (might be due to invalid IL or missing references)
				//IL_0039: Unknown result type (might be due to invalid IL or missing references)
				//IL_0088: Unknown result type (might be due to invalid IL or missing references)
				//IL_0089: Unknown result type (might be due to invalid IL or missing references)
				//IL_008a: Unknown result type (might be due to invalid IL or missing references)
				//IL_008f: Unknown result type (might be due to invalid IL or missing references)
				Vector3 val = (Vector3)node.position;
				Vector3 val2 = lineOrigin + Vector3.Dot(val - lineOrigin, lineDirection) * lineDirection;
				float num = Mathf.Abs(val2.x - val.x);
				num *= num;
				if (num > minDist)
				{
					return true;
				}
				num = Mathf.Abs(val2.z - val.z);
				num *= num;
				if (num > minDist)
				{
					return true;
				}
				Vector3 val3 = val2 - val;
				float sqrMagnitude = ((Vector3)(ref val3)).sqrMagnitude;
				if (sqrMagnitude < minDist)
				{
					minDist = sqrMagnitude;
					nearestNode = node;
				}
				return true;
			});
		}
		return nearestNode;
	}
}
