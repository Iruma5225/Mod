using UnityEngine;

public class UI_CurrentDay : MonoBehaviour
{
	private enum LabelState
	{
		Off,
		FadeIn,
		Shown,
		FadeOut
	}

	private LabelState label_state;

	[SerializeField]
	private UILabel m_label;

	public float m_fadeInTime = 2f;

	public float m_fadeOutTime = 2f;

	public float m_displayTime = 5f;

	[SerializeField]
	private AudioClip m_NewDaySound;

	private float m_displayTimer;

	public void Start()
	{
		m_fadeInTime = Mathf.Max(m_fadeInTime, 0.1f);
		m_fadeOutTime = Mathf.Max(m_fadeOutTime, 0.1f);
		if ((Object)(object)m_label != (Object)null)
		{
			((Behaviour)m_label).enabled = false;
			GameTime.newDay += onNewDay;
		}
	}

	public void OnDestroy()
	{
		if ((Object)(object)m_label != (Object)null)
		{
			GameTime.newDay -= onNewDay;
		}
	}

	public void Update()
	{
		if (label_state == LabelState.FadeIn)
		{
			float num = 1f / m_fadeInTime * Time.deltaTime;
			m_label.alpha = Mathf.Clamp(m_label.alpha + num, 0f, 1f);
			if (m_label.alpha >= 1f)
			{
				m_displayTimer = m_displayTime;
				label_state = LabelState.Shown;
			}
		}
		else if (label_state == LabelState.Shown)
		{
			m_displayTimer -= Time.deltaTime;
			if (m_displayTimer <= 0f)
			{
				label_state = LabelState.FadeOut;
			}
		}
		else if (label_state == LabelState.FadeOut)
		{
			float num2 = 1f / m_fadeOutTime * Time.deltaTime;
			m_label.alpha = Mathf.Clamp(m_label.alpha - num2, 0f, 1f);
			if (m_label.alpha <= 0f)
			{
				((Behaviour)m_label).enabled = false;
				label_state = LabelState.Off;
			}
		}
	}

	private void onNewDay()
	{
		string text = Localization.Get("Text.UI.Day");
		text = text.Replace("$day$", GameTime.Day.ToString());
		m_label.text = text;
		((Behaviour)m_label).enabled = true;
		label_state = LabelState.FadeIn;
		if ((Object)(object)m_NewDaySound != (Object)null)
		{
			AudioManager.Instance.PlayUI(m_NewDaySound);
		}
	}
}
