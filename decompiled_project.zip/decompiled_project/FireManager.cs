using System.Collections.Generic;
using UnityEngine;

public class FireManager : BaseManager, ISaveable
{
	[SerializeField]
	private float m_updateInterval;

	private float m_updateTimer;

	private List<Obj_Base> m_burnableObjects = new List<Obj_Base>();

	[Header("Smoke")]
	[SerializeField]
	private int m_maxValue = 20;

	[SerializeField]
	private int m_spreadThreshold = 10;

	[SerializeField]
	private int m_spreadRate = 2;

	[SerializeField]
	private int m_dissipateRate = 1;

	[SerializeField]
	private GameObject smokePrefab;

	[SerializeField]
	private float m_maxSmokeAlpha = 1f;

	private int m_gridWidth;

	private int m_gridHeight;

	private int[] m_grid;

	private ParticleSystem[] m_particleGrid;

	private bool m_initialised;

	private static FireManager m_theInstance;

	public static FireManager instance => m_theInstance;

	private void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
		}
		else
		{
			Debug.Log((object)"Duplicate FireMan created!");
		}
	}

	public override void StartManager()
	{
		if ((Object)(object)SaveManager.instance != (Object)null)
		{
			SaveManager.instance.RegisterSaveable(this);
		}
	}

	public override void UpdateManager()
	{
		if (!m_initialised)
		{
			if ((Object)(object)ShelterRoomGrid.Instance == (Object)null || !ShelterRoomGrid.Instance.isInitialized)
			{
				return;
			}
			m_initialised = true;
			InitializeGrid();
			InitializeParticleGrid();
		}
		m_updateTimer -= Time.deltaTime;
		if (m_updateTimer > 0f)
		{
			return;
		}
		m_updateTimer = m_updateInterval;
		m_burnableObjects = GetAllBurnableObjects();
		for (int i = 0; i < m_burnableObjects.Count; i++)
		{
			if (m_burnableObjects[i].isBurning)
			{
				SpreadFire(m_burnableObjects[i]);
			}
		}
		UpdateSmoke();
		UpdateSmokeParticles();
	}

	public List<Obj_Base> GetAllBurnableObjects()
	{
		List<Obj_Base> allObjects = ObjectManager.Instance.GetAllObjects();
		return allObjects.FindAll((Obj_Base x) => x.isBurnable);
	}

	public List<Obj_Base> GetAllFireHazards()
	{
		List<Obj_Base> allObjects = ObjectManager.Instance.GetAllObjects();
		return allObjects.FindAll((Obj_Base x) => x.isBurnable && !x.isBurningOrBurntOut);
	}

	public Obj_Base GetClosestObjectOnFire(Vector3 pos)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		List<Obj_Base> list = m_burnableObjects.FindAll((Obj_Base x) => x.isBurning);
		list.Sort((Obj_Base left, Obj_Base right) => Vector3.Distance(((Component)left).transform.position, pos).CompareTo(Vector3.Distance(((Component)right).transform.position, pos)));
		if (list.Count > 0)
		{
			return list[0];
		}
		return null;
	}

	public bool AreObjectsOnFire()
	{
		if (m_burnableObjects.FindIndex((Obj_Base x) => x.isBurning) >= 0)
		{
			return true;
		}
		return false;
	}

	private void SpreadFire(Obj_Base obj)
	{
		if (!obj.isBurnable || !obj.isBurning)
		{
			return;
		}
		BurnableObject component = ((Component)obj).GetComponent<BurnableObject>();
		if ((Object)(object)component == (Object)null)
		{
			return;
		}
		float radius = component.spreadRadius;
		List<Obj_Base> list = m_burnableObjects.FindAll((Obj_Base x) => Vector3.Distance(((Component)x).transform.position, ((Component)obj).transform.position) <= radius);
		for (int num = 0; num < list.Count; num++)
		{
			if (!list[num].isBurningOrBurntOut)
			{
				BurnableObject component2 = ((Component)list[num]).GetComponent<BurnableObject>();
				if ((Object)(object)component2 != (Object)null && Random.value <= component2.burnChance)
				{
					list[num].StartFire();
				}
			}
		}
	}

	private void InitializeGrid()
	{
		if (!((Object)(object)ShelterRoomGrid.Instance == (Object)null))
		{
			m_gridWidth = ShelterRoomGrid.Instance.grid_width;
			m_gridHeight = ShelterRoomGrid.Instance.grid_height;
			if (m_gridWidth * m_gridHeight > 0)
			{
				m_grid = new int[m_gridWidth * m_gridHeight];
			}
		}
	}

	private void UpdateSmoke()
	{
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		Obj_OxygenFilter obj_OxygenFilter = null;
		if ((Object)(object)ObjectManager.Instance != (Object)null)
		{
			List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.OxygenFilter);
			if (objectsOfType.Count > 0)
			{
				obj_OxygenFilter = objectsOfType[0] as Obj_OxygenFilter;
			}
		}
		for (int i = 0; i < m_burnableObjects.Count; i++)
		{
			if (m_burnableObjects[i].isBurning)
			{
				flag = true;
				if (ShelterRoomGrid.Instance.WorldCoordsToCellCoords(((Component)m_burnableObjects[i]).transform.position, out var cell_x, out var cell_y))
				{
					IncreaseSmoke(cell_x, cell_y, m_spreadRate);
				}
			}
		}
		if (flag)
		{
			for (int j = 0; j < m_grid.Length; j++)
			{
				if (m_grid[j] >= m_spreadThreshold)
				{
					int num = j % m_gridWidth;
					int y = (j - num) / m_gridWidth;
					SpreadSmoke(num, y);
				}
			}
		}
		else if ((Object)(object)obj_OxygenFilter != (Object)null && !obj_OxygenFilter.IsBroken() && obj_OxygenFilter.HasEnoughPower() && ((Behaviour)obj_OxygenFilter).isActiveAndEnabled)
		{
			for (int k = 0; k < m_grid.Length; k++)
			{
				m_grid[k] = Mathf.Max(m_grid[k] - m_dissipateRate, 0);
			}
		}
	}

	private void SpreadSmoke(int x, int y)
	{
		IncreaseSmoke(x - 1, y, m_spreadRate);
		IncreaseSmoke(x + 1, y, m_spreadRate);
		if (ShelterRoomGrid.Instance.HasLadder(x, y - 1))
		{
			IncreaseSmoke(x, y - 1, m_spreadRate * 2);
		}
		IncreaseSmoke(x, y, -m_dissipateRate);
	}

	private void IncreaseSmoke(int x, int y, int increase)
	{
		if (x < 0 || x >= m_gridWidth || y < 0 || y >= m_gridHeight)
		{
			return;
		}
		int num = y * m_gridWidth + x;
		if (num >= 0 && num < m_grid.Length)
		{
			ShelterRoomGrid.GridCell cell = ShelterRoomGrid.Instance.GetCell(x, y);
			if (cell != null && (cell.type == ShelterRoomGrid.CellType.Room || cell.type == ShelterRoomGrid.CellType.RoomTop))
			{
				m_grid[num] = Mathf.Clamp(m_grid[num] + increase, 0, m_maxValue);
			}
		}
	}

	private void InitializeParticleGrid()
	{
		if (m_gridWidth * m_gridHeight > 0)
		{
			m_particleGrid = (ParticleSystem[])(object)new ParticleSystem[m_gridWidth * m_gridHeight];
		}
	}

	private void UpdateSmokeParticles()
	{
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		if (m_grid == null)
		{
			InitializeParticleGrid();
			return;
		}
		for (int i = 0; i < m_grid.Length; i++)
		{
			if (m_grid[i] <= 0)
			{
				if ((Object)(object)m_particleGrid[i] != (Object)null)
				{
					Object.Destroy((Object)(object)((Component)m_particleGrid[i]).gameObject);
					m_particleGrid[i] = null;
				}
				continue;
			}
			if ((Object)(object)m_particleGrid[i] == (Object)null)
			{
				int num = i % m_gridWidth;
				int y = (i - num) / m_gridWidth;
				SpawnSmokeParticle(num, y);
			}
			if (m_grid[i] > 0 && (Object)(object)m_particleGrid[i] != (Object)null)
			{
				MainModule main = m_particleGrid[i].main;
				MinMaxGradient startColor = ((MainModule)(ref main)).startColor;
				Color color = ((MinMaxGradient)(ref startColor)).color;
				color.a = (float)m_grid[i] / (float)m_maxValue * m_maxSmokeAlpha;
				MainModule main2 = m_particleGrid[i].main;
				((MainModule)(ref main2)).startColor = MinMaxGradient.op_Implicit(color);
			}
		}
	}

	private void SpawnSmokeParticle(int x, int y)
	{
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)smokePrefab == (Object)null || x < 0 || x >= m_gridWidth || y < 0 || y >= m_gridHeight)
		{
			return;
		}
		int num = y * m_gridWidth + x;
		if (num < 0 || num >= m_grid.Length)
		{
			return;
		}
		ShelterRoomGrid.GridCell cell = ShelterRoomGrid.Instance.GetCell(x, y);
		if (cell == null || (Object)(object)cell.prefab == (Object)null || (cell.type != ShelterRoomGrid.CellType.Room && cell.type != ShelterRoomGrid.CellType.RoomTop))
		{
			return;
		}
		ShelterRoom component = cell.prefab.GetComponent<ShelterRoom>();
		if ((Object)(object)component == (Object)null || (Object)(object)component.smoke_pos == (Object)null)
		{
			return;
		}
		GameObject val = Object.Instantiate<GameObject>(smokePrefab, Vector3.zero, Quaternion.identity);
		if ((Object)(object)val != (Object)null)
		{
			ParticleSystem component2 = val.GetComponent<ParticleSystem>();
			if ((Object)(object)component2 != (Object)null)
			{
				((Component)component2).transform.parent = component.smoke_pos;
				((Component)component2).transform.localPosition = Vector3.zero;
				((Component)component2).transform.localRotation = Quaternion.identity;
				((Component)component2).transform.localScale = Vector3.one;
				m_particleGrid[num] = component2;
			}
		}
	}

	public bool IsRelocationEnabled()
	{
		return false;
	}

	public bool IsReadyForLoad()
	{
		return m_initialised;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("FireManager");
		List<int> smokeGrid = new List<int>();
		if (m_grid != null)
		{
			for (int i = 0; i < m_grid.Length; i++)
			{
				smokeGrid.Add(m_grid[i]);
			}
		}
		data.SaveLoadList("smokeGrid", smokeGrid, delegate(int index)
		{
			int value = smokeGrid[index];
			data.SaveLoad("value", ref value);
		}, delegate
		{
			int value = 0;
			data.SaveLoad("value", ref value);
			smokeGrid.Add(value);
		});
		if (data.isLoading)
		{
			for (int num = 0; num < m_grid.Length && num < smokeGrid.Count; num++)
			{
				m_grid[num] = smokeGrid[num];
			}
		}
		data.GroupEnd();
		return true;
	}
}
