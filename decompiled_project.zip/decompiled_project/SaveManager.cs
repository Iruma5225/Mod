using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SaveManager : MonoBehaviour
{
	private enum SaveState
	{
		Idle,
		SavingSceneContents,
		SavingWait,
		SavingData,
		LoadingData,
		LoadingSceneContents,
		SavingGlobalData,
		LoadingGlobalData,
		Transitioning,
		DeletingData
	}

	public enum SaveType
	{
		GlobalData,
		Slot1,
		Slot2,
		Slot3,
		Invalid
	}

	private delegate void UpdateDelegate();

	public delegate void GlobalDataEvent(bool success);

	public delegate void SlotDataLoadEvent(bool success);

	private SaveState m_state;

	private SaveType m_currentType = SaveType.Invalid;

	private SaveType m_slotInUse = SaveType.Invalid;

	private bool m_pendingLoad;

	private int m_framesUntilLoad;

	private bool m_pendingSaveGlobalData;

	private bool m_lastSaveErrorOccurred;

	private UpdateDelegate m_update;

	private PlatformSave_Base m_saveScript;

	private List<ISaveable> m_saveables = new List<ISaveable>();

	private List<ISaveable> m_toSave = new List<ISaveable>();

	private List<ISaveable> m_toLoad = new List<ISaveable>();

	private List<ISaveable> m_loaded = new List<ISaveable>();

	private SaveData m_data;

	private int m_loadIterations;

	private int m_updatesWithZeroLoads;

	private int m_toLoadIndex;

	private byte[] m_dataToSave;

	private AsyncOperation m_sceneLoadAsyncOp;

	private static SaveManager m_instance;

	public bool isSaving => m_state == SaveState.SavingData || m_state == SaveState.SavingWait || m_state == SaveState.SavingSceneContents || m_state == SaveState.SavingGlobalData;

	public bool isLoading => m_pendingLoad || m_framesUntilLoad > 0 || m_state == SaveState.LoadingData || m_state == SaveState.LoadingSceneContents;

	public bool isDeleting => m_state == SaveState.DeletingData;

	public bool wasSaveError => m_lastSaveErrorOccurred;

	public bool isRelocating => m_data != null && m_data.isRelocating;

	public PlatformSave_Base platformSave => m_saveScript;

	public AsyncOperation SceneLoadAsyncOp
	{
		get
		{
			return m_sceneLoadAsyncOp;
		}
		set
		{
			m_sceneLoadAsyncOp = value;
		}
	}

	public static SaveManager instance
	{
		get
		{
			if ((Object)(object)m_instance == (Object)null)
			{
				m_instance = Object.FindObjectOfType<SaveManager>();
			}
			return m_instance;
		}
	}

	public event GlobalDataEvent onGlobalDataLoaded;

	public event SlotDataLoadEvent onSlotDataLoadFinished;

	public void Awake()
	{
		if ((Object)(object)m_instance == (Object)null)
		{
			m_instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
		}
		else if ((Object)(object)m_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)this);
			return;
		}
		m_saveScript = new PlatformSave_PC();
		if (m_saveScript != null)
		{
			m_saveScript.PlatformInit();
		}
		m_update = Update_Idle;
	}

	public void RegisterSaveable(ISaveable saveable)
	{
		if (!m_saveables.Contains(saveable))
		{
			m_saveables.Add(saveable);
		}
		if (m_state == SaveState.LoadingSceneContents && !m_toLoad.Contains(saveable))
		{
			m_toLoad.Add(saveable);
		}
	}

	public void UnregisterSaveable(ISaveable saveable)
	{
		if (m_saveables.Contains(saveable))
		{
			m_saveables.Remove(saveable);
		}
		if (m_state != SaveState.LoadingSceneContents && m_state != SaveState.SavingSceneContents)
		{
		}
	}

	public void ClearAll()
	{
		if (m_state == SaveState.Idle)
		{
			m_saveables.Clear();
			m_toLoad.Clear();
			m_toSave.Clear();
			m_loaded.Clear();
			m_toLoadIndex = 0;
		}
	}

	public void DoesSaveExist(int slot, out bool exists, out bool corrupted)
	{
		exists = false;
		corrupted = false;
		if (m_saveScript != null)
		{
			switch (slot)
			{
			case 1:
				m_saveScript.DoesSaveExist(SaveType.Slot1, out exists, out corrupted);
				break;
			case 2:
				m_saveScript.DoesSaveExist(SaveType.Slot2, out exists, out corrupted);
				break;
			case 3:
				m_saveScript.DoesSaveExist(SaveType.Slot3, out exists, out corrupted);
				break;
			}
		}
	}

	public bool DoesInUseSaveExist()
	{
		if (m_saveScript == null || m_slotInUse == SaveType.Invalid)
		{
			return false;
		}
		bool exists = false;
		bool corrupted = false;
		m_saveScript.DoesSaveExist(m_slotInUse, out exists, out corrupted);
		return exists;
	}

	public bool SaveToCurrentSlot(bool alsoSaveGlobalDataOnPs4)
	{
		if (m_slotInUse == SaveType.Invalid)
		{
			return false;
		}
		bool result = StartSave(m_slotInUse);
		m_pendingSaveGlobalData = false;
		return result;
	}

	public bool LoadFromCurrentSlot()
	{
		bool exists = false;
		bool corrupted = false;
		if (m_saveScript != null)
		{
			m_saveScript.DoesSaveExist(m_slotInUse, out exists, out corrupted);
		}
		if (m_saveScript == null || !exists || corrupted)
		{
			return false;
		}
		ClearAll();
		StartLoad(m_slotInUse);
		return true;
	}

	public bool SetCurrentSlot(int slot)
	{
		ClearAll();
		switch (slot)
		{
		case 1:
			m_slotInUse = SaveType.Slot1;
			return false;
		case 2:
			m_slotInUse = SaveType.Slot2;
			return false;
		case 3:
			m_slotInUse = SaveType.Slot3;
			return false;
		default:
			m_slotInUse = SaveType.Invalid;
			return false;
		}
	}

	public bool SetSlotToLoad(int slot)
	{
		switch (slot)
		{
		case 1:
			m_slotInUse = SaveType.Slot1;
			break;
		case 2:
			m_slotInUse = SaveType.Slot2;
			break;
		case 3:
			m_slotInUse = SaveType.Slot3;
			break;
		default:
			m_slotInUse = SaveType.Invalid;
			return false;
		}
		ClearAll();
		StartLoad(m_slotInUse);
		return true;
	}

	public bool DeleteCurrentSlot()
	{
		if (m_saveScript != null && !m_saveScript.IsBusy() && m_slotInUse != SaveType.Invalid)
		{
			m_saveScript.PlatformDelete(m_slotInUse);
			SetState(SaveState.DeletingData);
			return true;
		}
		return false;
	}

	public bool DeleteSlot(int slot)
	{
		SaveType saveType = SaveType.Invalid;
		switch (slot)
		{
		case 1:
			saveType = SaveType.Slot1;
			break;
		case 2:
			saveType = SaveType.Slot2;
			break;
		case 3:
			saveType = SaveType.Slot3;
			break;
		default:
			return false;
		}
		if (m_saveScript != null && !m_saveScript.IsBusy())
		{
			m_saveScript.PlatformDelete(saveType);
			SetState(SaveState.DeletingData);
			return true;
		}
		return false;
	}

	public bool SaveGlobalData()
	{
		return StartSave(SaveType.GlobalData);
	}

	public bool LoadGlobalData()
	{
		return StartLoad(SaveType.GlobalData);
	}

	public void ContinueTransition()
	{
		if (m_state == SaveState.Transitioning)
		{
			m_pendingLoad = true;
		}
	}

	private bool StartSave(SaveType type)
	{
		if (m_state != SaveState.Idle)
		{
			return false;
		}
		if (m_saveScript == null || m_saveScript.IsBusy())
		{
			return false;
		}
		if (type == SaveType.Invalid)
		{
			return false;
		}
		m_currentType = type;
		m_lastSaveErrorOccurred = false;
		if (type == SaveType.GlobalData)
		{
			if ((Object)(object)SaveGlobal.Instance != (Object)null)
			{
				m_data = new SaveData();
				bool flag = false;
				try
				{
					m_data.StartSaveable();
					flag = SaveGlobal.Instance.SaveLoad(m_data);
				}
				catch (SaveData.MissingGroupException)
				{
					m_data.CancelSaveable();
				}
				catch (Exception)
				{
					m_data.CancelSaveable();
				}
				if (flag)
				{
					m_data.Finished();
					byte[] bytes = m_data.GetBytes();
					if (!m_saveScript.PlatformSave(m_currentType, bytes))
					{
						return false;
					}
					SetState(SaveState.SavingGlobalData);
				}
			}
		}
		else
		{
			m_toSave.Clear();
			m_toSave.AddRange(m_saveables);
			m_data = new SaveData();
			SetState(SaveState.SavingSceneContents);
		}
		return true;
	}

	private bool StartLoad(SaveType type)
	{
		if (m_state != SaveState.Idle)
		{
			return false;
		}
		if (m_saveScript == null || m_saveScript.IsBusy())
		{
			return false;
		}
		if (type == SaveType.Invalid)
		{
			return false;
		}
		m_currentType = type;
		bool result = false;
		if (type == SaveType.GlobalData)
		{
			if (m_saveScript.PlatformLoad(type))
			{
				result = true;
				SetState(SaveState.LoadingGlobalData);
			}
		}
		else if (m_saveScript.PlatformLoad(type))
		{
			result = true;
			SetState(SaveState.LoadingData);
		}
		else if (this.onSlotDataLoadFinished != null)
		{
			this.onSlotDataLoadFinished(success: false);
		}
		return result;
	}

	private void SetState(SaveState state)
	{
		switch (state)
		{
		case SaveState.Idle:
			m_update = Update_Idle;
			break;
		case SaveState.LoadingData:
			m_update = Update_LoadData;
			break;
		case SaveState.LoadingSceneContents:
			m_update = Update_LoadSceneContents;
			break;
		case SaveState.SavingData:
			m_update = Update_SaveData;
			break;
		case SaveState.SavingWait:
			m_update = Update_SaveWait;
			break;
		case SaveState.SavingSceneContents:
			m_update = Update_SaveSceneContents;
			break;
		case SaveState.LoadingGlobalData:
			m_update = Update_LoadGlobalData;
			break;
		case SaveState.SavingGlobalData:
			m_update = Update_SaveGlobalData;
			break;
		case SaveState.Transitioning:
			m_update = Update_Transitioning;
			break;
		case SaveState.DeletingData:
			m_update = Update_DeletingData;
			break;
		default:
			m_state = SaveState.Idle;
			m_update = Update_Idle;
			break;
		}
		if (m_state != state)
		{
		}
		m_state = state;
	}

	public void Update()
	{
		if (m_update != null)
		{
			m_update();
		}
		if (m_saveScript != null)
		{
			m_saveScript.PlatformUpdate();
		}
	}

	private void Update_Idle()
	{
	}

	private void Update_Transitioning()
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		if (m_pendingLoad && m_sceneLoadAsyncOp != null && m_sceneLoadAsyncOp.isDone && Application.isPlaying)
		{
			Scene activeScene = SceneManager.GetActiveScene();
			if (((Scene)(ref activeScene)).name == "ShelterScene" && LoadingScreen.nextLevel == string.Empty)
			{
				m_pendingLoad = false;
				m_framesUntilLoad = 20;
				m_sceneLoadAsyncOp = null;
			}
		}
		if (m_framesUntilLoad <= 0 || --m_framesUntilLoad != 0)
		{
			return;
		}
		if (m_state == SaveState.Transitioning)
		{
			m_loaded.Clear();
			m_toLoad.Clear();
			m_toLoad.AddRange(m_saveables);
			m_toLoadIndex = 0;
			SetState(SaveState.LoadingSceneContents);
		}
		else
		{
			SetState(SaveState.Idle);
			if ((Object)(object)LoadingScreen.Instance != (Object)null && LoadingScreen.Instance.isShowing)
			{
				LoadingScreen.Instance.HideLoadingScreen();
			}
		}
	}

	private void Update_DeletingData()
	{
		if (m_saveScript == null || !m_saveScript.IsDeleting())
		{
			SetState(SaveState.Idle);
		}
	}

	private void Update_SaveGlobalData()
	{
		if (!m_saveScript.IsSaving())
		{
			m_lastSaveErrorOccurred = m_lastSaveErrorOccurred || m_saveScript.WasSaveError();
			SetState(SaveState.Idle);
		}
	}

	private void Update_LoadGlobalData()
	{
		if (m_saveScript.IsLoading())
		{
			return;
		}
		bool flag = false;
		byte[] data = null;
		if (m_saveScript.PlatformGetLoadedData(out data) && data != null && (Object)(object)SaveGlobal.Instance != (Object)null)
		{
			m_data = new SaveData(data);
			try
			{
				m_data.StartSaveable();
				flag = SaveGlobal.Instance.SaveLoad(m_data);
			}
			catch (SaveData.MissingGroupException)
			{
				m_data.CancelSaveable();
			}
			catch (Exception)
			{
				m_data.CancelSaveable();
			}
			if (flag)
			{
			}
		}
		else
		{
			SetState(SaveState.Idle);
		}
		if (this.onGlobalDataLoaded != null)
		{
			this.onGlobalDataLoaded(flag);
		}
		if (m_data != null)
		{
			m_data.Finished();
		}
		SetState(SaveState.Idle);
	}

	private void Update_SaveData()
	{
		if (!m_saveScript.IsSaving())
		{
			SetState(SaveState.Idle);
			m_lastSaveErrorOccurred = m_lastSaveErrorOccurred || m_saveScript.WasSaveError();
			m_dataToSave = null;
			if (m_pendingSaveGlobalData && m_currentType != SaveType.GlobalData && m_currentType != SaveType.Invalid)
			{
				bool lastSaveErrorOccurred = m_lastSaveErrorOccurred;
				StartSave(SaveType.GlobalData);
				m_lastSaveErrorOccurred = lastSaveErrorOccurred;
			}
			m_pendingSaveGlobalData = false;
		}
	}

	private void Update_SaveWait()
	{
		if (m_dataToSave == null)
		{
			m_dataToSave = m_data.GetBytes();
		}
		else if (m_dataToSave != null)
		{
			m_saveScript.PlatformSave(m_currentType, m_dataToSave);
			SetState(SaveState.SavingData);
		}
	}

	private void Update_LoadData()
	{
		if (m_saveScript.IsLoading())
		{
			return;
		}
		byte[] data = null;
		bool flag = m_saveScript.PlatformGetLoadedData(out data) && data != null;
		if (flag)
		{
			m_data = new SaveData(data);
			if (m_data != null && m_data.isFinished)
			{
				flag = false;
				m_data = null;
			}
			else
			{
				m_loadIterations = 0;
				m_updatesWithZeroLoads = 0;
				if ((Object)(object)LoadingScreen.Instance != (Object)null)
				{
					LoadingScreen.Instance.ShowLoadingScreen("ShelterScene");
					SetState(SaveState.Transitioning);
				}
				else
				{
					SetState(SaveState.Idle);
				}
			}
		}
		if (!flag)
		{
			SetState(SaveState.Idle);
		}
		if (this.onSlotDataLoadFinished != null)
		{
			this.onSlotDataLoadFinished(flag);
		}
	}

	private void Update_SaveSceneContents()
	{
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		int num = 0;
		string text = string.Empty;
		for (int num2 = m_toSave.Count - 1; num2 >= 0; num2--)
		{
			if (m_toSave[num2] == null)
			{
				m_toSave.RemoveAt(num2);
			}
			else
			{
				float realtimeSinceStartup2 = Time.realtimeSinceStartup;
				bool flag = false;
				try
				{
					m_data.StartSaveable();
					flag = m_toSave[num2].SaveLoad(m_data);
				}
				catch (SaveData.MissingGroupException)
				{
					m_data.CancelSaveable();
				}
				catch (Exception)
				{
					m_data.CancelSaveable();
				}
				if (!flag)
				{
				}
				float num3 = Time.realtimeSinceStartup - realtimeSinceStartup2;
				string text2 = text;
				text = text2 + num + ". " + m_toSave[num2].ToString() + " (" + num3 + " seconds)\n";
				num++;
			}
		}
		m_toSave.Clear();
		float num4 = Time.realtimeSinceStartup - realtimeSinceStartup;
		m_data.Finished();
		m_dataToSave = null;
		SetState(SaveState.SavingWait);
	}

	private void Update_LoadSceneContents()
	{
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		int num = 0;
		string text = string.Empty;
		ISaveable saveable = null;
		int count = m_toLoad.Count;
		for (int i = 0; i < count; i++)
		{
			if (m_toLoadIndex >= m_toLoad.Count)
			{
				m_toLoadIndex = 0;
			}
			if (m_toLoad.Count == 0 || Time.realtimeSinceStartup - realtimeSinceStartup >= 0.2f)
			{
				break;
			}
			saveable = m_toLoad[m_toLoadIndex];
			if (saveable == null)
			{
				m_toLoad.RemoveAt(m_toLoadIndex);
			}
			else if (saveable.IsReadyForLoad())
			{
				float realtimeSinceStartup2 = Time.realtimeSinceStartup;
				if (!isRelocating || saveable.IsRelocationEnabled())
				{
					bool flag = false;
					try
					{
						m_data.StartSaveable();
						flag = saveable.SaveLoad(m_data);
					}
					catch (SaveData.MissingGroupException)
					{
						m_data.CancelSaveable();
					}
					catch (Exception)
					{
						m_data.CancelSaveable();
					}
					if (flag)
					{
					}
				}
				float num2 = Time.realtimeSinceStartup - realtimeSinceStartup2;
				string text2 = text;
				text = text2 + num + ". " + saveable.ToString() + " (" + num2 + " seconds)\n";
				num++;
				m_loaded.Add(saveable);
				m_toLoad.RemoveAt(m_toLoadIndex);
			}
			else
			{
				m_toLoadIndex++;
			}
		}
		float num3 = Time.realtimeSinceStartup - realtimeSinceStartup;
		if (m_toLoad.Count > 0)
		{
			if (num == 0)
			{
				m_updatesWithZeroLoads++;
			}
			else
			{
				m_updatesWithZeroLoads = 0;
			}
			if (m_updatesWithZeroLoads < 30)
			{
				return;
			}
			string text3 = "the following saveables were not loaded:\n";
			for (int j = 0; j < m_toLoad.Count; j++)
			{
				string text2 = text3;
				text3 = text2 + j + ". " + m_toLoad[j].ToString() + "\n";
			}
		}
		m_data.Finished();
		SetState(SaveState.Idle);
		if ((Object)(object)LoadingScreen.Instance != (Object)null && LoadingScreen.Instance.isShowing)
		{
			LoadingScreen.Instance.HideLoadingScreen();
		}
	}

	public bool HasBeenLoaded(ISaveable saveable)
	{
		if (m_state == SaveState.LoadingSceneContents)
		{
			if (m_loaded.Contains(saveable))
			{
				return true;
			}
			return false;
		}
		return false;
	}
}
