using UnityEngine;

public class InteractionInstance_MedicateFoodBowl : InteractionInstance_Base
{
	private Obj_FoodBowl m_bowl;

	protected override bool OnInteractionStarted()
	{
		m_bowl = obj_base as Obj_FoodBowl;
		if ((Object)(object)m_bowl == (Object)null || !m_bowl.hasFood)
		{
			return false;
		}
		if ((Object)(object)InventoryManager.Instance == (Object)null || InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.AntiRadMedicine) < 1)
		{
			return false;
		}
		InventoryManager.Instance.RemoveItemOfType(ItemManager.ItemType.AntiRadMedicine);
		member.TriggerAnim("Rummage");
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled)
		{
			m_bowl.Medicate();
		}
		else if ((Object)(object)InventoryManager.Instance != (Object)null)
		{
			InventoryManager.Instance.AddNewItem(ItemManager.ItemType.AntiRadMedicine);
		}
		return true;
	}
}
