using UnityEngine;

public class UISpriteAnimationEx : UISpriteAnimation
{
	public delegate void AnimFinishedDelegate();

	public int m_fps = 30;

	public string m_prefix = string.Empty;

	public bool m_looping = true;

	public bool m_snap = true;

	public AnimFinishedDelegate m_onAnimFinished;

	private bool m_reversed;

	private bool m_initialized;

	protected override void Start()
	{
		Initialize();
	}

	private void Initialize()
	{
		if (!m_initialized)
		{
			m_initialized = true;
			mFPS = m_fps;
			mPrefix = m_prefix;
			mLoop = m_looping;
			mSnap = m_snap;
			RebuildSpriteList();
		}
	}

	protected override void Update()
	{
		if (!mActive || mSpriteNames.Count <= 1 || !Application.isPlaying || !((float)mFPS > 0f))
		{
			return;
		}
		mDelta += RealTime.deltaTime;
		float num = 1f / (float)mFPS;
		if (!(num < mDelta))
		{
			return;
		}
		mDelta = ((!(num > 0f)) ? 0f : (mDelta - num));
		mIndex += ((!m_reversed) ? 1 : (-1));
		if ((!m_reversed && mIndex >= mSpriteNames.Count) || (m_reversed && mIndex <= 0))
		{
			mIndex = 0;
			mSprite.spriteName = mSpriteNames[mIndex];
			if (mSnap)
			{
				mSprite.MakePixelPerfect();
			}
			mActive = base.loop;
			if (!mActive && m_onAnimFinished != null)
			{
				m_onAnimFinished();
			}
		}
		if (mActive)
		{
			mSprite.spriteName = mSpriteNames[mIndex];
			if (mSnap)
			{
				mSprite.MakePixelPerfect();
			}
		}
	}

	public void Play()
	{
		if (!m_initialized)
		{
			Initialize();
		}
		Reset();
		m_reversed = false;
	}

	public void PlayReversed()
	{
		if (!m_initialized)
		{
			Initialize();
		}
		Reset();
		m_reversed = true;
		mIndex = mSpriteNames.Count;
	}
}
