public class TutorialStage_EndDialog : BaseTutorial
{
	private bool m_bContinue;

	public override TutorialManager.TutorialStage GetTutorialStage()
	{
		return TutorialManager.TutorialStage.EndDialog;
	}

	public override void OnEnterStage(bool showPanel)
	{
		base.OnEnterStage(showPanel);
		m_bContinue = false;
	}

	public override bool IsStageComplete()
	{
		if (m_bContinue)
		{
			return true;
		}
		return false;
	}

	public void Continue()
	{
		m_bContinue = true;
	}
}
