using UnityEngine;

public class Int_EmptyWaterCondenser : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_EmptyWaterCondenser";
	}

	public override string GetInteractionType()
	{
		return "empty_water_condenser";
	}

	public override bool IsPlayerSelectable()
	{
		if (obj.isBurningOrBurntOut || !base.InteractionEnabled)
		{
			return false;
		}
		Obj_WaterCondenser obj_WaterCondenser = obj as Obj_WaterCondenser;
		if ((Object)(object)obj_WaterCondenser != (Object)null && obj_WaterCondenser.WaterGenerated > 0f)
		{
			return true;
		}
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}
}
