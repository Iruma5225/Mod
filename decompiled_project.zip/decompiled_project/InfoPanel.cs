using UnityEngine;

public class InfoPanel : BasePanel
{
	[SerializeField]
	private float m_scrollDelay = 1f;

	private float m_scrollTimeout;

	public UITweener m_tween;

	public UILabel[] m_lines = new UILabel[3];

	public UISpriteAnimationEx m_animation;

	public UITweener m_focusPrompt;

	public GameObject m_pageContents;

	public UIButton m_upArrow;

	public UIButton m_downArrow;

	public AudioClip m_openSound;

	public AudioClip m_closeSound;

	public AudioClip m_pageFlipSound;

	private AudioSource m_audioSource;

	[SerializeField]
	private InfoPanelNotification m_Notification;

	private readonly int m_visibleLines = 3;

	private int m_topLineIndex;

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool PausesGameInput()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return false;
	}

	public override void OnShow()
	{
		base.OnShow();
		if (m_lines.Length > 0)
		{
			for (int i = 0; i < m_lines.Length; i++)
			{
				m_lines[i].text = string.Empty;
			}
			int num = ActivityLog.Instance.numMessages / m_visibleLines;
			if (ActivityLog.Instance.numMessages % m_visibleLines > 0)
			{
				num++;
			}
			int topLineIndex = (Mathf.Max(1, num) - 1) * m_visibleLines;
			m_topLineIndex = topLineIndex;
			UpdateText();
		}
		if ((Object)(object)m_tween != (Object)null)
		{
			m_tween.onFinished.Clear();
			m_tween.PlayForward();
		}
		if ((Object)(object)m_animation != (Object)null)
		{
			m_animation.m_onAnimFinished = OnAnimFinished;
			m_animation.Play();
		}
		m_audioSource = ((Component)this).GetComponent<AudioSource>();
		if ((Object)(object)m_audioSource != (Object)null && (Object)(object)m_openSound != (Object)null)
		{
			m_audioSource.PlayOneShot(m_openSound);
		}
		UI_PanelContainer.Instance.InfoPanelNotification.Deactivate();
	}

	public void StartClose()
	{
		if ((Object)(object)m_tween != (Object)null)
		{
			m_tween.onFinished.Clear();
			m_tween.AddOnFinished(OnTweenFinished);
			m_tween.PlayReverse();
		}
		m_audioSource = ((Component)this).GetComponent<AudioSource>();
		if ((Object)(object)m_audioSource != (Object)null && (Object)(object)m_closeSound != (Object)null)
		{
			m_audioSource.PlayOneShot(m_closeSound);
		}
	}

	private void OnTweenFinished()
	{
		if ((Object)(object)UIPanelManager.Instance() != (Object)null)
		{
			UIPanelManager.Instance().PopPanel(this);
		}
	}

	private void OnAnimFinished()
	{
		if ((Object)(object)m_pageContents != (Object)null)
		{
			m_pageContents.SetActive(true);
		}
	}

	private void OnNewActivity()
	{
		UpdateText();
	}

	private void ScrollUp()
	{
		if ((Object)(object)m_tween != (Object)null && ((Behaviour)m_tween).isActiveAndEnabled)
		{
			return;
		}
		int num = Mathf.Max(0, m_topLineIndex - 3);
		if (num != m_topLineIndex)
		{
			float time = Time.time;
			if (!(time < m_scrollTimeout))
			{
				m_topLineIndex = num;
				UpdateText();
				PlayScrollAnim(up: true);
				m_scrollTimeout = time + m_scrollDelay;
			}
		}
	}

	private void ScrollDown()
	{
		if ((Object)(object)m_tween != (Object)null && ((Behaviour)m_tween).isActiveAndEnabled)
		{
			return;
		}
		int num = ActivityLog.Instance.numMessages / m_visibleLines;
		if (ActivityLog.Instance.numMessages % m_visibleLines > 0)
		{
			num++;
		}
		int num2 = (Mathf.Max(1, num) - 1) * m_visibleLines;
		int num3 = Mathf.Min(m_topLineIndex + m_visibleLines, num2);
		if (num3 != m_topLineIndex)
		{
			float time = Time.time;
			if (!(time < m_scrollTimeout))
			{
				m_topLineIndex = num3;
				UpdateText();
				PlayScrollAnim(up: false);
				m_scrollTimeout = time + m_scrollDelay;
			}
		}
	}

	public override void Update()
	{
		if ((Object)(object)m_focusPrompt != (Object)null && (Object)(object)ActivityLog.Instance != (Object)null)
		{
			bool validTransform = ActivityLog.Instance.validTransform;
			if (m_focusPrompt.tweenFactor <= 0f && validTransform)
			{
				((Component)m_focusPrompt).gameObject.SetActive(true);
				m_focusPrompt.PlayForward();
			}
			else if (m_focusPrompt.tweenFactor >= 1f && !validTransform)
			{
				((Component)m_focusPrompt).gameObject.SetActive(true);
				m_focusPrompt.PlayReverse();
			}
		}
		if (IsShowing())
		{
		}
	}

	private void UpdateText()
	{
		if ((Object)(object)ActivityLog.Instance != (Object)null)
		{
			for (int i = 0; i < m_visibleLines; i++)
			{
				string text = "[b]activity text goes here[/b]";
				if (i < m_lines.Length)
				{
					m_lines[i].text = text;
				}
			}
		}
		UpdateScrollIndicators();
	}

	private void UpdateScrollIndicators()
	{
		int num = ActivityLog.Instance.numMessages / m_visibleLines;
		if (ActivityLog.Instance.numMessages % m_visibleLines > 0)
		{
			num++;
		}
		int num2 = (Mathf.Max(1, num) - 1) * m_visibleLines;
		if ((Object)(object)m_upArrow != (Object)null)
		{
			m_upArrow.isEnabled = m_topLineIndex > 0;
		}
		if ((Object)(object)m_downArrow != (Object)null)
		{
			m_downArrow.isEnabled = m_topLineIndex < num2;
		}
	}

	private void PlayScrollAnim(bool up)
	{
		if ((Object)(object)m_animation != (Object)null)
		{
			if (up)
			{
				m_animation.PlayReversed();
			}
			else
			{
				m_animation.Play();
			}
			if ((Object)(object)m_pageContents != (Object)null)
			{
				m_pageContents.SetActive(false);
			}
		}
		if ((Object)(object)m_audioSource != (Object)null && (Object)(object)m_pageFlipSound != (Object)null)
		{
			m_audioSource.PlayOneShot(m_pageFlipSound);
		}
	}
}
