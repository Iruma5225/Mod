using UnityEngine;

[AddComponentMenu("Sheltered/Interaction/Take Corpse")]
public class Int_TakeCorpse : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_TakeCorpse";
	}

	public override string GetInteractionType()
	{
		return "take_corpse";
	}

	public override bool IsPlayerSelectable()
	{
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}
}
