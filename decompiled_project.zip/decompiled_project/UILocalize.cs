using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(UIWidget))]
[ExecuteInEditMode]
[AddComponentMenu("NGUI/UI/Localize")]
public class UILocalize : MonoBehaviour
{
	private Dictionary<string, string> stringReplacements = new Dictionary<string, string>();

	public bool bGetRandomValue;

	public string key;

	private bool mStarted;

	public string value
	{
		set
		{
			if (string.IsNullOrEmpty(value))
			{
				return;
			}
			UIWidget component = ((Component)this).GetComponent<UIWidget>();
			UILabel uILabel = component as UILabel;
			UISprite uISprite = component as UISprite;
			if ((Object)(object)uILabel != (Object)null)
			{
				UIInput uIInput = NGUITools.FindInParents<UIInput>(((Component)uILabel).gameObject);
				if ((Object)(object)uIInput != (Object)null && (Object)(object)uIInput.label == (Object)(object)uILabel)
				{
					uIInput.defaultText = value;
				}
				else
				{
					uILabel.text = value;
				}
			}
			else if ((Object)(object)uISprite != (Object)null)
			{
				uISprite.spriteName = value;
				uISprite.MakePixelPerfect();
			}
		}
	}

	private void OnEnable()
	{
		if (mStarted)
		{
			OnLocalize();
		}
	}

	public void Refresh()
	{
		OnEnable();
	}

	public void SetStringReplacement(string repKey, string repValue)
	{
		if (stringReplacements.TryGetValue(repKey, out var _))
		{
			stringReplacements.Remove(repKey);
			stringReplacements.Add(repKey, repValue);
		}
		else
		{
			stringReplacements.Add(repKey, repValue);
		}
	}

	private void Start()
	{
		mStarted = true;
		OnLocalize();
	}

	private void OnLocalize()
	{
		if (string.IsNullOrEmpty(key))
		{
			UILabel component = ((Component)this).GetComponent<UILabel>();
			if ((Object)(object)component != (Object)null)
			{
				key = component.text;
			}
		}
		if (string.IsNullOrEmpty(key))
		{
			return;
		}
		string text = ((!bGetRandomValue) ? Localization.Get(key) : Localization.GetRandomValueFromKey(key));
		foreach (KeyValuePair<string, string> stringReplacement in stringReplacements)
		{
			text = text.Replace(stringReplacement.Key, stringReplacement.Value);
		}
		value = text;
	}
}
