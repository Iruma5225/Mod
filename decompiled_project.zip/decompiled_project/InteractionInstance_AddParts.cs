using System.Collections.Generic;
using UnityEngine;

public class InteractionInstance_AddParts : InteractionInstance_Base
{
	private Int_AddParts interaction;

	private Obj_CamperVan obj_Vehicle;

	protected override bool OnInteractionStarted()
	{
		interaction = base_interaction as Int_AddParts;
		if ((Object)(object)interaction == (Object)null)
		{
			return false;
		}
		obj_Vehicle = ((Component)this).GetComponent<Obj_CamperVan>();
		if ((Object)(object)obj_Vehicle == (Object)null)
		{
			return false;
		}
		if ((Object)(object)InventoryManager.Instance == (Object)null)
		{
			return false;
		}
		if (!obj_Vehicle.PlayerHasParts())
		{
			return false;
		}
		if (obj_Vehicle.IsDrivable())
		{
			return false;
		}
		member.TriggerAnim("Rummage");
		return true;
	}

	protected override bool OnInteractionComplete()
	{
		if (!base.cancelled)
		{
			List<ItemManager.ItemType> listOfRequiredParts = obj_Vehicle.GetListOfRequiredParts();
			int num = 0;
			for (int i = 0; i < listOfRequiredParts.Count; i++)
			{
				num = Mathf.Min(obj_Vehicle.GetRemainingRequiredPart(listOfRequiredParts[i]), InventoryManager.Instance.GetNumItemsOfType(listOfRequiredParts[i]));
				InventoryManager.Instance.RemoveItemsOfType(listOfRequiredParts[i], num);
				obj_Vehicle.AddPart(listOfRequiredParts[i], num);
			}
		}
		return true;
	}
}
