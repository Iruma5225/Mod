using UnityEngine;

public class Int_RemoveAllDesperateMeat : Int_Base
{
	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_RemoveAllDesperateMeat";
	}

	public override string GetInteractionType()
	{
		return "remove_all_desperate_meat";
	}

	public override int GetInteractionPriority()
	{
		return 2;
	}

	public override bool IsPlayerSelectable()
	{
		if (obj.isBurningOrBurntOut || !base.InteractionEnabled)
		{
			return false;
		}
		Obj_Freezer obj_Freezer = obj as Obj_Freezer;
		if ((Object)(object)obj_Freezer != (Object)null && !obj_Freezer.IsMeatContaminated() && obj_Freezer.DesperateMeat > 0)
		{
			return true;
		}
		return false;
	}

	public override bool IsAvailable()
	{
		return true;
	}
}
