using UnityEngine;

public class Int_SnareTrap : Int_Base
{
	private Obj_SnareTrap obj_snare;

	public override string GetInstanceTypeName()
	{
		return "InteractionInstance_SnareTrap";
	}

	public override string GetInteractionType()
	{
		return "harvest_snare_trap";
	}

	public override int GetInteractionPriority()
	{
		return 1;
	}

	public override void Awake()
	{
		base.Awake();
		obj_snare = ((Component)this).GetComponent<Obj_SnareTrap>();
	}

	public override bool IsPlayerSelectable()
	{
		if (!base.IsPlayerSelectable())
		{
			return false;
		}
		if (!obj_snare.HasBeenUsed())
		{
			return false;
		}
		return true;
	}

	public override bool IsAvailable()
	{
		return true;
	}
}
