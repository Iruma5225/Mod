using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

public class ExpeditionMainPanelNew : BasePanel
{
	private enum eCurrentPage
	{
		PartySetup,
		LoadoutMember1,
		LoadoutMember2,
		RouteSetup
	}

	private enum VehicleType
	{
		None,
		Horse,
		CamperVan,
		Max
	}

	public GameObject PartySetup;

	public GameObject MapScreen;

	public GameObject LoadoutScreen;

	public ExpeditionPartySetup partySetupScript;

	private UI_ExpeditionMap m_mapUI;

	public string noCharacterImageName = "Blank";

	public string hasmatImageName = "PIPHazmat";

	public UI_PlatformButton mapScreenConfirmButton;

	public LegendContainer m_mapScreenLegend;

	public UILabel waterRequiredLabel;

	public UITablePivot m_mapUITable;

	public UIWidget m_vehicleUI;

	public UILabel vehicleLabel;

	public UIWidget m_petrolUI;

	public UILabel petrolRequiredLabel;

	public UIWidget m_petUI;

	public UILabel petLabel;

	public AudioClip openSound;

	public AudioClip closeSound;

	public AudioClip backSound;

	public AudioClip scrollMemberSound;

	public AudioClip selectMemberSound;

	public AudioClip acceptRouteSound;

	public AudioClip sendPartySound;

	public bool closeOnCancelButton = true;

	public int maxWaypoints = 20;

	private static ExpeditionMainPanelNew m_instance;

	private eCurrentPage m_page;

	private List<FamilyMember> m_eligiblePeople = new List<FamilyMember>();

	public const int kNobody = -1;

	private int m_currentPerson1Index = -1;

	private int m_currentPerson2Index = -1;

	private bool m_isReadyToGo = true;

	private bool m_routeIsDirty = true;

	private float m_routeDistance;

	private float m_waterRequired;

	private TweenColor m_waterColourTween;

	private Obj_CamperVan m_vehicle;

	private Obj_Horse m_horse;

	private CompanionAnimal m_pet;

	private bool useVehicle;

	private bool useHorse;

	private bool takePet;

	private int m_petrolRequired;

	private TweenColor m_petrolColourTween;

	private List<Vector2> m_route = new List<Vector2>();

	private ExpeditionLoadout m_loadoutScript;

	private int m_partyId = -1;

	private PartyMember m_partyMember1;

	private PartyMember m_partyMember2;

	private bool scaleSet;

	private Action m_pageChangeTarget;

	private bool m_pageCoroutineRunning;

	private VehicleType m_vehicleType;

	public static ExpeditionMainPanelNew Instance => m_instance;

	public List<Vector2> route => m_route;

	public IList<FamilyMember> eligiblePeople => m_eligiblePeople.AsReadOnly();

	public int currentPerson1Index => m_currentPerson1Index;

	public int currentPerson2Index => m_currentPerson2Index;

	public int petrolRequired => m_petrolRequired;

	public float waterRequiredForRoute => m_waterRequired;

	private void Awake()
	{
		if ((Object)(object)m_instance != (Object)null)
		{
			throw new Exception("Duplicate ExpeditionMainPanel created");
		}
		m_instance = this;
	}

	private void Start()
	{
		if ((Object)(object)waterRequiredLabel != (Object)null)
		{
			m_waterColourTween = ((Component)waterRequiredLabel).gameObject.GetComponent<TweenColor>();
		}
		if ((Object)(object)petrolRequiredLabel != (Object)null)
		{
			m_petrolColourTween = ((Component)petrolRequiredLabel).gameObject.GetComponent<TweenColor>();
		}
	}

	public override void Update()
	{
		if (Input.GetKeyDown((KeyCode)27) && !MessageBox.isOpen)
		{
			Close();
		}
		if (m_routeIsDirty)
		{
			CalculateRouteDistance();
			m_routeIsDirty = false;
		}
		bool isReadyToGo = m_isReadyToGo;
		m_isReadyToGo = (m_currentPerson1Index != -1 || m_currentPerson2Index != -1) && m_route.Count > 0;
		m_isReadyToGo = m_isReadyToGo && WaterManager.Instance.StoredWater >= m_waterRequired;
		m_isReadyToGo = m_isReadyToGo && InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.Petrol) >= m_petrolRequired;
		int num = ((m_currentPerson1Index != -1) ? 1 : 0) + ((m_currentPerson2Index != -1) ? 1 : 0);
		m_isReadyToGo = m_isReadyToGo && num < m_eligiblePeople.Count;
		if (MapScreen.activeInHierarchy && isReadyToGo != m_isReadyToGo)
		{
			if ((Object)(object)mapScreenConfirmButton != (Object)null)
			{
				mapScreenConfirmButton.SetEnabled(m_isReadyToGo);
			}
			if ((Object)(object)m_mapScreenLegend != (Object)null)
			{
				m_mapScreenLegend.SetButtonEnabled(LegendContainer.ButtonEnum.XButton, m_isReadyToGo);
			}
		}
	}

	public void CycleCharacter1()
	{
		if ((m_currentPerson1Index == m_eligiblePeople.Count - 2 && m_currentPerson2Index == m_eligiblePeople.Count - 1) || m_currentPerson1Index >= m_eligiblePeople.Count - 1)
		{
			m_currentPerson1Index = 0;
		}
		else
		{
			NextPartyMember1();
		}
	}

	public void CycleCharacter2()
	{
		if ((m_currentPerson2Index == m_eligiblePeople.Count - 2 && m_currentPerson1Index == m_eligiblePeople.Count - 1) || m_currentPerson2Index >= m_eligiblePeople.Count - 1)
		{
			m_currentPerson2Index = -1;
		}
		else
		{
			NextPartyMember2();
		}
	}

	public void NextPartyMember1()
	{
		if (m_eligiblePeople.Count >= 1)
		{
			if ((m_currentPerson1Index == m_eligiblePeople.Count - 2 && m_currentPerson2Index == m_eligiblePeople.Count - 1) || m_currentPerson1Index >= m_eligiblePeople.Count - 1)
			{
				m_currentPerson1Index = 0;
			}
			else
			{
				m_currentPerson1Index++;
			}
			if (m_currentPerson1Index == m_currentPerson2Index)
			{
				NextPartyMember1();
				return;
			}
			AudioManager.Instance.PlayUI(scrollMemberSound);
			m_routeIsDirty = true;
		}
	}

	public void NextPartyMember2()
	{
		if (m_eligiblePeople.Count >= 1)
		{
			if ((m_currentPerson2Index == m_eligiblePeople.Count - 2 && m_currentPerson1Index == m_eligiblePeople.Count - 1) || m_currentPerson2Index >= m_eligiblePeople.Count - 1)
			{
				m_currentPerson2Index = -1;
			}
			else
			{
				m_currentPerson2Index++;
			}
			if (m_currentPerson2Index == m_currentPerson1Index)
			{
				NextPartyMember2();
				return;
			}
			AudioManager.Instance.PlayUI(scrollMemberSound);
			m_routeIsDirty = true;
		}
	}

	public void PrevPartyMember1()
	{
		if (m_eligiblePeople.Count >= 1 && m_currentPerson1Index != -1)
		{
			if (m_currentPerson1Index > 0)
			{
				m_currentPerson1Index--;
			}
			else
			{
				m_currentPerson1Index = m_eligiblePeople.Count - 1;
			}
			if (m_currentPerson1Index == m_currentPerson2Index)
			{
				PrevPartyMember1();
				return;
			}
			AudioManager.Instance.PlayUI(scrollMemberSound);
			m_routeIsDirty = true;
		}
	}

	public void PrevPartyMember2()
	{
		if (m_eligiblePeople.Count >= 1)
		{
			if (m_currentPerson2Index > 0)
			{
				m_currentPerson2Index--;
			}
			else if (m_currentPerson2Index != -1)
			{
				m_currentPerson2Index = -1;
			}
			else
			{
				m_currentPerson2Index = m_eligiblePeople.Count - 1;
			}
			if (m_currentPerson2Index == m_currentPerson1Index)
			{
				PrevPartyMember2();
				return;
			}
			AudioManager.Instance.PlayUI(scrollMemberSound);
			m_routeIsDirty = true;
		}
	}

	public IList<Vector2> GetRoute()
	{
		return m_route.AsReadOnly();
	}

	public int SetWaypoint(Vector2 waypoint, int index = -1)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		if (index < 0 || index >= m_route.Count)
		{
			if (m_route.Count >= maxWaypoints)
			{
				return -1;
			}
			index = m_route.Count;
			m_route.Add(waypoint);
		}
		else
		{
			m_route[index] = waypoint;
		}
		m_routeIsDirty = true;
		return index;
	}

	public void ClearWaypoint()
	{
		if (m_route.Count > 0)
		{
			m_route.RemoveAt(m_route.Count - 1);
			m_routeIsDirty = true;
		}
	}

	public void ClearAllWaypoints()
	{
		m_route.Clear();
		m_routeIsDirty = true;
	}

	private bool CheckObjectReferences()
	{
		if ((Object)(object)PartySetup == (Object)null || (Object)(object)LoadoutScreen == (Object)null || (Object)(object)MapScreen == (Object)null)
		{
			return false;
		}
		return true;
	}

	private bool CheckForEmptyShelter()
	{
		List<FamilyMember> list = new List<FamilyMember>();
		if ((Object)(object)FamilyManager.Instance != (Object)null)
		{
			list.AddRange(FamilyManager.Instance.GetAllFamilyMembers());
		}
		if (m_currentPerson1Index != -1)
		{
			list.Remove(m_eligiblePeople[m_currentPerson1Index]);
		}
		if (m_currentPerson2Index != -1)
		{
			list.Remove(m_eligiblePeople[m_currentPerson2Index]);
		}
		int num = 0;
		for (int i = 0; i < list.Count; i++)
		{
			if (!((Object)(object)list[i] == (Object)null) && !list[i].isDead && !list[i].isCatatonic && !list[i].isUncontrollable && !list[i].isAway)
			{
				num++;
			}
		}
		bool flag = num <= 0;
		if (flag)
		{
			MessageBox.Show(MessageBoxButtons.Okay_Button, "UI.ExpeditionPartyEmptyWarning");
		}
		return flag;
	}

	private bool CheckForLoyalty()
	{
		List<FamilyMember> list = new List<FamilyMember>();
		if (m_currentPerson1Index != -1)
		{
			list.Add(m_eligiblePeople[m_currentPerson1Index]);
		}
		if (m_currentPerson2Index != -1)
		{
			list.Add(m_eligiblePeople[m_currentPerson2Index]);
		}
		float disloyalNeedThreshold = ExplorationManager.Instance.disloyalNeedThreshold;
		bool flag = false;
		bool flag2 = false;
		for (int i = 0; i < list.Count; i++)
		{
			if (!list[i].isLoyal)
			{
				if (list[i].loyalty <= FamilyMember.LoyaltyEnum.Cautious)
				{
					flag = true;
				}
				BehaviourStats stats = list[i].stats;
				if (stats.hunger.NormalizedValue >= disloyalNeedThreshold || stats.thirst.NormalizedValue >= disloyalNeedThreshold || stats.fatigue.NormalizedValue >= disloyalNeedThreshold || stats.toilet.NormalizedValue >= disloyalNeedThreshold || stats.dirtiness.NormalizedValue >= disloyalNeedThreshold || stats.stress.NormalizedValue >= disloyalNeedThreshold)
				{
					flag2 = true;
				}
			}
		}
		if (flag)
		{
			MessageBox.Show(MessageBoxButtons.Okay_Button, "UI.ExpeditionPartyDisloyalWarning");
		}
		else if (flag2)
		{
			MessageBox.Show(MessageBoxButtons.Okay_Button, "UI.ExpeditionPartyDisloyalWarning.Stats");
		}
		return flag || flag2;
	}

	private void OnConfirmQuitSetupClosed(int response)
	{
		if (response == 1)
		{
			if (m_partyId != -1)
			{
				ExplorationManager.Instance.DisbandExplorationParty(m_partyId);
				m_partyId = -1;
			}
			UIPanelManager.Instance().PopPanel(this);
		}
	}

	private void CreateNewParty()
	{
		if (m_partyId != -1)
		{
			ExplorationManager.Instance.DisbandExplorationParty(m_partyId);
		}
		if (ExplorationManager.Instance.CreateExplorationParty(out m_partyId))
		{
			m_partyMember1 = ExplorationManager.Instance.AddMemberToParty(m_partyId);
			m_partyMember2 = ExplorationManager.Instance.AddMemberToParty(m_partyId);
		}
	}

	private void UpdatePartyMembers()
	{
		FamilyMember familyMember = null;
		FamilyMember familyMember2 = null;
		if (currentPerson1Index != -1)
		{
			familyMember = m_eligiblePeople[currentPerson1Index];
		}
		if (currentPerson2Index != -1)
		{
			familyMember2 = m_eligiblePeople[currentPerson2Index];
		}
		if ((Object)(object)m_partyMember1.person != (Object)(object)familyMember)
		{
			m_partyMember1.person = familyMember;
			m_partyMember1.ClearAllEquipment();
		}
		if ((Object)(object)m_partyMember2.person != (Object)(object)familyMember2)
		{
			m_partyMember2.person = familyMember2;
			m_partyMember2.ClearAllEquipment();
		}
	}

	private void ConfirmExpeditionSettings()
	{
		MessageBox.Show(MessageBoxButtons.YesNo_Buttons, "UI.Expedition.ConfirmNewExpedition", OnConfirmExpeditionClosed, sendPartySound);
		bool flag = false;
		if ((Object)(object)m_partyMember1 != (Object)null)
		{
			List<ItemStack> equippedItems = m_partyMember1.GetEquippedItems();
			if (equippedItems.FindIndex((ItemStack x) => x.m_type == ItemManager.ItemType.GasMask && x.m_count > 0) < 0)
			{
				flag = true;
			}
		}
		if ((Object)(object)m_partyMember1 != (Object)null)
		{
			List<ItemStack> equippedItems2 = m_partyMember1.GetEquippedItems();
			if (equippedItems2.FindIndex((ItemStack x) => x.m_type == ItemManager.ItemType.GasMask && x.m_count > 0) < 0)
			{
				flag = true;
			}
		}
		if (flag)
		{
			UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.GasMask);
		}
	}

	private void OnConfirmExpeditionClosed(int response)
	{
		if (response == 1 && FinaliseExpedition())
		{
			ExplorationManager.Instance.BeginExploring(m_partyId);
			m_partyId = -1;
			UIPanelManager.Instance().PopPanel(this);
		}
	}

	private bool FinaliseExpedition()
	{
		if (((Object)(object)m_partyMember1.person == (Object)null && (Object)(object)m_partyMember2.person == (Object)null) || m_route.Count == 0)
		{
			return false;
		}
		if ((Object)(object)m_partyMember1.person != (Object)null)
		{
			m_partyMember1.person.job_queue.ForceClear();
			m_partyMember1.person.ai_queue.ForceClear();
			List<ItemStack> equippedItems = m_partyMember1.GetEquippedItems();
			foreach (ItemStack item in equippedItems)
			{
				InventoryManager.Instance.RemoveItemsOfType(item.m_type, item.m_count);
			}
		}
		else
		{
			ExplorationManager.Instance.RemoveMemberFromParty(m_partyId, m_partyMember1);
		}
		if ((Object)(object)m_partyMember2.person != (Object)null)
		{
			m_partyMember2.person.job_queue.ForceClear();
			m_partyMember2.person.ai_queue.ForceClear();
			List<ItemStack> equippedItems2 = m_partyMember2.GetEquippedItems();
			foreach (ItemStack item2 in equippedItems2)
			{
				InventoryManager.Instance.RemoveItemsOfType(item2.m_type, item2.m_count);
			}
		}
		else
		{
			ExplorationManager.Instance.RemoveMemberFromParty(m_partyId, m_partyMember2);
		}
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		int num4 = 0;
		ReadOnlyCollection<ItemGrid.ItemSlot> items = m_loadoutScript.carriedItems.GetItems();
		foreach (ItemGrid.ItemSlot item3 in items)
		{
			InventoryManager.Instance.RemoveItemsOfType(item3.m_type, item3.m_count);
			ExplorationManager.Instance.AddToPartyItems(m_partyId, item3.m_type, item3.m_count);
			if (item3.m_type == ItemManager.ItemType.Water)
			{
				num += item3.m_count;
			}
			else if (item3.m_type == ItemManager.ItemType.Ration)
			{
				num2 += item3.m_count;
			}
			else if (item3.m_type == ItemManager.ItemType.Meat)
			{
				num3 += item3.m_count;
			}
			else if (item3.m_type == ItemManager.ItemType.DesperateMeat)
			{
				num4 += item3.m_count;
			}
		}
		ExplorationManager.Instance.SetRoute(m_partyId, m_route);
		if (WaterManager.Instance.UseWater(m_waterRequired))
		{
			ExplorationManager.Instance.SetWater(m_partyId, m_waterRequired, WaterManager.Instance.Contamination);
		}
		if (InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.Petrol) >= m_petrolRequired)
		{
			InventoryManager.Instance.RemoveItemsOfType(ItemManager.ItemType.Petrol, m_petrolRequired);
			ExplorationManager.Instance.SetPetrol(m_partyId, m_petrolRequired);
		}
		if ((Object)(object)WaterManager.Instance != (Object)null && num > 0)
		{
			WaterManager.Instance.UseWater(num);
		}
		if ((Object)(object)FoodManager.Instance != (Object)null)
		{
			if (num2 > 0)
			{
				FoodManager.Instance.TakeRations(num2);
			}
			if (num3 > 0)
			{
				FoodManager.Instance.TakeMeat(num3);
			}
			if (num4 > 0)
			{
				FoodManager.Instance.TakeDesperateMeat(num4);
			}
		}
		if ((Object)(object)TutorialManager.Instance != (Object)null)
		{
			TutorialManager.Instance.SetPopupSeen(TutorialManager.PopupType.ExpeditionReminder);
		}
		return true;
	}

	private void CalculateRouteDistance()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_034c: Unknown result type (might be due to invalid IL or missing references)
		m_routeDistance = 0f;
		for (int i = 1; i < m_route.Count; i++)
		{
			m_routeDistance += Vector2.Distance(m_route[i - 1], m_route[i]);
		}
		if (m_route.Count > 0)
		{
			float routeDistance = m_routeDistance;
			Vector2 val = m_route[0];
			m_routeDistance = routeDistance + ((Vector2)(ref val)).magnitude;
			float routeDistance2 = m_routeDistance;
			Vector2 val2 = m_route[m_route.Count - 1];
			m_routeDistance = routeDistance2 + ((Vector2)(ref val2)).magnitude;
		}
		m_waterRequired = m_routeDistance / ExplorationManager.Instance.worldUnitsPerMile * ExplorationManager.Instance.waterPerPersonPerMile;
		int num = ((m_currentPerson1Index != -1) ? 1 : 0) + ((m_currentPerson2Index != -1) ? 1 : 0);
		m_waterRequired *= num;
		if (useVehicle)
		{
			vehicleLabel.text = Localization.Get("UI.CamperVan");
			m_petrolRequired = Mathf.FloorToInt(m_routeDistance / ExplorationManager.Instance.worldUnitsPerMile * m_vehicle.PetrolPerPersonPerMile);
			m_waterRequired *= ExplorationManager.Instance.RVWaterModifier;
		}
		else if (useHorse)
		{
			vehicleLabel.text = Localization.Get("UI.Horse");
			m_petrolRequired = 0;
			m_waterRequired *= ExplorationManager.Instance.HorseWaterModifier;
		}
		else
		{
			vehicleLabel.text = Localization.Get("Text.UI.None");
			m_petrolRequired = 0;
		}
		waterRequiredLabel.text = Mathf.Ceil(m_waterRequired).ToString("N0") + "/" + WaterManager.Instance.StoredWater.ToString("N0");
		petrolRequiredLabel.text = Mathf.Ceil((float)m_petrolRequired).ToString("N0") + "/" + InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.Petrol).ToString("N0");
		((Component)m_petrolUI).gameObject.SetActive(useVehicle);
		petLabel.text = Localization.Get((!takePet) ? "Text.UI.No" : "Text.UI.Yes");
		if ((Object)(object)m_waterColourTween != (Object)null)
		{
			if (m_waterRequired >= WaterManager.Instance.StoredWater)
			{
				((Behaviour)m_waterColourTween).enabled = true;
			}
			else
			{
				((Behaviour)m_waterColourTween).enabled = false;
				waterRequiredLabel.color = m_waterColourTween.from;
			}
		}
		if ((Object)(object)m_petrolColourTween != (Object)null)
		{
			if (m_petrolRequired > InventoryManager.Instance.GetNumItemsOfType(ItemManager.ItemType.Petrol))
			{
				((Behaviour)m_petrolColourTween).enabled = true;
				return;
			}
			((Behaviour)m_petrolColourTween).enabled = false;
			petrolRequiredLabel.color = m_petrolColourTween.from;
		}
	}

	public void ShowPartySetup()
	{
		if (!PartySetup.activeInHierarchy)
		{
			m_page = eCurrentPage.PartySetup;
			PartySetup.SetActive(true);
			MapScreen.SetActive(false);
			LoadoutScreen.SetActive(false);
		}
		UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.ChooseParty);
	}

	public void ShowMapMenu()
	{
		DelayedPageChange(delegate
		{
			if (!MapScreen.activeInHierarchy)
			{
				m_page = eCurrentPage.RouteSetup;
				MapScreen.SetActive(true);
				PartySetup.SetActive(false);
				LoadoutScreen.SetActive(false);
				if ((Object)(object)mapScreenConfirmButton != (Object)null)
				{
					mapScreenConfirmButton.SetEnabled(m_isReadyToGo);
				}
				if ((Object)(object)m_mapScreenLegend != (Object)null)
				{
					m_mapScreenLegend.SetButtonEnabled(LegendContainer.ButtonEnum.XButton, m_isReadyToGo);
				}
			}
		});
		UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.PlotWaypoints);
	}

	public void ShowMember1Loadout()
	{
		DelayedPageChange(delegate
		{
			if (!LoadoutScreen.activeInHierarchy)
			{
				LoadoutScreen.SetActive(true);
				PartySetup.SetActive(false);
				MapScreen.SetActive(false);
			}
			m_loadoutScript.InitializeLoadout(m_partyMember1, m_page == eCurrentPage.RouteSetup);
			m_page = eCurrentPage.LoadoutMember1;
			string confirmText = Localization.Get("UI.SendParty");
			if (m_currentPerson2Index != -1)
			{
				confirmText = Localization.Get("UI.NextPerson");
			}
			m_loadoutScript.SetConfirmText(confirmText);
		});
		UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.ChooseEquipment);
	}

	public void ShowMember2Loadout()
	{
		if (!LoadoutScreen.activeInHierarchy)
		{
			LoadoutScreen.SetActive(true);
			PartySetup.SetActive(false);
			MapScreen.SetActive(false);
		}
		m_page = eCurrentPage.LoadoutMember2;
		m_loadoutScript.InitializeLoadout(m_partyMember2, resetItems: false);
		m_loadoutScript.SetConfirmText(Localization.Get("UI.SendParty"));
	}

	private void DelayedPageChange(Action page)
	{
		if (page != null)
		{
			m_pageChangeTarget = page;
			if (!m_pageCoroutineRunning)
			{
				((MonoBehaviour)this).StartCoroutine(DelayedPageChange());
			}
		}
	}

	private IEnumerator DelayedPageChange()
	{
		if (!m_pageCoroutineRunning)
		{
			m_pageCoroutineRunning = true;
			yield return (object)new WaitForEndOfFrame();
			if (m_pageChangeTarget != null)
			{
				m_pageChangeTarget();
			}
			m_pageCoroutineRunning = false;
			m_pageChangeTarget = null;
		}
	}

	public override void OnShow()
	{
		//IL_0391: Unknown result type (might be due to invalid IL or missing references)
		//IL_0396: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c9: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)openSound != (Object)null)
		{
			UISound.instance.Play(openSound);
		}
		base.OnShow();
		if (!CheckObjectReferences())
		{
			return;
		}
		if ((Object)(object)m_loadoutScript == (Object)null)
		{
			m_loadoutScript = LoadoutScreen.GetComponent<ExpeditionLoadout>();
		}
		if ((Object)(object)m_loadoutScript == (Object)null)
		{
			throw new Exception("Couldn't find the loadout script on the ExpeditionMainPanel object");
		}
		m_mapUI = MapScreen.GetComponent<UI_ExpeditionMap>();
		if ((Object)(object)m_mapUI != (Object)null)
		{
			m_mapUI.setWaypointFunction = SetWaypoint;
			m_mapUI.clearWaypointFunction = ClearWaypoint;
			m_mapUI.clearAllWaypointsFunction = ClearAllWaypoints;
			m_mapUI.getRouteFunction = GetRoute;
		}
		List<Obj_Base> objectsOfType = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.CamperVan);
		if (objectsOfType != null && objectsOfType.Count > 0)
		{
			m_vehicle = objectsOfType[0] as Obj_CamperVan;
		}
		List<Obj_Base> objectsOfType2 = ObjectManager.Instance.GetObjectsOfType(ObjectManager.ObjectType.Horse);
		if (objectsOfType2 != null && objectsOfType2.Count > 0)
		{
			m_horse = objectsOfType2[0] as Obj_Horse;
		}
		m_pet = FamilyManager.Instance.GetPet();
		CreateNewParty();
		if (m_partyId == -1)
		{
			return;
		}
		ShowPartySetup();
		ClearAllWaypoints();
		int numFamilyMembers = InteractionManager.Instance.GetNumFamilyMembers();
		m_eligiblePeople.Clear();
		for (int i = 0; i < numFamilyMembers; i++)
		{
			FamilyMember familyMemberByIndex = InteractionManager.Instance.GetFamilyMemberByIndex(i);
			if ((Object)(object)familyMemberByIndex != (Object)null && !familyMemberByIndex.isAway && !familyMemberByIndex.isUncontrollable && !familyMemberByIndex.isCatatonic && !familyMemberByIndex.isDead)
			{
				m_eligiblePeople.Add(familyMemberByIndex);
			}
		}
		partySetupScript.SelectFirstMember();
		if (m_eligiblePeople.Count > 0)
		{
			m_currentPerson1Index = 0;
		}
		else
		{
			m_currentPerson1Index = -1;
		}
		if (m_eligiblePeople.Count > 1)
		{
			m_currentPerson2Index = -1;
		}
		else
		{
			m_currentPerson2Index = -1;
		}
		useVehicle = false;
		useHorse = false;
		if (((Object)(object)m_vehicle != (Object)null && m_vehicle.IsDrivable() && m_vehicle.isAvailableForExpedition) || ((Object)(object)m_horse != (Object)null && m_horse.IsDrivable() && m_horse.isAvailableForExpedition))
		{
			((Component)m_vehicleUI).gameObject.SetActive(true);
		}
		else
		{
			((Component)m_vehicleUI).gameObject.SetActive(false);
		}
		takePet = false;
		if ((Object)(object)m_pet != (Object)null && m_pet.isAvailableForExpedition)
		{
			((Component)m_petUI).gameObject.SetActive(true);
		}
		else
		{
			((Component)m_petUI).gameObject.SetActive(false);
		}
		if ((Object)(object)m_mapUITable != (Object)null)
		{
			m_mapUITable.Reposition();
		}
		m_vehicleType = VehicleType.None;
		if (Camera.main.aspect > 1.35f && !scaleSet)
		{
			((Component)this).gameObject.transform.localScale = new Vector3(((Component)this).gameObject.transform.localScale.x + 0.2f, ((Component)this).gameObject.transform.localScale.x + 0.2f, 0f);
			scaleSet = true;
		}
	}

	public override void OnClose()
	{
		base.OnClose();
		if ((Object)(object)m_loadoutScript != (Object)null && m_loadoutScript.IsContextMenuOpen())
		{
			m_loadoutScript.CancelInteractionMenu();
		}
	}

	public override void OnSelect()
	{
		switch (m_page)
		{
		case eCurrentPage.PartySetup:
			if (!CheckForEmptyShelter() && !CheckForLoyalty())
			{
				UpdatePartyMembers();
				if (!partySetupScript.ConfirmPerson())
				{
					ShowMapMenu();
				}
				AudioManager.Instance.PlayUI(selectMemberSound);
			}
			break;
		case eCurrentPage.LoadoutMember1:
		case eCurrentPage.LoadoutMember2:
			if ((Object)(object)m_loadoutScript != (Object)null)
			{
				m_loadoutScript.OnSelect();
			}
			break;
		}
	}

	public override void OnCancel()
	{
		switch (m_page)
		{
		case eCurrentPage.PartySetup:
			if (!partySetupScript.CancelPerson())
			{
				Close();
			}
			else
			{
				AudioManager.Instance.PlayUI(backSound);
			}
			break;
		case eCurrentPage.RouteSetup:
			ShowPartySetup();
			AudioManager.Instance.PlayUI(backSound);
			break;
		case eCurrentPage.LoadoutMember1:
			m_partyMember1.ClearAllEquipment();
			m_partyMember2.ClearAllEquipment();
			ShowMapMenu();
			AudioManager.Instance.PlayUI(backSound);
			break;
		case eCurrentPage.LoadoutMember2:
			ShowMember1Loadout();
			AudioManager.Instance.PlayUI(backSound);
			break;
		}
	}

	public override void Close()
	{
		MessageBox.Show(MessageBoxButtons.YesNo_Buttons, "UI.ConfirmExitPartySetup", OnConfirmQuitSetupClosed, closeSound);
	}

	public override void OnExtra1()
	{
		switch (m_page)
		{
		case eCurrentPage.LoadoutMember1:
			if (m_currentPerson2Index != -1)
			{
				ShowMember2Loadout();
				AudioManager.Instance.PlayUI(selectMemberSound);
			}
			else
			{
				ConfirmExpeditionSettings();
			}
			break;
		case eCurrentPage.LoadoutMember2:
			ConfirmExpeditionSettings();
			break;
		case eCurrentPage.RouteSetup:
			if (m_isReadyToGo)
			{
				ShowMember1Loadout();
				AudioManager.Instance.PlayUI(acceptRouteSound);
			}
			else if (m_waterRequired >= WaterManager.Instance.StoredWater)
			{
				MessageBox.Show(MessageBoxButtons.Okay_Button, "Text.UI.NotEnoughWater");
			}
			break;
		}
	}

	public override void OnExtra2()
	{
		switch (m_page)
		{
		case eCurrentPage.RouteSetup:
			m_mapUI.OnDeleteWaypoint();
			break;
		case eCurrentPage.LoadoutMember1:
		case eCurrentPage.LoadoutMember2:
			if ((Object)(object)m_loadoutScript != (Object)null)
			{
				m_loadoutScript.OnExtra2();
			}
			break;
		}
	}

	public override void OnExtra3()
	{
		eCurrentPage page = m_page;
		if (page == eCurrentPage.RouteSetup)
		{
			VehicleType vehicleType = ((m_vehicleType != VehicleType.Max) ? (m_vehicleType + 1) : VehicleType.None);
			while (vehicleType != m_vehicleType && vehicleType != VehicleType.None && (vehicleType != VehicleType.Horse || !((Object)(object)m_horse != (Object)null) || !m_horse.IsDrivable() || !m_horse.isAvailableForExpedition) && (vehicleType != VehicleType.CamperVan || !((Object)(object)m_vehicle != (Object)null) || !m_vehicle.IsDrivable() || !m_vehicle.isAvailableForExpedition))
			{
				vehicleType = ((vehicleType != VehicleType.Max) ? (vehicleType + 1) : VehicleType.None);
			}
			m_vehicleType = vehicleType;
			if (m_vehicleType == VehicleType.None)
			{
				useVehicle = false;
				useHorse = false;
				ExplorationManager.Instance.SetVehicle(m_partyId, null);
				ExplorationManager.Instance.SetHorse(m_partyId, null);
			}
			if (m_vehicleType == VehicleType.Horse)
			{
				useVehicle = false;
				useHorse = true;
				ExplorationManager.Instance.SetVehicle(m_partyId, null);
				ExplorationManager.Instance.SetHorse(m_partyId, m_horse);
			}
			if (m_vehicleType == VehicleType.CamperVan)
			{
				useVehicle = true;
				useHorse = false;
				ExplorationManager.Instance.SetVehicle(m_partyId, m_vehicle);
				ExplorationManager.Instance.SetHorse(m_partyId, null);
			}
			m_routeIsDirty = true;
		}
	}

	public override void OnExtra4()
	{
		eCurrentPage page = m_page;
		if (page == eCurrentPage.RouteSetup)
		{
			if (!takePet && (Object)(object)m_pet != (Object)null && m_pet.isAvailableForExpedition)
			{
				takePet = true;
				ExplorationManager.Instance.SetPet(m_partyId, m_pet);
			}
			else
			{
				takePet = false;
				ExplorationManager.Instance.SetPet(m_partyId, null);
			}
			m_routeIsDirty = true;
		}
	}

	public override void OnTabRight()
	{
		if (m_page == eCurrentPage.PartySetup)
		{
			partySetupScript.NextMember();
		}
	}

	public override void OnTabLeft()
	{
		if (m_page == eCurrentPage.PartySetup)
		{
			partySetupScript.PreviousMember();
		}
	}

	public override bool AlwaysShow()
	{
		return false;
	}

	public override bool DestroyOnClose()
	{
		return false;
	}

	public override bool PausesGameTime()
	{
		return true;
	}

	public override bool PausesGameInput()
	{
		return true;
	}
}
