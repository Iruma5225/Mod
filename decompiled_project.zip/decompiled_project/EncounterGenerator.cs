using System;
using System.Collections.Generic;
using UnityEngine;

public class EncounterGenerator : BaseManagerNoUpdate, ISaveable
{
	[Serializable]
	public class CharacterTemplate
	{
		public string type = string.Empty;

		public EncounterCharacter.SpeciesEnum species;

		public EncounterCharacter.PersonalityType personality;

		public RandomStatGenerator stats = new RandomStatGenerator();

		public List<ItemBias> allowedWeapons_Inspector = new List<ItemBias>();

		[HideInInspector]
		public List<ItemManager.ItemType> allowedWeapons = new List<ItemManager.ItemType>();

		[Range(0f, 2f)]
		public int equipmentCount;

		public List<ItemBias> allowedEquipment_Inspector = new List<ItemBias>();

		[HideInInspector]
		public List<ItemManager.ItemType> allowedEquipment = new List<ItemManager.ItemType>();

		public List<ItemStack> guaranteedItems = new List<ItemStack>();

		[Range(0f, 100f)]
		public int commonItemsMin = 1;

		[Range(0f, 100f)]
		public int commonItemsMax = 10;
	}

	[Serializable]
	public class Encounter
	{
		public string name = string.Empty;

		public int startDate;

		public int endDate;

		public bool animal;

		[Range(0f, 10f)]
		public float bias = 1f;

		public EncounterTypeBias encounterTypeChances = new EncounterTypeBias();

		public string leader = string.Empty;

		public string character2 = string.Empty;

		public string character3 = string.Empty;

		public string character4 = string.Empty;
	}

	[SerializeField]
	[Header("Difficulty")]
	private int m_day = 1;

	[Header("Character Templates")]
	[SerializeField]
	private List<CharacterTemplate> characterTypes_Inspector = new List<CharacterTemplate>();

	private Dictionary<string, CharacterTemplate> characterTypes = new Dictionary<string, CharacterTemplate>();

	[Header("Encounter Templates")]
	[SerializeField]
	private List<Encounter> encounters_Inspector = new List<Encounter>();

	private List<Encounter> encounters_active = new List<Encounter>();

	private List<Encounter> encounters_active_animal = new List<Encounter>();

	private Encounter lastChosenEncounter;

	private static EncounterGenerator m_theInstance;

	public int currentDay => m_day;

	public int encounterCount => encounters_active.Count;

	public int encounterCountAnimal => encounters_active_animal.Count;

	public static EncounterGenerator Instance => m_theInstance;

	public void SetDay(int new_day)
	{
		m_day = new_day - 1;
		OnNewDay();
	}

	private void Awake()
	{
		if ((Object)(object)m_theInstance == (Object)null)
		{
			m_theInstance = this;
		}
		else
		{
			Debug.Log((object)"Duplicate EncounterGenerator created!");
		}
	}

	public override void StartManager()
	{
		LoadCharacterTemplatesFromInspector();
		for (int i = 0; i < characterTypes_Inspector.Count; i++)
		{
			SetupItemBias(characterTypes_Inspector[i].allowedWeapons_Inspector, characterTypes_Inspector[i].allowedWeapons);
			SetupItemBias(characterTypes_Inspector[i].allowedEquipment_Inspector, characterTypes_Inspector[i].allowedEquipment);
		}
		for (int j = 0; j < encounters_Inspector.Count; j++)
		{
			encounters_Inspector[j].leader = ConvertString(encounters_Inspector[j].leader);
			encounters_Inspector[j].character2 = ConvertString(encounters_Inspector[j].character2);
			encounters_Inspector[j].character3 = ConvertString(encounters_Inspector[j].character3);
			encounters_Inspector[j].character4 = ConvertString(encounters_Inspector[j].character4);
			if ((Object)(object)DifficultyManager.instance != (Object)null)
			{
				encounters_Inspector[j].encounterTypeChances.IntimidateChance = Mathf.CeilToInt((float)encounters_Inspector[j].encounterTypeChances.IntimidateChance * DifficultyManager.instance.GetIntimidateChanceModifier());
				encounters_Inspector[j].encounterTypeChances.IntimidateChance = Mathf.Min(encounters_Inspector[j].encounterTypeChances.IntimidateChance, 10);
				encounters_Inspector[j].encounterTypeChances.RecruitChance = Mathf.CeilToInt((float)encounters_Inspector[j].encounterTypeChances.RecruitChance * DifficultyManager.instance.GetTradeRecruitChanceModifier());
				encounters_Inspector[j].encounterTypeChances.RecruitChance = Mathf.Min(encounters_Inspector[j].encounterTypeChances.RecruitChance, 10);
				encounters_Inspector[j].encounterTypeChances.TradeChance = Mathf.CeilToInt((float)encounters_Inspector[j].encounterTypeChances.TradeChance * DifficultyManager.instance.GetTradeRecruitChanceModifier());
				encounters_Inspector[j].encounterTypeChances.TradeChance = Mathf.Min(encounters_Inspector[j].encounterTypeChances.TradeChance, 10);
			}
			if (!ValidateEncounter(encounters_Inspector[j]))
			{
				encounters_Inspector.RemoveAt(j);
			}
		}
		UpdateActiveEncounters();
		GameTime.newDay += OnNewDay;
	}

	private void OnDestroy()
	{
		GameTime.newDay -= OnNewDay;
	}

	private string ConvertString(string txt)
	{
		return txt.Trim().ToLower();
	}

	private void LoadCharacterTemplatesFromInspector()
	{
		if (characterTypes_Inspector.Count <= 0)
		{
			return;
		}
		for (int i = 0; i < characterTypes_Inspector.Count; i++)
		{
			characterTypes_Inspector[i].type = ConvertString(characterTypes_Inspector[i].type);
			if (!string.IsNullOrEmpty(characterTypes_Inspector[i].type) && !characterTypes.ContainsKey(characterTypes_Inspector[i].type))
			{
				characterTypes.Add(characterTypes_Inspector[i].type, characterTypes_Inspector[i]);
			}
		}
	}

	private void SetupItemBias(List<ItemBias> preBias, List<ItemManager.ItemType> postBias)
	{
		postBias.Clear();
		for (int i = 0; i < preBias.Count; i++)
		{
			for (int j = 0; j < preBias[i].bias; j++)
			{
				postBias.Add(preBias[i].itemType);
			}
		}
	}

	private bool ValidateEncounter(Encounter encounter)
	{
		if (encounter == null)
		{
			return false;
		}
		if (encounter.bias <= 0f)
		{
		}
		if (encounter.startDate < 0)
		{
		}
		if (encounter.endDate < 0)
		{
		}
		if (!encounter.animal && encounter.encounterTypeChances.IntimidateChance <= 0 && encounter.encounterTypeChances.RecruitChance <= 0 && encounter.encounterTypeChances.TradeChance <= 0)
		{
			return false;
		}
		if (string.IsNullOrEmpty(encounter.leader) || !characterTypes.ContainsKey(encounter.leader))
		{
			return false;
		}
		if (!string.IsNullOrEmpty(encounter.character2) && !characterTypes.ContainsKey(encounter.character2))
		{
			return false;
		}
		if (!string.IsNullOrEmpty(encounter.character3) && !characterTypes.ContainsKey(encounter.character3))
		{
			return false;
		}
		if (!string.IsNullOrEmpty(encounter.character4) && !characterTypes.ContainsKey(encounter.character4))
		{
			return false;
		}
		return true;
	}

	public void UpdateActiveEncounters()
	{
		encounters_active.Clear();
		for (int i = 0; i < encounters_Inspector.Count; i++)
		{
			if (encounters_Inspector[i].startDate > m_day || (encounters_Inspector[i].endDate <= m_day && encounters_Inspector[i].endDate != 0))
			{
				continue;
			}
			for (int j = 0; (float)j < encounters_Inspector[i].bias; j++)
			{
				if (encounters_Inspector[i].animal)
				{
					encounters_active_animal.Add(encounters_Inspector[i]);
				}
				else
				{
					encounters_active.Add(encounters_Inspector[i]);
				}
			}
		}
	}

	public void OnNewDay()
	{
		m_day++;
		UpdateActiveEncounters();
	}

	public EncounterManager.EncounterType GetRandomEncounterType(EncounterCharacter character)
	{
		if (lastChosenEncounter == null)
		{
			return EncounterManager.EncounterType.Invalid;
		}
		return lastChosenEncounter.encounterTypeChances.GetRandomEncounterType();
	}

	public List<EncounterCharacter> GenerateNPCs(List<EncounterCharacter> potential_characters, bool animal = false)
	{
		if ((!animal && (encounters_active == null || encounters_active.Count <= 0)) || (animal && (encounters_active_animal == null || encounters_active_animal.Count <= 0)))
		{
			return null;
		}
		if (potential_characters == null || potential_characters.Count <= 0)
		{
			return null;
		}
		Encounter encounter = null;
		encounter = ((!animal) ? encounters_active[Random.Range(0, encounters_active.Count)] : encounters_active_animal[Random.Range(0, encounters_active_animal.Count)]);
		if (encounter == null)
		{
			return null;
		}
		lastChosenEncounter = encounter;
		List<EncounterCharacter> list = new List<EncounterCharacter>();
		if (potential_characters.Count >= 1 && !string.IsNullOrEmpty(encounter.leader) && SetupCharacter(potential_characters[0], characterTypes[encounter.leader]))
		{
			list.Add(potential_characters[0]);
		}
		if (potential_characters.Count >= 2 && !string.IsNullOrEmpty(encounter.character2) && SetupCharacter(potential_characters[1], characterTypes[encounter.character2]))
		{
			list.Add(potential_characters[1]);
		}
		if (potential_characters.Count >= 3 && !string.IsNullOrEmpty(encounter.character3) && SetupCharacter(potential_characters[2], characterTypes[encounter.character3]))
		{
			list.Add(potential_characters[2]);
		}
		if (potential_characters.Count >= 4 && !string.IsNullOrEmpty(encounter.character4) && SetupCharacter(potential_characters[3], characterTypes[encounter.character4]))
		{
			list.Add(potential_characters[3]);
		}
		return list;
	}

	public List<EncounterCharacter> GenerateFactionNPCs(List<EncounterCharacter> potential_characters, int factionId)
	{
		if (potential_characters == null || potential_characters.Count <= 0)
		{
			return null;
		}
		if ((Object)(object)FactionMan.instance == (Object)null)
		{
			return null;
		}
		lastChosenEncounter = new Encounter();
		lastChosenEncounter.encounterTypeChances.IntimidateChance = 10;
		lastChosenEncounter.encounterTypeChances.TradeChance = 2;
		lastChosenEncounter.encounterTypeChances.RecruitChance = 0;
		List<EncounterCharacter> list = new List<EncounterCharacter>();
		int numFactionNpcsToSpawn = FactionMan.instance.GetNumFactionNpcsToSpawn(factionId);
		int num = 0;
		for (int i = 0; i < potential_characters.Count; i++)
		{
			if (num >= numFactionNpcsToSpawn)
			{
				continue;
			}
			FactionMan.FactionCharacterInfo info = null;
			if (FactionMan.instance.GetFactionCharacterInfo(factionId, out info))
			{
				EncounterCharacter encounterCharacter = potential_characters[num++];
				string firstName = NameGenerator.GetFirstName((!(info.m_preset.m_meshId == "man")) ? NameGenerator.Gender.Female : NameGenerator.Gender.Male);
				string surname = NameGenerator.GetSurname();
				encounterCharacter.SetName(firstName, surname);
				encounterCharacter.SetSpecies(EncounterCharacter.SpeciesEnum.Human);
				encounterCharacter.SetPersonality(EncounterCharacter.PersonalityType.Aggressive);
				encounterCharacter.SetAppearance(info.m_preset);
				encounterCharacter.SetStats(info.m_strength, 20, info.m_dexterity, 20, info.m_intelligence, 20, info.m_perception, 20, info.m_charisma, 20);
				encounterCharacter.SetWeapon(info.m_weapon);
				encounterCharacter.EmptyBackpack();
				for (int j = 0; j < info.m_items.Count; j++)
				{
					encounterCharacter.AddToBackpack(info.m_items[j], 1);
				}
				list.Add(encounterCharacter);
			}
		}
		return list;
	}

	private bool SetupCharacter(EncounterCharacter character, CharacterTemplate template)
	{
		if ((Object)(object)character == (Object)null)
		{
			return false;
		}
		character.SetSpecies(template.species);
		character.SetPersonality(template.personality);
		bool flag = Random.Range(0, 2) == 0;
		SetRandomAppearance(character, template.species, flag);
		SetRandomName(character, template.species, flag);
		character.SetStats(template.stats.GetRandomStrength(), 20, template.stats.GetRandomDexterity(), 20, template.stats.GetRandomIntelligence(), 20, template.stats.GetRandomCharisma(), 20, template.stats.GetRandomPerception(), 20);
		ItemManager.ItemType itemType = ItemManager.ItemType.Undefined;
		if (template.allowedWeapons.Count > 0)
		{
			itemType = template.allowedWeapons[Random.Range(0, template.allowedWeapons.Count)];
			character.SetWeapon(itemType);
		}
		if (template.allowedEquipment.Count > 0)
		{
			if (template.equipmentCount >= 1)
			{
				character.SetEquippedItem(0, template.allowedEquipment[Random.Range(0, template.allowedEquipment.Count)]);
			}
			if (template.equipmentCount >= 2)
			{
				character.SetEquippedItem(1, template.allowedEquipment[Random.Range(0, template.allowedEquipment.Count)]);
			}
		}
		character.EmptyBackpack();
		if ((Object)(object)ItemManager.Instance != (Object)null && (itemType == ItemManager.ItemType.Weapon_Pistol || itemType == ItemManager.ItemType.Weapon_Shotgun || itemType == ItemManager.ItemType.Weapon_Rifle))
		{
			ItemDefinition_Combat combatDefinition = ItemManager.Instance.GetCombatDefinition(itemType);
			if ((Object)(object)combatDefinition != (Object)null)
			{
				int quantity = Random.Range(Mathf.CeilToInt((float)combatDefinition.ClipSize / 2f), combatDefinition.ClipSize + 1);
				ItemManager.ItemType itemType2 = ItemManager.ItemType.Undefined;
				switch (itemType)
				{
				case ItemManager.ItemType.Weapon_Pistol:
					itemType2 = ItemManager.ItemType.Ammo_Pistol;
					break;
				case ItemManager.ItemType.Weapon_Shotgun:
					itemType2 = ItemManager.ItemType.Ammo_Shotgun;
					break;
				case ItemManager.ItemType.Weapon_Rifle:
					itemType2 = ItemManager.ItemType.Ammo_Rifle;
					break;
				}
				if (itemType2 != ItemManager.ItemType.Undefined)
				{
					character.AddToBackpack(itemType2, quantity);
				}
			}
		}
		for (int i = 0; i < template.guaranteedItems.Count; i++)
		{
			character.AddToBackpack(template.guaranteedItems[i].m_type, template.guaranteedItems[i].m_count);
		}
		if (template.commonItemsMax > 0)
		{
			int num = Random.Range(template.commonItemsMin, template.commonItemsMax);
			for (int j = 0; j < num; j++)
			{
				character.AddToBackpack(ExpeditionMap.Instance.GetRandomCommonItemType(), 1);
			}
		}
		return true;
	}

	private void SetRandomName(EncounterCharacter character, EncounterCharacter.SpeciesEnum species, bool male)
	{
		if (!((Object)(object)character == (Object)null))
		{
			string firstName = string.Empty;
			string surname = string.Empty;
			switch (species)
			{
			case EncounterCharacter.SpeciesEnum.Human:
			case EncounterCharacter.SpeciesEnum.Mutant:
			{
				NameGenerator.Gender gender = ((!male) ? NameGenerator.Gender.Female : NameGenerator.Gender.Male);
				firstName = NameGenerator.GetFirstName(gender);
				surname = NameGenerator.GetSurname();
				break;
			}
			case EncounterCharacter.SpeciesEnum.Bear:
				firstName = Localization.Get("Species.Bear");
				surname = string.Empty;
				break;
			case EncounterCharacter.SpeciesEnum.Wolf:
				firstName = Localization.Get("Species.Wolf");
				surname = string.Empty;
				break;
			case EncounterCharacter.SpeciesEnum.Dog:
				firstName = Localization.Get("Species.Dog");
				surname = string.Empty;
				break;
			}
			character.SetName(firstName, surname);
		}
	}

	private void SetRandomAppearance(EncounterCharacter character, EncounterCharacter.SpeciesEnum species, bool isMale)
	{
		if (!((Object)(object)character == (Object)null))
		{
			string empty = string.Empty;
			switch (species)
			{
			default:
				return;
			case EncounterCharacter.SpeciesEnum.Human:
			case EncounterCharacter.SpeciesEnum.Mutant:
				empty = ((!isMale) ? "woman" : "man");
				break;
			case EncounterCharacter.SpeciesEnum.Bear:
				empty = "bear";
				break;
			case EncounterCharacter.SpeciesEnum.Wolf:
				empty = "wolf";
				break;
			case EncounterCharacter.SpeciesEnum.Dog:
				empty = "dog";
				break;
			}
			if (!string.IsNullOrEmpty(empty))
			{
				character.SetAppearance(empty);
			}
		}
	}

	public bool IsRelocationEnabled()
	{
		return false;
	}

	public bool IsReadyForLoad()
	{
		if (GameTime.HasBeenLoaded() && (Object)(object)DifficultyManager.instance != (Object)null && SaveManager.instance.HasBeenLoaded(DifficultyManager.instance))
		{
			return true;
		}
		return false;
	}

	public bool SaveLoad(SaveData data)
	{
		data.GroupStart("EncounterGenerator");
		bool flag = data.SaveLoad("day", ref m_day);
		if (data.isLoading && !flag)
		{
			m_day = GameTime.Day;
		}
		data.GroupEnd();
		return true;
	}
}
