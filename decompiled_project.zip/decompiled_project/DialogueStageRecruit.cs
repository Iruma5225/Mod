using System.Collections.Generic;
using UnityEngine;

public class DialogueStageRecruit : BaseDialogueStage
{
	private string m_textId = string.Empty;

	private string m_npcPersonality = string.Empty;

	private bool m_acceptRecruit;

	private EncounterManager.EncounterType m_altEncounter;

	private QuestInstance m_quest;

	public DialogueStageRecruit(QuestInstance quest)
	{
		m_quest = quest;
		m_npcPersonality = EncounterManager.Instance.GetLeadNpc().Personality.ToString();
		if ((Object)(object)FactionMan.instance != (Object)null && (Object)(object)EncounterManager.Instance != (Object)null && EncounterManager.Instance.encounterFactionId > -1)
		{
			string factionDialogueId = FactionMan.instance.GetFactionDialogueId(EncounterManager.Instance.encounterFactionId);
			if (!string.IsNullOrEmpty(factionDialogueId))
			{
				m_npcPersonality = factionDialogueId;
			}
		}
		if (EncounterDialoguePanel.Instance.PlayerControlled || m_quest != null)
		{
			SetState(State_Player_Begin);
		}
		else
		{
			SetState(State_Npc_Begin);
		}
	}

	private DialogueResult State_Player_Begin()
	{
		UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.Recruit);
		int intelligence = EncounterDialoguePanel.Instance.LeadPlayerCharacter.Intelligence;
		int intelligence2 = EncounterManager.Instance.GetLeadNpc().Intelligence;
		EncounterLogic.StatCheckResult statCheckResult = EncounterLogic.StatCheck(intelligence, intelligence2);
		Debug.Log((object)("Recruit check result was " + statCheckResult));
		if (statCheckResult < EncounterLogic.StatCheckResult.FailedSlightly)
		{
			statCheckResult = EncounterLogic.StatCheckResult.FailedSlightly;
		}
		if (m_quest != null)
		{
			EncounterDialoguePanel.Instance.RevealNpcStats();
			SetState(State_Player_WaitNpcPositiveResponseText);
		}
		else if (statCheckResult >= EncounterLogic.StatCheckResult.PoorSuccess)
		{
			EncounterDialoguePanel.Instance.RevealNpcStats();
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Recruit.RecruitSuccess";
			SetState(State_Player_ShowNpcPositiveResponse);
		}
		else if (statCheckResult >= EncounterLogic.StatCheckResult.FailedSlightly)
		{
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Recruit.RecruitCautious";
			SetState(State_Player_ShowNpcPositiveResponse);
		}
		else
		{
			SetState(State_Player_ShowNpcNegativeResponse);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_ShowNpcPositiveResponse()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText(m_textId))
		{
			SetState(State_Player_WaitNpcPositiveResponseText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitNpcPositiveResponseText()
	{
		if (!EncounterDialoguePanel.Instance.IsTextDone())
		{
			return DialogueResult.Continue;
		}
		EncounterDialoguePanel.Instance.PushPlayerOptions(new List<string> { "Text.UI.Recruit", "Text.UI.Reject" });
		SetState(State_Player_WaitChoice);
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitChoice()
	{
		string chosenOption = EncounterDialoguePanel.Instance.GetChosenOption();
		if (string.IsNullOrEmpty(chosenOption))
		{
			return DialogueResult.Continue;
		}
		switch (chosenOption)
		{
		case "Text.UI.Recruit":
			m_textId = "Encounter.Player." + m_npcPersonality + ".Recruit.AcceptRecruit";
			m_acceptRecruit = true;
			break;
		case "Text.UI.Reject":
			m_textId = "Encounter.Player." + m_npcPersonality + ".Recruit.RejectRecruit";
			m_acceptRecruit = false;
			break;
		}
		EncounterDialoguePanel.Instance.RevealNpcStats();
		SetState(State_Player_ShowPlayerChoice);
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_ShowPlayerChoice()
	{
		if (EncounterDialoguePanel.Instance.PushPlayerText(m_textId))
		{
			SetState(State_Player_WaitPlayerChoiceText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitPlayerChoiceText()
	{
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			m_textId = "Encounter.Npc." + m_npcPersonality + ".Recruit." + ((!m_acceptRecruit) ? "PlayerRefused" : "PlayerAccepted");
			SetState(State_Player_ShowNPCRecruitResponse);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_ShowNPCRecruitResponse()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText(m_textId))
		{
			SetState(State_Player_WaitNPCRecruitResponseText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitNPCRecruitResponseText()
	{
		if (!EncounterDialoguePanel.Instance.IsTextDone())
		{
			return DialogueResult.Continue;
		}
		EncounterManager.Instance.OnRecruitOver(m_acceptRecruit);
		return DialogueResult.RecruitOver;
	}

	private DialogueResult State_Player_ShowNpcNegativeResponse()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText("Encounter.Npc." + m_npcPersonality + ".Recruit.RecruitFailed"))
		{
			SetState(State_Player_WaitNpcNegativeResponseText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitNpcNegativeResponseText()
	{
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			switch (EncounterGenerator.Instance.GetRandomEncounterType(EncounterManager.Instance.GetLeadNpc()))
			{
			case EncounterManager.EncounterType.Trade:
				m_altEncounter = EncounterManager.EncounterType.Trade;
				m_textId = "Encounter.Npc." + m_npcPersonality + ".Recruit.TryTrade";
				break;
			case EncounterManager.EncounterType.Intimidate:
				m_altEncounter = EncounterManager.EncounterType.Intimidate;
				m_textId = "Encounter.Npc." + m_npcPersonality + ".Recruit.TryIntimidate";
				break;
			default:
				m_altEncounter = EncounterManager.EncounterType.WalkAway;
				m_textId = "Encounter.Npc." + m_npcPersonality + ".WalkAway";
				break;
			}
			SetState(State_Player_ShowNpcAlternateEncounterText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_ShowNpcAlternateEncounterText()
	{
		if (EncounterDialoguePanel.Instance.PushNpcText(m_textId))
		{
			SetState(State_Player_WaitNpcAlternateEncounterText);
		}
		return DialogueResult.Continue;
	}

	private DialogueResult State_Player_WaitNpcAlternateEncounterText()
	{
		DialogueResult result = DialogueResult.Continue;
		if (EncounterDialoguePanel.Instance.IsTextDone())
		{
			switch (m_altEncounter)
			{
			case EncounterManager.EncounterType.Trade:
				result = DialogueResult.NpcSwitchToTrade;
				break;
			case EncounterManager.EncounterType.Intimidate:
				result = DialogueResult.NpcSwitchToIntimidate;
				break;
			case EncounterManager.EncounterType.WalkAway:
				result = DialogueResult.EndEncounter;
				break;
			}
		}
		return result;
	}

	private DialogueResult State_Npc_Begin()
	{
		UI_TutorialPanels.ShowTutorialPopup(TutorialManager.PopupType.Recruit);
		int intelligence = EncounterManager.Instance.GetLeadNpc().Intelligence;
		int intelligence2 = EncounterDialoguePanel.Instance.LeadPlayerCharacter.Intelligence;
		EncounterLogic.StatCheckResult statCheckResult = EncounterLogic.StatCheck(intelligence, intelligence2);
		Debug.Log((object)("Recruit check result was " + statCheckResult));
		if (statCheckResult < EncounterLogic.StatCheckResult.PoorSuccess)
		{
			EncounterDialoguePanel.Instance.RevealNpcStats();
		}
		EncounterDialoguePanel.Instance.PushPlayerOptions(new List<string> { "Text.UI.Recruit", "Text.UI.Reject" });
		SetState(State_Player_WaitChoice);
		return DialogueResult.Continue;
	}
}
